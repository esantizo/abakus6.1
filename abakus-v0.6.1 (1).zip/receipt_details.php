<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'receipts.php';

	$module_name = 'receipts';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	$receipt_id = (int)$_REQUEST['id'];

	$return = 'search';
	if($_GET['return']) $return = $_GET['return'];

	$currencies = $db->fetch_all("SELECT * FROM currency ORDER BY id",false,'id');

	if($receipt_id){
		$receipt = $db->fetch_item("SELECT * FROM receipts WHERE id=$receipt_id");
		if($receipt){
			$id_client = (int)$receipt['id_client'];
			$checks = $db->fetch_all("SELECT c.* FROM receipt_checks AS rc JOIN checks AS c ON c.id=rc.id_check WHERE rc.id_receipt={$receipt['id']}");
			$invoices = $db->fetch_all("SELECT i.*,ri.amount FROM receipt_invoices AS ri JOIN invoices AS i ON i.id=ri.id_invoice WHERE ri.id_receipt={$receipt['id']}");
			foreach($invoices as $k => $i){
				$invoices[$k]['number'] = sprintf($config['invoice_number_format'],$i['number']);
				$invoices[$k]['date'] = fecha($i['date']);
				$invoices[$k]['symbol'] = $currencies[$i['id_currency']]['symbol'];
			}

			$client = $db->fetch_item("SELECT * FROM clients WHERE id={$receipt['id_client']}");
			$symbol = $currencies[$receipt['receipt_currency']]['symbol'];
			$currency = (int)$currencies[$receipt['receipt_currency']]['id'];
		}
	}

	if($client){
		switch($_GET['return']){
			case 'account': $return_url = "account.php?id_client={$client['id']}"; break;
			case 'invoice': $return_url = "invoice_details.php?id=".(int)$_GET['id_invoice']; break;
			default: $return_url = return_to_module_url($module_name);
		}
	}

	if((int)$_GET['id'] > 0 && $_GET['delete']==1 && $_GET['reallysure']==1){
		$module->deleteElement($_GET['id']);
		redirect($return_url);
	}

	$number = (int)$db->fetch_item_field("SELECT number FROM receipts ORDER BY number DESC LIMIT 1") + 1;
	$banks = $db->fetch_all("SELECT * FROM bank_entities ORDER BY name");

	$smarty->assign('return_url',$return_url);
	$smarty->assign('client',$client);
	$smarty->assign('receipt',$receipt);
	$smarty->assign('currencies',$currencies);
	$smarty->assign('checks',$checks);
	$smarty->assign('symbol',$symbol);
	$smarty->assign('invoices',$invoices);
	$smarty->assign('double_confirm_delete',$user_preferences['double_confirm_delete']);

	$smarty->display('receipt_details.tpl');
?>