<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';
	include 'inc/class.upload_image.php';

	$module_name = 'repairs';
	// We load the module
	$module = loadModule($module_name,$db);
	$thispage = 'repair_shop.php';

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$id_client = (int)$_GET['id_client'];

	$upload_image = new UploadImage($db,'repairs');

	$return = 'search';
	if($_GET['return']) $return = $_GET['return'];

	$redirect_url = return_to_module_url($module_name);

	$categories = $db->fetch_all("SELECT * FROM categories ORDER BY name",'name','id');
	$repairs_statuses = $db->fetch_all("SELECT * FROM repairs_statuses ORDER BY name");

	if((int)$_GET['id']){
		$repair = $db->fetch_item("
			SELECT r.*,rs.*,
				c.id AS client_id,
				c.name AS client,
				p.id AS product_id,
				p.name AS product,
				rt.name AS repair_type
			FROM repairs AS r
			LEFT JOIN repair_shop AS rs
				ON r.id=rs.id_repair
			JOIN clients AS c
				ON c.id=r.id_client
			JOIN product_models AS p
				ON p.id = r.id_product
			JOIN repairs_types AS rt
				ON rt.id = r.id_repair_type
			WHERE r.id=".(int)$_GET['id']
		);
		if($repair) $image = $db->fetch_item("SELECT * FROM images WHERE id={$repair['id_image']}");

		if($_POST['save']){
			$id_repair = $repair['id'];
			$repair_cost = float($_POST['repair_cost']);
			$repair_price = float($_POST['repair_price']);
			$id_status = (int)$_POST['id_status'];
			$notice_date = date_formatted2sql($_POST['notice_date']);
			$delivery_date = date_formatted2sql($_POST['delivery_date']);
			$delivery_charge = float($_POST['delivery_charge']);
			$notes = $db->escape_string($_POST['repair_shop_notes']);

			$fields = "
				id_repair='$id_repair',
				repair_cost='$repair_cost',
				repair_price='$repair_price',
				id_status='$id_status',
				notice_date='$notice_date',
				delivery_date='$delivery_date',
				delivery_charge='$delivery_charge',
				notes='$notes'
			";
			$db->insert("INSERT INTO repair_shop SET $fields ON DUPLICATE KEY UPDATE $fields");

			if(is_array($_POST['annotations_uid'])){
				$db->delete("DELETE FROM repairs_annotations WHERE id_repair={$repair['id']}");
				foreach($_POST['annotations_uid'] as $key => $uid){
					$uid = (int)$uid;
					$date = date_formatted2sql($_POST['annotations_date'][$key]);
					$problem = $db->escape_string($_POST['annotations_problem'][$key]);
					$solved = ($_POST['annotations_solved'][$key]?1:0);
					$solution = $db->escape_string($_POST['annotations_solution'][$key]);
					$notes = $db->escape_string($_POST['annotations_notes'][$key]);
					$time_spent = $db->escape_string($_POST['annotations_time_spent'][$key]);
					$cost = float($_POST['annotations_cost'][$key]);

					$db->insert("INSERT INTO repairs_annotations SET
						id_repair={$repair['id']},
						id_user=$uid,
						date='$date',
						problem='$problem',
						solved='$solved',
						solution='$solution',
						notes='$notes',
						time_spent='$time_spent',
						cost='$cost'
					");
				}
			}

			redirect($redirect_url);
		}

	}

	$users = $db->fetch_all("SELECT id,name FROM users WHERE active=1 AND deleted=0");
	$repair_statuses = $db->fetch_all("SELECT * FROM repairs_statuses");
	$annotations = $db->fetch_all("
		SELECT a.*, u.name AS user
		FROM repairs_annotations as a
		JOIN users AS u
			ON u.id=a.id_user
		WHERE id_repair='{$repair['id']}'
	");
	$form_action = "$thispage?return=$return";

	if($repair) $form_action.="&amp;id={$repair['id']}";

	$smarty->assign('annotations',$annotations);
	$smarty->assign('statuses',$repairs_statuses);
	$smarty->assign('users',$users);
	$smarty->assign('repair_types',$repair_types);
	$smarty->assign('form_action',$form_action);
	$smarty->assign('repair',$repair);
	$smarty->assign('categories',$categories);
	$smarty->assign('repairs_statuses',$repairs_statuses);
	$smarty->assign('upload_image',$upload_image);
	$smarty->assign('image',$image);
	$smarty->assign('redirect_url',$redirect_url);

	$smarty->display('repair_shop.tpl');
?>
