(function(){

window.actionStack = function(options){
	var defaultOptions = {
		'retryInterval': 100,
		'bind': this
	}
	var self = this;
	var timeout = false;
	var allow = false;
	var executing = false;
	var functions = {};

	self.options = merge(defaultOptions,options);

	var execute = function(){
		executing = true;
		if(allow){
			for(var f in functions){
				functions[f].call(self.options.bind);
				functions[f] = null;
				delete functions[f];
			}
			executing = false;
		} else {
			timeout = setTimeout(execute,self.options.retryInterval);
		}
	};

	this.add = function(name,func){
		if(!this.exists(name) && typeof func == 'function'){
			functions[name] = func;
		}
		if(!executing) execute();
		return this;
	};

	this.remove = function(name){
		if(this.exists(name)){
			functions[name] = null;
			delete functions[name];
		}
		return this;
	};

	this.exists = function(name){
		return typeof functions[name] == 'object';
	};

	this.isAllowed = function(){
		return allow;
	};

	this.setAllowed = function(val){
		allow = (val ? true : false);
		return this;
	};
}

})();
