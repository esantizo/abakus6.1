<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';
	include 'inc/class.upload_image.php';

	if(!$user || !$user->isValid()) noPermissionsError();

	$thispage = "user_preferences.php";

	require 'inc/smarty.php';

	$image = $user->getImage();

	$valid_attributes = array('abakalc_on_new_windows','lang','tablet_friendly','display_menu_on_click','pager_max_per_page','paging_style','search_collapse',
		"dialer_10","dialer_1","dialer_2","dialer_3","dialer_4","dialer_5","dialer_6","dialer_7","dialer_8","dialer_9",
		"double_confirm_delete",'ask_to_change_prices');

	$upload_image = new UploadImage($db,'users');
	if($_POST['save']){
		if($_POST['tablet_friendly']){
			$_POST['display_menu_on_click'] = 'on';
		}
		foreach($valid_attributes as $att){
			$val = $db->escape_string($_POST[$att]);
			$db->update("
				INSERT INTO user_preferences (id_user,module,attribute,value) VALUES (".$user->getId().",'general','$att','$val')
				ON DUPLICATE KEY UPDATE value='$val'
			");
		}
		$image_id = $upload_image->process_upload($_POST,$_FILES);
		if($upload_image->deleted) $db->delete("UPDATE users SET id_image=0 WHERE id=".$user->getId());
		if($image_id) $db->insert("UPDATE users SET id_image=$image_id WHERE id=".$user->getId());
		$_SESSION['user_preferences_message'] = __('##SAVED_SUCCESFULLY##');
		redirect($thispage);
	}
	if($_SESSION['user_preferences_message']){
		$smarty->assign('message',$_SESSION['user_preferences_message']);
		unset($_SESSION['user_preferences_message']);
	}

	$smarty->assign('upload_image',$upload_image);
	$smarty->assign('available_languages',$smarty->language->getAvailableLanguages());
	$smarty->assign('image',$image);

	$smarty->display('user_preferences.tpl');
