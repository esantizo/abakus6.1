<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'import_csv.php';

	require 'inc/smarty.php';

	$return_url = 'index.php';

	function in_range($number,$min,$max){
		if($number >= $min && $number <= $max)  return true;
		return false;
	}

	function csv_in_array($url,$delm2=';',$encl='"',$head=false) {

		$delm = ',';

		$csvxrow = file($url,FILE_SKIP_EMPTY_LINES | FILE_IGNORE_NEW_LINES);   // ---- csv rows to array ----

		$csvxrow[0] = str_replace($encl,'',$csvxrow[0]);
		$keydata = explode($delm,$csvxrow[0]);
		$keynumb = count($keydata);

		if ($head === true) {
			$anzdata = count($csvxrow);
			$z=0;
			for($x=1; $x<$anzdata; $x++) {
				$csvxrow[$x] = chop($csvxrow[$x]);
				$csvxrow[$x] = str_replace($encl,'',$csvxrow[$x]);
				$csvxrow[$x] = str_replace($delm2,$delm,$csvxrow[$x]);
				$csv_data[$x] = explode($delm,$csvxrow[$x]);
				$i=0;
				foreach($keydata as $key) {
					$out[$z][$key] = trim($csv_data[$x][$i]);
					$i++;
				}
				$z++;
			}
		}
		else {
			$i=0;
			foreach($csvxrow as $item) {
				$item = str_replace($encl,'',$item);
				$csv_data = explode($delm,$item);
				for ($y=0; $y<$keynumb; $y++) {
					$out[$i][$y] = trim($csv_data[$y]);
				}
				$i++;
			}
		}

		return $out;
	}

	$fields = array(
		'reference' => array( 'label' => __('##Reference##'), 'required' => true, 'validation' => 'string' ),
		'name' => array( 'label' => __('##Name##'), 'required' => true, 'validation' => 'string'),
		'short_description' => array( 'label' => __('##Short description##'), 'required' => true, 'validation' => 'string'),
		'price' => array( 'label' => __('##Price##'), 'required' => true, 'validation' => 'float'),
/*
		'tax' => array( 'label' => __('##Tax##'), 'required' => true),
		'currency' => array( 'label' => __('##Currency##'), 'required' => true),
/**/
		'cost' => array( 'label' => __('##Cost##'), 'required' => false, 'validation' => 'float'),
		'manufacturers_code' => array( 'label' => __('##Manufacturers Code##'), 'required' => false, 'validation' => 'string'),
		'manufacturers_price' => array( 'label' => __('##Manufacturers Price##'), 'required' => false, 'validation' => 'none'),
		'description' => array( 'label' => __('##Description##'), 'required' => false, 'validation' => 'none'),
		'color' => array( 'label' => __('##Color##'), 'required' => false, 'validation' => 'none'),
		'notes' => array( 'label' => __('##Notes##'), 'required' => false, 'validation' => 'none'),
		'none' => array( 'label' => __('##NG_IGNORE##'), 'required' => false, 'validation' => 'none')
	);

	if($_POST['verify']==1){
		if($_FILES['csv_file']['error']==0){
			$min = (int)$_REQUEST['import_from_row'];
			$max = (int)$_REQUEST['import_to_row'];

			$import_tmp = csv_in_array($_FILES['csv_file']['tmp_name']);

			if($max <= 0) $min = 1;
			if($max == 0) $max = count($import_tmp);

			$import_list = array();
			if(is_array($import_tmp)) foreach($import_tmp as $k => $v){
				if(in_range($k+1,$min,$max)){
					foreach($v as $l => $w){
						if(preg_match("/^[\d\.\,]+$/",$w)) $w = str_replace(',','.',$w);
						$import_list[$k][$l] = utf8_decode($w);
					}
				}
			}
		}

		$preferences = $db->fetch_all("SELECT * FROM user_preferences WHERE id_user={$user->getId()} AND module='import_csv'",'value','attribute');
		if(is_array($preferences)) foreach($preferences as $k => $v){
			$preferences[$k] = json_decode($v,true);
		}

		$taxes = $db->fetch_all("SELECT * FROM taxes");
		$currencies = $db->fetch_all("SELECT * FROM currency");
		$price_scales = $db->fetch_all("SELECT * FROM price_scales");
		$providers = $db->fetch_all("SELECT * FROM providers");

		$smarty->assign('preferences',$preferences);
		$smarty->assign('min',$min);
		$smarty->assign('max',$max);
		$smarty->assign('currencies',$currencies);
		$smarty->assign('taxes',$taxes);
		$smarty->assign('providers',$providers);
		$smarty->assign('price_scales',$price_scales);
		$smarty->assign('fields',$fields);
		$smarty->assign('import_list',$import_list);
	}

	elseif($_POST['save']=='1'){
		$data = null;
		$fields = $_POST['fields'];
		$values = $_POST['values'];
		$global_currency = (int)$_POST['global_currency'];
		$global_tax = (int)$_POST['global_tax'];
		$provider = (int)$_POST['id_provider'];
		$price_scale = (int)$_POST['price_scale'];

		if(is_array($_POST['rows'])) foreach($_POST['rows'] as $idx){
			$tmp['notes'] = '';
			foreach($fields as $i => $name){
				if($name == 'notes'){
					$tmp[$name] .= $db->escape_string($values[$idx][$i])."\n\n";
				} else {
					$tmp[$name] = $db->escape_string($values[$idx][$i]);
				}
			}
			$tmp['id_currency'] = $global_currency;
			$tmp['id_tax'] = $global_tax;

			if($_POST['name_as_short_description']){
				$tmp['short_description'] = $tmp['name'];
			}
			if($_POST['short_description_as_description']){
				$tmp['description'] = $tmp['short_description'];
			}
			if($_POST['calculate_price_from_cost']){
				$tmp['price']=float($tmp['cost']) * float($_POST['cost_multiplier']);
			}
			if($_POST['auto_generate_reference']){
				$tmp['reference']=$provider.'/'.str_replace(' ','',$tmp['manufacturers_code']);
			}

			$tmp['id_provider'] = $provider;
			$tmp['price_scale'] = $price_scale;
			if(is_array($tmp)) $data[] = $tmp;
		}

		$preferences = array(
			'fields' => $fields,
			'global_currency' => $global_currency,
			'global_tax' => $global_tax,
			'provider' => $provider,
			'price_scale' => $price_scale,
			'name_as_short_description' => ($_POST['name_as_short_description']?true:false),
			'short_description_as_description' => ($_POST['short_description_as_description']?true:false),
			'calculate_price_from_cost' => ($_POST['calculate_price_from_cost']?true:false),
			'cost_multiplier' => float($_POST['cost_multiplier']),
			'auto_generate_reference' => ($_POST['auto_generate_reference']?true:false)
		);

		foreach($preferences as $k => $v){
			$db->update("
				INSERT INTO user_preferences SET id_user={$user->getId()},module='import_csv',attribute='$k',value='".json_encode($v)."'
				ON DUPLICATE KEY UPDATE value='".json_encode($v)."'
			");
		}

		if(is_array($data)){
			foreach($data as $d){

				if($_POST['update_data']=='yes'){
					$insert = false;
					$id = $db->fetch_item_field("SELECT id FROM products WHERE reference LIKE '{$d['reference']}'");
					if($id){
						$fields = array("
							id_provider='{$d['id_provider']}',
							id_category='{$d['id_category']}',
							id_tax='{$d['id_tax']}',
							id_currency='{$d['id_currency']}'
						");
						if($d['name']) $fields[] = "name='{$d['name']}'";
						if($d['cost']) $fields[] = "cost='{$d['cost']}'";
						if($d['manufacturers_code']) $fields[] = "manufacturers_code='{$d['manufacturers_code']}'";
						if($d['manufacturers_price']) $fields[] = "manufacturers_price='{$d['manufacturers_price']}'";
						if($d['description']) $fields[] = "description='{$d['description']}'";
						if($d['short_description']) $fields[] = "short_description='{$d['short_description']}'";
						if($d['notes']) $fields[] = "notes='{$d['notes']}'";
						if($d['color']) $fields[] = "color='{$d['color']}'";

						$db->update("
							UPDATE products SET
							".implode(',',$fields)."
							WHERE reference LIKE '{$d['reference']}'
							LIMIT 1
						");
						if($d['price']){
							$db->insert("INSERT INTO products_prices SET id_product=$id, id_price_scale={$d['price_scale']}, price='{$d['price']}' ON DUPLICATE KEY UPDATE price='{$d['price']}'");
						}
					} else {
						$insert = true;
					}
				} else {
					$insert = true;
				}

				if($insert){
					$id = $db->insert("INSERT INTO products SET
						name='{$d['name']}',
						cost='{$d['cost']}',
						id_provider='{$d['id_provider']}',
						id_category='{$d['id_category']}',
						id_tax='{$d['id_tax']}',
						id_currency='{$d['id_currency']}',
						reference='{$d['reference']}',
						manufacturers_code='{$d['manufacturers_code']}',
						manufacturers_price='{$d['manufacturers_price']}',
						description='{$d['description']}',
						short_description='{$d['short_description']}',
						notes='{$d['notes']}',
						color='{$d['color']}',
						insert_date=NOW()
					");

					if($id && $d['price']){
						$db->insert("INSERT INTO products_prices SET id_product=$id, id_price_scale={$d['price_scale']}, price='{$d['price']}'");
					}
				}
			}

			$smarty->assign('imported_data',$data);
			$return_url = 'import_csv.php';
		}

	}


	$smarty->assign('return_url',$return_url);
	$smarty->display('import_csv.tpl');
?>
