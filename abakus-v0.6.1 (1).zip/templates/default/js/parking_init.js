$(document).addEvent('domready',function(){

	$(document).addEvent('keydown',keyboardListener);

	$$('.license_plate_input').addEvents({
		'keypress':function(ev){
			ev.preventDefault();
			this.value = this.value + String.fromCharCode(ev.keyCode).toUpperCase();
		}
	});

	$$('#park_in .license_plate_input').addEvents({
		'keydown': function(ev){
			if(ev.keyCode==13){
				if(parkOutLightbox.opened || stayPriceLightbox.opened){
					return ev.preventDefault();
				}
				if(this.value.trim().length == 0){
					msgBox("##NG_LICENSEPLATE_MUST_NOT_BE_EMPTY##");
				} else {
					checkClient(this.value,function(){
						$('license_plate_notes').focus();
					});
				}
				return ev.preventDefault();
			}
		}
	});

	$$('#park_out .license_plate_input').addEvents({
		'keydown': function(ev){
			if(ev.keyCode==13){
				if(parkOutLightbox.opened || stayPriceLightbox.opened){
					return ev.preventDefault();
				}
				parking_check();
				return ev.preventDefault();
			}
		}
	});

	$$('.license_plate_notes').addEvents({
		'keydown': function(ev){
			if(ev.keyCode==13){
				$$('.stay_type')[0].focus();
				return ev.preventDefault();
			}
		}
	});

	$$('.stay_type').addEvents({
		'keydown': function(ev){
			if(ev.keyCode==13){
				$this = $(this);
				if($this.getParent('label').getFirst('.options_block')){
					var type = $$('.stay_type:checked')[0].value;
					if( type == 'shift' ){
						$('shift_options').setStyle('display','block')
						setFocus('shift_options');
						return;
					}

					if( type == 'monthly' ){
						$('monthly_options').setStyle('display','block')
						setFocus('monthly_options');
						return;
					}
				} else {
					park_in_ok();
				}
				return ev.preventDefault();
			}
		},
		'click': function(ev){
			if($(this).getParent('label').getFirst('.options_block')){
				var type = $$('.stay_type:checked')[0].value;
				if( type == 'shift' ){
					$('shift_options').setStyle('display','block')
					setFocus('shift_options');
					return;
				}

				if( type == 'monthly' ){
					$('monthly_options').setStyle('display','block')
					setFocus('monthly_options');
					return;
				}
			}
		}
	});

	parkOutLightbox = new Lightbox('parkOutLightbox',{ autoposition: true,autoHeight: true });
	stayPriceLightbox = new Lightbox('stayPriceLightbox',{ autoposition: true,autoHeight: true });

	showDate();
});
