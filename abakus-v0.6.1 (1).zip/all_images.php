<?php
	include 'inc/config.php';

	$thispage = "all_images.php";

	include 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId('dictionary.php'),'write')) noPermissionsError();

	$lang_dir = $smarty->getLanguagesDir();
	$curr_lang = $smarty->language->getCurrentLocale();

	$images_str = file_get_contents($lang_dir.$curr_lang.'/images.lng');
	$images_arr = split("\n",str_replace(array("\r\n","\r"),"\n",$images_str));
	foreach($images_arr as $i){
		if(empty($i) || preg_match('#^\W*//#',$i)) continue;
		list($name,$image) = split("=",$i);
		$images[$name] = trim($image);
	}

	// Save anew path for an image
	if($_GET['imgname'] && isset($_GET['newpath']) && isset($images[$_GET['imgname']])){
		$name = trim($_GET['imgname']);
		$images[$name] = trim($_GET['newpath']);

		if(is_array($images)){
			unlink($lang_dir.$curr_lang.'/images.lng');
			$fh = fopen($lang_dir.$curr_lang.'/images.lng','w');
			foreach($images as $n => $p){
				fwrite($fh,"$n=$p\n");
			}
			fclose($fh);
			@chmod($lang_dir.$curr_lang.'/images.lng', 0666);
		}
		redirect($thispage.'?rand='.rand(0,10000000000));
	}

	$smarty->assign('images',$images);
	$smarty->display('all_images.tpl');
?>