var lightbox_notes;
var navigateNotes = false;

$(document).addEvent('domready',function(){
	if(!$('box_search_note')){
		new Element('div',{ 'id':'box_search_note', 'class':'lightbox search_box' })
			.adopt(new Element('div',{'class':'search_item_search_container'})
				.adopt(new Element('input',{ type:'text', id:'search_note_input', 'class':'search_items_input' }))
				.adopt(new Element('img',{ src:'##IMG_CLEAN##', width:20, height:20, alt:'X', 'class': 'search_items_clean_btn', events:{'click':function(){ $('search_note_input').value='';executeNoteSearch(); } } }))
				.adopt(new Element('input',{ type:'button', value:'Buscar', id:'search_note_btn' }))
			)
			.adopt(
				new Element('div',{ id:'search_note_response','class':'search_results_response' }).adopt(new Element('table',{ id:'notes_results_table','class': 'search_results_table'})
					.adopt(new Element('thead').adopt(new Element('tr')
						.adopt(new Element('th',{ text:'##Id##' }))
						.adopt(new Element('th',{ text:'##Name##' }))
						.adopt(new Element('th',{ text:'##Note##' }))
					))
					.adopt(new Element('tbody',{ id:'notes_results_table_body' }))
				)
			)
			.inject(document.body);
	}

	$('search_note_input').addEvent('focus',function(){
		$$('#notes_results_table_body tr').each(function(e){e.removeClass('selected');});
		current = null;
	});
	$('search_note_input').addEvent('keydown',function(ev){ if(ev.keyCode==13){ executeNoteSearch(); } });
	$('search_note_btn').addEvent('click',function(){executeNoteSearch();});

	if($('note')) setFocus('note');

	$(window).addEvent('keydown',searchNoteNavigationListener);
});

function openSearchNoteBox(){
	lightbox_notes = new Lightbox('box_search_note',{'onClose':function(){navigateNotes=false;current=null;}}).open();
	if($('note')) $('search_note_input').value=$('note').value;
	$('notes_results_table_body').empty();
	navigateNotes = true;
	current = null;
	executeNoteSearch();
}

function executeNoteSearch(){
	Request({
		'url':'ajax/search_notes.php',
		'method':'post',
		'data':'q='+$('search_note_input').value,
		'onSuccess':function(response){
			$('notes_results_table_body').set('html',response);
			$$('#notes_results_table_body tr').each(function(tr){
				if(tr && tr.tagName=='TR'){
					tr.setStyle('cursor','pointer');
					tr.addEvent('click',function(){
						if($('note')) $('note').value = this.getElements('td')[0].innerHTML;
						lightbox_notes.close();
						searchNote(this.getElements('td')[0].innerHTML);
					});
				}
			});
			lightbox_notes.reposition();
		}
	});
	if($('search_note_input')) setFocus('search_note_input');
}

function searchNoteNavigationListener(ev){
	if(calculator && calculator.opened) return false;
	if(navigateNotes==true){
		$$('#notes_results_table_body tr').each(function(e){e.removeClass('selected');});
		if(ev.target==$('search_note_input')){
			if(ev.keyCode==40 || ev.keyCode==38){
				$('search_note_input').blur();
			}
		}
		if(ev.keyCode==40){
			if(current == null){
				current = $('notes_results_table_body').getFirst('tr');
			} else {
				current = nextItem(current,'TR');
				if(!current) current = $('notes_results_table_body').getFirst('tr');
			}
		} else if(ev.keyCode==38){
			if(current == null){
				current = $('notes_results_table_body').getLast('tr');
			} else {
				current = previousItem(current,'TR');
				if(!current) current = $('notes_results_table_body').getLast('tr');
			}
		} else if(ev.keyCode==13) {
			if(current){
				if($('note')) $('note').value = current.getElements('td')[0].innerHTML;
				lightbox_notes.close();
				searchNote(current.getElements('td')[0].innerHTML);
				navigateNotes = false;
				return false;
			}
		}
		if(current){
			current.addClass('selected');
			var curPos = current.getPosition();
				var contHeight = $('search_note_response').getPosition().height;
				var maxScroll = $('notes_results_table').getPosition().totalHeight - contHeight;
			var scroll = curPos.top + curPos.height - contHeight / 2;
			if(scroll < 0) scroll = 0;
			if(scroll > maxScroll) scroll = maxScroll;
				$('search_note_response').scrollTop = scroll;
			if(ev.preventDefault) ev.preventDefault();
			if(ev.preventBubble) ev.preventBubble();
			return false;
		}
	}
}
