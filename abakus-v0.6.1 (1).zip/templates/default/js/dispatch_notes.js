var searchLightbox;

$(document).addEvent('domready',function(){
	$('search_item_input').addEvent('keydown',function(ev){ if(ev.keyCode==13){ executeItemSearch(); } });
	$('search_item_btn').addEvent('click',function(){executeItemSearch();});
	$(window).addEvent('keydown',searchNavigationListener);
	$(window).addEvent('keydown',keyboardActionListener);
	setFocus('client');
});

function saveInvoice(){
	$('invoice_form').submit();
}

function savePending(){
	$('save').value = 'pending';
	$('invoice_form').submit();
}

function acceptEdit(el){
	var cols = $(el).getElements('td');

	$(cols[0]).set('html','<input type="hidden" name="product_id[]" value="'+$(cols[0]).getFirst('input').value+'"><a href="javascript:;" onclick="deleteItem($(this).getParent(\'tr\'))"><img src="##IMG_DELETE##" width="20" height="20"></a> <a href="javascript:;" onclick="editItem($(this).getParent(\'tr\'))"><img src="##IMG_EDIT##" width="20" height="20"></a>');
	$(cols[2]).set('html','<input type="hidden" name="desc[]" value="'+$(cols[2]).getFirst('input').value+'">'+$(cols[2]).getFirst('input').value);
	if($('stock_input') && $('selected_stock')){
		$(cols[3]).set('html','<input type="hidden" name="qty[]" value="'+$(cols[3]).getFirst('input').value+'"><input type="hidden" name="stock[]" value="'+$(cols[3]).getElements('input')[1].value+'"><input type="hidden" name="sel_stock[]" value="'+$(cols[3]).getElements('input')[2].value+'">'+$(cols[3]).getFirst('input').value);
	} else {
		$(cols[3]).set('html','<input type="hidden" name="qty[]" value="'+$(cols[3]).getFirst('input').value+'">'+$(cols[3]).getFirst('input').value);
	}

	updateTotals();
	unlockControls();
	$('insert_row').setStyle('display','table-row');
	setFocus('ref_input');
}

function cancelEdit(el){
	var cols = $(el).getElements('td');
	$(cols[0]).set('html','<input type="hidden" name="product_id[]" value="'+$(cols[0]).getElements('input')[1].value+'"><a href="javascript:;" onclick="deleteItem($(this).getParent(\'tr\'))"><img src="##IMG_DELETE##" width="20" height="20"></a> <a href="javascript:;" onclick="editItem($(this).getParent(\'tr\'))"><img src="##IMG_EDIT##" width="20" height="20"></a>');
	$(cols[2]).set('html','<input type="hidden" name="desc[]" value="'+$(cols[2]).getFirst('input').get('alt')+'">'+$(cols[2]).getFirst('input').get('alt'));
	if($('stock_input') && $('selected_stock')){
		$(cols[3]).set('html','<input type="hidden" name="qty[]" value="'+$(cols[3]).getFirst('input').get('alt')+'"><input type="hidden" name="stock[]" value="'+$(cols[3]).getElements('input')[1].value+'"><input type="hidden" name="sel_stock[]" value="'+$(cols[3]).getElements('input')[2].value+'">'+$(cols[3]).getFirst('input').get('alt'));
	} else {
		$(cols[3]).set('html','<input type="hidden" name="qty[]" value="'+$(cols[3]).getFirst('input').get('alt')+'">'+$(cols[3]).getFirst('input').get('alt'));
	}

	updateTotals();
	unlockControls();
	$('insert_row').setStyle('display','table-row');
	setFocus('ref_input');
}

function editItem(el){
	$('insert_row').setStyle('display','none');
	lockControls();
	var cols = $(el).getElements('td');

	var prodidval = $(cols[0]).getFirst('input').value;

	$(cols[0]).empty()
		.adopt(new Element('input',{'type':'hidden','name':'product_id[]','value':prodidval}))
		.adopt(new Element('a',{'href':'javascript:;','html':'<img src="##IMG_ACCEPT##" width="20" height="20">','events':{'click':function(){acceptEdit($(this).getParent('tr'));}}}))
		.adopt(new Element('text',' '))
		.adopt(new Element('a',{'href':'javascript:;','html':'<img src="##IMG_CANCEL##" width="20" height="20">','events':{'click':function(){cancelEdit($(this).getParent('tr'));}}}));

	var desc = $(cols[2]).get('text');
	var cant = $(cols[3]).getFirst('input').value.toInt();
	if($('stock_input') && $('selected_stock')){
		var stock = $(cols[3]).getElements('input')[1].value;
		var sel_stock = $(cols[3]).getElements('input')[2].value;
	}
	$(cols[2]).empty();
	$(cols[3]).empty();
	var inp_desc = new Element('input',{'type':'text','alt':desc,'value':desc}).addEvent('keydown',function(ev){if(ev.keyCode==13){setFocus(inp_cant);inp_cant.select();}}).inject(cols[2]);
	var inp_cant = new Element('input',{'type':'text','alt':cant,'value':cant}).addEvent('keydown',function(ev){
		quantityHandler(ev,inp_stock,sel_stock,inp_cant,function(){ acceptEdit(el); });
	}).inject(cols[3]);
	if($('stock_input') && $('selected_stock')){
		var inp_stock = new Element('input',{'type':'hidden','value':stock}).inject(cols[3]);
		var sel_stock = new Element('input',{'type':'hidden','value':sel_stock}).inject(cols[3]);
	}

	setFocus(inp_desc);
	inp_desc.select();
}

function deleteItem(el){
	if(confirmBox("##NG_DELETE_CONFIRMATION##")){
		$(el).destroy();
		updateTotals();
	}
}

function itemOk(){
	var tr = new Element('tr');
	var td = new Element('td')
		.adopt(new Element('input',{'type':'hidden','name':'product_id[]','value':$('prod_id_input').value}))
		.adopt(new Element('a',{'href':'javascript:;','html':'<img src="##IMG_DELETE##" width="20" height="20">','events':{'click':function(){deleteItem($(this).getParent('tr'));}}}))
		.adopt(new Element('text',' '))
		.adopt(new Element('a',{'href':'javascript:;','html':'<img src="##IMG_EDIT##" width="20" height="20">','events':{'click':function(){editItem($(this).getParent('tr'));}}}))
		.inject(tr);
	td = new Element('td')
		.adopt(new Element('input',{'type':'hidden','name':'ref[]','value':html_entity_decode($('ref_input').value)}))
		.adopt(new Element('text',$('ref_input').value))
		.inject(tr);
	td = new Element('td')
		.adopt(new Element('input',{'type':'hidden','name':'desc[]','value':html_entity_decode($('desc_input').value)}))
		.adopt(new Element('text',$('desc_input').value))
		.inject(tr);

	td = new Element('td')
		.adopt(new Element('input',{'type':'hidden','name':'qty[]','value':$('qty_input').value}));
	if($('stock_input') && $('selected_stock')){
		td.adopt(new Element('input',{'type':'hidden','name':'stock[]','value':$('stock_input').value}))
			.adopt(new Element('input',{'type':'hidden','name':'sel_stock[]','value':$('selected_stock').value}));
	}
	td.adopt(new Element('text',$('qty_input').value))
		.inject(tr);
	$('table_body').insertBefore(tr,$('insert_row'));

	updateTotals();

	$('prod_id_input').value = '';
	$('ref_input').value = '';
	$('desc_input').value = '';
	$('qty_input').value = '';
	if($('stock_input') && $('selected_stock')){
		$('stock_input').value = '';
		$('selected_stock').value = '';
	}
	lockDescription();
	unlockControls();
	setFocus('ref_input');
}

function openSearchItemBox(){
	searchLightbox = new Lightbox('box_search_item',{'focusOnClose':'ref_input','onClose':function(){navigateItems = false;current=null;}}).open();
	$('search_item_input').value=$('ref_input').value;
	$('items_results_table_body').empty();
	navigateItems = true;
	current = null;
	executeItemSearch();
}

function executeItemSearch(){
	Request({
		'url':'ajax/search_item.php',
		'method':'post',
		'data':'q='+$('search_item_input').value,
		'onSuccess':function(response){
			$('items_results_table_body').stopWaiting();
			$('items_results_table_body').empty();
			var res = parseJSON(response);
			for(var i=0,len=res.length; i<len; i++){
				var it = res[i];
				new Element('tr',{
						styles: {
							'cursor': 'pointer'
						},
						events: {
							'click':function(){
								$('ref_input').value = this.getFirst('td input').value;
								searchItem();
								searchLightbox.close();
							}
						}
					})
					.adopt(new Element('td',{ text: it.reference }).adopt(new Element('input',{ 'type':'hidden','name':'return_field','value':it[ret_field] })))
					.adopt(new Element('td',{ text: it.name }))
					.adopt(new Element('td',{ text: it.short_description }))
					.adopt(new Element('td',{ text: it.stock }))
					.inject('items_results_table_body');
			}
			searchLightbox.reposition();
		}
	});
	setFocus('search_item_input');
}

function searchItem(){
	Request({
		'url':'ajax/search_item.php',
		'method':'post',
		'data':'ref='+$("ref_input").value,
		'onSuccess':function(res){
			if(res.length > 0){
				unlockDescription();
				lockControls();
				var json = eval('('+res+')');
				$("prod_id_input").value = json.product_id;
				$("desc_input").value = json.short_description;
				if($('stock_input')){
					$("stock_input").value = json.stock;
				}
				$('qty_input').value = 1;

				setFocus("desc_input");
			} else {
				openSearchItemBox();
			}
		}
	});
}

function openSearchNoteBox(){
	searchLightbox = new Lightbox('box_search_notes',{'focusOnClose':'notes','onClose':function(){navigateNotes=false;current=null;}}).open();
	$('notes_results_table_body').empty();
	navigateNotes = true;
	current = null;
	executeNotesSearch();
}

function addNote(str){
	if($('notes').value.length > 0) $('notes').value += "\n\n";
	$('notes').value += str;
}

function executeNotesSearch(){
	Request({
		'url':'ajax/search_notes.php',
		'method':'post',
		'data':'q='+$('search_notes_input').value,
		'onSuccess':function(response){
			$('notes_results_table_body').set('html',response);
			var els = $('notes_results_table').getElements('tbody tr');
			for(i in els){
				tr = $(els[i]);
				if(tr && tr.tagName=='TR'){
					tr.setStyle('cursor','pointer');
					tr.addEvent('click',function(){
						addNote(this.getFirst('td input').value);
						searchLightbox.close();
					});
				}
			}
		}
	});
	setFocus('notes');
}

function searchClient(id){
	if(id==0) {
		setFocus(nextInput('client'));
		return false;
	}
	Request({
		'url':'ajax/search_client.php',
		'method':'post',
		'data':'id='+id,
		'onSuccess':function(response){
			if(response){
				var res = eval('('+response+')');
			}
			if(res && res.name){
				$('client').set('rel',id);
				$('client_name').set('html',(res.name?res.name:''));
				$('client_address').set('html',(res.address?res.address:''));
				$('client_taxpayer_id').set('html',(res.taxpayer_id?res.taxpayer_id:''));
				if(res.postcode && res.city)
					$('client_city').set('html','('+res.postcode+') '+res.city);
				else
					$('client_city').set('html',(res.city?res.city:''));
				$('client_state').set('html',(res.state?res.state:''));
				$('client_country').set('html',(res.country?res.country:''));

				$('client_name_input').value = (res.name?res.name:'');
				$('client_address_input').value = (res.address?res.address:'');
				$('client_taxpayer_id_input').value = (res.taxpayer_id?res.taxpayer_id:'');
				$('client_city_input').value = (res.city?res.city:'');
				$('client_state_input').value = (res.state?res.state:'');
				$('client_country_input').value = (res.country?res.country:'');
				$('client_postcode_input').value = (res.postcode?res.postcode:'');

				$('invoice_table').setStyle('display','block');

				$('client').onkeydown = function(){return false;};
				$('client').setStyles({
					'background':'transparent',
					'border':0,
					'padding':'0',
					'-webkit-box-shadow':'none',
					'-moz-box-shadow':'none',
					'box-shadow':'none'
				});
				$('search_item_icon').setStyle('display','none');

				setFocus("ref_input");
			} else {
				msgBox("##NG_WRONG_CLIENT##");
				setFocus('client');
			}
		}
	});
}

$('client').addEvent('keydown',function(ev){
	if(ev.keyCode==13){
		if(this.value===0 || this.value==='0') {
			$('client').set('rel',0);
			$('client_name_input').value='';
			$('client_address_input').value='';
			$('client_city_input').value='';
			$('client_state_input').value='';
			$('client_country_input').value='';
			$('client_taxpayer_id_input').value='';

			$('client_name').set('text','');
			$('client_address').set('text','');
			$('client_city').set('text','');
			$('client_state').set('text','');
			$('client_country').set('text','');
			$('client_taxpayer_id').set('text','');

			$('client_name_input').set('type','text');
			$('client_address_input').set('type','text');
			$('client_city_input').set('type','text');
			$('client_state_input').set('type','text');
			$('client_country_input').set('type','text');
			$('client_taxpayer_id_input').set('type','text');

			$('invoice_table').setStyle('display','block');
		} else if(!isNaN(this.value)){
			$('client_name_input').value='';
			$('client_address_input').value='';
			$('client_city_input').value='';
			$('client_state_input').value='';
			$('client_country_input').value='';
			$('client_taxpayer_id_input').value='';

			$('client_name').set('text','');
			$('client_address').set('text','');
			$('client_city').set('text','');
			$('client_state').set('text','');
			$('client_country').set('text','');
			$('client_taxpayer_id').set('text','');

			$('client_name_input').set('type','hidden');
			$('client_address_input').set('type','hidden');
			$('client_city_input').set('type','hidden');
			$('client_state_input').set('type','hidden');
			$('client_country_input').set('type','hidden');
			$('client_taxpayer_id_input').set('type','hidden');

			$('invoice_table').setStyle('display','none');
			//~ if(this.value===''){
				//~ openSearchClientBox();
			//~ } else {
				//~ searchClient(this.value);
			//~ }
		//~ } else {
			//~ openSearchClientBox();
		}
	}
});
//~ }).addEvent('blur',function(){
	//~ if(!isNaN(this.get('rel')))
		//~ this.value = this.get('rel');
//~ });

$("ref_input").addEvent('keydown',function(ev){
	if(ev.keyCode==13){
		if(this.value==='0' || this.value===0){
			var cols = $(this.getParent('tr')).getElements('td');
			$("qty_input").value = 1;
			unlockDescription();
			lockControls();
			setFocus("desc_input");
			$('desc_input').select();
		} else if(this.value===''){
			openSearchItemBox();
		} else {
			searchItem();
		}
	}
});
$("desc_input").addEvent('keydown',function(ev){
	if(ev.keyCode==13){
		setFocus("qty_input");
		$("qty_input").select();
	}
});

function updateRemaining(){
	var total_qty = 0;
	$$('#stock_response .qty_input').each(function(el){
		total_qty += el.value.toInt();
	});
	var rem = $('total_qty').get('rel').toInt() - total_qty;
	var classname = '';
	if(rem > 0) classname = 'over';
	if(rem < 0) classname = 'under';
	$('remaining_qty').set({'text':rem,'class':classname});
}

//~ $("qty_input").addEvent('keydown',function(ev){
	//~ if(ev.keyCode==13){
		//~ itemOk();
	//~ }
//~ });

$("qty_input").addEvent('keydown',function(ev){
	quantityHandler(ev,'stock_input','selected_stock','qty_input',itemOk);
});

var current = null;
var navigateItems = false;
lockDescription();
unlockControls();

function searchNavigationListener(ev){
	if(calculator && calculator.opened) return false;
	if(navigateItems==true){
		$$('#items_results_table_body tr').each(function(e){e.removeClass('selected');});
		if(ev.target==$('search_item_input')){
			if(ev.keyCode==40 || ev.keyCode==38){
				$('search_item_input').blur();
			}
		}
		if(ev.keyCode==40){
			if(current == null){
				current = $('items_results_table_body').getFirst('tr');
			} else {
				current = nextItem(current,'TR');
				if(!current) current = $('items_results_table_body').getFirst('tr');
			}
		} else if(ev.keyCode==38){
			if(current == null){
				current = $('items_results_table_body').getLast('tr');
			} else {
				current = previousItem(current,'TR');
				if(!current) current = $('items_results_table_body').getLast('tr');
			}
		} else if(ev.keyCode==13) {
			if(current){
				$('ref_input').value = current.getFirst('td input').value;
				searchLightbox.close();
				searchItem();
				navigateItems = false;
				return false;
			}
		}
		if(current){
			current.addClass('selected');
			var curPos = current.getPosition();
			if($('items_results_table')){
				var contHeight = $('search_item_response').getPosition().height;
				var maxScroll = $('items_results_table').getPosition().totalHeight - contHeight;
			}
			var scroll = curPos.top + curPos.height - contHeight / 2;
			if(scroll < 0) scroll = 0;
			if(scroll > maxScroll) scroll = maxScroll;
			if($('items_results_table')){
				$('search_item_response').scrollTop = scroll;
			}
			if(ev.preventDefault) ev.preventDefault();
			if(ev.preventBubble) ev.preventBubble();
			return false;
		}
	}
}

function keyboardActionListener(ev){
	//~ if(calculator && calculator.opened) return false;
	//~ if(!navigateItems==true){
		//~ if(ev.keyCode==83 && ev.ctrlKey){ //CTRL+S
			//~ if(ev.cancelBubble) ev.cancelBubble();
			//~ if(ev.preventDefault) ev.preventDefault();
		//~ }
	//~ }
}

function quantityHandler(ev,data_container,selected_container,quantity_container,cbFunction){
	if(ev.keyCode==13){
		var self = ev.target;
		if(!ignore_stock && $(data_container) && $(data_container).value.length > 0){
			var stocks = $(data_container).value.split('|');
			if(stocks.length == 1){
				var data = stocks[0].split(';');
				$(selected_container).value = data[0]+';'+self.value;
				if(typeof cbFunction == 'function') cbFunction.call();
			} else if(stocks.length > 1){
				var first = null;
				var inputs = [];
				$('stock_response').empty();
				var startValues = {};
				$(selected_container).value.split('|').each(function(el){
					var thisel = el.split(';');
					startValues[thisel[0]] = thisel[1];
				});
				new Element('div')
					.adopt(new Element('span',{'text':'Cantidad Total: '}))
					.adopt(new Element('span',{'rel':self.value,'text':self.value,'id':'total_qty'}))
					.inject('stock_response');
				new Element('div')
					.adopt(new Element('span',{'text':'Restantes: '}))
					.adopt(new Element('span',{'text':self.value,'id':'remaining_qty'}))
					.inject('stock_response');
				for(var i=0,len=stocks.length;i<len;i++){
					var data = stocks[i].split(';');
					var el = new Element('label').inject('stock_response');
					el.adopt(new Element('span',{'text':data[2]+' (max: '+data[1]+'): '}));
					var inp = new Element('input',{'type':'text','value':0,'class':'qty_input','id':'qty_input_'+i,'rel':i,'data-id':data[0],'data-max':data[1]});
					if(startValues[data[0]]) inp.set('value',startValues[data[0]]);
					el.adopt(inp);
					inputs.push(inp);
				}
				for(var i=0,len=inputs.length-1; i<len; i++){
					inputs[i].addEvent('keyup',function(ev){
						if(ev.keyCode==13){
							setFocus($('qty_input_'+(this.get('rel').toInt()+1)));
						} else if (!keyCodeIsNumber(ev.keyCode) && !keyCodeIsNavigation(ev.keyCode)) {
							ev.stopPropagation();
							return false;
						} else {
							updateRemaining();
						}
					});
				}

				new Element('div',{'id':'qty_message'}).setStyle('display','none').inject('stock_response');

				if(inputs[inputs.length-1]) inputs[inputs.length-1].addEvent('keyup',function(ev){
					if(ev.keyCode==13){
						var sel_stock = [];
						var total_qty = 0;
						$$('#stock_response .qty_input').each(function(el){
							sel_stock.push(el.get('data-id')+';'+el.value);
							total_qty += el.value.toInt();
						});
						if(total_qty != $('total_qty').get('rel').toInt()){
							$('qty_message').set('text','##NG_QUANTITY_DOESNT_MATCH_STOCK##').setStyle('display','block');
							searchLightbox.autoHeight();
							setFocus($$('#stock_response .qty_input')[0]);
						} else {
							$(selected_container).value = sel_stock.join('|');
							$(quantity_container).value = total_qty;
							searchLightbox.close();
							if(typeof cbFunction == 'function') cbFunction.call();
						}
					} else {
						updateRemaining();
					}
				});
				setFocus(inputs[0]);
				updateRemaining();
				searchLightbox = new Lightbox('box_stock',{'onClose':function(){searchLightbox=null}}).open().autoHeight();
			} else {
				if(typeof cbFunction == 'function') cbFunction.call();
			}
		} else {
			if(typeof cbFunction == 'function') cbFunction.call();
		}
	}
}

function updateTotals(){
	var childs = $('table_body').childNodes;

	var messages = [];
	for(i in childs) if(typeof(childs[i])=='object' && childs[i].tagName=='TR' && !childs[i].getAttribute('id')){
		var cols = $(childs[i]).getElements('td');
		var prod_id = $(cols[0]).getFirst('input').value;

		// Check stock
		var cant = $(cols[3]).get('text').toInt();
		if(!ignore_stock && prod_id > 0 && $(cols[3]).getElements('input')[1]){
			var stocks = $(cols[3]).getElements('input')[1].value.split('|');
			var sel_stocks = $(cols[3]).getElements('input')[2].value.split('|');
			var stock = {};
			var branches = {};
			var total_stock = 0;
			var item_ref = $(cols[1]).get('text');
			for(var i=0,len=stocks.length;i<len;i++){
				var tmp = stocks[i].split(';');
				if(tmp[1] > 0){
					stock[tmp[0]] = tmp[1].toInt();
					branches[tmp[0]] = tmp[2];
					total_stock += tmp[1].toInt();
				}
			}
			if(cant > total_stock){
				messages.push("##NG_STOCK_EXCEEDED## ("+item_ref+" - ##NG_MAXIMUM##: "+total_stock+")");
				$(cols[3]).addClass('stock_exceeded');
			} else {
				$(cols[3]).removeClass('stock_exceeded');
			}
			for(var i=0,len=sel_stocks.length;i<len;i++){
				var tmp = sel_stocks[i].split(';');
				if(tmp[0] && tmp[1]){
					var this_stock = tmp[1].toInt();
				} else {
					var this_stock = 0;
				}
				if(this_stock > stock[tmp[0]]){
					messages.push("##NG_NO_STOCK## ("+item_ref+"/"+branches[tmp[0]]+" - ##NG_STOCK##: "+stock[tmp[0]]+")");
				}
			}
		}
	}

	if(messages.length > 0){
		$('messages').set('html',messages.join('<br>')).addClass('error').setStyle('display','block');
		if($('save_btn')) $('save_btn').setStyle('display','none');
	} else {
		$('messages').set('text','').setStyle('display','none').removeClass('error');
		if($('save_btn')) $('save_btn').setStyle('display','inline');
	}
}

function lockControls(){
	$('save_btn').setStyle('display','none');
	if($('save_pending_btn')) $('save_pending_btn').setStyle('display','none');
	if($('save_and_new')) $('save_and_new').setStyle('display','none');
}

function unlockControls(){
	$('save_btn').setStyle('display','inline');
	if($('save_pending_btn')) $('save_pending_btn').setStyle('display','inline');
	if($('save_and_new')) $('save_and_new').setStyle('display','inline');
}

function lockDescription(){
	var inputs = ['desc_input','qty_input'];
	for(var i=0,len=inputs.length; i<len; i++){
		if($(inputs[i])) $(inputs[i]).setStyle('display','none');
	}
}

function unlockDescription(){
	var inputs = ['desc_input','qty_input'];
	for(var i=0,len=inputs.length; i<len; i++){
		if($(inputs[i])) $(inputs[i]).setStyle('display','inline');
	}
}
