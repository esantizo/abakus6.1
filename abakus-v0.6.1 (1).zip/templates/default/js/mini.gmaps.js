(function(){

window.gMaps = function(options){
	var self = this;
	var firstStack = new actionStack({ 'bind': self });
	var readyStack = new actionStack({ 'bind': self });
	var marker_objs = {};
	var marker_arr = [];
	var loadedMarkers = 0;
	var totalMarkers = 0;
	var relational = false;
	var directionsRenderer = null;
	var directionsService = null;

	// http://code.google.com/intl/es-419/apis/maps/documentation/javascript/controls.html
	var defaultOptions = {
		'map_canvas': 'gmap',
		'region':'AR',
		'language':'es',
		'sensor':false,
		'mapStartPosition': 'mar del plata, argentina',
		'mapStartZoom': 13,
		'mapMaxZoom': 18,
		'mapMinZoom': 1,
		'panControl': false,
		'zoomControl': true,
		'mapTypeControl': true,
		'scaleControl': true,
		'streetViewControl': true,
		'overviewMapControl': true,
		'onLoadedMap': null,
		'onRenderedMap': null,
		'onLoadedMarkers': null
	};
	self.options = merge(defaultOptions,options);

	var boundTimer = null;
	var markers = [];

	self.googleMaps = null;
	self.map = null;
	self.geocoder = null;
	self.bounds = null;
	self.infoWindow = null;

	self.loaded = false;

	var loadScript = function(){
		if(google && typeof google.load != 'undefined'){
			google.load('maps',3,{
				'callback': function(){ __initialize(); },
				'language':self.options.language,
				'other_params': 'sensor='+(self.options.sensor?'true':'false')+'&region='+self.options.region+'&language='+self.options.language
			});
		} else {
			var script = document.createElement("script");
			script.type = "text/javascript";
			script.src = "https://www.google.com/jsapi";
			script.onload = function () {
				google.load('maps',3,{
					'callback': function(){ __initialize(); },
					'language':self.options.language,
					'other_params': 'sensor='+(self.options.sensor?'true':'false')+'&region='+self.options.region+'&language='+self.options.language
				});
			}
			document.head.appendChild(script);
		}
	}

	var __initialize = function(){
		this.loaded = true;
		firstStack.setAllowed(true);
		self.googleMaps = google.maps;
		self.geocoder = new google.maps.Geocoder();
		self.bounds = new google.maps.LatLngBounds();
		self.infoWindow = new google.maps.InfoWindow({
			'pixelOffset': new google.maps.Size(0,35,'px','px'),
			'disableAutoPan': false
		});
		if(typeof self.options.onLoadedMap == 'function'){
			self.options.onLoadedMap.call(self);
		}
	}

	loadScript.call(this);

	var parseXml = function(str) {
		if (window.ActiveXObject) {
			var doc = new ActiveXObject('Microsoft.XMLDOM');
			doc.loadXML(str);
			return doc;
		} else if (window.DOMParser) {
			return (new DOMParser).parseFromString(str, 'text/xml');
		}
	}

	this.renderMap = function(){
		firstStack.add('renderMap',function(){
			var mapCenter = null;
			if(self.options.mapStartPosition.match(/^\d+(\.\d+),\d+(\.\d+)$/)){
				var coords = self.options.mapStartPosition.split(',');
				mapCenter = new google.maps.LatLng(coords[0],coords[1]);
			}
			var myOptions = {
				center: mapCenter || new google.maps.LatLng(0,0),
				zoom: self.options.mapStartZoom,
				maxZoom: self.options.mapMaxZoom,
				minZoom: self.options.mapMinZoom,
				panControl: self.options.panControl,
				zoomControl: self.options.zoomControl,
				mapTypeControl: self.options.mapTypeControl,
				scaleControl: self.options.scaleControl,
				streetViewControl: self.options.streetViewControl,
				overviewMapControl: self.options.overviewMapControl,
				mapTypeId: google.maps.MapTypeId.ROADMAP,
				mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU}
			};
			self.map = new google.maps.Map($(self.options.map_canvas), myOptions);
			if(self.map && !mapCenter){
				self.geocoder.geocode({ 'language': self.options.language, 'address':self.options.mapStartPosition }, function(data,status){
					if(status=='OK' && data[0]){
						self.map.setCenter(data[0].geometry.location);
					}
				});
			}

			google.maps.event.addListener(self.map, 'tilesloaded', function() {
				readyStack.setAllowed(true);
				if(typeof self.options.onRenderedMap == 'function'){
					self.options.onRenderedMap.call(self);
				}
			});
		});
		return this;
	}

	this.markersLoaded = function(){
		if(loadedMarkers >= totalMarkers){
			return true;
		}
		return false;
	}

	this.getMarkers = function(){
		if(relational)
			return marker_objs;
		if(marker_arr.length > 0){
			return marker_arr;
		}
	}

	this.loadMarkersFromXml = function(xml_str){
		xml = parseXml(xml_str);
		var markerNodes = xml.documentElement.getElementsByTagName('marker');

		for(var i=0; i < markerNodes.length; i++){
			var marker = {};
			var atts = markerNodes[i].attributes;
			for(var j=0,len=atts.length; j<len; j++){
				marker[atts[j].name] = atts[j].value;
			}
			markers[markers.length] = marker;
		}
		return self.loadMarkers(markers);
	}

	this.loadMarkers = function(markers_json){
		markers = markers_json;
		marker_arr = [];
		marker_objs = {};
		totalMarkers = 0;
		loadedMarkers = 0;
		readyStack.add('loadMarkers',function(){
			for(var i=0; i < markers_json.length; i++){
				var myData = {
					'region': self.options.region,
					'address': markers_json[i].address
				};

				totalMarkers++;

				self.geocoder.geocode(myData, (function(marker,index){
					return function(data,status) {
						if(status=='OK' && data[0]){
							mapMarker = new google.maps.Marker({
								'clickable': true,
								'map': self.map,
								'position': data[0].geometry.location,
								'title': marker.title,
								'animation': google.maps.Animation.DROP,
								'visible': (marker.visible?true:false),
								'draggable': (marker.draggable?true:false)
							});
							mapMarker.center = function(){
								self.map.setCenter(this.getPosition());
							};
							if(marker.info){
								(function(map_obj,mapMarker){
									google.maps.event.addListener(mapMarker, 'click', function() {
										self.infoWindow.setContent(marker.info);
										self.infoWindow.open(map_obj,mapMarker);
									});
								})(self.map,mapMarker);
							}
							if(marker.rel){
								marker_objs[marker.rel] = mapMarker;
								relational = true;
							}
							if(self.options.markerEvents){
								for(var i in self.options.markerEvents){
									google.maps.event.addListener(mapMarker, i, self.options.markerEvents[i]);
								}
							}
							marker_arr[marker_arr.length] = mapMarker;
							self.bounds.extend(data[0].geometry.location);
						}
						loadedMarkers++;
						if(self.markersLoaded() && typeof self.options.onLoadedMarkers == 'function'){
							directionsRenderer = new google.maps.DirectionsRenderer( {'draggable':false} );
							directionsRenderer.setMap(self.map);
							directionsService = new google.maps.DirectionsService();
							self.map.fitBounds(self.bounds);
							self.options.onLoadedMarkers.call(self);
						}
					};
				})(markers_json[i],i));
			}
		});
		return this;
	}

	this.renderDirections = function(points,panel){
		var waypoints = [];
		for(var i=1,len=points.length-1;i<len;i++){
			waypoints[waypoints.length] = { 'location': points[i], 'stopover': true };
		}
		directionsService.route({
			'origin': points[0],
			'destination':  points[points.length-1],
			'travelMode': google.maps.DirectionsTravelMode.DRIVING,
			'waypoints': waypoints
		}, function(res,sts) {
			if(sts=='OK'){
				if($(panel)){
					directionsRenderer.setPanel($(panel));
				}
				directionsRenderer.setOptions({
					'directions': res,
					'draggable': true,
					'infoWindow': self.infoWindow,
					'suppressMarkers': false,
					'suppressInfoWindows': false
				});
			}
		});
		return this;
	}

	return this;
}

})();
