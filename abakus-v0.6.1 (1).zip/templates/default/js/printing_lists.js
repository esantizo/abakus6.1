function updateList(){
	var error = false;
	if($('client_checked') && $('client_checked').value==0){
		msgBox("##NG_EMPTY_CLIENT##");
		error = true;
	}
	if($('provider_checked') && $('provider_checked').value==0){
		msgBox("##NG_EMPTY_PROVIDER##");
		error = true;
	}
	if(!error) $('form_filters').submit();
}

function printList(){
	$('form_filters').set({ 'action': $('form_filters').get('action') + '&print=1', 'target':'_blank' });
	$('form_filters').submit();
}

function searchClient(id){
	Request({
		'url':'ajax/search_client.php',
		'method':'post',
		'data':'id='+id,
		'onSuccess':function(response){
			var res = eval('('+response+')');
			if(res.name){
				$('client').set('rel',id);
				$('client_name').set('text',res.name);
				$('client_checked').value = 1;
				setFocus('from_date');
			} else {
				msgBox("##NG_WRONG_CLIENT##");
				$('client_checked').value = 0;
				setFocus('client');
			}
		}
	});
}

function searchSalesman(id){
	Request({
		'url':'ajax/search_salesman.php',
		'method':'post',
		'data':'id='+id,
		'onSuccess':function(response){
			var res = eval('('+response+')');
			if(res.name){
				$('salesman').set('rel',id);
				$('salesman_name').set('text',res.name);
				$('salesman_checked').value = 1;
				setFocus('from_date');
			} else {
				msgBox("##NG_WRONG_SALESMAN##");
				$('salesman_checked').value = 0;
				setFocus('salesman');
			}
		}
	});
}

function searchNote(id){
	Request({
		'url':'ajax/search_notes.php',
		'method':'post',
		'data':'id='+id,
		'onSuccess':function(response){
			var res = eval('('+response+')');
			if(res.id){
				var qty = promptBox('##NG_INSERT_QUANTITY##').toInt();
				if(qty > 0){
					$('selected_notes').adopt(
						new Element('li')
							.adopt(new Element('img',{ src:'##IMG_DELETE##',width:16,height:16,styles:{ 'cursor':'pointer','vertical-align':'middle' },events:{ 'click':function(){ this.getParent('li').destroy(); } } }))
							.adopt(new Element('text', ' '+res.name+' ('+qty+')'))
							.adopt(new Element('input',{ type:'hidden',name:'notes_items[]',value:res.id }))
							.adopt(new Element('input',{ type:'hidden',name:'notes_items_qty[]',value:qty }))
					);
				}
			} else {
				msgBox("##NG_WRONG_NOTE##");
			}
		}
	});
}

function toggleButtonSet(el,val){
	var parent = el.getParent();
	var input = parent.getFirst('input');
	var btn = parent.getFirst('img');
	if((input.value==1 && val===null) || (val!==null && val!=1)){
		input.value=0;
		btn.removeClass('selected');
	} else {
		input.value=1;
		btn.addClass('selected');
	}
}

$$('#list_filters .toggleButton').each(function(el){
	el.addEvent('click',function(){
		toggleButtonSet(this,null);
	});

	var input = el.getParent().getFirst('input');
	if(input.value==1){
		el.addClass('selected');
	} else {
		el.removeClass('selected');
	}
});

function loadFavorite(type,id){
	if($('favorite_'+id)){
		var data = parseJSON($('favorite_'+id).get('alt'));
		if(data){
			if(type=='clients'){
				$('client').value = data.id_client;
				if(data.date_type=='range'){
					$('date_type_range').checked = true;
					$('date_range').setStyle('display','block');
					$('date_period').setStyle('display','none');
				} else {
					$('date_type_period').checked = true;
					$('date_range').setStyle('display','none');
					$('date_period').setStyle('display','block');
				};
				$('period_date').value = data.date_period;
				$('from_date').value = data.date_from;
				$('to_date').value = data.date_to;
				$('balance_currency').setSelected(data.balance_currency);
				toggleButtonSet($('opt_account'),data.opt_account);
				toggleButtonSet($('opt_quotes'),data.opt_quotes);
				toggleButtonSet($('opt_invoices'),data.opt_invoices);
				toggleButtonSet($('opt_receipts'),data.opt_receipts);
				toggleButtonSet($('opt_contacts'),data.opt_contacts);
				searchClient($('client').value);
			} else if(type=='providers'){
				$('provider').value = data.id_provider;
				if(data.date_type=='range'){
					$('date_type_range').checked = true;
					$('date_range').setStyle('display','block');
					$('date_period').setStyle('display','none');
				} else {
					$('date_type_period').checked = true;
					$('date_range').setStyle('display','none');
					$('date_period').setStyle('display','block');
				};
				$('period_date').value = data.date_period;
				$('from_date').value = data.date_from;
				$('to_date').value = data.date_to;
				$('balance_currency').setSelected(data.balance_currency);
				toggleButtonSet($('opt_account'),data.opt_account);
				toggleButtonSet($('opt_quotes'),data.opt_quotes);
				toggleButtonSet($('opt_invoices'),data.opt_invoices);
				toggleButtonSet($('opt_receipts'),data.opt_receipts);
				toggleButtonSet($('opt_contacts'),data.opt_contacts);
				searchProvider($('provider').value);
			} else if(type=='salesmen'){
				$('salesman').value = data.id_salesman;
				if(data.date_type=='range'){
					$('date_type_range').checked = true;
					$('date_range').setStyle('display','block');
					$('date_period').setStyle('display','none');
				} else {
					$('date_type_period').checked = true;
					$('date_range').setStyle('display','none');
					$('date_period').setStyle('display','block');
				};
				$('period_date').value = data.date_period;
				$('from_date').value = data.date_from;
				$('to_date').value = data.date_to;
				$('balance_currency').setSelected(data.balance_currency);
				toggleButtonSet($('opt_sales'),data.opt_sales);
				searchSalesman($('salesman').value);
			} else if(type=='labels'){
				$('selected_labels').empty();
				data.each(function(e){
					$('selected_labels').adopt(new Element('li')
						.adopt(new Element('img',{ src:'##IMG_DELETE##',width:16,height:16,styles:{ 'cursor':'pointer','vertical-align':'middle' },events:{ 'click':function(){ $(this).getParent('li').destroy(); } } }))
						.adopt(new Element('text',e.item_name))
						.adopt(new Element('input',{ 'type':'hidden','name':'labels_items[]','value':e.item_id }))
						.adopt(new Element('input',{ 'type':'hidden','name':'labels_items_qty[]','value':e.qty }))
					);
				});
			} else if(type=='shipping_labels'){
				$('selected_shipping_labels').empty();
				data.each(function(e){
					$('selected_shipping_labels').adopt(new Element('li')
						.adopt(new Element('img',{ src:'##IMG_DELETE##',width:16,height:16,styles:{ 'cursor':'pointer','vertical-align':'middle' },events:{ 'click':function(){ $(this).getParent('li').destroy(); } } }))
						.adopt(new Element('text',e.item_name))
						.adopt(new Element('input',{ 'type':'hidden','name':'shipping_labels_items[]','value':e.item_id }))
						.adopt(new Element('input',{ 'type':'hidden','name':'shipping_labels_items_qty[]','value':e.qty }))
					);
				});
			} else if(type=='notes'){
				$('selected_notes').empty();
				data.each(function(e){
					$('selected_notes').adopt(new Element('li')
						.adopt(new Element('img',{ src:'##IMG_DELETE##',width:16,height:16,styles:{ 'cursor':'pointer','vertical-align':'middle' },events:{ 'click':function(){ $(this).getParent('li').destroy(); } } }))
						.adopt(new Element('text',e.item_name))
						.adopt(new Element('input',{ 'type':'hidden','name':'notes_items[]','value':e.item_id }))
						.adopt(new Element('input',{ 'type':'hidden','name':'notes_items_qty[]','value':e.qty }))
					);
				});
			}
		}
	}
}

function saveFavorite(type,name){
	if(name){
		if(type=='clients'){
			var data = {
				'id_client': $('client').value.toInt(),
				'date_type': ($('date_type_range').checked?'range':'period'),
				'date_period': $('period_date').value.toInt(),
				'date_from': $('from_date').value,
				'date_to': $('to_date').value,
				'balance_currency': $('balance_currency').value.toInt(),
				'opt_account': $('opt_account').value.toInt(),
				'opt_quotes': $('opt_quotes').value.toInt(),
				'opt_invoices': $('opt_invoices').value.toInt(),
				'opt_receipts': $('opt_receipts').value.toInt(),
				'opt_contacts': $('opt_contacts').value.toInt()
			};
		} else if(type=='providers'){
			var data = {
				'id_provider': $('provider').value.toInt(),
				'date_type': ($('date_type_range').checked?'range':'period'),
				'date_period': $('period_date').value.toInt(),
				'date_from': $('from_date').value,
				'date_to': $('to_date').value,
				'balance_currency': $('balance_currency').value.toInt(),
				'opt_account': $('opt_account').value.toInt(),
				'opt_quotes': $('opt_quotes').value.toInt(),
				'opt_invoices': $('opt_invoices').value.toInt(),
				'opt_receipts': $('opt_receipts').value.toInt(),
				'opt_contacts': $('opt_contacts').value.toInt()
			};
		} else if(type=='salesmen'){
			var data = {
				'id_salesman': $('salesman').value.toInt(),
				'date_type': ($('date_type_range').checked?'range':'period'),
				'date_period': $('period_date').value.toInt(),
				'date_from': $('from_date').value,
				'date_to': $('to_date').value,
				'balance_currency': $('balance_currency').value.toInt(),
				'opt_sales': $('opt_sales').value.toInt()
			};
		} else if(type=='labels') {
			var data = [];
			$$('#selected_labels li').each(function(el){
				var inputs = el.getElements('input');
				data.push({ 'item_name':el.get('text'),'item_id':inputs[0].value.toInt(),'qty':inputs[1].value.toInt() });
			});
		} else if(type=='shipping_labels') {
			var data = [];
			$$('#selected_shipping_labels li').each(function(el){
				var inputs = el.getElements('input');
				data.push({ 'item_name':el.get('text'),'item_id':inputs[0].value.toInt(),'qty':inputs[1].value.toInt() });
			});
		} else if(type=='notes') {
			var data = [];
			$$('#selected_notes li').each(function(el){
				var inputs = el.getElements('input');
				data.push({ 'item_name':el.get('text'),'item_id':inputs[0].value.toInt(),'qty':inputs[1].value.toInt() });
			});
		}
		var jsondata = JSON.stringify(data);
		Request({
			'method':'post',
			'url':'ajax/printing_list_favorites.php',
			'data':{ 'action':'save', 'type':type, 'name':name, 'data': jsondata },
			'onSuccess': function(result){
				if(result == 'ok'){
					msgBox('##NG_FAVORITE_SAVED_OK##');
					refreshFavorites(type);
				} else {
					msgBox(result);
				}
			}
		});
	}
}

function deleteFavorite(type,id){
	id = id.toInt();
	if(id > 0){
		Request({
			'method':'post',
			'url':'ajax/printing_list_favorites.php',
			'data':{ 'action':'delete', 'type':type, 'id':id },
			'onSuccess': function(result){
				if(result == 'ok'){
					refreshFavorites(type);
					$('favorites').click();
				} else {
					msgBox(result);
				}
			}
		});
	}
}

function refreshFavorites(type){
	Request({
		'method':'post',
		'url':'ajax/printing_list_favorites.php',
		'data':{ 'action':'list', 'type': type },
		'onSuccess': function(result){
			var res = parseJSON(result);
			if(res){
				$('favorites').empty();
				res.each(function(el){
					$('favorites').adopt(
						new Element('li',{
							'id': 'favorite_'+el.id,
							'class': (el.id==$('sel_favorite').value.toInt()?'selected':''),
							'alt': el.data,
							'text': el.name
						}).addEvent('click',function(ev){
							var parts = this.get('id').split('_');
							$('sel_favorite').value = parts[1];
							$('sel_favorite_name').value = this.get('text');
							$$('#favorites li').removeClass('selected');
							this.addClass('selected');
							$('favorites_load').disabled = false;
							$('favorites_load').removeClass('disabled');
							$('favorites_save').disabled = false;
							$('favorites_save').removeClass('disabled');
							$('favorites_delete').disabled = false;
							$('favorites_delete').removeClass('disabled');
							ev.stopPropagation();
						})
					);
				});
			}
		}
	});
}

if($('favorites')){
	refreshFavorites(type);

	$('favorites').addEvent('click',function(){
		$('sel_favorite').value = 0;
		$('sel_favorite_name').value = '';
		$$('#favorites li').removeClass('selected');
		$('favorites_load').disabled = true;
		$('favorites_load').addClass('disabled');
		$('favorites_save').disabled = true;
		$('favorites_save').addClass('disabled');
		$('favorites_delete').disabled = true;
		$('favorites_delete').addClass('disabled');
	});

	$('favorites_load').addEvent('click',function(){
		if(!this.disabled){
			loadFavorite(type,$('sel_favorite').value)
		}
	});
	$('favorites_save').addEvent('click',function(){
		if(!this.disabled){
			var name = $('sel_favorite_name').value;
			if(name == ''){
				name = promptBox('##NG_FAVORITE_NAME##');
			} else {
				if(!confirmBox('##NG_OVERWRITE_FAVORITE##')){
					return false;
				}
			}
			saveFavorite(type,name);
		}
	});
	$('favorites_save_as').addEvent('click',function(){
		if(!this.disabled){
			var name = promptBox('##NG_FAVORITE_NAME##');
			saveFavorite(type,name);
		}
	});
	$('favorites_delete').addEvent('click',function(){
		if(!this.disabled){
			if(confirmBox('##NG_CONFIRM_DELETE_FAVORITE##'))
				deleteFavorite(type,$('sel_favorite').value);
		}
	});

	if($('sel_favorite').value.toInt() > 0){
		$('favorites_load').disabled = false;
		$('favorites_load').removeClass('disabled');
		$('favorites_save').disabled = false;
		$('favorites_save').removeClass('disabled');
		$('favorites_delete').disabled = false;
		$('favorites_delete').removeClass('disabled');
	} else {
		$('favorites_load').disabled = true;
		$('favorites_load').addClass('disabled');
		$('favorites_save').disabled = true;
		$('favorites_save').addClass('disabled');
		$('favorites_delete').disabled = true;
		$('favorites_delete').addClass('disabled');
	}
}

if($('client') && $('client').value > 0){
	searchClient($('client').value);
}
if($('provider') && $('provider').value > 0){
	searchProvider($('provider').value);
}
if($('salesman') && $('salesman').value > 0){
	searchSalesman($('salesman').value);
}

if($('date_type_period') && $('date_type_range')){
	$('date_type_period').addEvent('click',function(){
		$('date_range').setStyle('display','none');
		$('date_period').setStyle('display','block');
	});
	$('date_type_range').addEvent('click',function(){
		$('date_range').setStyle('display','block');
		$('date_period').setStyle('display','none');
	});
	if($('date_type_period').checked){
		$('date_range').setStyle('display','none');
		$('date_period').setStyle('display','block');
	};
	if($('date_type_range').checked){
		$('date_range').setStyle('display','block');
		$('date_period').setStyle('display','none');
	};
}

if($('salesman')) $('salesman').addEvent('keydown',function(ev){
	if(ev.keyCode==13){
		if(!isNaN(this.value)){
			if(this.value===''){
				openSearchSalesmanBox();
			} else {
				searchSalesman(this.value);
			}
		} else {
			openSearchSalesmanBox();
		}
	}
}).addEvent('blur',function(){
	if(!isNaN(this.get('rel')))
		this.value = this.get('rel');
});

var search_product = new SearchItemsBox({
	returnField: 'id',
	returnContainer: null,
	secondaryField: null,
	secondaryFieldContainer: null,
	fields: [ 'id','reference','name','short_description','stock' ],
	bindButtonEvents: [ 'search_item_btn' ],
	onOpen: null,
	onClose: null,
	onSelect: function(item){
		if(item.id){
			var qty = promptBox('##NG_INSERT_QUANTITY##').toInt();
			if(qty > 0){
				var text = '';
				if(item.reference.length > 0){
					text = item.reference;
				} else if(item.name.length > 0){
					text = item.name;
				} else if (item.short_description.length > 0) {
					text = item.short_description;
				}
				var li = new Element('li').inject('selected_labels');
				new Element('img',{ src:'##IMG_DELETE##',width:16,height:16,styles:{ 'cursor':'pointer','vertical-align':'middle' },events:{ 'click':function(){ this.getParent('li').destroy(); } } }).inject(li);
				new Element('text', ' '+text+' ('+qty+')').inject(li);
				new Element('input',{ type:'hidden',name:'labels_items[]',value:item.id }).inject(li);
				new Element('input',{ type:'hidden',name:'labels_items_qty[]',value:qty }).inject(li);
			}
		} else {
			msgBox("##NG_WRONG_PRODUCT##");
		}
	}
});

var shipping_labels = new SearchItemsBox({
	requestUrl: 'ajax/search_client.php',
	returnField: 'id',
	returnContainer: null,
	secondaryField: null,
	secondaryFieldContainer: null,
	defaultValueContainer: null,
	fields: [ 'id','name','taxpayer_id','address','city','state' ],
	bindInputEvents: null,
	bindButtonEvents: [ 'add_shipping_label_btn' ],
	onOpen: null,
	onClose: null,
	onSelect: function(item){
		if(item.id){
			var qty = promptBox('##NG_INSERT_QUANTITY##').toInt();
			if(qty > 0){
				var text = item.name;
				var li = new Element('li').inject('selected_shipping_labels');
				new Element('img',{ src:'##IMG_DELETE##',width:16,height:16,styles:{ 'cursor':'pointer','vertical-align':'middle' },events:{ 'click':function(){ this.getParent('li').destroy(); } } }).inject(li);
				new Element('text', ' '+text+' ('+qty+')').inject(li);
				new Element('input',{ type:'hidden',name:'shipping_labels_items[]',value:item.id }).inject(li);
				new Element('input',{ type:'hidden',name:'shipping_labels_items_qty[]',value:qty }).inject(li);
			}
		} else {
			msgBox("##NG_WRONG_PRODUCT##");
		}
	}
});

if(type=='shipping_labels'){
	$(window).addEvent('keydown',function(ev){
		if(ev.keyCode==107 || ev.keyCode==187){
			shipping_labels.open();
		}
	});
}
