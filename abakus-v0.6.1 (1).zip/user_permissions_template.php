<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = "user_permissions.php";
	$module_name = 'users';
	// We load the module
	$module = loadModule($module_name,$db);

	$_GET['loaded'] = (int)$_GET['loaded'];

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	if($_POST['save_template']){
		$permissions = $_POST['permissions'];
		foreach ($menu as $r){
			$permissions[$r['id']]['read'] = ($_POST['permissions'][$r['id']]['read']?1:0);
			$permissions[$r['id']]['write'] = ($_POST['permissions'][$r['id']]['write']?1:0);
			foreach ($r['submenus'] as $r2){
				$permissions[$r2['id']]['read'] = ($_POST['permissions'][$r2['id']]['read']?1:0);
				$permissions[$r2['id']]['write'] = ($_POST['permissions'][$r2['id']]['write']?1:0);
			}
		}

		$permissions_json = json_encode($permissions);
		$name = $db->escape_string($_POST['template_name']);
		if(!empty($name)){
			$db->insert("
				INSERT INTO user_permissions_templates SET
					name='$name',
					data='{$permissions_json}'
				ON DUPLICATE KEY UPDATE
					name='$name',
					data='{$permissions_json}'
			");
		}
		redirect('user_permissions_template.php?id='.$_GET['id']);
	}


	$id = (int)$_GET['id'];
	$template = $db->fetch_item("SELECT * FROM user_permissions_templates WHERE id=$id");
	if(!$template) die();

	$permissions = json_decode($template['data'],true);

	$smarty->assign('template',$template);
	$smarty->assign('uid',$uid);
	$smarty->assign('permissions',$permissions);
	$smarty->assign('loaded',$_GET['loaded']);
	$smarty->assign('templates',$templates);

	$smarty->display('user_permissions_template.tpl');
?>