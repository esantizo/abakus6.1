<?php
	$login = true;
	require 'inc/config.php';
	require 'inc/smarty.php';

	if(isset($_GET['logout'])){
		session_destroy();
		setcookie($autologin_cookie_name, "", time() - 3600, "/");
		unset($_COOKIE[$autologin_cookie_name]);
		redirect('login.php');
	}

	if(isset($_POST['login_username_abk'])){
		$user = $_POST['login_username_abk'];
		$password = sha1($_POST['login_password_abk']);
		$login_user = new User($db, $user, $password);

		if($login_user && $login_user->isValid()){
			$_SESSION['username'] = $user;
			$_SESSION['password'] = $password;

			$db->update("UPDATE users SET last_login=NOW() WHERE id=".$login_user->getId());

			if($_POST['login_remember_me_abk']) {
				$password_hash = sha1($password.sha1($autologin_salt).$_SERVER['REMOTE_ADDR']);
				$cookie_info = 'usr='.$login_user->getId().'&hash='.$password_hash;
				setcookie($autologin_cookie_name, $cookie_info , time() + $autologin_cookie_time, '/');
			}
			redirect('index.php');
		} else {
			$error = __("##NG_INCORRECT_LOGIN##");
		}
	}

	$smarty->assign('error',$error);
	$smarty->display('login.tpl');
?>