<?php
	include 'inc/config.php';
	include 'inc/functions_invoices.php';
	include 'inc/class.pager.php';

	$thispage = 'sales.php';

	$module_name = 'invoices';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	if($_GET['from_quote']){
		$quote_id = (int)$_GET['from_quote'];
		$quote = $db->fetch_item("SELECT * FROM quotes WHERE id=$quote_id LIMIT 1");
		if($quote){
			$quote_items = $db->fetch_all("SELECT * FROM quote_items WHERE id_quote=$quote_id");
			$invoice_type = $db->fetch_item_field("SELECT id FROM invoice_types ORDER BY `default` DESC,id ASC");
			$invoice_number = max(1,$db->fetch_item_field("SELECT (MAX(number)+1) FROM invoices"));

			$iid = $db->insert("
				INSERT INTO invoices SET
					invoice_type='$invoice_type',
					number='$invoice_number',
					`date`=NOW(),
					due_date=DATE_ADD(NOW(),INTERVAL 30 DAY),
					salesman='{$quote['salesman']}',
					client_id='{$quote['client_id']}',
					client_name='{$quote['client_name']}',
					client_address='{$quote['client_address']}',
					client_taxpayer_id='{$quote['client_taxpayer_id']}',
					client_postcode='{$quote['client_postcode']}',
					client_city='{$quote['client_city']}',
					client_state='{$quote['client_state']}',
					client_country='{$quote['client_country']}',
					id_tax_condition='{$quote['id_tax_condition']}',
					id_payment_type='{$quote['id_payment_type']}',
					id_price_scale='{$quote['id_price_scale']}',
					id_currency='{$quote['id_currency']}',
					currencies='{$quote['currencies']}',
					subtotal='{$quote['subtotal']}',
					discount='{$quote['discount']}',
					taxes='{$quote['taxes']}',
					total='{$quote['total']}',
					notes='{$quote['notes']}',
					pending=1,
					payed=0,
					amount_payed=0,
					id_quote='$quote_id'
			");
			$db->update("UPDATE quotes SET id_invoice=$iid WHERE id=$quote_id");
			foreach($quote_items as $qi){
				$db->insert("
					INSERT INTO invoice_items SET
					id_invoice=$iid,
					id_product={$qi['id_product']},
					reference='{$qi['reference']}',
					description='{$qi['description']}',
					quantity='{$qi['quantity']}',
					selected_stock='',
					price='{$qi['price']}',
					tax='{$qi['tax']}',
					total='{$qi['total']}'
				");
			}

			consolidateInvoice($quote['client_id'],$iid);

			redirect("invoice_edit.php?id=$iid");
		}
	}

	if($_GET['from_dispatch_note']){
		$dispatch_note_id = (int)$_GET['from_dispatch_note'];
		$dispatch_note = $db->fetch_item("SELECT * FROM dispatch_notes WHERE id=$dispatch_note_id LIMIT 1");
		if($dispatch_note){
			if($dispatch_note['client_id'] > 0){
				$client = $db->fetch_item("SELECT * FROM clients WHERE id='{$dispatch_note['client_id']}'");
				$id_price_scale = $client['id_price_scale'];
				$id_currency = $client['credit_limit_currency'];
			} else {
				$id_price_scale = $db->fetch_item_field("SELECT id FROM price_scales ORDER BY `default` DESC,id LIMIT 1");
				$id_currency = $db->fetch_item_field("SELECT id FROM currency ORDER BY `default` DESC,id LIMIT 1");
			}
			$dispatch_note_items = $db->fetch_all("SELECT * FROM dispatch_note_items WHERE id_dispatch_note=$dispatch_note_id");
			$invoice_type = $db->fetch_item_field("SELECT id FROM invoice_types ORDER BY `default` DESC,id ASC");
			$invoice_number = max(1,$db->fetch_item_field("SELECT (MAX(number)+1) FROM invoices"));

			$currencies_arr = $db->fetch_all("SELECT * FROM currency",'rate','id');
			$currencies = stringifyCurrencies($currencies_arr);

			$iid = $db->insert("
				INSERT INTO invoices SET
					invoice_type='$invoice_type',
					number='$invoice_number',
					`date`=NOW(),
					due_date=DATE_ADD(NOW(),INTERVAL 30 DAY),
					salesman='{$dispatch_note['salesman']}',
					client_id='{$dispatch_note['client_id']}',
					client_name='{$dispatch_note['client_name']}',
					client_address='{$dispatch_note['client_address']}',
					client_taxpayer_id='{$dispatch_note['client_taxpayer_id']}',
					client_postcode='{$dispatch_note['client_postcode']}',
					client_city='{$dispatch_note['client_city']}',
					client_state='{$dispatch_note['client_state']}',
					client_country='{$dispatch_note['client_country']}',
					id_tax_condition='{$client['id_tax_condition']}',
					id_payment_type='{$client['id_payment_type']}',
					id_price_scale='{$id_price_scale}',
					id_currency='$id_currency',
					currencies='$currencies',
					subtotal='',
					discount=0,
					taxes='',
					total='',
					notes='{$dispatch_note['notes']}',
					pending=1,
					payed=0,
					amount_payed=0,
					from_dispatch_note=1,
					id_dispatch_note='$dispatch_note_id'
			");
			$db->update("UPDATE dispatch_notes SET id_invoice=$iid WHERE id=$dispatch_note_id");
			$grand_subtotal = 0;
			$taxes = array();
			$taxes_total = 0;
			$grand_total = 0;
			foreach($dispatch_note_items as $di){
				$product = $db->fetch_item("
					SELECT p.*,
						pp.price AS price,
						t.percentage AS tax_percentage
					FROM products AS p
					JOIN products_prices AS pp
						ON pp.id_product=p.id
						AND pp.id_price_scale={$id_price_scale}
					LEFT JOIN taxes AS t
						ON t.id=p.id_tax
					WHERE p.id='{$di['id_product']}'
				");
				if($product['id_currency'] != id_currency){
					$multiplier = $currencies_arr[$product['id_currency']] / $currencies_arr[$id_currency];
					$price = float($product['price']) / $multiplier;
				} else {
					$price = float($product['price']);
				}
				$tax = float($product['tax_percentage']);
				$total = $di['quantity'] * $price;
				$db->insert("
					INSERT INTO invoice_items SET
					id_invoice=$iid,
					id_product={$di['id_product']},
					reference='{$di['reference']}',
					description='{$di['description']}',
					quantity='{$di['quantity']}',
					selected_stock='',
					price='$price',
					tax='$tax',
					total='$total'
				");
				$grand_subtotal += $total;
				$taxes[$tax] += round($tax / 100 * $price,4);
				$total_taxes += round($tax / 100 * $price,4);
				$grand_total += ($total+round($tax / 100 * $price,4));
			}
			$grand_subtotal = round($grand_subtotal,4);
			$grand_total = round($grand_total,4);
			$taxes_str = stringifyTaxes($taxes);
			$db->update("UPDATE invoices SET subtotal='$grand_subtotal', taxes='$taxes_str', total='$grand_total' WHERE id=$iid LIMIT 1");

			consolidateInvoice($dispatch_note['client_id'],$iid);

			redirect("invoice_edit.php?id=$iid");
		}
	}

	if($_POST['save']){
		$pending = ($_POST['save']=='pending'?1:0);
		$number = (int)$_POST['number'];
		$date = date2db($_POST['date'],$date_format);
		$salesman = (int)$_POST['salesman'];
		$invoice_type = (int)$_POST['invoice_type'];
		$client = (int)$_POST['client'];
		$client_name = $db->escape_string($_POST['client_name']);
		$client_address = $db->escape_string($_POST['client_address']);
		$client_taxpayer_id = $db->escape_string($_POST['client_taxpayer_id']);
		$client_city = $db->escape_string($_POST['client_city']);
		$client_state = $db->escape_string($_POST['client_state']);
		$client_country = $db->escape_string($_POST['client_country']);
		$client_postcode = $db->escape_string($_POST['client_postcode']);
		$client_tax_condition = (int)$_POST['client_tax_condition'];
		$client_payment_type = (int)$_POST['client_payment_type'];
		$client_price_scale = (int)$_POST['client_price_scale'];
		$id_currency = (int)$_POST['currency'];
		if(is_array($_POST['currency_rates'])){
			$currencies = stringifyCurrencies($_POST['currency_rates']);
		}
		$subtotal = float($_POST['subtotal']);
		if(is_array($_POST['total_taxes'])){
			$taxes = stringifyTaxes($_POST['total_taxes']);
		}
		$discount = float($_POST['discount']);
		$total = float($_POST['total']);
		$notes = $db->escape_string($_POST['notes']);

		// The invoice has items
		if(is_array($_POST['ref'])){
			$invoice_id = $db->insert("
				INSERT INTO invoices SET
					invoice_type='$invoice_type',
					number='$number',
					`date`='$date',
					due_date=DATE_ADD('$data',INTERVAL 30 DAY),
					salesman='$salesman',
					client_id='$client',
					client_name='$client_name',
					client_address='$client_address',
					client_taxpayer_id='$client_taxpayer_id',
					client_city='$client_city',
					client_postcode='$client_postcode',
					client_state='$client_state',
					client_country='$client_country',
					id_tax_condition='$client_tax_condition',
					id_payment_type='$client_payment_type',
					id_price_scale='$client_price_scale',
					id_currency='$id_currency',
					currencies='$currencies',
					subtotal='$subtotal',
					taxes='$taxes',
					discount='$discount',
					total='$total',
					pending=$pending,
					notes='$notes'
			");
			if($invoice_id){
				foreach($_POST['ref'] as $k => $ref){
					$product_id = (int)$_POST['product_id'][$k];
					$ref = $db->escape_string($ref);
					$desc = $db->escape_string($_POST['desc'][$k]);
					$qty = $db->escape_string($_POST['qty'][$k]);
					$price = $db->escape_string($_POST['price'][$k]);
					$tax = $db->escape_string($_POST['tax'][$k]);
					$item_total = $db->escape_string($_POST['item_total'][$k]);
					$selected_stock = $db->escape_string($_POST['sel_stock'][$k]);
					$db->insert("
						INSERT INTO invoice_items SET
							id_invoice=$invoice_id,
							id_product=$product_id,
							reference='$ref',
							description='$desc',
							quantity='$qty',
							selected_stock='$selected_stock',
							price='$price',
							tax='$tax',
							total='$item_total'
					");
					if(!$pending){
						$sel_stock = explode('|',$_POST['sel_stock'][$k]);
						if(is_array($sel_stock)){
							foreach($sel_stock as $st){
								list($id,$qty) = explode(';',$st);
								if((int)$id > 0 && (int)$qty > 0){
									$db->insert("INSERT INTO products_stock SET
										id_product=$product_id,
										id_location=".(int)$id.",
										quantity=(".(int)$qty." * -1),
										relation='invoice|$invoice_id'
									");
								}
							}
						} else {
						}
					}

					// Insert invoice in account
					consolidateInvoice($client,$invoice_id);
				}

				redirect("invoice_details.php?id=$invoice_id");
			}

			// INSERT error
			else{
				//echo $db->error();
			}

		}

		// The invoice doesn't have any item
		else {
		}
	}

	$salesmen = $db->fetch_all("
		SELECT u.*, IF(u.id='{$user->getId()}','selected=\"selected\"','') AS selected
		FROM users AS u
		WHERE u.can_sell=1
			AND deleted=0
	");
	$invoice_number = max(1,$db->fetch_item_field("SELECT (MAX(number)+1) FROM invoices"));
	$tax_values = $db->fetch_all("SELECT percentage FROM taxes ORDER BY percentage",'percentage');
	$currency = $db->fetch_all("SELECT * FROM currency ORDER BY rate");

	$price_scale = $db->fetch_item("SELECT id,name FROM price_scales ORDER BY `default` DESC,id DESC LIMIT 1");
	$tax_conditions = $db->fetch_all("SELECT * FROM tax_conditions ORDER BY name");
	$payment_types = $db->fetch_all("SELECT * FROM payment_types ORDER BY name");
	$invoice_types = $db->fetch_all("SELECT * FROM invoice_types ORDER BY `default` DESC,name");

	switch($config['invoice_search_field']){
		case 'internal_code': $first_field = __("Internal Code"); break;
		case 'manufacturers_code': $first_field = __("Manufacturers Code"); break;
		default: $first_field = __("Reference");
	}

	$return_url = return_to_module_url($module_name);

	$smarty->assign('return_url',$return_url);
	$smarty->assign('tax_conditions',$tax_conditions);
	$smarty->assign('payment_types',$payment_types);
	$smarty->assign('invoice_types',$invoice_types);
	$smarty->assign('invoice_number',$invoice_number);
	$smarty->assign('price_scale',$price_scale);
	$smarty->assign('currency',$currency);
	$smarty->assign('salesmen',$salesmen);
	$smarty->assign('first_field',$first_field);
	$smarty->assign('tax_values',implode(',',$tax_values));
	$smarty->assign('ignore_stock',($config['ignore_stock']?1:0));

	$smarty->display('sales.tpl');
?>
