function selectAll(){
	$$('#import_table tbody input[type="checkbox"]').set('checked',true);
}
function deselectAll(){
	$$('#import_table tbody input[type="checkbox"]').set('checked',false);
}
function invertSelection(){
	$$('#import_table tbody input[type="checkbox"]').each(function(el){
		el.set('checked',!el.get('checked'));
	});
}

function fieldExists(field){
	var ret = false;
	$$('#import_table thead select').each(function(el){
		if(el.getSelected().value == field){
			ret = true;
		};
	});
	return ret;
}

var missing_fields = [];
function checkFields(){
	missing_fields = [];
	for(var f in fields){
		if(fields[f].required){
			if(!fieldExists(f)){
				missing_fields[missing_fields.length] = fields[f].label;
			}
		}
	}

	var label_short_description = fields['short_description'].label;
	if(missing_fields.contains(label_short_description) && fieldExists('name') && $('name_as_short_description').checked){
		missing_fields.removeValue(label_short_description);
	}

	var label_price = fields['price'].label;
	if(missing_fields.contains(label_price) && fieldExists('cost') && $('calculate_price_from_cost').checked){
		missing_fields.removeValue(label_price);
	}

	var label_reference = fields['reference'].label;
	if(missing_fields.contains(label_reference) && fieldExists('manufacturers_code') && $('auto_generate_reference').checked){
		missing_fields.removeValue(label_reference);
	}

	if(missing_fields.length > 0){
		msgBox('##NG_MISSING_FIELDS##: '+missing_fields.join(', '));
		return false;
	}
	return true;
}

function validateField(val,type){
	val = ''+val;
	if(type=='none'){
		return true;
	} else if(type=='string'){
		if(val.length > 0) return true;
	} else if(type=='float'){
		if(val.length > 0 && val == ''+val.toFloat()){
			return true;
		}
	} else if(type=='int'){
		if(val.length > 0 && val == ''+val.toInt()){
			return true;
		}
	}
	return false;
}

function checkData(){
	var validations = [];
	$$('#import_table thead select').each(function(el){
		validations[validations.length] = fields[el.getSelected().value].validation;
	});

	var tr_num = 0;
	var errors = [];
	$$('#import_table tbody tr').each(function(tr){
		tr_num++;
		var values = [];
		var count = 0;
		var is_selected = tr.getFirst('input[type="checkbox"]').checked;
		if(is_selected){
			tr.getElements('input[type="hidden"]').each(function(input){
				if(!validateField(input.value,validations[count])){
					if(!errors.contains(tr_num)) errors[errors.length] = tr_num;
				}
				count++;
			});
		}
	});
	if(errors.length > 0){
		if(confirmBox('##NG_WRONG_DATA_IN_FOLLOWING_ROWS##: '+errors.join(', ')+"\n"+'##NG_DO_YOU_WANT_TO_UNSELECT_THOSE_ROWS##')){
			for(var i=0,len=errors.length; i<len; i++){
				$('item_'+errors[i]).set('checked',false);
			}
		}
		return false;
	}
	return true;
}

function verify(){
	var ff = checkFields();
	var dd = checkData();
	return ff && dd;
}

function send(){
	if(verify())
		$('import_form').submit();
}

function editLine(el){
	var $el = $(el);
	var parent = $el.getParent('tr');
	parent.getElements('td label').setStyle('display','none');
	parent.getElements('td input[type=hidden]').set('type','text');
	parent.getElements('a.iconButtonLink').setStyle('visibility','hidden');
}

function costMultiplierEnabler(){
	if($('calculate_price_from_cost').checked){
		$('cost_multiplier').set('disabled',false);
		$('cost_multiplier').focus();
	} else {
		$('cost_multiplier').set('disabled',true);
	}
}

$(document).addEvent('domready',function(){
	$('calculate_price_from_cost').addEvent('change',costMultiplierEnabler);
	costMultiplierEnabler();
});
