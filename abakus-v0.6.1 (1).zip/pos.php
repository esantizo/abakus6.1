<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'pos.php';

	$module_name = 'invoices';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$last_action = $db->fetch_item("
		SELECT ca.*,u.name
		FROM cashbox_actions AS ca
		JOIN users AS u
			ON u.id=ca.id_user
		ORDER BY date_added DESC LIMIT 1
	");

	switch($last_action['type']){
		case 'C':
			$message = __('##NG_CASHBOX_IS_CLOSED##');
			redirect('cashbox_open.php');
			break;
	}


	$ticket = $db->fetch_item("
		SELECT i.*,ps.name AS price_scale_name
		FROM invoices AS i
		LEFT JOIN price_scales AS ps
			ON ps.id=i.id_price_scale
		WHERE i.pos_opened=1 LIMIT 1
	");
	if($ticket){
		$ticket_items = $db->fetch_all("SELECT * FROM invoice_items WHERE id_invoice={$ticket['id']}");
		if($ticket['client_id'] > 0){
			$client = $db->fetch_item("
				SELECT c.*,ps.name AS price_scale_name
				FROM clients AS c
				LEFT JOIN price_scales AS ps
					ON ps.id=c.id_price_scale
				WHERE c.id='{$ticket['client_id']}'
			");
		}
	}

	$salesmen = $db->fetch_all("
		SELECT u.*, IF(u.id='{$user->getId()}','selected=\"selected\"','') AS selected
		FROM users AS u
		WHERE u.can_sell=1
			AND deleted=0
	");
	$invoice_number = max(1,$db->fetch_item_field("SELECT (MAX(number)+1) FROM invoices"));
	$tax_values = $db->fetch_all("SELECT percentage FROM taxes ORDER BY percentage",'percentage');
	$currency = $db->fetch_all("SELECT * FROM currency ORDER BY rate");

	$price_scale = $db->fetch_item("SELECT id,name FROM price_scales ORDER BY `default` DESC,id DESC LIMIT 1");
	$tax_conditions = $db->fetch_all("SELECT * FROM tax_conditions ORDER BY name");
	$payment_types = $db->fetch_all("SELECT * FROM payment_types ORDER BY name");
	$invoice_types = $db->fetch_all("SELECT * FROM invoice_types ORDER BY name");

	switch($config['invoice_search_field']){
		case 'internal_code': $first_field = __("Internal Code"); break;
		case 'manufacturers_code': $first_field = __("Manufacturers Code"); break;
		default: $first_field = __("Reference");
	}

	$return_url = return_to_module_url($module_name);

	$smarty->assign('ticket',$ticket);
	$smarty->assign('ticket_items',$ticket_items);
	$smarty->assign('client',$client);
	$smarty->assign('return_url',$return_url);
	$smarty->assign('tax_conditions',$tax_conditions);
	$smarty->assign('payment_types',$payment_types);
	$smarty->assign('invoice_types',$invoice_types);
	$smarty->assign('invoice_number',$invoice_number);
	$smarty->assign('price_scale',$price_scale);
	$smarty->assign('currency',$currency);
	$smarty->assign('salesmen',$salesmen);
	$smarty->assign('first_field',$first_field);
	$smarty->assign('tax_values',implode(',',$tax_values));
	$smarty->assign('ignore_stock',($config['ignore_stock']?1:0));

	$smarty->display('pos.tpl');
?>
