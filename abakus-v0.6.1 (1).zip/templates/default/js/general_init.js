// Home Key - goes Home
$(window).addEvent('keydown', function(ev){
	if(typeof calculator != 'undefined' && calculator && calculator.opened) return false;
	if((ev.altKey==true || ev.ctrlKey==true || ev.shiftKey==true) && ev.keyCode==27){
		location.href = 'index.php';
		if (event.stopPropagation) {
			event.stopPropagation();
		} else {
			event.cancelBubble = true;
		}
	}
});
var calculator = new Lightbox('calculator',{ 'onOpen':function(){ setFocus('abakalc_display'); } });

var focusEl = nextInput();
if(focusEl) setFocus(focusEl);
