<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'quotes.php';

	$module_name = 'quotes';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	$qid = (int)$_GET['id'];

	$sql = "
		SELECT q.*,
			CONCAT('<span class=\"currency\">',c.symbol,'</span> ',q.discount) AS discount,
			CONCAT('<span class=\"currency\">',c.symbol,'</span> ',q.subtotal) AS subtotal,
			CONCAT('<span class=\"currency\">',c.symbol,'</span> ',q.total) AS total,
			u.name AS salesman,
			tc.name AS tax_condition,
			pt.name AS payment_type,
			ps.name AS price_scale,
			c.symbol,
			c.name AS currency,
			s.id AS status_id,
			s.name AS status
		FROM quotes AS q
		JOIN users AS u
			ON u.id=q.salesman
		LEFT JOIN tax_conditions AS tc
			ON tc.id=q.id_tax_condition
		LEFT JOIN payment_types AS pt
			ON pt.id=q.id_payment_type
		LEFT JOIN price_scales AS ps
			ON ps.id=q.id_price_scale
		LEFT JOIN quotes_statuses AS s
			ON s.id=q.status
		LEFT JOIN currency AS c
			ON c.id=q.id_currency
		WHERE q.id=$qid
	";
	$quote = $db->fetch_item($sql);

	if($_GET['delete']=='1' && $_GET['reallysure']=='1' && $quote){
		$db->delete("DELETE FROM quote_items WHERE id_quote={$quote['id']}");
		$db->delete("DELETE FROM quotes WHERE id={$quote['id']}");
		redirect('search.php?module=quotes');
	}

	if($_GET['change_status'] && $_GET['current_status'] && $quote){
		$status = (int)$_GET['current_status'];
		$new_status = $db->fetch_item_field("(SELECT id FROM quotes_statuses WHERE id > $status LIMIT 1) UNION (SELECT MIN(id) FROM quotes_statuses LIMIT 1) LIMIT 1");
		if($new_status)
			$db->update("UPDATE quotes SET status=$new_status WHERE id={$quote['id']}");
		redirect("quote_details.php?id={$quote['id']}");
	}

	if($quote){
		$quote_items = $db->fetch_all("
			SELECT *,
				IF(LENGTH(reference)>0,reference,'&nbsp;') AS reference,
				CONCAT('<span class=\"symbol\">{$quote['symbol']}</span> ',price) AS price,
				CONCAT('<span class=\"symbol\">{$quote['symbol']}</span> ',total) AS total
			FROM quote_items
			WHERE id_quote={$quote['id']}
			ORDER BY id
		");

		$quote['number'] = str_pad($quote['number'],8,'0',STR_PAD_LEFT);
		if($quote['status_image']){
			$quote['status_image'] = 'img/'.$quote['status_image'];
			$size = @getimagesize($quote['status_image']);
			$quote['status_image_size'] = $size[3];
		}
	} else {
		$error = __("##NG_INCORRECT_QUOTE_ID##");
	}

	$taxes = parseTaxes($quote['taxes']);

	$return_url = return_to_module_url($module_name);

	$smarty->assign('quote',$quote);
	$smarty->assign('quote_items',$quote_items);
	$smarty->assign('taxes',$taxes);
	$smarty->assign('double_confirm_delete',$user_preferences['double_confirm_delete']);
	$smarty->assign('return_url',$return_url);

	$smarty->display('quote_details.tpl');
?>