var lightbox_checks;
var navigateChecks = false;

$(document).addEvent('domready',function(){
	if(!$('box_search_check')){
		new Element('div',{ 'id':'box_search_check', 'class':'lightbox search_box' })
			.adopt(new Element('div',{'class':'search_item_search_container'})
				.adopt(new Element('input',{ type:'text', id:'search_check_input', 'class':'search_items_input' }))
				.adopt(new Element('img',{ src:'##IMG_CLEAN##', width:20, height:20, alt:'X', 'class': 'search_items_clean_btn', events:{'click':function(){ $('search_check_input').value='';executeCheckSearch(); } } }))
				.adopt(new Element('input',{ type:'button', value:'Buscar', id:'search_check_btn' }))
			)
			.adopt(
				new Element('div',{ id:'search_check_response','class':'search_results_response' }).adopt(new Element('table',{ id:'checks_results_table','class': 'search_results_table'})
					.adopt(new Element('thead').adopt(new Element('tr')
						.adopt(new Element('th',{ text:'##Id##' }))
						.adopt(new Element('th',{ text:'##Client##' }))
						.adopt(new Element('th',{ text:'##Provider##' }))
						.adopt(new Element('th',{ text:'##Bank##' }))
						.adopt(new Element('th',{ text:'##Total##' }))
						.adopt(new Element('th',{ text:'##Cashing Date##' }))
					))
					.adopt(new Element('tbody',{ id:'checks_results_table_body' }))
				)
			)
			.inject(document.body);
	}

	$('search_check_input').addEvent('focus',function(){
		$$('#checks_results_table_body tr').each(function(e){e.removeClass('selected');});
		current = null;
	});
	$('search_check_input').addEvent('keydown',function(ev){ if(ev.keyCode==13){ executeCheckSearch(); } });
	$('search_check_btn').addEvent('click',function(){executeCheckSearch();});

	if($('check')) setFocus('check');

	$(window).addEvent('keydown',searchCheckNavigationListener);
});

function openSearchCheckBox(){
	lightbox_checks = new Lightbox('box_search_check',{'onClose':function(){navigateChecks=false;current=null;}}).open();
	if($('check')) $('search_check_input').value=$('check').value;
	$('checks_results_table_body').empty();
	navigateChecks = true;
	current = null;
	executeCheckSearch();
}

function executeCheckSearch(){
	Request({
		'url':'ajax/search_check.php',
		'method':'post',
		'data':'q='+$('search_check_input').value,
		'onSuccess':function(response){
			$('checks_results_table_body').stopWaiting();
			$('checks_results_table_body').empty();
			if(response){
				var res = parseJSON(response);
				for(var i=0,len=res.length; i<len; i++){
					var it = res[i];
					new Element('tr',{
							styles: {
								'cursor': 'pointer'
							},
							events: {
								'click':function(){
									if($('check')) $('check').value = this.getFirst('td input').value;
									searchCheck(this.getFirst('td input').value,this);
									lightbox_checks.close();
								}
							}
						})
						.adopt(new Element('td',{ text: it.id }).adopt(new Element('input',{ 'type':'hidden','name':'return_field','value':it.id })))
						.adopt(new Element('td',{ text: it.client }))
						.adopt(new Element('td',{ text: it.provider }))
						.adopt(new Element('td',{ text: it.bank }))
						.adopt(new Element('td',{ text: it.total }))
						.adopt(new Element('td',{ text: it.cashing_date }))
						.inject('checks_results_table_body');
				}
			}
			lightbox_checks.reposition();
		}
	});
	setFocus('search_check_input');
}

function searchCheckNavigationListener(ev){
	if(calculator && calculator.opened) return false;
	if(navigateChecks==true){
		$$('#checks_results_table_body tr').each(function(e){e.removeClass('selected');});
		if(ev.target==$('search_check_input')){
			if(ev.keyCode==40 || ev.keyCode==38){
				$('search_check_input').blur();
			}
		}
		if(ev.keyCode==40){
			if(current == null){
				current = $('checks_results_table_body').getFirst('tr');
			} else {
				current = nextItem(current,'TR');
				if(!current) current = $('checks_results_table_body').getFirst('tr');
			}
		} else if(ev.keyCode==38){
			if(current == null){
				current = $('checks_results_table_body').getLast('tr');
			} else {
				current = previousItem(current,'TR');
				if(!current) current = $('checks_results_table_body').getLast('tr');
			}
		} else if(ev.keyCode==13) {
			if(current){
				if($('check')) $('check').value = current.getFirst('td input').value;
				lightbox_checks.close();
				searchCheck(current.getFirst('td input').value,current);
				navigateChecks = false;
				return false;
			}
		}
		if(current){
			current.addClass('selected');
			var curPos = current.getPosition();
				var contHeight = $('search_check_response').getPosition().height;
				var maxScroll = $('checks_results_table').getPosition().totalHeight - contHeight;
			var scroll = curPos.top + curPos.height - contHeight / 2;
			if(scroll < 0) scroll = 0;
			if(scroll > maxScroll) scroll = maxScroll;
				$('search_check_response').scrollTop = scroll;
			if(ev.preventDefault) ev.preventDefault();
			if(ev.preventBubble) ev.preventBubble();
			return false;
		}
	}
}
