<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = $_GET['module'];

	// We load the module
	$module = loadModule($module_name,$db);

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	$item = $module->getElement($_GET['id']);

	switch($config['invoice_search_field']){
		case 'internal_code': $search_field = 'internal_code'; break;
		case 'manufacturers_code': $search_field = 'manufacturers_code'; break;
		default: $search_field = 'reference';
	}
	$ref = strtoupper(strtoascii($item[$search_field],' '));
	$desc = $item['short_description'];
	$cant = (int)$_GET['qty'];
	$time = time();
	$type = $_GET['type'];

	for($i=0; $i < $cant; $i++){
		$barcodes[] = array(
			'ref' => $ref,
			'desc' => $desc,
			'time' => $time,
			'id' => (int)$item['id']
		);
	}

	include 'inc/class.template.php';
	if($type=='qr'){
		$content = $db->fetch_item_field("SELECT content FROM print_templates WHERE id=".(int)$config['qrs_print_template']);
	} else {
		$content = $db->fetch_item_field("SELECT content FROM print_templates WHERE id=".(int)$config['barcodes_print_template']);
	}
	if(empty($content)){
		print __("##NG_ERR_MUST_CHOOSE_BARCODES_TEMPLATE##");
	} else {
		$template = new Template();
		$template->set('barcodes',$barcodes);

		echo $template->replace($content);
	}
?>
