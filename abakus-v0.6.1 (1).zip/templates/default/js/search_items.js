var SearchItemsBox = function(options){
	var self = this;
	this.items = null;
	this.current_item = null;
	this.lightbox = null;
	this.opened = false;
	this.error = true;
	this.selected = null;

	var searchElements = {};

	var defaults = {
		requestUrl: 'ajax/search_item.php',
		newItemUrl: null,
		returnField: 'id',
		returnContainer: 'item',
		secondaryField: 'name',
		secondaryFieldContainer: '',
		defaultValueContainer: null,
		fields: [ 'reference','name','short_description','stock' ],
		bindInputEvents: null,
		bindButtonEvents: null,
		onOpen: null,
		onClose: null,
		onSelect: null
	};

	this.options = merge(defaults,options);

	if(self.options.returnContainer){
		self.returnContainer = $(self.options.returnContainer);
	}
	if(self.options.secondaryFieldContainer){
		self.secondaryContainer = $(self.options.secondaryFieldContainer);
	}

	this.init = function(){
		// Creates Mainbox structure
		searchElements.mainBox = new Element('div',{ 'class':'lightbox search_box' });
		searchElements.inputField = new Element('input',{ type:'text', 'class':'search_items_input' });
		searchElements.searchImg = new Element('img',{ src:'##IMG_CLEAN##', width:20, height:20, alt:'X', 'class': 'search_items_clean_btn', events:{ 'click':function(){ self.resetSearch(); } } });
		searchElements.searchBtn = new Element('input',{ type:'button', value:'##NG_SEARCH##' });
		if(self.options.newItemUrl){
			searchElements.newItemBtn = new Element('input',{ type:'button', 'class':'add_in_search_button actionButton', value:'##NG_ADD##' });
		}
		searchElements.searchResponse = new Element('div',{ 'class':'search_results_response' });
		searchElements.searchResultsTable = new Element('table',{ 'class': 'search_results_table'});
		var theadTR = new Element('tr');
		for(var i=0,len=self.options.fields.length; i<len; i++){
			theadTR.adopt(new Element('th',{ text: self.options.fields[i] }))
		}
		searchElements.searchResultsTableHead = new Element('thead').adopt(theadTR);
		searchElements.searchResultsTableBody = new Element('tbody');

		var search_item_search_container = new Element('div',{'class':'search_item_search_container'})
			.adopt(searchElements.inputField)
			.adopt(searchElements.searchImg)
			.adopt(searchElements.searchBtn);
		if(searchElements.newItemBtn)
			search_item_search_container.adopt(searchElements.newItemBtn);

		searchElements.mainBox
			.adopt(search_item_search_container)
			.adopt(searchElements.searchResponse
				.adopt(searchElements.searchResultsTable
					.adopt(searchElements.searchResultsTableHead)
					.adopt(searchElements.searchResultsTableBody)
				)
			)
			.inject(document.body);

		// Adds events for the relevant elements
		searchElements.inputField.addEvents({
			'keydown':function(ev){ if(ev.keyCode==13){ self.executeItemSearch(); } },
			'focus':function(){
				searchElements.searchResultsTableBody.getElements('tr').each(function(e){ e.removeClass('selected'); });
				self.current_item = null;
			}
		});
		searchElements.searchBtn.addEvent('click',function(){ self.executeItemSearch(); });

		if(searchElements.newItemBtn){
			searchElements.newItemBtn.addEvent('click',function(){ self.addNewItem(); });
		}

		if(self.options.bindInputEvents && self.options.bindInputEvents.length > 0){
			for(var i=0, len=self.options.bindInputEvents.length; i<len; i++){
				if($(self.options.bindInputEvents[i])){
					$(self.options.bindInputEvents[i]).addEvent('keydown', function(ev){
						if(!self.opened && ev.keyCode == 13){
							self.open();
							if(ev.preventDefault) ev.preventDefault();
							if(ev.preventBubble) ev.preventBubble();
							return false;
						}
					});
				}
			}
		}

		if(self.options.bindButtonEvents && self.options.bindButtonEvents.length > 0){
			for(var i=0, len=self.options.bindButtonEvents.length; i<len; i++){
				if($(self.options.bindButtonEvents[i])){
					$(self.options.bindButtonEvents[i]).addEvent('click', function(ev){
						if(!self.opened){
							self.open();
							if(ev.preventDefault) ev.preventDefault();
							if(ev.preventBubble) ev.preventBubble();
							return false;
						}
					});
				}
			}
		}

		self.lightbox = new Lightbox(searchElements.mainBox,{'onClose':function(){
			self.opened=false;
			self.current_item=null;
			if(typeof self.options.onClose == 'function'){
				self.options.onClose.call(self,self.error);
			}
			if(window.lightbox) window.lightbox.close();
		}});
		$(window).addEvent('keydown',function(ev){ self.searchItemNavigationListener(ev); });
	}

	this.close = function(){
		self.lightbox.close();
		self.opened = false;
		self.current_item=null;
	}

	this.open = function(default_value){
		self.opened = true;
		self.lightbox.open();
		var defValCont = $(self.options.defaultValueContainer);
		if(defValCont){
			if(defValCont.tagName == 'INPUT'){
				searchElements.inputField.value = defValCont.value;
			} else if(defValCont.get('text')) {
				searchElements.inputField.value = defValCont.get('text');
			} else {
				searchElements.inputField.value = '';
			}
		} else if(default_value){
			searchElements.inputField.value = default_value;
		} else {
			if(self.returnContainer) searchElements.inputField.value = self.returnContainer.value;
		}
		searchElements.searchResultsTableBody.empty();
		self.current_item = null;
		self.executeItemSearch();
		if(typeof self.options.onOpen == 'function'){
			self.options.onOpen.call(self);
		}
	}

	this.resetSearch = function(){
		searchElements.inputField.value='';
		self.executeItemSearch();
	}

	this.executeItemSearch = function(){
		Request({
			'url': self.options.requestUrl,
			'method': 'post',
			'data':{ 'q': searchElements.inputField.value },
			'onRequest': function(){
				searchElements.searchResultsTableBody.startWaiting();
			},
			'onSuccess':function(response){
				searchElements.searchResultsTableBody.stopWaiting();
				searchElements.searchResultsTableBody.empty();
				if(response.length){
					var res = parseJSON(response);
					for(var i=0,len=res.length; i<len; i++){
						var it = res[i];
						var tr = new Element('tr')
							.setStyle('cursor','pointer')
							.addEvent('click',function(){
								self.searchItem(this);
							});
						for(var j=0,len2=self.options.fields.length; j<len2; j++){
							var td = new Element('td',{ text: it[self.options.fields[j]] });
							if(j==0){
								new Element('input',{ 'type':'hidden','rel':'returnField','value':it[self.options.returnField] }).inject(td);
								if(self.options.secondaryField){
									new Element('input',{ 'type':'hidden','rel':'secondaryField','value':it[self.options.secondaryField] }).inject(td);
								}
							}
							td.inject(tr);
						}
						tr.inject(searchElements.searchResultsTableBody);
					}
					self.lightbox.reposition();
				}
			}
		});
		setFocus(searchElements.inputField);
	}

	this.searchItemNavigationListener = function(ev){
		if(calculator && calculator.opened) return false;
		if(self.opened == true){
			searchElements.searchResultsTableBody.getElements('tr').each(function(e){ e.removeClass('selected'); });

			if(ev.target == searchElements.inputField){
				if(ev.keyCode==40 || ev.keyCode==38){
					searchElements.inputField.blur();
				}
			}
			if(ev.keyCode==40){
				if(self.current_item == null){
					self.current_item = searchElements.searchResultsTableBody.getFirst('tr');
				} else {
					self.current_item = nextItem(self.current_item,'TR');
					if(!self.current_item) self.current_item = searchElements.searchResultsTableBody.getFirst('tr');
				}
			} else if(ev.keyCode==38){
				if(self.current_item == null){
					self.current_item = searchElements.searchResultsTableBody.getLast('tr');
				} else {
					self.current_item = previousItem(self.current_item,'TR');
					if(!self.current_item) self.current_item = searchElements.searchResultsTableBody.getLast('tr');
				}
			} else if(ev.keyCode==13) {
				if(self.current_item){
					//if($('item')) $('item').value = self.current_item.getFirst('td input').value;
					self.searchItem(self.current_item);
					return false;
				}
			} else if(ev.keyCode==107 || ev.keyCode==187) {
				self.addNewItem();
				return false;
			}
			if(self.current_item){
				self.current_item.addClass('selected');
				var curPos = self.current_item.getPosition();
				var contHeight = searchElements.searchResponse.getPosition().height;
				var maxScroll = searchElements.searchResultsTable.getPosition().totalHeight - contHeight;
				var scroll = curPos.top + curPos.height - contHeight / 2;
				if(scroll < 0) scroll = 0;
				if(scroll > maxScroll) scroll = maxScroll;
				searchElements.searchResponse.scrollTop = scroll;
				if(ev.preventDefault) ev.preventDefault();
				if(ev.preventBubble) ev.preventBubble();
				return false;
			}
		}
	}

	var searchHelper = function(data){
		if(self.returnContainer && data.returnFieldValue){
			if(self.returnContainer.tagName == 'INPUT'){
				self.returnContainer.value = data.returnFieldValue;
			} else {
				self.returnContainer.set('text',data.returnFieldValue);
			}
		}
		if(self.secondaryContainer && data.secondaryFieldValue){
			if(self.secondaryContainer.tagName == 'INPUT'){
				self.secondaryContainer.value = data.secondaryFieldValue;
			} else {
				self.secondaryContainer.set('text',data.secondaryFieldValue);
			}
		}
		new Request({
			'url': self.options.requestUrl,
			'method': 'post',
			'data': data,
			'onSuccess':function(response){
				if(response.length){
					var res = parseJSON(response);
					self.selected = res;
					if(res[self.options.returnField]){
						self.error = false;
					} else {
						self.error = true;
					}
					if(typeof self.options.onSelect == 'function'){
						self.options.onSelect.call(self,res);
					}
					self.close();
				}
			}
		});
	}

	this.searchItem = function(item){
		self.selected = null;
		var value = item.getFirst('input[rel=returnField]').value;
		var data = {};
		data[self.options.returnField] = value;
		data['returnFieldValue'] = value;
		if(item.getFirst('input[rel=secondaryField]')){
			data['secondaryFieldValue'] = item.getFirst('input[rel=secondaryField]').value;
		}
		searchHelper(data);
		return self;
	}

	this.addNewItem = function(){
		var mainBox = new Element('div',{ 'styles':{
			'display':'block',
			'width':1100,
			'height':600
		}});
		var iframe = new Element('iframe',{ 'src':self.options.newItemUrl, 'styles': {
			'width':'100%',
			'height':'100%',
			'border':0
		} }).inject(mainBox);

		window.lightbox = new Lightbox(mainBox,{
			'overlay':false,
			'onClose':function(){
				var data = parseJSON(window.lightboxData);
				if(data && data.status == 'OK'){
					searchHelper({ 'id': data.id, 'returnFieldValue': data[self.options.returnField], 'secondaryFieldValue': data[self.options.secondaryField] });
				}
				window.lightbox = null;
				window.lightboxData = null;
				delete window.lightboxData;
				setFocus(searchElements.inputField);
			}
		}).open();
	}

	this.init();
}

