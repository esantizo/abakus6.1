<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';
	include 'inc/class.upload_image.php';

	$module_name = 'contacts';
	// We load the module
	$module = loadModule($module_name,$db);
	$thispage = 'contacts.php';

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$fields = $module->getFields();

	$upload_image = new UploadImage($db,'people');

	if((int)$_GET['id']){
		$contact = $db->fetch_item("SELECT * FROM contacts WHERE id=".(int)$_GET['id']);
		$image = $db->fetch_item("SELECT * FROM images WHERE id={$contact['id_image']}");
		$relation = $contact['relation'];
		$id_relation = $contact['id_relation'];
	} else {
		$relation = $_GET['relation'];
		$id_relation = (int)$_GET['id_relation'];
	}

	$return = 'search';
	if($_GET['return']) $return = $_GET['return'];

	if($return == 'search' && $relation) {
		if($relation == 'client'){
			$redirect_url = "search.php?module=clients&preview_item=$id_relation";
		} elseif($relation == 'provider') {
			$redirect_url = "search.php?module=providers&preview_item=$id_relation";
		} else {
			$redirect_url = return_to_module_url($module_name);
		}
	} elseif((int)$_GET['id_relation']){
		if($_GET['relation']=='client'){
			$redirect_url = "clients.php?id={$_GET['id_relation']}";
		} else {
			$redirect_url = "providers.php?id={$_GET['id_relation']}";
		}
	} else {
		if($return == 'client' || $relation == 'client'){
			$redirect_url = return_to_module_url('clients');
		} elseif($return == 'provider' || $relation == 'provider') {
			$redirect_url = return_to_module_url('providers');
		} else {
			$redirect_url = return_to_module_url($module_name);
		}
	}

	if($_POST['save']){
		switch($_REQUEST['relation']){
			case 'client':
			case 'provider':
				$relation = $_REQUEST['relation'];
				break;
			default:
				$relation = '';
		}
		$id_relation = (int)$_REQUEST['id_relation'];

		$name = $db->escape_string($_POST['name']);
		$telephone = $db->escape_string($_POST['telephone']);
		$email = $db->escape_string($_POST['email']);
		$address = $db->escape_string($_POST['address']);
		$postcode = $db->escape_string($_POST['postcode']);
		$city = $db->escape_string($_POST['city']);
		$state = $db->escape_string($_POST['state']);
		$country = $db->escape_string($_POST['country']);
		$notes = $db->escape_string($_POST['notes']);
		$is_branch = ($_POST['is_branch']?1:0);

		$fields = "
			relation='$relation',
			id_relation='$id_relation',
			name='$name',
			telephone='$telephone',
			email='$email',
			address='$address',
			postcode='$postcode',
			city='$city',
			state='$state',
			country='$country',
			notes='$notes',
			is_branch=$is_branch
		";

		if($contact){
			$db->update("UPDATE contacts SET $fields WHERE id={$contact['id']}");
			$contact_id = $contact['id'];
		} else {
			$contact_id = $db->insert("INSERT INTO contacts SET $fields");
		}

		$image_id = $upload_image->process_upload($_POST,$_FILES);
		if($upload_image->deleted) $db->delete("UPDATE contacts SET id_image=0 WHERE id=$contact_id");
		if($image_id) $db->insert("UPDATE contacts SET id_image=$image_id WHERE id=$contact_id");

		if($_POST['next']=='new'){
			if($_GET['id_relation']){
				redirect("contacts.php?relation={$_GET['relation']}&rel_id={$_GET['id_relation']}&return=$return");
			} else {
				redirect("contacts.php?return=$return");
			}
		} else {
			redirect($redirect_url);
		}
	}

	switch($relation){
		case 'client':
			$relation = 'client';
			$relation_name = __('Client');
			if($id_relation > 0){
				$rel_item = $db->fetch_item("SELECT id, name FROM clients WHERE id=$id_relation");
			} else {
				$items = $db->fetch_all("SELECT id, name FROM clients",'name','id');
			}
			break;
		case 'provider':
			$relation = 'provider';
			$relation_name = __('Provider');
			if($id_relation > 0){
				$rel_item = $db->fetch_item("SELECT id,name FROM providers WHERE id=$id_relation");
			} else {
				$items = $db->fetch_all("SELECT id,name FROM providers",'name','id');
			}
			break;
	}

	$form_action = "$thispage?return=$return";
	if($relation){
		$form_action = "$thispage?relation=$relation&amp;id_relation=$id_relation&amp;return=$return";
	}
	if($contact) $form_action.="&amp;id={$contact['id']}";

	$possible_relations = array();
	if($db->fetch_item_field("SELECT COUNT(*) FROM clients") > 0){
		$possible_relations[] = array('name'=>'Client', 'value'=>'client');
	}
	if($db->fetch_item_field("SELECT COUNT(*) FROM providers") > 0){
		$possible_relations[] = array('name'=>'Provider', 'value'=>'provider');
	}

	$smarty->assign('possible_relations',$possible_relations);

	$smarty->assign('form_action',$form_action);
	$smarty->assign('items',$items);
	$smarty->assign('rel_item',$rel_item);
	$smarty->assign('relation_name',$relation_name);
	$smarty->assign('contact',$contact);
	$smarty->assign('upload_image',$upload_image);
	$smarty->assign('image',$image);
	$smarty->assign('redirect_url',$redirect_url);
	$smarty->display('contacts.tpl');
?>