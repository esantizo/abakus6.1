<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'parking.php';

	$module_name = 'parking';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$salesmen = $db->fetch_all("
		SELECT u.*, IF(u.id='{$user->getId()}','selected=\"selected\"','') AS selected
		FROM users AS u
		WHERE u.can_sell=1
			AND deleted=0
	");

	$return_url = return_to_module_url($module_name);

	$smarty->assign('shift_options',json_decode($config['parking_shift_scales'],true));
	$smarty->assign('monthly_options',json_decode($config['parking_monthly_scales'],true));
	$smarty->assign('return_url',$return_url);
	$smarty->assign('salesmen',$salesmen);
	//$smarty->assign('tax_values',implode(',',$tax_values));

	$smarty->display('parking.tpl');
?>
