<?php
	$js_parser = true;
	include '../../../inc/config.php';

	$ajax_path_prefix = '../../../';
	include '../../../inc/smarty.php';

	$content = file_get_contents($_GET['js']);
	$content = preg_replace_callback(
		'|##(.*?)##|',
		create_function(
			// single quotes are essential here,
			// or alternative escape all $ as \$
			'$matches',
			'return __($matches[1]);'
		),
		$content
	);

	if(0 && $config['pack_js']){
		include '../../../inc/class.JavaScriptPacker.php';
	$generatedoutput = str_replace("\\\r\n", "\\n", $content);
	$generatedoutput = str_replace("\\\n", "\\n", $generatedoutput);
	$generatedoutput = str_replace("\\\r", "\\n", $generatedoutput);
	$generatedoutput = str_replace("}\r\n", "};\r\n", $generatedoutput);
	$generatedoutput = str_replace("}\n", "};\n", $generatedoutput);
	$generatedoutput = str_replace("}\r", "};\r", $generatedoutput);
		$myPacker = new JavaScriptPacker($generatedoutput);
		$content = $myPacker->pack();
/*
	$generatedoutput = ob_get_contents();
	ob_end_clean();
	$generatedoutput = str_replace(array("\\\r\n", "\\n", $generatedoutput);
	$generatedoutput = str_replace("\\\n", "\\n", $generatedoutput);
	$generatedoutput = str_replace("\\\r", "\\n", $generatedoutput);
	$generatedoutput = str_replace("}\r\n", "};\r\n", $generatedoutput);
	$generatedoutput = str_replace("}\n", "};\n", $generatedoutput);
	$generatedoutput = str_replace("}\r", "};\r", $generatedoutput);
	require 'class.JavaScriptPacker.php';
	$myPacker = new JavaScriptPacker($generatedoutput);
	$packed = $myPacker->pack();
	echo($packed)
*/
	}

	header('Content-type: application/javascript');
	echo $content;
?>
