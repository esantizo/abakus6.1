(function(){

window.Sortable = function(el,options){
	this.el = $(el);
	var self = this;
	var defaults = {
		clone: false,
		/*handle: false,*/
		opacity: 0.9,
		cursor: 'move',
		cloneOpacity: 0.5,
		onStart: null,
		onSort: null,
		onComplete: null
	};
	this.options = merge(defaults,options);

	var dragging = false;

	this.getPreviousItem = function(elem){
		var ret = previousItem(elem,elem.nodeName);
		while(ret == dragging.element){
			ret = previousItem(ret,elem.nodeName);
		};
		return ret;
	};

	this.getNextItem = function(elem){
		var ret = nextItem(elem,elem.nodeName);
		while(ret == dragging.element){
			ret = nextItem(ret,elem.nodeName);
		};
		return ret;
	};

	this.mouseDownEvent = function(ev){
		var element = $(ev.target);
		var parent = element.getParent();
		var pos = element.getPosition(true);
		var parentPos = parent.getPosition(true);

		var offX = parentPos.left + parent.getStyle('border-left-width').toInt() + ev.offsetX;
		var offY = parentPos.top + parent.getStyle('border-top-width').toInt() + ev.offsetY;

		if(self.options.clone){
			var cloned = element.clone().inject(parent).setStyles({
				'display':'block',
				'box-sizing': 'border-box',
				'width': pos.width + element.getStyle('border-left-width').toInt() + element.getStyle('border-right-width').toInt(),
				'height': pos.height + element.getStyle('border-top-width').toInt() + element.getStyle('border-bottom-width').toInt(),
				'opacity': self.options.cloneOpacity
			});
		} else {
			var cloned = new Element(element.nodeName).inject(parent).setStyles({
				'display':'block',
				'box-sizing': 'border-box',
				'width': pos.width + element.getStyle('border-left-width').toInt() + element.getStyle('border-right-width').toInt(),
				'height': pos.height + element.getStyle('border-top-width').toInt() + element.getStyle('border-bottom-width').toInt()
			});
		}
		parent.replaceChild(cloned,element);
		parent.adopt(element);
		dragging = {
			'element': element,
			'cloned': cloned,
			'parent': parent,
			'offsetx': offX,
			'offsety': offY,
			'maxY': parentPos.height - pos.totalHeight,
			'resetStyles': {
				'display': element.getStyle('display'),
				'position': element.getStyle('position'),
				'box-sizing': element.getStyle('box-sizing'),
				'width': element.getStyle('width'),
				'height': element.getStyle('height'),
				'opacity': element.getStyle('opacity'),
				'top':'auto'
			}
		};
		element.setStyles({
			'position':'absolute',
			'box-sizing': 'border-box',
			'width': pos.width + element.getStyle('border-left-width').toInt() + element.getStyle('border-right-width').toInt(),
			'height': pos.height + element.getStyle('border-top-width').toInt() + element.getStyle('border-bottom-width').toInt(),
			'top': ev.pageY - offY
		});

		parent
			.set('unselectable', 'on')
			.setStyles({
				'position':'relative',
				'-ms-user-select':'none',
				'-moz-user-select':'none',
				'-webkit-user-select':'none',
				'user-select':'none'
			});
		element.setStyle('opacity',self.options.opacity);
		if(typeof self.options.onStart=='function'){
			self.options.onStart.call(self,element);
		}
		return false;
	};

	this.mouseMoveEvent = function(ev){
		if(dragging){
			var top = ev.pageY - dragging.offsety;
			if(top < 0) top = 0;
			if(top > dragging.maxY) top = dragging.maxY;
			dragging.element.setStyle('top',top);

			var item = dragging.cloned;
			var xmouse = ev.pageY;
			var moveTo = null;

			var previous = self.getPreviousItem(item);
			while (previous != null) {
				if (xmouse <= (findPos(previous).y + previous.clientHeight)) {
					moveTo = previous;
					break;
				}
				previous = self.getPreviousItem(previous);
			}
			if (moveTo != null){
				moveBefore(item, moveTo);
				if(typeof self.options.onSort=='function'){
					self.options.onSort.call(self,dragging.element);
				}
				return;
			}

			var next = self.getNextItem(item);
			while (next != null) {
				if (findPos(next).y <= xmouse) {
					moveTo = next;
					break;
				}
				next = self.getNextItem(next);
			}
			if (moveTo != null) {
				moveBefore(item, nextItem(moveTo, item.nodeName));
				if(typeof self.options.onSort=='function'){
					self.options.onSort.call(self,dragging.element);
				}
				return;
			}
		}
	};

	this.mouseUpEvent = function(ev){
		if(dragging){
			dragging.parent.replaceChild(dragging.element,dragging.cloned);
			dragging.element.setStyles(dragging.resetStyles);
			if(typeof self.options.onComplete=='function'){
				self.options.onComplete.call(self,dragging.element);
			}
			dragging = false;
		}
	};

	this.addItem = function(e){
		e.addEvents({
			'mousedown': this.mouseDownEvent,
			'mouseup': this.mouseUpEvent
		}).setStyle('cursor',self.options.cursor);
		$(window).addEvent('mouseup',this.mouseUpEvent)
	}

	this.el.getElements().each(function(e){ self.addItem(e); });
	this.el.addEvent('mousemove',this.mouseMoveEvent);
}

})();
