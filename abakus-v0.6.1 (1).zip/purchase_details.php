<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'purchases.php';
	$module_name = 'purchases';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	$iid = (int)$_GET['id'];

	$sql = "
		SELECT p.*,
			CONCAT_WS(' ',c.symbol,p.subtotal) AS subtotal,
			CONCAT_WS(' ',c.symbol,p.total) AS total,
			u.name AS buyer,
			c.symbol,
			IF(LENGTH(p.provider_postcode)>0,CONCAT('(',p.provider_postcode,') ',p.provider_city),p.provider_city) AS provider_city
		FROM purchases AS p
		LEFT JOIN users AS u
			ON u.id=p.buyer
		JOIN currency AS c
			ON c.id=p.id_currency
		WHERE p.id=$iid
	";
	$purchase = $db->fetch_item($sql);

	switch($_GET['return']){
		case 'balance': $return_url = "balance.php"; break;
		case 'printing_lists': $return_url = "printing_lists.php"; break;
		default: $return_url = return_to_module_url($module_name);
	}

	if($_GET['delete']=='1' && $_GET['reallysure']=='1' && $purchase){
		$db->delete("DELETE FROM products_stock WHERE relation='purchase|{$purchase['id']}'");
		$db->delete("DELETE FROM purchase_items WHERE id_purchase={$purchase['id']}");
		$db->delete("DELETE FROM purchases WHERE id={$purchase['id']}");

		// Update account balances
		$balance = 0;
		if($_GET['return_url']){
			redirect(urldecode($_GET['return_url']));
		} else {
			return_to_module($module_name);
		}
	}

	if($purchase){
		$purchase_items = $db->fetch_all("
			SELECT *, IF(reference LIKE '0','&nbsp;',reference) AS reference, CONCAT('<span class=\"symbol\">{$purchase['symbol']}</span> ',price) AS price,CONCAT('<span class=\"symbol\">{$purchase['symbol']}</span> ',total) AS total
			FROM purchase_items
			WHERE id_purchase=$iid
			ORDER BY id
		");
	} else {
		$error = __("##NG_INCORRECT_PURCHASE_ID##");
	}

	switch($config['invoice_search_field']){
		case 'internal_code': $first_field = __("Internal Code"); break;
		case 'manufacturers_code': $first_field = __("Manufacturers Code"); break;
		default: $first_field = __("Reference");
	}

	$taxes = parseTaxes($purchase['taxes']);

	$smarty->assign('purchase',$purchase);
	$smarty->assign('purchase_items',$purchase_items);
	$smarty->assign('taxes',$taxes);
	$smarty->assign('double_confirm_delete',$user_preferences['double_confirm_delete']);
	$smarty->assign('return_url',$return_url);
	$smarty->assign('first_field',$first_field);

	$smarty->display('purchase_details.tpl');
?>