var lightbox_items;
var navigateItems = false;
var item_relfield_name = null;
var item_hiddenfield_name = null;
var current_item_popup = null;

$(document).addEvent('domready',function(){
	if(!$('box_search_item')){
		new Element('div',{ 'id':'box_search_item', 'class':'lightbox search_box' })
			.adopt(new Element('div',{'class':'search_item_search_container'})
				.adopt(new Element('input',{ type:'text', id:'search_item_input', 'class':'search_items_input' }))
				.adopt(new Element('img',{ src:'##IMG_CLEAN##', width:20, height:20, alt:'X', 'class': 'search_items_clean_btn', events:{ 'click':function(){ resetSearch(); } } }))
				.adopt(new Element('input',{ type:'button', value:'Buscar', id:'search_item_btn' }))
			)
			.adopt(
				new Element('div',{ id:'search_item_response','class':'search_results_response' }).adopt(new Element('table',{ id:'items_results_table','class': 'search_results_table'})
					.adopt(new Element('thead').adopt(new Element('tr')
						.adopt(new Element('th',{ text:'##Reference##' }))
						.adopt(new Element('th',{ text:'##Name##' }))
						.adopt(new Element('th',{ text:'##Description##' }))
						.adopt(new Element('th',{ text:'##Stock##' }))
					))
					.adopt(new Element('tbody',{ id:'items_results_table_body' }))
				)
			)
			.inject(document.body);
	}

	$('search_item_input').addEvent('focus',function(){
		$$('#items_results_table_body tr').each(function(e){e.removeClass('selected');});
		current_item_popup = null;
	});
	$('search_item_input').addEvent('keydown',function(ev){ if(ev.keyCode==13){ executeItemSearch(item_relfield_name); } });
	$('search_item_btn').addEvent('click',function(){executeItemSearch(item_relfield_name);});

	if($('item')){
		$('item').addEvent('keydown',function(ev){
			if (!ev) var ev = window.event;
			if(ev.keyCode==13){
				ev.cancelBubble = true;
				if (ev.stopPropagation) ev.stopPropagation();
				ev.preventDefault();
				return false;
			}
		});
		setFocus('item');
	}
	if($('id_product') && $('id_product').value){
		searchItem($('id_product').value);
	}

	$(window).addEvent('keydown',searchItemNavigationListener);
});

function resetSearch(){
	$('search_item_input').value='';
	executeItemSearch(item_relfield_name,item_hiddenfield_name);
}

function openSearchItemBox(field,hiddenfield){
	if(hiddenfield) item_hiddenfield_name = hiddenfield;
	if(!field) field = 'reference';
	item_relfield_name = field;
	lightbox_items = new Lightbox('box_search_item',{'onClose':function(){ navigateItems=false;current_item_popup=null; }}).open();
	if($('item')) $('search_item_input').value=$('item').value;
	$('items_results_table_body').empty();
	navigateItems = true;
	current_item_popup = null;
	executeItemSearch(field,hiddenfield);
}

function executeItemSearch(ret_field,hiddenfield){
	Request({
		'url':'ajax/search_item.php',
		'method':'post',
		'data':'q='+$('search_item_input').value,
		'onRequest': function(){
			$('items_results_table_body').startWaiting();
		},
		'onSuccess':function(response){
			$('items_results_table_body').stopWaiting();
			$('items_results_table_body').empty();
			var res = parseJSON(response);
			for(var i=0,len=res.length; i<len; i++){
				var it = res[i];
				new Element('tr',{
						styles: {
							'cursor': 'pointer'
						},
						events: {
							'click':function(){
								if($('item')) $('item').value = this.getFirst('td input').value;
								searchItem(this.getFirst('td input').value,ret_field,hiddenfield,this);
								lightbox_items.close();
							}
						}
					})
					.adopt(new Element('td',{ text: it.reference })
						.adopt(new Element('input',{ 'type':'hidden','name':'return_field','value':it[ret_field] }))
						.adopt(new Element('input',{ 'type':'hidden','class':'id_field','value':it.id }))
					)
					.adopt(new Element('td',{ text: it.name }))
					.adopt(new Element('td',{ text: it.short_description }))
					.adopt(new Element('td',{ text: it.stock }))
					.inject('items_results_table_body');
			}
			lightbox_items.reposition();
		}
	});
	if($('search_item_input')) setFocus('search_item_input');
}

function searchItemNavigationListener(ev){
	if(calculator && calculator.opened) return false;
	if(navigateItems==true){
		$$('#items_results_table_body tr').each(function(e){e.removeClass('selected');});
		if(ev.target==$('search_item_input')){
			if(ev.keyCode==40 || ev.keyCode==38){
				$('search_item_input').blur();
			}
		}
		if(ev.keyCode==40){
			if(current_item_popup == null){
				current_item_popup = $('items_results_table_body').getFirst('tr');
			} else {
				current_item_popup = nextItem(current_item_popup,'TR');
				if(!current_item_popup) current_item_popup = $('items_results_table_body').getFirst('tr');
			}
		} else if(ev.keyCode==38){
			if(current_item_popup == null){
				current_item_popup = $('items_results_table_body').getLast('tr');
			} else {
				current_item_popup = previousItem(current_item_popup,'TR');
				if(!current_item_popup) current_item_popup = $('items_results_table_body').getLast('tr');
			}
		} else if(ev.keyCode==13) {
			if(current_item_popup){
				if($('item')) $('item').value = current_item_popup.getFirst('td input').value;
				searchItem(current_item_popup.getFirst('td input').value,item_relfield_name,item_hiddenfield_name,current_item_popup);
				lightbox_items.close();
				navigateItems = false;
				return false;
			}
		}
		if(current_item_popup){
			current_item_popup.addClass('selected');
			var curPos = current_item_popup.getPosition();
				var contHeight = $('search_item_response').getPosition().height;
				var maxScroll = $('items_results_table').getPosition().totalHeight - contHeight;
			var scroll = curPos.top + curPos.height - contHeight / 2;
			if(scroll < 0) scroll = 0;
			if(scroll > maxScroll) scroll = maxScroll;
				$('search_item_response').scrollTop = scroll;
			if(ev.preventDefault) ev.preventDefault();
			if(ev.preventBubble) ev.preventBubble();
			return false;
		}
	}
}

//~ function searchItem(val,relfield,hiddenfield,item){
	//~ if($('item')){
		//~ //$('item').value = item.getFirst('td').get('text');
		//~ $('item').set('text',val);
		//~ if($(hiddenfield)) $(hiddenfield).value = item.getFirst('td .id_field').value;
	//~ }
//~ }

function searchItem(id){
	Request({
		'url':'ajax/search_item.php',
		'method':'post',
		'data':'id='+id,
		'onSuccess': function(response){
			if(response.length){
				var res = parseJSON(response);
				if(res.product_id){
					$('item').value = res.name;
				} else {
					msgBox("##NG_WRONG_PRODUCT##");
				}
			}
		}
	});
}
