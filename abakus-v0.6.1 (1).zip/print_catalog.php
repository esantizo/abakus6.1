<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = 'quotes';

	// We load the module
	$module = loadModule($module_name,$db);

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	require 'inc/smarty.php';

	$qid = (int)$_GET['id_quote'];

	$sql = "
		SELECT q.*,
			CONCAT('<span class=\"currency\">',c.symbol,'</span> ',q.discount) AS discount,
			CONCAT('<span class=\"currency\">',c.symbol,'</span> ',q.subtotal) AS subtotal,
			CONCAT('<span class=\"currency\">',c.symbol,'</span> ',q.total) AS total,
			u.name AS salesman,
			tc.name AS tax_condition,
			pt.name AS payment_type,
			ps.name AS price_scale,
			c.symbol,
			c.name AS currency,
			s.id AS status_id,
			s.name AS status
		FROM quotes AS q
		JOIN users AS u
			ON u.id=q.salesman
		LEFT JOIN tax_conditions AS tc
			ON tc.id=q.id_tax_condition
		LEFT JOIN payment_types AS pt
			ON pt.id=q.id_payment_type
		LEFT JOIN price_scales AS ps
			ON ps.id=q.id_price_scale
		LEFT JOIN quotes_statuses AS s
			ON s.id=q.status
		JOIN currency AS c
			ON c.id=q.id_currency
		WHERE q.id=$qid
	";
	$quote = $db->fetch_item($sql);

	if($quote){
		$quote_items = $db->fetch_all("
			SELECT id_product
			FROM quote_items
			WHERE id_quote={$quote['id']}
			ORDER BY id
		",'id_product');
		$items = array();
		if(is_array($quote_items)) foreach($quote_items as $qiid){
			$item = $db->fetch_item("
				SELECT p.*,i.filename AS image, c.name AS category, pack.name AS packaging, o.name AS origin
				FROM products AS p
				LEFT JOIN categories AS c
					ON c.id = p.id_category
				LEFT JOIN packagings AS pack
					ON pack.id = p.id_packaging
				LEFT JOIN origins AS o
					ON o.id = p.id_origin
				LEFT JOIN products_to_images AS pi
					ON pi.id_product = p.id
				LEFT JOIN images AS i
					ON i.id = pi.id_image
				WHERE p.id=$qiid
			");
			$items[] = $item;
		}
	} else {
		$error = __("##NG_INCORRECT_QUOTE_ID##");
	}

	$smarty->assign('quote',$quote);
	$smarty->assign('items',$items);

	$template = 'string:'.$db->fetch_item_field("
		SELECT content
		FROM print_templates
		WHERE id='{$config['catalog_print_template']}'
		LIMIT 1
	");

	if(!$_GET['view'] && !$_GET['preview']){
		$smarty->display($template.'<script type="text/javascript">window.print();</script>');
	} else {
		$smarty->display($template);
	}
?>