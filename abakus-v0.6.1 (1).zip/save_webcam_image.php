<?php
	include "inc/config.php";
	include "inc/class.image.php";

	$tempdir = realpath($uploads_path.'tmp/');
	$tempfilename = tempnam($tempdir,'cam_upload_');

	$result = file_put_contents($tempfilename,file_get_contents('php://input'));
	if (!$result) {
		print __("ERROR: Failed to write data to %s, check permissions",$tempfilename);
		exit;
	}

	$image = new Image($tempfilename,$errors);
	if(empty($errors)){
		switch($_GET['type']){
			case 'product':
				$prefix = 'products_';
				break;
			case 'entity':
				$prefix = 'entities_';
				break;
			case 'user':
				$prefix = 'users_';
				break;
			case 'people':
				$prefix = 'people_';
				break;
			default:
		}
		$path = "uploads/images/";
		do {
			$filename = $prefix.mt_rand().date("Ymd").'.jpg';
		} while(file_exists($path.$filename));

		if($image->save($path.$filename)){
			print $filename."|".$image->getWidth()."|".$image->getHeight();
			unlink($tempfilename);
			die();
		}
	}
	print "error: ";
	print_r($error);
	unlink($tempfilename);
?>