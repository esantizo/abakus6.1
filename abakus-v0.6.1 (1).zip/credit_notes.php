<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'credit_notes.php';

	$module_name = 'credit_notes';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	if($_GET['from_invoice']){
		$invoice_id = (int)$_GET['from_invoice'];
		$invoice = $db->fetch_item("SELECT * FROM invoices WHERE id=$invoice_id LIMIT 1");
		if($invoice){
			$invoice_items = $db->fetch_all("SELECT * FROM invoice_items WHERE id_invoice=$invoice_id");
			$invoice_type = $invoice['invoice_type']; //$db->fetch_item_field("SELECT id FROM invoice_types ORDER BY `default` DESC,id ASC");
			$credit_note_number = max(1,$db->fetch_item_field("SELECT (MAX(number)+1) FROM credit_notes"));

			$cnid = $db->insert("
				INSERT INTO credit_notes SET
					invoice_type='$invoice_type',
					number='$credit_note_number',
					`date`=NOW(),
					due_date=DATE_ADD(NOW(),INTERVAL 30 DAY),
					salesman='{$invoice['salesman']}',
					client_id='{$invoice['client_id']}',
					client_name='{$invoice['client_name']}',
					client_address='{$invoice['client_address']}',
					client_taxpayer_id='{$invoice['client_taxpayer_id']}',
					client_postcode='{$invoice['client_postcode']}',
					client_city='{$invoice['client_city']}',
					client_state='{$invoice['client_state']}',
					client_country='{$invoice['client_country']}',
					id_tax_condition='{$invoice['id_tax_condition']}',
					id_payment_type='{$invoice['id_payment_type']}',
					id_price_scale='{$invoice['id_price_scale']}',
					id_currency='{$invoice['id_currency']}',
					currencies='{$invoice['currencies']}',
					subtotal='{$invoice['subtotal']}',
					discount='{$invoice['discount']}',
					taxes='{$invoice['taxes']}',
					total='{$invoice['total']}',
					notes='{$invoice['notes']}',
					pending=1,
					id_invoice='$invoice_id'
			");
			foreach($invoice_items as $ii){
				$db->insert("
					INSERT INTO credit_note_items SET
					id_credit_note=$cnid,
					id_product={$ii['id_product']},
					reference='{$ii['reference']}',
					description='{$ii['description']}',
					quantity='{$ii['quantity']}',
					selected_stock='',
					price='{$ii['price']}',
					tax='{$ii['tax']}',
					total='{$ii['total']}'
				");
			}

			redirect("credit_note_edit.php?id=$cnid");
		}
	}

	if($_POST['save']){
		$pending = ($_POST['save']=='pending'?1:0);
		$number = (int)$_POST['number'];
		$date = date2db($_POST['date'],$date_format);
		$salesman = (int)$_POST['salesman'];
		$invoice_type = (int)$_POST['invoice_type'];
		$client = (int)$_POST['client'];
		$client_name = $db->escape_string($_POST['client_name']);
		$client_address = $db->escape_string($_POST['client_address']);
		$client_taxpayer_id = $db->escape_string($_POST['client_taxpayer_id']);
		$client_city = $db->escape_string($_POST['client_city']);
		$client_state = $db->escape_string($_POST['client_state']);
		$client_country = $db->escape_string($_POST['client_country']);
		$client_postcode = $db->escape_string($_POST['client_postcode']);
		$client_tax_condition = (int)$_POST['client_tax_condition'];
		$client_payment_type = (int)$_POST['client_payment_type'];
		$client_price_scale = (int)$_POST['client_price_scale'];
		$id_currency = (int)$_POST['currency'];
		if(is_array($_POST['currency_rates'])){
			$currencies = stringifyCurrencies($_POST['currency_rates']);
		}
		$subtotal = float($_POST['subtotal']);
		if(is_array($_POST['total_taxes'])){
			$taxes = stringifyTaxes($_POST['total_taxes']);
		}
		$discount = float($_POST['discount']);
		$total = float($_POST['total']);
		$notes = $db->escape_string($_POST['notes']);

		// The invoice has items
		if(is_array($_POST['ref'])){
			$credit_note_id = $db->insert("
				INSERT INTO credit_notes SET
					invoice_type='$invoice_type',
					number='$number',
					`date`='$date',
					due_date=DATE_ADD('$data',INTERVAL 30 DAY),
					salesman='$salesman',
					client_id='$client',
					client_name='$client_name',
					client_address='$client_address',
					client_taxpayer_id='$client_taxpayer_id',
					client_city='$client_city',
					client_postcode='$client_postcode',
					client_state='$client_state',
					client_country='$client_country',
					id_tax_condition='$client_tax_condition',
					id_payment_type='$client_payment_type',
					id_price_scale='$client_price_scale',
					id_currency='$id_currency',
					currencies='$currencies',
					subtotal='$subtotal',
					taxes='$taxes',
					discount='$discount',
					total='$total',
					pending=$pending,
					notes='$notes'
			");
			if($credit_note_id){
				foreach($_POST['ref'] as $k => $ref){
					$product_id = (int)$_POST['product_id'][$k];
					$ref = $db->escape_string($ref);
					$desc = $db->escape_string($_POST['desc'][$k]);
					$qty = $db->escape_string($_POST['qty'][$k]);
					$price = $db->escape_string($_POST['price'][$k]);
					$tax = $db->escape_string($_POST['tax'][$k]);
					$item_total = $db->escape_string($_POST['item_total'][$k]);
					$selected_stock = $db->escape_string($_POST['sel_stock'][$k]);
					$db->insert("
						INSERT INTO credit_note_items SET
							id_credit_note=$credit_note_id,
							id_product=$product_id,
							reference='$ref',
							description='$desc',
							quantity='$qty',
							selected_stock='$selected_stock',
							price='$price',
							tax='$tax',
							total='$item_total'
					");
					//~ if(!$pending){
						//~ $sel_stock = explode('|',$_POST['sel_stock'][$k]);
						//~ if(is_array($sel_stock)){
							//~ foreach($sel_stock as $st){
								//~ list($id,$qty) = explode(';',$st);
								//~ if((int)$id > 0 && (int)$qty > 0){
									//~ $db->insert("INSERT INTO products_stock SET
										//~ id_product=$product_id,
										//~ id_location=".(int)$id.",
										//~ quantity=(".(int)$qty." * -1),
										//~ relation='invoice|$invoice_id'
									//~ ");
								//~ }
							//~ }
						//~ } else {
						//~ }
					//~ }

					// Insert credit note in account
					if($client > 0){
						$curr_balance = float($db->fetch_item_field("SELECT balance FROM accounts WHERE id_client=$client ORDER BY `date` DESC,id DESC LIMIT 1"));
						$client_arr = $db->fetch_item("SELECT * FROM clients WHERE id=".(int)$client." LIMIT 1");
						$due_days = $client_arr['credit_limit'];
						$client_currency = $client_arr['credit_limit_currency'];
						if(!$client_currency){
							$foo = $db->fetch_item("SELECT id,symbol FROM currency ORDER BY `default` DESC,id LIMIT 1");
							$client_currency = $foo['id'];
						}

						$currencies_arr = parseCurrencies($currencies);
						$client_rate = $currencies_arr[$client_currency];
						$receipt_rate = $currencies_arr[$id_currency];

						$debit = round(1 * ($total * $receipt_rate / $client_rate),4);

						$db->insert("INSERT INTO accounts SET
							id_client=$client,
							type='credit_note',
							`date`=NOW(),
							due_date=ADDDATE(CURDATE(),INTERVAL $due_days DAY),
							id_item=$credit_note_id,
							reference='$number',
							id_currency='$id_currency',
							debit='$debit',
							credit=0,
							balance=($curr_balance + $debit),
							currencies='$currencies'
						");
					}
				}

				redirect("credit_note_details.php?id=$credit_note_id");
			}

			// INSERT error
			else{
				//echo $db->error();
			}

		}

		// The invoice doesn't have any item
		else {
		}
	}

	$salesmen = $db->fetch_all("
		SELECT u.*, IF(u.id='{$user->getId()}','selected=\"selected\"','') AS selected
		FROM users AS u
		WHERE u.can_sell=1
			AND deleted=0
	");
	$credit_note_number = max(1,$db->fetch_item_field("SELECT (MAX(number)+1) FROM credit_notes"));
	$tax_values = $db->fetch_all("SELECT percentage FROM taxes ORDER BY percentage",'percentage');
	$currency = $db->fetch_all("SELECT * FROM currency ORDER BY rate");

	$price_scale = $db->fetch_item("SELECT id,name FROM price_scales ORDER BY `default` DESC,id DESC LIMIT 1");
	$tax_conditions = $db->fetch_all("SELECT * FROM tax_conditions ORDER BY name");
	$payment_types = $db->fetch_all("SELECT * FROM payment_types ORDER BY name");
	$invoice_types = $db->fetch_all("SELECT * FROM invoice_types ORDER BY name");

	switch($config['invoice_search_field']){
		case 'internal_code': $first_field = __("Internal Code"); break;
		case 'manufacturers_code': $first_field = __("Manufacturers Code"); break;
		default: $first_field = __("Reference");
	}

	$return_url = return_to_module_url($module_name);

	$smarty->assign('return_url',$return_url);
	$smarty->assign('tax_conditions',$tax_conditions);
	$smarty->assign('payment_types',$payment_types);
	$smarty->assign('invoice_types',$invoice_types);
	$smarty->assign('credit_note_number',$credit_note_number);
	$smarty->assign('price_scale',$price_scale);
	$smarty->assign('currency',$currency);
	$smarty->assign('salesmen',$salesmen);
	$smarty->assign('first_field',$first_field);
	$smarty->assign('tax_values',implode(',',$tax_values));
	$smarty->assign('ignore_stock',($config['ignore_stock']?1:0));

	$smarty->display('credit_notes.tpl');
?>
