var SearchItemsBox = function(options){
	var self = this;
	this.items = null;
	this.current_item = null;
	this.lightbox = null;
	this.opened = false;
	this.error = false;

	var searchElements = {};

	var defaults = {
		requestUrl: 'ajax/search_client.php',
		returnField: 'id',
		returnContainer: 'item',
		secondaryField: 'name',
		secondaryFieldContainer: '',
		defaultValueContainer: null,
		fields: [ 'id','name','taxpayer_id','address','city','postcode' ],
		bindInputEvents: null,
		bindButtonEvents: null,
		onOpen: null,
		onClose: null,
		onSelect: null
	};

	this.options = merge(defaults,options);

	if(self.options.returnContainer){
		self.returnContainer = $(self.options.returnContainer);
	}
	if(self.options.secondaryFieldContainer){
		self.secondaryContainer = $(self.options.secondaryFieldContainer);
	}

	this.init = function(){
		// Creates Mainbox structure
		searchElements.mainBox = new Element('div',{ 'class':'lightbox search_box' });
		searchElements.inputField = new Element('input',{ type:'text', 'class':'search_items_input' });
		searchElements.searchImg = new Element('img',{ src:'##IMG_CLEAN##', width:20, height:20, alt:'X', 'class': 'search_items_clean_btn', events:{ 'click':function(){ self.resetSearch(); } } });
		searchElements.searchBtn = new Element('input',{ type:'button', value:'##NG_SEARCH##' });
		searchElements.searchResponse = new Element('div',{ 'class':'search_results_response' });
		searchElements.searchResultsTable = new Element('table',{ 'class': 'search_results_table'});
		var theadTR = new Element('tr');
		for(var i=0,len=self.options.fields.length; i<len; i++){
			theadTR.adopt(new Element('th',{ text: self.options.fields[i] }))
		}
		searchElements.searchResultsTableHead = new Element('thead').adopt(theadTR);
		searchElements.searchResultsTableBody = new Element('tbody');

		searchElements.mainBox
			.adopt(new Element('div',{'class':'search_item_search_container'})
				.adopt(searchElements.inputField)
				.adopt(searchElements.searchImg)
				.adopt(searchElements.searchBtn)
			)
			.adopt(searchElements.searchResponse
				.adopt(searchElements.searchResultsTable
					.adopt(searchElements.searchResultsTableHead)
					.adopt(searchElements.searchResultsTableBody)
				)
			)
			.inject(document.body);

		// Adds events for the relevant elements
		searchElements.inputField.addEvents({
			'keydown':function(ev){ if(ev.keyCode==13){ self.executeItemSearch(); } },
			'focus':function(){
				searchElements.searchResultsTableBody.getElements('tr').each(function(e){ e.removeClass('selected'); });
				self.current_item = null;
			}
		});
		searchElements.searchBtn.addEvent('click',function(){ self.executeItemSearch(); });

		if(self.options.bindInputEvents.length > 0){
			for(var i=0, len=self.options.bindInputEvents.length; i<len; i++){
				$(self.options.bindInputEvents[i]).addEvent('keydown', function(ev){
					if(!self.opened && ev.keyCode == 13){
						self.open();
						if(ev.preventDefault) ev.preventDefault();
						if(ev.preventBubble) ev.preventBubble();
						return false;
					}
				});
			}
		}

		if(self.options.bindButtonEvents.length > 0){
			for(var i=0, len=self.options.bindButtonEvents.length; i<len; i++){
				$(self.options.bindButtonEvents[i]).addEvent('click', function(ev){
					if(!self.opened){
						self.open();
						if(ev.preventDefault) ev.preventDefault();
						if(ev.preventBubble) ev.preventBubble();
						return false;
					}
				});
			}
		}

		self.lightbox = new Lightbox(searchElements.mainBox,{'onClose':function(){ self.opened=false;self.current_item=null; }})
		$(window).addEvent('keydown',function(ev){ self.searchItemNavigationListener(ev); });
	}

	this.close = function(){
		self.opened = false;
		self.current_item=null;
		self.lightbox.close();
		if(typeof self.options.onClose == 'function'){
			self.options.onClose.call(self);
		}
	}

	this.open = function(default_value){
		self.opened = true;
		self.lightbox.open();
		var defValCont = $(self.options.defaultValueContainer);
		if(defValCont){
			if(defValCont.get('tag') == 'INPUT'){
				searchElements.inputField.value = defValCont.value;
			} else if(defValCont.get('text')) {
				searchElements.inputField.value = defValCont.get('text');
			} else {
				searchElements.inputField.value = '';
			}
		} else if(default_value){
			searchElements.inputField.value = default_value;
		} else {
			if(self.returnContainer) searchElements.inputField.value = self.returnContainer.value;
		}
		searchElements.searchResultsTableBody.empty();
		self.current_item = null;
		self.executeItemSearch();
		if(typeof self.options.onOpen == 'function'){
			self.options.onOpen.call(self);
		}
	}

	this.resetSearch = function(){
		searchElements.inputField.value='';
		self.executeItemSearch();
	}

	this.executeItemSearch = function(){
		Request({
			'url':self.options.requestUrl,
			'method':'post',
			'data':{ 'q': searchElements.inputField.value },
			'onRequest': function(){
				searchElements.searchResultsTableBody.startWaiting();
			},
			'onSuccess':function(response){
				searchElements.searchResultsTableBody.stopWaiting();
				searchElements.searchResultsTableBody.empty();
				if(response.length){
					var res = parseJSON(response);
					for(var i=0,len=res.length; i<len; i++){
						var it = res[i];
						var tr = new Element('tr')
							.setStyle('cursor','pointer')
							.addEvent('click',function(){
								self.searchItem(this);
								self.close();
							});
						for(var j=0,len2=self.options.fields.length; j<len2; j++){
							var td = new Element('td',{ text: it[self.options.fields[j]] });
							if(j==0){
								new Element('input',{ 'type':'hidden','rel':'returnField','value':it[self.options.returnField] }).inject(td);
								if(self.options.secondaryField){
									new Element('input',{ 'type':'hidden','rel':'secondaryField','value':it[self.options.secondaryField] }).inject(td);
								}
							}
							td.inject(tr);
						}
						tr.inject(searchElements.searchResultsTableBody);
					}
					self.lightbox.reposition();
				}
			}
		});
		setFocus(searchElements.inputField);
	}

	this.searchItemNavigationListener = function(ev){
		if(calculator && calculator.opened) return false;
		if(self.opened == true){
			searchElements.searchResultsTableBody.getElements('tr').each(function(e){ e.removeClass('selected'); });

			if(ev.target == searchElements.inputField){
				if(ev.keyCode==40 || ev.keyCode==38){
					searchElements.inputField.blur();
				}
			}
			if(ev.keyCode==40){
				if(self.current_item == null){
					self.current_item = searchElements.searchResultsTableBody.getFirst('tr');
				} else {
					self.current_item = nextItem(self.current_item,'TR');
					if(!self.current_item) self.current_item = searchElements.searchResultsTableBody.getFirst('tr');
				}
			} else if(ev.keyCode==38){
				if(self.current_item == null){
					self.current_item = searchElements.searchResultsTableBody.getLast('tr');
				} else {
					self.current_item = previousItem(self.current_item,'TR');
					if(!self.current_item) self.current_item = searchElements.searchResultsTableBody.getLast('tr');
				}
			} else if(ev.keyCode==13) {
				if(self.current_item){
					//if($('item')) $('item').value = self.current_item.getFirst('td input').value;
					self.searchItem(self.current_item);
					self.close();
					return false;
				}
			}
			if(self.current_item){
				self.current_item.addClass('selected');
				var curPos = self.current_item.getPosition();
				var contHeight = searchElements.searchResponse.getPosition().height;
				var maxScroll = searchElements.searchResultsTable.getPosition().totalHeight - contHeight;
				var scroll = curPos.top + curPos.height - contHeight / 2;
				if(scroll < 0) scroll = 0;
				if(scroll > maxScroll) scroll = maxScroll;
				searchElements.searchResponse.scrollTop = scroll;
				if(ev.preventDefault) ev.preventDefault();
				if(ev.preventBubble) ev.preventBubble();
				return false;
			}
		}
	}

	this.searchItem = function(item){
		var value = item.getFirst('input[rel=returnField]').value;
		if(self.returnContainer){
			if(self.returnContainer.tagName == 'INPUT'){
				self.returnContainer.value = value;
			} else {
				self.returnContainer.set('text',value);
			}
		}
		if(self.secondaryContainer){
			if(self.secondaryContainer.tagName == 'INPUT'){
				self.secondaryContainer.value = item.getFirst('input[rel=secondaryField]').value;
			} else {
				self.secondaryContainer.set('text',item.getFirst('input[rel=secondaryField]').value);
			}
		}
		var data = {};
		data[self.options.returnField] = value;
		Request({
			'url':self.options.requestUrl,
			'method':'post',
			'data': data,
			'onSuccess':function(response){
				if(response.length){
					var res = parseJSON(response);
					if(typeof self.options.onSelect == 'function'){
						if(res[self.options.returnField]){
							self.options.onSelect.call(self,res);
							self.error = false;
						} else {
							self.options.onSelect.call(self,null);
							self.error = true;
						}
					}
				} else {
					self.error = true;
				}
			}
		});
	}

	this.init();
}
