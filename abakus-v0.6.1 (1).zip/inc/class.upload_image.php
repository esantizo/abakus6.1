<?php
include_once "class.image.php";

class UploadImage{
	private $db;
	private $type = null;
	public $deleted = null;
	private $uploads_path = null;
	private $tmp_path = null;

	public function __construct($db,$type,$uploadsPath=null){
		global $uploads_path;
		$this->db = $db;
		$this->type = $type;
		if($uploadsPath===null){
			$this->uploads_path = $uploads_path.'images/';
			$this->tmp_path = $uploads_path.'tmp/';
		} else {
			$this->uploads_path = $uploadsPath.'images/';
			$this->tmp_path = $uploadsPath.'tmp/';
		}
	}

	public function process_upload($post,$files){
		$db = $this->db;

		if($post['delete_image']){
			$old_image = $db->fetch_item("SELECT * FROM images WHERE id=".(int)$post['old_image']);
			if($old_image){
				unlink($this->uploads_path.$old_image['filename']);
				$db->delete("DELETE FROM images WHERE id={$old_image['id']}");
				$this->deleted = $old_image['id'];
			}
		}

		if(is_array($files['uploaded_image']) && $files['uploaded_image']['error']===0) {
			$image = new Image($files['uploaded_image']['tmp_name'],$errors);
			if(empty($errors)){
				switch($this->type){
					case 'product':
						$prefix = 'products_';
						break;
					case 'entity':
						$prefix = 'entities_';
						break;
					case 'user':
						$prefix = 'users_';
						break;
					case 'people':
						$prefix = 'people_';
						break;
					default:
				}

				do {
					$filename = $prefix.mt_rand().date("Ymd").'.jpg';
				} while(file_exists($this->uploads_path.$filename));

				$image->resize(800,600,MODE_KEEP_AR);
				if($image->save($this->uploads_path.$filename)){
					$post['image']= $filename."|".$image->getWidth()."|".$image->getHeight();
				}
			}
		}

		if($post['image']) { // The image comes from camera upload
			list($image_filename,$image_width,$image_height) = explode('|',$db->escape_string($post['image']));
			if(!empty($image_filename) && !empty($image_width) && !empty($image_height)){
				$image_id = $db->insert("INSERT INTO images SET filename='$image_filename', width='$image_width', height='$image_height'");
			}
		}
		return $image_id;
	}

	public function getForm($image){
?>
		<div id="snapshot_container_wrapper">
<?php if($image){
				$width_limit = 320;
				if($image['width'] > $width_limit){
					$image['height'] = round($image['height'] * $width_limit / $image['width']);
					$image['width'] = $width_limit;
				}
?>
			<div id="snapshot_container" class="form_field">
				<img src="<?php echo $this->uploads_path.$image['filename'];?>" width="<?php echo $image['width'];?>" height="<?php echo $image['height'];?>" alt="">
				<input type="hidden" name="old_image" value="<?php echo $image['id'];?>" >
<?php } else { ?>
			<div id="snapshot_container_buttons">
				<?php echo button('javascript:showSnapshot()',__('##NG_TAKE_SNAPSHOT##'),false,__('##IMG_TAKE_SNAPSHOT##')); ?>
				<?php echo button('javascript:showUpload()',__('##NG_UPLOAD_IMAGE##'),false,__('##IMG_UPLOAD##')); ?>
			</div>
			<div id="upload_container" class="form_field" style="display:none">
					<input type="file" id="uploaded_image" name="uploaded_image" size="6"><br>
					<input type="button" id="cancel" value="<?php echo __("##NG_CANCEL##");?>" onClick="hideUpload()">
					<div id="delete_image_info">
						<?php echo __("##NG_MUST_SAVE_TO_COMPLETE_IMAGE_SAVING##");?>
					</div>
			</div>
			<div id="snapshot_container" class="form_field" style="display:none">
<?php } ?>
				<div id="cam_image_container"></div>
				<div id="upload_results"></div>
				<input type="hidden" name="image" id="image" value="" >
				<div id="cam_image_buttons">
<?php if($image){ ?>
					<label><input type="checkbox" name="delete_image" onchange="if(this.checked){var display = 'block'} else {var display='none'}; $('delete_image_info').setStyle('display',display);"> <?php echo __("##NG_DELETE_IMAGE##");?></label>
					<div id="delete_image_info" style="display:none">
						<?php echo __("##NG_MUST_SAVE_TO_COMPLETE_IMAGE_DELETION##");?>
					</div>
<?php } else { ?>
					<input type="button" value="<?php echo __("##NG_CONFIGURE##");?>" onClick="webcam.configure()">
					&nbsp;&nbsp;
					<input type="button" id="take_snapshot" value="<?php echo __("##NG_TAKE_SNAPSHOT##");?>" onClick="takeSnapshot()">
					&nbsp;&nbsp;
					<input type="button" id="reset_snapshot" style="display:none" value="<?php echo __("##NG_RESET##");?>" onClick="resetSnapshot()">
					&nbsp;&nbsp;
					<input type="button" id="cancel" value="<?php echo __("##NG_CANCEL##");?>" onClick="hideSnapshot()">
					<div id="delete_image_info">
						<?php echo __("##NG_MUST_SAVE_TO_COMPLETE_IMAGE_SAVING##");?>
					</div>
<?php } ?>
				</div>
			</div>
		</div>
<?php
	}

	public function getJavascript($form){
?>
		var webcamOn = false;
		var uploadOn = false;
		var image_type = '<?php echo $this->type;?>';

		function takeSnapshot(){
			$('take_snapshot').setStyle('display','none');
			$('reset_snapshot').setStyle('display','inline');
			webcam.freeze();
		}

		function resetSnapshot(){
			$('reset_snapshot').setStyle('display','none');
			$('take_snapshot').setStyle('display','inline');
			if(webcam.loaded) webcam.reset();
		}

		function showSnapshot(){
			hideUpload();
			$('snapshot_container').setStyle('display','block');
			webcam.set_api_url('save_webcam_image.php?type='+image_type);
			webcam.set_quality(90); // JPEG quality (1 - 100)
			webcam.set_shutter_sound(false); // play shutter click sound
			webcam.set_hook('onError', 'cbWebcamError');
			webcam.set_hook('onLoad', 'cbWebcamLoad');
			webcam.set_hook('onComplete', 'cbWebcamActionComplete');
			resetSnapshot();
			$('cam_image_container').innerHTML = webcam.get_html(320, 240);
			webcamOn = true;
			deactivateControls();
		}

		function hideSnapshot(){
			activateControls();
			$('snapshot_container').setStyle('display','none');
			webcamOn = false;
		}

		function showUpload(){
			hideSnapshot();
			$('upload_container').setStyle('display','block');
			$('uploaded_image').disabled = false;
			uploadOn = true;
			deactivateControls();
		}

		function hideUpload(){
			activateControls();
			$('upload_container').setStyle('display','none');
			$('uploaded_image').disabled = true;
			uploadOn = false;
		}

		function activateControls(){
			$$('#snapshot_container_buttons a').each(function(el){
				el.removeClass("disabled");
				if(el.alt) el.href = el.alt;
			});
		}

		function deactivateControls(){
			$$('#snapshot_container_buttons a').each(function(el){
				el.addClass('disabled');
				el.alt = el.href;
				el.href = 'javascript:;';
			});
		}

		function cbWebcamError(msg) {
			msgBox('Error: '+msg);
			resetSnapshot();
		}

		function cbWebcamLoad() {
		}

		function cbWebcamActionComplete(msg) {
			// extract URL out of PHP output
			if (msg.match(/error\:(.*)/)) {
				var error = RegExp.$1;
				$('cam_image_buttons').setStyle('display','block');
				if($('action_buttons')) $('action_buttons').setStyle('display','block');
				$('upload_results').innerHTML = '';
				resetSnapshot();
				msgBox(msg);
			} else {
				$('image').value = msg;
				$('<?php echo $form;?>').submit();
			}
		}

		function uploadAndSubmit() {
			if(webcamOn){
				// Take snapshot and upload to server
				$('cam_image_buttons').setStyle('display','none');
				if($('action_buttons')) $('action_buttons').setStyle('display','none');
				$('upload_results').innerHTML = '<?php echo __("##NG_UPLOADING##");?>';
				webcam.upload();
			} else {
				$('<?php echo $form;?>').submit();
			}
		}

<?php
	}
}
