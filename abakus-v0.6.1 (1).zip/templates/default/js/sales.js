var searchLightbox;
var current = null;
var navigateItems = false;

function validate(){
	$$('#table_body tr').each(function(el){
		if(!el.get('id')){
			var cols = el.getElements('td');
			var curr_id = $(cols[0]).getFirst('input').value;
			var prod_id = $(cols[0]).getElements('input')[1].value.toInt();

			// Check stock
			var cant = $(cols[3]).get('text').toInt();
			if(!ignore_stock && prod_id > 0 && $(cols[3]).getElements('input')[1]){
				var stocks = $(cols[3]).getElements('input')[1].value.split('|');
				var sel_stocks = $(cols[3]).getElements('input')[2].value.split('|');
				if(!sel_stocks){
					messages.push("##NG_MUST_SELECT_STOCK## ("+item_ref+")");
				}
				var stock = {};
				var branches = {};
				var total_stock = 0;
				var item_ref = $(cols[1]).get('text');
				for(var i=0,len=stocks.length;i<len;i++){
					var tmp = stocks[i].split(';');
					if(tmp[1] > 0){
						stock[tmp[0]] = tmp[1].toInt();
						branches[tmp[0]] = tmp[2];
						total_stock += tmp[1].toInt();
					}
				}
				if(cant > total_stock){
					messages.push("##NG_STOCK_EXCEEDED## ("+item_ref+" - ##NG_MAXIMUM##: "+total_stock+")");
					$(cols[3]).addClass('stock_exceeded');
				} else {
					$(cols[3]).removeClass('stock_exceeded');
				}
				for(var i=0,len=sel_stocks.length;i<len;i++){
					var tmp = sel_stocks[i].split(';');
					if(tmp[0] && tmp[1]){
						var this_stock = tmp[1].toInt();
					} else {
						var this_stock = 0;
					}
					if(this_stock > stock[tmp[0]]){
						messages.push("##NG_NO_STOCK## ("+item_ref+"/"+branches[tmp[0]]+" - ##NG_STOCK##: "+stock[tmp[0]]+")");
					}
				}
			}
		}
	});
}

function saveInvoice(){
	//if(validate()){
		$('invoice_form').submit();
	//}
}

function savePending(){
	$('save').value = 'pending';
	$('invoice_form').submit();
}

function acceptEdit(el){
	var cols = $(el).getElements('td');
	var id_currency = $(cols[0]).getFirst('input').value;

	$(cols[0]).set('html','<input type="hidden" name="curr[]" value="'+id_currency+'"><input type="hidden" name="product_id[]" value="'+$(cols[0]).getElements('input')[1].value+'"><a href="javascript:;" onclick="deleteItem($(this).getParent(\'tr\'))"><img src="##IMG_DELETE##" width="20" height="20"></a> <a href="javascript:;" onclick="editItem($(this).getParent(\'tr\'))"><img src="##IMG_EDIT##" width="20" height="20"></a>');
	$(cols[2]).set('html','<input type="hidden" name="desc[]" value="'+$(cols[2]).getFirst('input').value+'">'+$(cols[2]).getFirst('input').value);
	if($('stock_input') && $('selected_stock')){
		$(cols[3]).set('html','<input type="hidden" name="qty[]" value="'+$(cols[3]).getFirst('input').value+'"><input type="hidden" name="stock[]" value="'+$(cols[3]).getElements('input')[1].value+'"><input type="hidden" name="sel_stock[]" value="'+$(cols[3]).getElements('input')[2].value+'">'+$(cols[3]).getFirst('input').value);
	} else {
		$(cols[3]).set('html','<input type="hidden" name="qty[]" value="'+$(cols[3]).getFirst('input').value+'">'+$(cols[3]).getFirst('input').value);
	}

	if(discriminate_taxes){
		var price = $(cols[4]).getFirst('input').value.replace(',','.');

		if(id_currency != $('currency').value){
			var currency_mult = $('curr_'+id_currency).value.toFloat() / $('curr_'+$('currency').value).value.toFloat();
			var orig_price = price / currency_mult;
		} else {
			var orig_price = price;
		}

		$(cols[4]).set('html','<input type="hidden" name="price[]" alt="'+orig_price+'" value="'+price+'">'+price);
		if($(cols[5]).getElements('select')[0]){
			$(cols[5]).set('html','<input type="hidden" name="tax[]" value="'+$(cols[5]).getFirst('select').value+'">'+$(cols[5]).getFirst('select').value);
		}
	} else {
		if($(cols[5]).getFirst('select')){
			var tax_val = $(cols[5]).getFirst('select').value;
		} else {
			var tax_val = $(cols[5]).get('text');
		}

		var price_taxed = $(cols[6]).getFirst('input').value.replace(',','.');
		var price = price_taxed / (1 + tax_val.toFloat() / 100);

		if(id_currency != $('currency').value){
			var currency_mult = $('curr_'+id_currency).value.toFloat() / $('curr_'+$('currency').value).value.toFloat();
			var orig_price = price / currency_mult;
		} else {
			var orig_price = price;
		}

		$(cols[4]).set('html','<input type="hidden" name="price[]" alt="'+orig_price+'" value="'+price+'">'+price);
		if($(cols[5]).getElements('select')[0]){
			$(cols[5]).set('html','<input type="hidden" name="tax[]" value="'+$(cols[5]).getFirst('select').value+'">'+$(cols[5]).getFirst('select').value);
		}
		$(cols[6]).set('text',price_taxed);
	}

	updateTotals();
	unlockCurrency();
	$('insert_row').setStyle('display','table-row');
	setFocus('ref_input');
}

function cancelEdit(el){
	var cols = $(el).getElements('td');
	$(cols[0]).set('html','<input type="hidden" name="curr[]" value="'+$(cols[0]).getFirst('input').value+'"><input type="hidden" name="product_id[]" value="'+$(cols[0]).getElements('input')[1].value+'"><a href="javascript:;" onclick="deleteItem($(this).getParent(\'tr\'))"><img src="##IMG_DELETE##" width="20" height="20"></a> <a href="javascript:;" onclick="editItem($(this).getParent(\'tr\'))"><img src="##IMG_EDIT##" width="20" height="20"></a>');
	$(cols[2]).set('html','<input type="hidden" name="desc[]" value="'+$(cols[2]).getFirst('input').get('alt')+'">'+$(cols[2]).getFirst('input').get('alt'));
	if($('stock_input') && $('selected_stock')){
		$(cols[3]).set('html','<input type="hidden" name="qty[]" value="'+$(cols[3]).getFirst('input').get('alt')+'"><input type="hidden" name="stock[]" value="'+$(cols[3]).getElements('input')[1].value+'"><input type="hidden" name="sel_stock[]" value="'+$(cols[3]).getElements('input')[2].value+'">'+$(cols[3]).getFirst('input').get('alt'));
	} else {
		$(cols[3]).set('html','<input type="hidden" name="qty[]" value="'+$(cols[3]).getFirst('input').get('alt')+'">'+$(cols[3]).getFirst('input').get('alt'));
	}
	if(discriminate_taxes){
		$(cols[4]).set('html','<input type="hidden" name="price[]" alt="'+$(cols[4]).getFirst('input').get('alt')+'" value="'+$(cols[4]).getFirst('input').get('alt')+'">'+$(cols[4]).getFirst('input').get('alt'));
	} else {
		$(cols[6]).set('html',$(cols[6]).getFirst('input').get('alt'));
	}
	if($(cols[5]).getElements('select')[0]){
		$(cols[5]).set('html','<input type="hidden" name="tax[]" value="'+$(cols[5]).getFirst('select').get('alt')+'">'+$(cols[5]).getFirst('select').get('alt'));
	}
	updateTotals();
	unlockCurrency();
	$('insert_row').setStyle('display','table-row');
	setFocus('ref_input');
}

function editItem(el){
	$('insert_row').setStyle('display','none');
	lockCurrency();
	var cols = $(el).getElements('td');

	var currval = $(cols[0]).getFirst('input').value;
	var prodidval = $(cols[0]).getElements('input')[1].value;

	$(cols[0]).empty()
		.adopt(new Element('input',{'type':'hidden','name':'curr[]','value':currval}))
		.adopt(new Element('input',{'type':'hidden','name':'product_id[]','value':prodidval}))
		.adopt(new Element('a',{'href':'javascript:;','html':'<img src="##IMG_ACCEPT##" width="20" height="20">','events':{'click':function(){acceptEdit($(this).getParent('tr'));}}}))
		.adopt(new Element('text',' '))
		.adopt(new Element('a',{'href':'javascript:;','html':'<img src="##IMG_CANCEL##" width="20" height="20">','events':{'click':function(){cancelEdit($(this).getParent('tr'));}}}));

	var desc = $(cols[2]).get('text');
	var cant = $(cols[3]).getFirst('input').value.toInt();
	if($('stock_input') && $('selected_stock')){
		var stock = $(cols[3]).getElements('input')[1].value;
		var sel_stock = $(cols[3]).getElements('input')[2].value;
	}
	if(discriminate_taxes){
		var price = $(cols[4]).getFirst('input').value.toFloat();
		var orig_price = $(cols[4]).getFirst('input').get('alt').toFloat();
		$(cols[4]).empty();
	} else {
		var orig_price = $(cols[6]).get('text').toFloat();
		$(cols[6]).empty();
	}
	if($(cols[1]).get('text')=='0'){
		var tax = $(cols[5]).getFirst('input').value.toFloat();
		$(cols[5]).empty();
	}
	$(cols[2]).empty();
	$(cols[3]).empty();
	if(discriminate_taxes){
		if($(cols[1]).get('text')=='0'){
			var sel = new Element('select',{'alt':tax}).inject(cols[5]);
			sel.addEvent('keydown',function(ev){if(ev.keyCode==13){acceptEdit(el);}});
			var opt = new Element('option',{'text':''}).inject(sel);
			for(i in tax_values){
				if(!isNaN(tax_values[i])){
					opt = new Element('option',{'text':tax_values[i]+'%'}).inject(sel);
					if(tax_values[i]==tax) opt.set('selected','selected');
				}
			}
		}
		var inp_desc = new Element('input',{'type':'text','alt':desc,'value':desc}).addEvent('keydown',function(ev){if(ev.keyCode==13){setFocus(inp_cant);inp_cant.select();}}).inject(cols[2]);
		var inp_cant = new Element('input',{'type':'text','alt':cant,'value':cant}).addEvent('keydown',function(ev){
			quantityHandler(ev,inp_stock,sel_stock,inp_cant,inp_price);
		}).inject(cols[3]);
		if($('stock_input') && $('selected_stock')){
			var inp_stock = new Element('input',{'type':'hidden','value':stock}).inject(cols[3]);
			var sel_stock = new Element('input',{'type':'hidden','value':sel_stock}).inject(cols[3]);
		}

		var inp_price = new Element('input',{'type':'text','alt':orig_price,'value':price.round(4)});
		if(sel){
			inp_price.addEvent('keydown',function(ev){if(ev.keyCode==13){setFocus(sel);}}).inject(cols[4]);
		} else {
			inp_price.addEvent('keydown',function(ev){if(ev.keyCode==13){acceptEdit(el);}}).inject(cols[4]);
		}
	} else {
		var inp_desc = new Element('input',{'type':'text','alt':desc,'value':desc}).addEvent('keydown',function(ev){if(ev.keyCode==13){setFocus(inp_cant);inp_cant.select();}}).inject(cols[2]);
		var inp_cant = new Element('input',{'type':'text','alt':cant,'value':cant}).addEvent('keydown',function(ev){
			quantityHandler(ev,inp_stock,sel_stock,inp_cant,inp_price);
		}).inject(cols[3]);
		if($('stock_input') && $('selected_stock')){
			var inp_stock = new Element('input',{'type':'hidden','value':stock}).inject(cols[3]);
			var sel_stock = new Element('input',{'type':'hidden','value':sel_stock}).inject(cols[3]);
		}

		var inp_price = new Element('input',{'type':'text','alt':orig_price,'value':orig_price.round(4)});
		inp_price.addEvent('keydown',function(ev){if(ev.keyCode==13){acceptEdit(el);}}).inject(cols[6]);
	}

	setFocus(inp_desc);
	inp_desc.select();
}

function deleteItem(el){
	if(confirmBox("##NG_DELETE_CONFIRMATION##")){
		$(el).destroy();
		updateTotals();
	}
}

function lockCurrency(){
	var inputs = ['#currency','.currency_data input[type=text]','#invoice_type','#discriminate_taxes'];
	disableInputs(inputs);
	if($('save_btn')) $('save_btn').setStyle('display','none');
	if($('save_pending_btn')) $('save_pending_btn').setStyle('display','none');
	if($('save_and_new')) $('save_and_new').setStyle('display','none');
}

function unlockCurrency(){
	var inputs = ['#currency','.currency_data input[type=text]','#invoice_type','#discriminate_taxes'];
	enableInputs(inputs);
	if($('save_btn')) $('save_btn').setStyle('display','inline');
	if($('save_pending_btn')) $('save_pending_btn').setStyle('display','inline');
	if($('save_and_new')) $('save_and_new').setStyle('display','inline');
}

function lockDescription(){
	var inputs = ['desc_input','qty_input','unit_price','unit_price_taxed'];
	for(var i=0,len=inputs.length; i<len; i++){
		if($(inputs[i])) $(inputs[i]).setStyle('display','none');
	}
	//var inputs = ['#desc_input','#qty_input','#unit_price'];
	//disableInputs(inputs);
}

function unlockDescription(){
	var inputs = ['desc_input','qty_input','unit_price','unit_price_taxed'];
	for(var i=0,len=inputs.length; i<len; i++){
		if($(inputs[i])) $(inputs[i]).setStyle('display','inline');
	}
//	var inputs = ['#desc_input','#qty_input','#unit_price'];
//	enableInputs(inputs);
}

function updateTotals(){
	var childs = $('table_body').childNodes;
	if($('currency').options){
		var symbol = $($('currency').options[$('currency').selectedIndex]).get('rel');
	} else {
		var symbol = $('currency').get('rel');
	}

	var subtotal = 0;
	var taxes = {};
	var total = 0;
	var messages = [];
	for(i in childs) if(typeof(childs[i])=='object' && childs[i].tagName=='TR' && !childs[i].getAttribute('id')){
		var cols = $(childs[i]).getElements('td');
		var curr_id = $(cols[0]).getFirst('input').value;
		var prod_id = $(cols[0]).getElements('input')[1].value.toInt();

		// Check stock
		var cant = $(cols[3]).get('text').toInt();
		if(!ignore_stock && prod_id > 0 && $(cols[3]).getElements('input')[1]){
			var stocks = $(cols[3]).getElements('input')[1].value.split('|');
			var sel_stocks = $(cols[3]).getElements('input')[2].value.split('|');
			var stock = {};
			var branches = {};
			var total_stock = 0;
			var item_ref = $(cols[1]).get('text');
			for(var i=0,len=stocks.length;i<len;i++){
				var tmp = stocks[i].split(';');
				if(tmp[1] > 0){
					stock[tmp[0]] = tmp[1].toInt();
					branches[tmp[0]] = tmp[2];
					total_stock += tmp[1].toInt();
				}
			}
			if(cant > total_stock){
				messages.push("##NG_STOCK_EXCEEDED## ("+item_ref+" - ##NG_MAXIMUM##: "+total_stock+")");
				$(cols[3]).addClass('stock_exceeded');
			} else {
				$(cols[3]).removeClass('stock_exceeded');
			}
			for(var i=0,len=sel_stocks.length;i<len;i++){
				var tmp = sel_stocks[i].split(';');
				if(tmp[0] && tmp[1]){
					var this_stock = tmp[1].toInt();
				} else {
					var this_stock = 0;
				}
				if(this_stock > stock[tmp[0]]){
					messages.push("##NG_NO_STOCK## ("+item_ref+"/"+branches[tmp[0]]+" - ##NG_STOCK##: "+stock[tmp[0]]+")");
				}
			}
		}

		var precio = $(cols[4]).getFirst('input').value.toFloat();
		var orig_price = $(cols[4]).getFirst('input').get('alt').toFloat();

		if(orig_price && $('curr_'+curr_id)){
			var currency_mult = $('curr_'+curr_id).value.toFloat();
			var current_mult = $('curr_'+$('currency').value).value.toFloat();
			precio = orig_price * currency_mult / current_mult;
		} else {
			orig_price = precio;
		}

		$(cols[4]).empty().adopt(new Element('input',{'type':"hidden",'alt':orig_price,'name':"price[]",'value':precio})).adopt(new Element('text',symbol+' '+precio.round(4)));

		var tax_name = $(cols[5]).get('text');
		var iva = $(cols[5]).getElements('input')[0].value.toFloat();

		$(cols[6]).empty().adopt(new Element('text',symbol+' '+((1+iva/100)*precio).round(4)));

		$(cols[7]).empty().adopt(new Element('input',{'type':"hidden",'name':"item_total[]",'value':cant*precio})).adopt(new Element('text',symbol+' '+(cant*precio).round(4)));

		$(cols[8]).empty().adopt(new Element('text',symbol+' '+(cant*(1+iva/100)*precio).round(4)));

		subtotal += (cant*precio);
		if(!isNaN(taxes[iva]))
			taxes[iva] += (cant*precio) * (iva/100);
		else
			taxes[iva] = (cant*precio) * (iva/100);
	}

	total = subtotal;

	for(i in taxes){
		val = taxes[i].toFloat();
		if(!isNaN(val)){
			total+=val;
		}
	}

	var discount = 0;
	if($('discount_p')) var discount_p = $('discount_p').value.toFloat();
	if(discount_p > 0){
		if($('salesman').getSelected){
			var max_discount = $('salesman').getSelected().get('rel');
		} else {
			var max_discount = $('salesman').get('rel');
		}
		if(discount_p > max_discount){
			discount_p = 0;
			discount = 0;
			messages.push("##NG_CANNOT_APPLY_THIS_DISCOUNT##");
			effective_total = total;
		} else {
			effective_total = total * (100 - discount_p) / 100;
			discount = total - effective_total;
		}
	} else {
		effective_total = total;
	}

	$('subtotals').empty()
		.adopt(new Element('text','##Subtotal## '))
		.adopt(new Element('input',{'type':"hidden",'name':"subtotal",'id':"invoice_subtotal",'value':subtotal.round(4)}))
		.adopt(new Element('text',symbol+' '+subtotal.round(4))).adopt(new Element('br'));

	if(discount > 0){
		discount = discount.round(4);
		$('subtotals')
			.adopt(new Element('text','##NG_DISCOUNT## '))
			.adopt(new Element('input',{'type':"hidden",'name':"discount",'id':"invoice_discount",'value':discount}))
			.adopt(new Element('text',symbol+' '+(subtotal * discount_p / 100).round(4))).adopt(new Element('br'));
	}

	for(i in taxes){
		val = taxes[i].toFloat().round(4);
		if(!isNaN(val)){
			$('subtotals')
				.adopt(new Element('text','##Tax## ('+i+'%) '))
				.adopt(new Element('input',{'type':'hidden','class':'invoice_taxes','name':'total_taxes['+i+']','id':'total_taxes_'+i,'value':val,'data-tax':i}));
			if(discount > 0){
				$('subtotals').adopt(new Element('text',symbol+' '+(val * (100 - discount_p) / 100).round(4))).adopt(new Element('br'));
			} else {
				$('subtotals').adopt(new Element('text',symbol+' '+val)).adopt(new Element('br'));
			}
		}
	}

	$('subtotals')
		.adopt(new Element('text','##Total## '))
		.adopt(new Element('input',{'type':"hidden",'name':"total",'id':"invoice_total",'value':effective_total.round(4)}))
		.adopt(new Element('text',symbol+' '+effective_total.round(4))).adopt(new Element('br'));

	var credit_limit = $('client_credit_limit_input').value.toFloat();
	if($('client_credit_limit_currency_input'))
		var credit_limit_currency = $('client_credit_limit_currency_input').value;
	if(orig_price && credit_limit_currency){
		var currency_mult = $('curr_'+credit_limit_currency).value.toFloat();
		var current_mult = $('curr_'+$('currency').value).value.toFloat();
		credit_limit = (credit_limit * currency_mult / current_mult).round(4);
	}
	if(credit_limit && effective_total.round(4) > credit_limit){
		var msg = '<span id="overlimit">##NG_CREDIT_LIMIT_EXCEEDED##</span>';
		if(!$('save_btn') && $('footnotes')){
			msg += ' <a href="#" onclick="addNote($(\'overlimit\').get(\'text\'))">##NG_ADD_TO_NOTES##</a>';
		}
		messages.push(msg);
	}

	if(messages.length > 0){
		$('messages').set('html',messages.join('<br>')).addClass('error').setStyle('display','block');
		if($('save_btn')) $('save_btn').setStyle('display','none');
	} else {
		$('messages').set('text','').setStyle('display','none').removeClass('error');
		if($('save_btn')) $('save_btn').setStyle('display','inline');
	}
}

function itemOk(){
	var id_currency = $('curr_input').value;
	if(!id_currency) id_currency = $('currency').value;
	var tr = new Element('tr');
	var td = new Element('td')
		.adopt(new Element('input',{'type':'hidden','name':'curr[]','value':id_currency}))
		.adopt(new Element('input',{'type':'hidden','name':'product_id[]','value':$('prod_id_input').value}))
		.adopt(new Element('a',{'href':'javascript:;','html':'<img src="##IMG_DELETE##" width="20" height="20">','events':{'click':function(){deleteItem($(this).getParent('tr'));}}}))
		.adopt(new Element('text',' '))
		.adopt(new Element('a',{'href':'javascript:;','html':'<img src="##IMG_EDIT##" width="20" height="20">','events':{'click':function(){editItem($(this).getParent('tr'));}}}))
		.inject(tr);
	td = new Element('td')
		.adopt(new Element('input',{'type':'hidden','name':'ref[]','value':html_entity_decode($('ref_input').value)}))
		.adopt(new Element('text',$('ref_input').value))
		.inject(tr);
	td = new Element('td')
		.adopt(new Element('input',{'type':'hidden','name':'desc[]','value':html_entity_decode($('desc_input').value)}))
		.adopt(new Element('text',$('desc_input').value))
		.inject(tr);
	td = new Element('td')
		.adopt(new Element('input',{'type':'hidden','name':'qty[]','value':$('qty_input').value}));
	if($('stock_input') && $('selected_stock')){
		td.adopt(new Element('input',{'type':'hidden','name':'stock[]','value':$('stock_input').value}))
			.adopt(new Element('input',{'type':'hidden','name':'sel_stock[]','value':$('selected_stock').value}));
	}
	td.adopt(new Element('text',$('qty_input').value))
		.inject(tr);

	if($('tax_select')){
		var tax_val = $('tax_select').value;
	} else {
		var tax_val = $('tax').get('html');
	}

	if(discriminate_taxes){
		var unit_price = $('unit_price').value.replace(',','.');
		var unit_price_taxed = unit_price.toFloat() * (1 + tax_val.toFloat() / 100);
	} else {
		var unit_price_taxed = $('unit_price_taxed').value.replace(',','.');
		var unit_price = unit_price_taxed / (1 + tax_val.toFloat() / 100);
	}

	if(id_currency != $('currency').value){
		var currency_mult = $('curr_'+id_currency).value.toFloat() / $('curr_'+$('currency').value).value.toFloat();
		var orig_price = unit_price / currency_mult;
	} else {
		var orig_price = unit_price;
	}

	td = new Element('td',{'class':'unit_price_cell'})
		.adopt(new Element('input',{'type':'hidden','name':'price[]','alt':orig_price,'value':unit_price}))
		.adopt(new Element('text',unit_price))
		.inject(tr);
	td = new Element('td',{'class':'tax_cell'})
		.adopt(new Element('input',{'type':'hidden','name':'tax[]','value':tax_val}))
		.adopt(new Element('text',tax_val))
		.inject(tr);

	td = new Element('td',{'class':'unit_price_taxed_cell' })
		.adopt(new Element('text',unit_price_taxed.round(4)))
		.inject(tr);
	td = new Element('td',{'class':'amount_single_cell'})
		.adopt(new Element('input',{'type':'hidden','name':'item_total[]','value':($('qty_input').value*$('unit_price').value)}))
		.adopt(new Element('text',($('qty_input').value*unit_price.toFloat()).round(4)))
		.inject(tr);
	td = new Element('td',{'class':'amount_taxed_cell'})
		.adopt(new Element('text',($('qty_input').value*unit_price_taxed).round(4)))
		.inject(tr);
	$('table_body').insertBefore(tr,$('insert_row'));

	updateTotals();

	$('prod_id_input').value = '';
	$('curr_input').value = '';
	$('ref_input').value = '';
	$('desc_input').value = '';
	if($('stock_input') && $('selected_stock')){
		$('stock_input').value = '';
		$('selected_stock').value = '';
	}
	if($('tax_select')){
		$('tax_select').destroy();
	}
	$('qty_input').value = '';
	$('unit_price').value = '';
	$('unit_price_taxed').value = '';
	$('tax').set('html','').set('rel','');
	$('total').set('html','');
	$('total_taxed').set('html','');
	lockDescription();
	unlockCurrency();
	changeInvoiceType(discriminate_taxes);
	setFocus('ref_input');
}

function openSearchItemBox(){
	searchLightbox = new Lightbox('box_search_item',{'focusOnClose':'ref_input','onClose':function(){navigateItems = false;current=null;}}).open();
	$('search_item_input').value=$('ref_input').value;
	$('items_results_table_body').empty();
	navigateItems = true;
	current = null;
	executeItemSearch();
}

function executeItemSearch(){
	Request({
		'url':'ajax/search_item.php',
		'method':'post',
		'data':'q='+$('search_item_input').value+'&psid='+$('client_price_scale_input').value+'&cur='+$('curr_'+$('currency').value).value.toFloat(),
		'onSuccess':function(response){
			$('items_results_table_body').set('html',response);
			var els = $('items_results_table').getElements('tbody tr');
			for(i in els){
				tr = $(els[i]);
				if(tr && tr.tagName=='TR'){
					tr.setStyle('cursor','pointer');
					tr.addEvent('click',function(){
						$('ref_input').value = this.getElements('td')[0].innerHTML;
						searchLightbox.close();
						searchItem();
					});
				}
			}
		}
	});
	setFocus('search_item_input');
}

function searchItem(){
	Request({
		'url':'ajax/search_item.php',
		'method':'post',
		'data':'ref='+$("ref_input").value+'&psid='+$('client_price_scale_input').value,
		'onSuccess':function(res){
			if(res.length > 0){
				unlockDescription();
				lockCurrency();
				var json = parseJSON(res);
				var id_currency = (json.id_currency?json.id_currency:0) * 1;
				$("curr_input").value = json.id_currency;
				$("prod_id_input").value = json.product_id;
				$("desc_input").value = json.short_description;
				if($('stock_input')){
					$("stock_input").value = json.stock;
				}
				$('qty_input').value = 1;

				var price = json.price;
				var currency_mult = $('curr_'+id_currency).value.toFloat();
				var current_mult = $('curr_'+$('currency').value).value.toFloat();
				price = (price * currency_mult / current_mult);

				$("unit_price").value = price.round(4);
				$("unit_price").set('alt',json.price);
				if($('unit_price_taxed')){
					var price_taxed = price.toFloat() * (1 + json.tax.toFloat() / 100);
					$("unit_price_taxed").value = price_taxed.round(4);
					$("unit_price_taxed").set('alt',price_taxed);
					$('total_taxed').set('text', price_taxed.round(4));
				}
				$("tax").set('html',json.tax+'%').set('rel',json.tax_name);
				$('total').set('text', price.round(4));
				setFocus("desc_input");
			} else {
				openSearchItemBox();
			}
		}
	});
}

function openSearchNoteBox(){
	searchLightbox = new Lightbox('box_search_notes',{'focusOnClose':'notes','onClose':function(){navigateNotes=false;current=null;}}).open();
	$('notes_results_table_body').empty();
	navigateNotes = true;
	current = null;
	executeNotesSearch();
}

function addNote(str){
	if($('notes').value.length > 0) $('notes').value += "\n\n";
	$('notes').value += str;
}

function executeNotesSearch(){
	Request({
		'url':'ajax/search_notes.php',
		'method':'post',
		'data':'q='+$('search_notes_input').value,
		'onSuccess':function(response){
			$('notes_results_table_body').set('html',response);
			var els = $('notes_results_table').getElements('tbody tr');
			for(i in els){
				tr = $(els[i]);
				if(tr && tr.tagName=='TR'){
					tr.setStyle('cursor','pointer');
					tr.addEvent('click',function(){
						addNote(this.getFirst('td input').value);
						searchLightbox.close();
					});
				}
			}
		}
	});
	setFocus('notes');
}

function searchClientData(id,cbFunction){
	Request({
		'url':'ajax/search_client.php',
		'method':'post',
		'data':'id='+id,
		'onSuccess':function(response){
			if(response){
				var res = parseJSON(response);
			}
			if(res && res.name){
				$('client').set('rel',id);
				$('client_name').set('html',(res.name?res.name:''));
				$('client_address').set('html',(res.address?res.address:''));
				$('client_price_scale').set('html',(res.price_scale?res.price_scale:''));
				$('client_tax_condition').set('html',(res.tax_condition?res.tax_condition:''));
				$('client_payment_type').set('html',(res.payment_type?res.payment_type:''));
				$('client_taxpayer_id').set('html',(res.taxpayer_id?res.taxpayer_id:''));
				if(res.postcode && res.city)
					$('client_city').set('html','('+res.postcode+') '+res.city);
				else
					$('client_city').set('html',(res.city?res.city:''));
				$('client_state').set('html',(res.state?res.state:''));
				$('client_country').set('html',(res.country?res.country:''));
				$('client_credit_limit').set('html',(res.credit_limit?res.credit_limit_symbol+' '+res.credit_limit:''));

				$('client_name_input').value = (res.name?res.name:'');
				$('client_address_input').value = (res.address?res.address:'');
				$('client_price_scale_input').value = (res.price_scale_id?res.price_scale_id:'');
				$('client_tax_condition_input').value = (res.tax_condition_id?res.tax_condition_id:'');
				$('client_tax_condition_input').set('data-printer-code',res.tax_condition_printer_code);
				$('client_payment_type_input').value = (res.payment_type_id?res.payment_type_id:'');
				$('client_taxpayer_id_input').value = (res.taxpayer_id?res.taxpayer_id:'');
				$('client_city_input').value = (res.city?res.city:'');
				$('client_state_input').value = (res.state?res.state:'');
				$('client_country_input').value = (res.country?res.country:'');
				$('client_postcode_input').value = (res.postcode?res.postcode:'');
				$('client_credit_limit_input').value = (res.credit_limit?res.credit_limit.toFloat():0);
				$('client_credit_limit_currency_input').value = (res.credit_limit?res.credit_limit_currency.toInt():0);

				$('invoice_table').setStyle('display','block');

				$('client').onkeydown = function(){return false;};
				$('client').setStyles({
					'background':'transparent',
					'border':0,
					'padding':'0',
					'-webkit-box-shadow':'none',
					'-moz-box-shadow':'none',
					'box-shadow':'none'
				});
				$('search_item_icon').setStyle('display','none');

				if(typeof cbFunction == 'function'){
					cbFunction.call(this,res);
				}

				setFocus("ref_input");
			} else {
				msgBox("##NG_WRONG_CLIENT##");
				setFocus('client');
			}
		}
	});
}

function searchClient(id){
	if(id==0) {
		setFocus(nextInput('client'));
		return false;
	}
	searchClientData(id);
}

function updateRemaining(){
	var total_qty = 0;
	$$('#stock_response .qty_input').each(function(el){
		total_qty += el.value.toInt();
	});
	var rem = $('total_qty').get('rel').toInt() - total_qty;
	var classname = '';
	if(rem > 0) classname = 'over';
	if(rem < 0) classname = 'under';
	$('remaining_qty').set({'text':rem,'class':classname});
}

function quantityHandler(ev,data_container,selected_container,quantity_container,next_field){
	if(ev.keyCode==13){
		var self = ev.target;
		if(!ignore_stock && $(data_container) && $(data_container).value.length > 0){
			var stocks = $(data_container).value.split('|');
			if(stocks.length == 1){
				var data = stocks[0].split(';');
				$(selected_container).value = data[0]+';'+self.value;
				setFocus(next_field);
				$(next_field).select();
			} else if(stocks.length > 1){
				var first = null;
				var inputs = [];
				$('stock_response').empty();
				var startValues = {};
				$(selected_container).value.split('|').each(function(el){
					var thisel = el.split(';');
					startValues[thisel[0]] = thisel[1];
				});
				new Element('div')
					.adopt(new Element('span',{'text':'Cantidad Total: '}))
					.adopt(new Element('span',{'rel':self.value,'text':self.value,'id':'total_qty'}))
					.inject('stock_response');
				new Element('div')
					.adopt(new Element('span',{'text':'Restantes: '}))
					.adopt(new Element('span',{'text':self.value,'id':'remaining_qty'}))
					.inject('stock_response');
				for(var i=0,len=stocks.length;i<len;i++){
					var data = stocks[i].split(';');
					var el = new Element('label').inject('stock_response');
					el.adopt(new Element('span',{'text':data[2]+' (max: '+data[1]+'): '}));
					var inp = new Element('input',{'type':'text','value':0,'class':'qty_input','id':'qty_input_'+i,'rel':i,'data-id':data[0],'data-max':data[1]});
					if(startValues[data[0]]) inp.set('value',startValues[data[0]]);
					el.adopt(inp);
					inputs.push(inp);
				}
				for(var i=0,len=inputs.length-1; i<len; i++){
					inputs[i].addEvent('keyup',function(ev){
						if(ev.keyCode==13){
							setFocus($('qty_input_'+(this.get('rel').toInt()+1)));
						} else if (!keyCodeIsNumber(ev.keyCode) && !keyCodeIsNavigation(ev.keyCode)) {
							ev.stopPropagation();
							return false;
						} else {
							updateRemaining();
						}
					});
				}

				new Element('div',{'id':'qty_message'}).setStyle('display','none').inject('stock_response');

				if(inputs[inputs.length-1]) inputs[inputs.length-1].addEvent('keyup',function(ev){
					if(ev.keyCode==13){
						var sel_stock = [];
						var total_qty = 0;
						$$('#stock_response .qty_input').each(function(el){
							sel_stock.push(el.get('data-id')+';'+el.value);
							total_qty += el.value.toInt();
						});
						if(total_qty != $('total_qty').get('rel').toInt()){
							$('qty_message').set('text','##NG_QUANTITY_DOESNT_MATCH_STOCK##').setStyle('display','block');
							searchLightbox.autoHeight();
							setFocus($$('#stock_response .qty_input')[0]);
						} else {
							$(selected_container).value = sel_stock.join('|');
							$(quantity_container).value = total_qty;
							searchLightbox.close();
							setFocus($(next_field));
							$(next_field).select();
						}
					} else {
						updateRemaining();
					}
				});
				setFocus(inputs[0]);
				updateRemaining();
				searchLightbox = new Lightbox('box_stock',{'onClose':function(){searchLightbox=null}}).open().autoHeight();
			} else {
				setFocus(next_field);
				$(next_field).select();
			}
		} else {
			setFocus(next_field);
			$(next_field).select();
		}
	}
}

function changeInvoiceType(discriminate){
	if(discriminate===true || (discriminate && discriminate.toInt()>0)){
		discriminate_taxes = true;
	} else {
		discriminate_taxes = false;
	}
	if(discriminate_taxes){
		$$('.unit_price_cell').setStyle('display','table-cell');
		$$('.tax_cell').setStyle('display','table-cell');
		$$('.amount_single_cell').setStyle('display','table-cell');

		$$('.unit_price_taxed_cell').setStyle('display','none');
		$$('.amount_taxed_cell').setStyle('display','none');
	} else {
		$$('.unit_price_cell').setStyle('display','none');
		$$('.tax_cell').setStyle('display','none');
		$$('.amount_single_cell').setStyle('display','none');

		$$('.unit_price_taxed_cell').setStyle('display','table-cell');
		$$('.amount_taxed_cell').setStyle('display','table-cell');
	}
}

function searchNavigationListener(ev){
	if(calculator && calculator.opened) return false;
	if(navigateItems==true){
		$$('#items_results_table_body tr').each(function(e){e.removeClass('selected');});
		if(ev.target==$('search_item_input')){
			if(ev.keyCode==40 || ev.keyCode==38){
				$('search_item_input').blur();
			}
		}
		if(ev.keyCode==40){
			if(current == null){
				current = $('items_results_table_body').getFirst('tr');
			} else {
				current = nextItem(current,'TR');
				if(!current) current = $('items_results_table_body').getFirst('tr');
			}
		} else if(ev.keyCode==38){
			if(current == null){
				current = $('items_results_table_body').getLast('tr');
			} else {
				current = previousItem(current,'TR');
				if(!current) current = $('items_results_table_body').getLast('tr');
			}
		} else if(ev.keyCode==13) {
			if(current){
				$('ref_input').value = current.getElements('td')[0].innerHTML;
				searchLightbox.close();
				searchItem();
				navigateItems = false;
				return false;
			}
		}
		if(current){
			current.addClass('selected');
			var curPos = current.getPosition();
			if($('items_results_table')){
				var contHeight = $('search_item_response').getPosition().height;
				var maxScroll = $('items_results_table').getPosition().totalHeight - contHeight;
			}
			var scroll = curPos.top + curPos.height - contHeight / 2;
			if(scroll < 0) scroll = 0;
			if(scroll > maxScroll) scroll = maxScroll;
			if($('items_results_table')){
				$('search_item_response').scrollTop = scroll;
			}
			if(ev.preventDefault) ev.preventDefault();
			if(ev.preventBubble) ev.preventBubble();
			return false;
		}
	}
}
