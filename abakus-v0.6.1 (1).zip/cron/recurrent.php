<?
	include '../inc/functions_invoices.php';

	// Parking_cron

	$date = date('Y-M-d');

	$res = $db->fetch_all("
		SELECT *,
			CASE period_unit
				WHEN 'DAY' THEN DATE_ADD(start, INTERVAL (period * (renovation_number+1)) DAY)
				WHEN 'MONTH' THEN DATE_ADD(start, INTERVAL (period * (renovation_number+1)) MONTH)
				WHEN 'YEAR' THEN DATE_ADD(start, INTERVAL (period * (renovation_number+1)) YEAR)
			END
			AS newDate
		FROM recurrent
		WHERE active=1
			AND start <= DATE(NOW())
		HAVING newDate = DATE(NOW())
	");

	if(is_array($res)) foreach($res as $r){
		if($r['action_name'] == 'parking_monthly'){
			$parking_id = (int)$r['action_rel'];
			$parking = $db->fetch_item("SELECT * FROM parking WHERE id=$parking_id");
			if($parking){
				generateParkingInvoice($parking);
			}
		}
	}


?>
