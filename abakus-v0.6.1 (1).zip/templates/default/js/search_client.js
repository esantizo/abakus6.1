var lightbox_clients;
var navigateClients = false;
var client_relfield_name = 'id';
var client_hiddenfield_name = null;

$(document).addEvent('domready',function(){
	if(!$('box_search_client')){
		new Element('div',{ 'id':'box_search_client', 'class':'lightbox search_box' })
			.adopt(new Element('div',{'class':'search_item_search_container'})
				.adopt(new Element('input',{ type:'text', id:'search_client_input', 'class':'search_items_input' }))
				.adopt(new Element('img',{ src:'##IMG_CLEAN##', width:20, height:20, alt:'X', 'class': 'search_items_clean_btn', events:{'click':function(){ resetSearch(); } } }))
				.adopt(new Element('input',{ type:'button', value:'Buscar', id:'search_client_btn' }))
			)
			.adopt(
				new Element('div',{ id:'search_client_response','class':'search_results_response' }).adopt(new Element('table',{ id:'clients_results_table','class': 'search_results_table'})
					.adopt(new Element('thead').adopt(new Element('tr')
						.adopt(new Element('th',{ text:'##Id##' }))
						.adopt(new Element('th',{ text:'##Name##' }))
						.adopt(new Element('th',{ text:'##Taxpayer Id##' }))
						.adopt(new Element('th',{ text:'##Address##' }))
						.adopt(new Element('th',{ text:'##City##' }))
						.adopt(new Element('th',{ text:'##Postcode##' }))
					))
					.adopt(new Element('tbody',{ id:'clients_results_table_body' }))
				)
			)
			.inject(document.body);
	}

	$('search_client_input').addEvent('focus',function(){
		$$('#clients_results_table_body tr').each(function(e){e.removeClass('selected');});
		current_client_popup = null;
	});
	$('search_client_input').addEvent('keydown',function(ev){ if(ev.keyCode==13){ executeClientSearch(); } });
	$('search_client_btn').addEvent('click',function(){executeClientSearch();});

	if($('client')) $('client').addEvent('keydown',function(ev){
		if(ev.keyCode==13){
			if(!isNaN(this.value)){
				if(this.value===''){
					openSearchClientBox();
				} else {
					defaultSearchClient(this.value);
				}
			} else {
				openSearchClientBox();
			}
		}
	}).addEvent('blur',function(){
		if(!isNaN(this.get('rel')))
			this.value = this.get('rel');
	});

	$(window).addEvent('keydown',searchClientNavigationListener);
});

function resetSearch(){
	$('search_client_input').value='';
	executeClientSearch();
}

function openSearchClientBox(field,hiddenfield){
	if(hiddenfield) client_hiddenfield_name = hiddenfield;
	if(field) client_relfield_name = field;
	lightbox_clients = new Lightbox('box_search_client',{'onClose':function(){navigateClients=false;current_client_popup=null;}}).open();
	$('search_client_input').value=$('client').value;
	$('clients_results_table_body').empty();
	navigateClients = true;
	current_client_popup = null;
	executeClientSearch();
}

function executeClientSearch(){
	Request({
		'url':'ajax/search_client.php',
		'method':'post',
		'data':'q='+$('search_client_input').value,
		'onRequest': function(){
			$('clients_results_table_body').startWaiting();
		},
		'onSuccess':function(response){
			$('clients_results_table_body').stopWaiting();
			$('clients_results_table_body').empty();
			var res = parseJSON(response);
			for(var i=0,len=res.length; i<len; i++){
				var it = res[i];
				new Element('tr',{
						styles: {
							'cursor': 'pointer'
						},
						events: {
							'click':function(){
								if($('client')) $('client').value = this.getFirst('td input').value;
								defaultSearchClient(this.getFirst('td input').value, it);
								lightbox_clients.close();
							}
						}
					})
					.adopt(new Element('td',{ text: it.id }).adopt(new Element('input',{ 'type':'hidden','name':'return_field','value':it[client_relfield_name] })))
					.adopt(new Element('td',{ text: it.name }))
					.adopt(new Element('td',{ text: it.taxpayer_id }))
					.adopt(new Element('td',{ text: it.address }))
					.adopt(new Element('td',{ text: it.city }))
					.adopt(new Element('td',{ text: it.postcode }))
					.inject('clients_results_table_body');
			}
			lightbox_clients.reposition();
		}
	});
	if($('search_client_input')) setFocus('search_client_input');
}

function searchClientNavigationListener(ev){
	if(calculator && calculator.opened) return false;
	if(navigateClients==true){
		$$('#clients_results_table_body tr').each(function(e){e.removeClass('selected');});
		if(ev.target==$('search_client_input')){
			if(ev.keyCode==40 || ev.keyCode==38){
				$('search_client_input').blur();
			}
		}
		if(ev.keyCode==40){
			if(current_client_popup == null){
				current_client_popup = $('clients_results_table_body').getFirst('tr');
			} else {
				current_client_popup = nextItem(current_client_popup,'TR');
				if(!current_client_popup) current_client_popup = $('clients_results_table_body').getFirst('tr');
			}
		} else if(ev.keyCode==38){
			if(current_client_popup == null){
				current_client_popup = $('clients_results_table_body').getLast('tr');
			} else {
				current_client_popup = previousItem(current_client_popup,'TR');
				if(!current_client_popup) current_client_popup = $('clients_results_table_body').getLast('tr');
			}
		} else if(ev.keyCode==13) {
			if(current_client_popup){
				if($('client')) $('client').value = current_client_popup.getFirst('td input').value;
				defaultSearchClient(current_client_popup.getFirst('td input').value,current_client_popup);
				lightbox_clients.close();
				navigateClients = false;
				return false;
			}
		}
		if(current_client_popup){
			current_client_popup.addClass('selected');
			var curPos = current_client_popup.getPosition();
				var contHeight = $('search_client_response').getPosition().height;
				var maxScroll = $('clients_results_table').getPosition().totalHeight - contHeight;
			var scroll = curPos.top + curPos.height - contHeight / 2;
			if(scroll < 0) scroll = 0;
			if(scroll > maxScroll) scroll = maxScroll;
				$('search_client_response').scrollTop = scroll;
			if(ev.preventDefault) ev.preventDefault();
			if(ev.preventBubble) ev.preventBubble();
			return false;
		}
	}
}

function defaultSearchClient(id){
	if(typeof searchClient == 'function'){
		return searchClient(id);
	}
	Request({
		'url':'ajax/search_client.php',
		'method':'post',
		'data':'id='+id,
		'onSuccess':function(response){
			if(!response) return false;
			var res = eval('('+response+')');
			if(res.name){
				$('client').value = id;
				$('client').set('rel',id);
				if($('client_name')) $('client_name').set('text',res.name);
				if($('client_checked')) $('client_checked').value = 1;
				setFocus(nextInput('client'));
			} else {
				msgBox("##NG_WRONG_CLIENT##");
				$('client').value = '';
				$('client').set('rel','');
				if($('client_name')) $('client_name').set('text','');
				if($('client_checked')) $('client_checked').value = 0;
				setFocus('client');
			}
		}
	});
}
