<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = 'print_templates';
	$thispage = "search.php?module=".$module_name;

	// We load the module
	$module = loadModule($module_name,$db);

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	require 'inc/smarty.php';

	if($_GET['id']){
		$template = $db->fetch_item("SELECT * FROM print_templates WHERE id=".(int)$_GET['id']);
		if($template['assigned_to']){
			// If the template is assigned to a module, qe get the last element of that module and get the data
			$mod_name = $db->fetch_item_field("SELECT value FROM menu WHERE id=".(int)$template['assigned_to']);
			$mod = loadModule($mod_name,$db);
			$mod->search();
			$res = $mod->getSearchResults();
			if(is_array($res)){
				$item = array_pop($res);
				$pdata = $mod->getPrintData($item['id']);
				$data = $pdata['data'];
			}
		}
		$template = $template['content'];
	}

	if(empty($template)){
		print __("##NG_ERR_MUST_CHOOSE_TEMPLATE##");
	} else {
		$company_info = $db->fetch_all("SELECT * FROM config WHERE name LIKE 'company_%'",'value','name');
		if(is_array($company_info) && is_array($data)){
			$data = array_merge($company_info,$data);
		} elseif(is_array($company_info)) {
			$data = $company_info;
		}

		if(is_array($data)) foreach($data as $key=>$value){
			$smarty->assign($key, $value);
		}

		$template = 'string:'.$template;
		if(!$_GET['view'] && !$_GET['preview']){
			$smarty->display($template.'<script type="text/javascript">window.print();</script>');
		} elseif($_GET['preview']) {
			$smarty->display($template);
		} else {
			$content = $smarty->fetch($template);
			require_once("inc/dompdf/dompdf_config.inc.php");
			$dompdf = new DOMPDF();
			$dompdf->set_paper("A4");
			$dompdf->load_html($content);
			$dompdf->render();
			$dompdf->stream("item_{$invoice['number']}.pdf");
		}
	}
?>