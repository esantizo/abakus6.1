var items = {};
var quickdrop_elements = [];
var currentObject = null;
var preview_iframe = null;
var videoTimer = null;
var modified = false;
var repairs_ids = [];
var selectedUser = null;

var dragIcon = new Element('img',{ 'src': 'img/repairs.png' });

function clearItemSelection(except){
	$$('.repair').each(function(e){
		if(e != except){
			e.setStyle('border','1px solid #ccc');
			if(markers[e.getData('id')]) markers[e.getData('id')].setAnimation(null);
		}
	});
}

function selectItem(el){
	clearItemSelection(el);

	el = $(el);
	if(el){
		if(selectedUser) clearUserSelection();
		el.setStyle('border','1px solid #00f');
		if(markers[el.getData('id')]){
			markers[el.getData('id')].center();
			markers[el.getData('id')].setAnimation(google.maps.Animation.BOUNCE);
		}
	}
}

function clearUserItemSelection(except){
	$$('.pending_job').each(function(e){
		if(e != except){
			e.setStyle('border','1px solid #ccc');
			if(markers[e.getData('job-id')]) markers[e.getData('job-id')].setAnimation(null);
		}
	});
}

function selectUserItem(el){
	clearUserItemSelection(el);

	el = $(el);
	if(el){
		el.setStyle('border','1px solid #00f');
		if(markers[el.getData('job-id')]){
			markers[el.getData('job-id')].center();
			markers[el.getData('job-id')].setAnimation(google.maps.Animation.BOUNCE);
		}
	}
}

function clearUserSelection(except){
	$$('.user').each(function(e){
		if(except != e){
			e.removeClass('selected');
			var slide = e.getFirst('.user_extended_info').slide;
			if(slide.visible){
				slide.slideOut();
			}
		}
	});
	if(selectedUser && usermarkers && usermarkers[selectedUser]){
		for(var i=0,len=usermarkers[selectedUser].length; i<len; i++){
			markers[usermarkers[selectedUser][i]].setVisible(false);
		}
	}
	if(!except){
		if(markers){
			for(var i=0,len=globalmarkers.length; i<len; i++){
				markers[globalmarkers[i]].setVisible(true);
			}
		}
	} else {
		selectedUser = except.getData('id');
	}
}

function selectUser(el){
	clearUserSelection(el);
	el = $(el);
	if(el){
		clearItemSelection(null);
		var slide = el.getFirst('.user_extended_info').slide;
		if(slide.visible){
			slide.slideOut();
			el.removeClass('selected');
		} else {
			for(var i=0,len=globalmarkers.length; i<len; i++){
				markers[globalmarkers[i]].setVisible(false);
			}
			var uid = selectedUser;
			if(usermarkers && usermarkers[uid]){
				var waypoints = [];
				$$('#user_extended_info_jobs_'+uid+' .pending_job').each(function(j){
					var marker_id = j.getData('job-id');
					waypoints[waypoints.length] = markers[marker_id].position;
				});
			}
			el.addClass('selected');
			slide.slideIn();

			window.map.renderDirections(waypoints);
		}
	}
}

function saveListOrder(uid){
	var list = [];
	$$('#user_extended_info_jobs_'+uid+' .pending_job').each(function(j){
		list[list.length] = j.getData('job-id');
	});

	new Request({
		'url':'ajax/repair_delivery_assignations.php',
		'method':'post',
		'data':{ 'action':'saveOrder', 'deliveryman_id':uid, 'list':JSON.stringify(list) },
		'onSuccess': function(response){
			if(response=='ok'){
			}
		}
	});
}

function userDropEvent(e){
	if (e.stopPropagation) e.stopPropagation(); // stops the browser from redirecting...why???
	var el = $(e.dataTransfer.getData('Text')); // Get the dragged element by its ID (saved in the 'Text' data of the transfer)

	var parent = $(e.target).getParent();
	parent.removeClass('over');
	var repair_id = el.get('id').split('_')[1];
	var user_id = parent.get('id').split('_')[1];
	new Request({
		'url':'ajax/repair_delivery_assignations.php',
		'method':'post',
		'data':{ 'deliveryman_id':user_id, 'repair_id':repair_id },
		'onSuccess': function(response){
			if(response=='ok'){
				var product_name = $('repair_'+repair_id).getFirst('.product_name').get('text');
				var insert_date = $('repair_'+repair_id).getFirst('.insert_date').get('text');
				var container = $('user_'+user_id).getFirst('.user_extended_info_jobs');
				var newItem = new Element('div',{ 'class':'pending_job' ,'text': insert_date + ':' + product_name, 'data-job-id': repair_id });
				container.adopt(newItem);
				$('user_'+user_id).getFirst('.user_extended_info').slide.hide();

				var pending = $('user_'+user_id).getFirst('.user_pending_jobs');
				pending.set('text',pending.get('text').toInt()+1);

				globalmarkers.removeValue(repair_id);
				usermarkers[user_id].push(repair_id);

				lists[user_id].addItem(newItem);

				location.href="repair_delivery_assignation.php";

				var repair = $('repair_'+repair_id);
				new Tween(repair,{
					'property': 'opacity',
					'duration': 250,
					'easing': 'quadEaseOut',
					'onEnd': function(){
						repair.destroy();
					}
				}).start(1,0);
			}
		}
	});
};

$$('#repairs_container .repair').addEvents({
	'dragstart':function(ev) {
		var dt = ev.dataTransfer;

		dt.effectAllowed = 'move'; // only dropEffect='copy' will be dropable
		dt.setData('Text', this.get('id')); // required otherwise doesn't work
		dt.setDragImage(dragIcon, 0, 0);
		return false;
	},
	'mousedown':function(ev){ selectItem(this);	}
});

$$('#users_container .user_pending_jobs').addEvents({
	'dragenter': function(e){
		if (e.preventDefault) e.preventDefault(); /* allows us to drop */
		$(this).getParent().set('class','user over');
		return false;
	},
	'dragover': function(e) {
		$(this).getParent().set('class','user over');;
		if (e.preventDefault) e.preventDefault(); // allows us to drop
		e.dataTransfer.dropEffect = 'move';
		return false;
	},
	'dragleave': function(){ $(this).getParent().set('class','user'); },
	'drop': userDropEvent,
	'click': function(){
		selectUser(this.getParent('article'));
	}
});

$$('.user_extended_info_close').addEvent('click',function(){
	var el = this.getParent('article');
	selectUser(el);
});

$$('.pending_job').addEvent('click',function(){
	selectUserItem(this);
});

$$('.user_extended_info').each(function(e){
	e.slide = new Slide(e);
	e.slide.hide();
});

function resizeWrappers(){
	var footerHeight = $('full_body_wrapper').getFirst('footer').getPosition().totalHeight;
	var wrapperPos = $('repairs_container').getPosition(true);
	var errorsContainerHeight = $('errors_container').getPosition().height;
	var actionButtonsHeight = $('action_buttons').getPosition().height;

	height = (Math.max(window.innerHeight - wrapperPos.top - footerHeight - errorsContainerHeight - actionButtonsHeight - 30,100)).toInt();
	$('repairs_container').setStyles({
		'overflow':'auto',
		'height':height+'px'
	});
	var wrapperPos = $('users_container').getPosition(true);
	height = (Math.max(window.innerHeight - wrapperPos.top - footerHeight - errorsContainerHeight - actionButtonsHeight - 30,100)).toInt();
	$('users_container').setStyles({
		'overflow':'auto',
		'height':height+'px'
	});
	return;
}

function checkNewAssignations(){
	Request({
		'url': 'ajax/repair_delivery_assignations.php',
		'method':'post',
		'data':{ 'ids': JSON.stringify(repairs_ids), 'check': 1 },
		'onSuccess': function(response){
			if(response.toInt() > 0){
				$('new_repairs_container').setStyle('display','block');
				$('new_repairs').set('text',response);
			}
			setTimeout(checkNewAssignations,30000);
		}
	});
	return true;
}

//setTimeout(checkNewAssignations,30000);
