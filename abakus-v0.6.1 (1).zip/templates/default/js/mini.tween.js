(function(){

window.Tween = function(obj,options){
	var defaultOptions = {
		'property': 'width',
		'duration': 250,
		'fps': 50,
		'loops': 1,
		'pulse': false,
		'easing': 'quadOut',
		'onStart': null,
		'onStep': null,
		'onEnd': null
	};
	var el = $(obj);
	var self = this;
	var timeout = null;
	var interval = 0;
	var startVal = 0;
	var endVal = 0;
	var currentTime = 0;
	var current = 0;
	var curentLoop = 0;
	var type = null;

	this.options = merge(defaultOptions,options);
	this.options.duration = this.options.duration.toInt();
	this.options.fps = this.options.fps.toInt();

	function pad(number, length) {
			var str = '' + number;
			while (str.length < length) {
					str = '0' + str;
			}
			return str;
	}

	var calculateValue = function(currentTime, startVal, endVal, totalTime){
		if(type == 'int'){
			return self[self.options.easing](currentTime.toFloat(), startVal.toFloat(), endVal.toFloat(), totalTime.toFloat());
		}

		else if(type == 'hex_color_6' || type == 'hex_color_3') {
			var rStartVal,gStartVal,bStartVal,rEndVal,gEndVal,bEndVal,r,g,b;
			if(type == 'hex_color_3'){
				rStartVal = parseInt(startVal.substr(1,1)+startVal.substr(1,1),16);
				gStartVal = parseInt(startVal.substr(2,1)+startVal.substr(2,1),16);
				bStartVal = parseInt(startVal.substr(3,1)+startVal.substr(3,1),16);
				rEndVal = parseInt(endVal.substr(1,1)+endVal.substr(1,1),16);
				gEndVal = parseInt(endVal.substr(2,1)+endVal.substr(2,1),16);
				bEndVal = parseInt(endVal.substr(3,1)+endVal.substr(3,1),16);
			} else {
				rStartVal = parseInt(startVal.substr(1,2),16);
				gStartVal = parseInt(startVal.substr(3,2),16);
				bStartVal = parseInt(startVal.substr(5,2),16);
				rEndVal = parseInt(endVal.substr(1,2),16);
				gEndVal = parseInt(endVal.substr(3,2),16);
				bEndVal = parseInt(endVal.substr(5,2),16);
			}
			r = self[self.options.easing](currentTime, rStartVal, rEndVal, totalTime);
			g = self[self.options.easing](currentTime, gStartVal, gEndVal, totalTime);
			b = self[self.options.easing](currentTime, bStartVal, bEndVal, totalTime);
			return '#'+pad(r.round(0).toString(16),2)+pad(g.round(0).toString(16),2)+pad(b.round(0).toString(16),2);
		}
	};

	var isFinished = function(startVal,endVal,current){
		if(type == 'int'){
			return ((startVal < endVal && current >= endVal) || (startVal > endVal && current <= endVal));
		}
		else if(type == 'hex_color_6' || type == 'hex_color_3') {
			var rStartVal,rEndVal,currentVal;
			if(type == 'hex_color_3'){
				rStartVal = parseInt(startVal.substr(1,1)+startVal.substr(1,1),16);
				rEndVal = parseInt(endVal.substr(1,1)+endVal.substr(1,1),16);
			} else {
				rStartVal = parseInt(startVal.substr(1,2),16);
				rEndVal = parseInt(endVal.substr(1,2),16);
			}
			currentVal = parseInt(current.substr(1,2),16);

			return ((rStartVal < rEndVal && currentVal >= rEndVal) || (rStartVal > rEndVal && currentVal <= rEndVal));
		}
	};

	var tweenHelper = function(){
		currentTime += interval;
		current = calculateValue(currentTime, startVal, endVal, totalTime);
		if(currentTime >= totalTime){ //isFinished(startVal,endVal,current)){
			el.setStyle(self.options.property,endVal);
			if(typeof self.options.onEnd == 'function'){
				self.options.onEnd.call(this,startVal,endVal);
			}
			if(currentLoop < self.options.loops){
				currentTime = 0;
				if(self.options.pulse){
					var tmp = startVal;
					startVal = endVal;
					endVal = tmp;
				}
				timeout = setTimeout(tweenHelper,interval);
			}
			currentLoop++;
		} else {
			el.setStyle(self.options.property,current);
			if(typeof self.options.onStep == 'function'){
				self.options.onStep.call(this,startVal,endVal,current);
			}
			timeout = setTimeout(tweenHelper,interval);
		}
	};

	this.cancel = function(){
		if(timeout) clearTimeout(timeout);
	};

	this.start = function(from,to){
		if(!isNaN(from) && !isNaN(to)){
			type = 'int';
		} else if(from.match(/^#[0-9a-f]{3}$/i) && to.match(/^#[0-9a-f]{3}$/i)) {
			type = 'hex_color_3';
		} else if(from.match(/^#[0-9a-f]{6}$/i) && to.match(/^#[0-9a-f]{6}$/i)) {
			type = 'hex_color_6';
		} else {
			return false;
		}
		currentLoop = 1;
		startVal = from;
		endVal = to;
		currentTime = 0;
		totalTime = self.options.duration;
		interval = (totalTime / (totalTime * self.options.fps / 1000)).toInt();
		this.set(startVal);
		if(typeof self.options.onStart == 'function'){
			self.options.onStart.call(this,startVal,endVal);
		}
		setTimeout(tweenHelper,interval);
	};

	this.set = function(value){
		self.cancel();
		el.setStyle(self.options.property,value);
		return this;
	};


	// Easing functions and helpers

	// Helper function for generating any kind of easing (linear, quad, cubic, etc)
	// t,b,e,d: currentTime, startVal, endVal, totalTime
	var easeIn = function(v){
		return function(t, b, e, d){
			var c = e - b;
			var ts = (t/=d) * Math.pow(t,v-1);
			return b + c * (ts);
			//~ var factor = Math.pow(t / d, v);
			//~ return b + c * factor;
		}
	}

	var easeOut = function(v){
		var neg = (v%2==0?-1:1);
		return function(t, b, e, d){
			var c = e - b;
			t /= d;
			t--;
			var factor = neg * (Math.pow(t,v) + neg*1);
			return b + c * factor;
			//~ var factor = 1 - Math.pow(1 - (t / d), v);
			//~ return b + c * factor;
		}
	}
	var easeInOut = function(v){
		var neg = (v%2==0?-1:1);
		return function(t, b, e, d){
			var c = e - b;
			t /= d/2;

			if (t < 1) return b + c / 2 * Math.pow(t,v);
			t -= 2;
			return b + neg * c / 2 * (Math.pow(t,v) + neg * 2);
		}
	}

	this.linear = function(t, b, e, d){
		var easing = easeIn(1);
		return easing.call(this,t, b, e, d);
	}

	this.quadIn = function(t, b, e, d){
		var easing = easeIn(2);
		return easing.call(this,t, b, e, d);
	}
	this.quadOut = function(t, b, e, d){
		var easing = easeOut(2);
		return easing.call(this,t, b, e, d);
	}
	this.quadInOut = function(t, b, e, d){
		var easing = easeInOut(2);
		return easing.call(this,t, b, e, d);
	}

	this.cubicIn = function(t, b, e, d){
		var easing = easeIn(3);
		return easing.call(this,t, b, e, d);
	}
	this.cubicOut = function(t, b, e, d){
		var easing = easeOut(3);
		return easing.call(this,t, b, e, d);
	}
	this.cubicInOut = function(t, b, e, d){
		var easing = easeInOut(3);
		return easing.call(this,t, b, e, d);
	}

	this.quarticIn = function(t, b, e, d){
		var easing = easeIn(4);
		return easing.call(this,t, b, e, d);
	}
	this.quarticOut = function(t, b, e, d){
		var easing = easeOut(4);
		return easing.call(this,t, b, e, d);
	}
	this.quarticInOut = function(t, b, e, d){
		var easing = easeInOut(4);
		return easing.call(this,t, b, e, d);
	}

	this.quinticIn = function(t, b, e, d){
		var easing = easeIn(5);
		return easing.call(this,t, b, e, d);
	}
	this.quinticOut = function(t, b, e, d){
		var easing = easeOut(5);
		return easing.call(this,t, b, e, d);
	}
	this.quinticInOut = function(t, b, e, d){
		var easing = easeInOut(5);
		return easing.call(this,t, b, e, d);
	}

	this.backIn = function(t, b, e, d, s){
		var c = e - b;
		if (s == undefined) s = 1.70158;
		var ret = c * (t/=d) * t * ((s+1)*t - s) + b;
    return ret;
	}
	this.backOut= function (t, b, e, d, s) {
		var c = e - b;
		if (s == undefined) s = 1.70158;
		return c*((t=t/d-1)*t*((s+1)*t + s) + 1) + b;
	}
	this.backInOut = function (t, b, e, d, s) {
		var c = e - b;
		if (s == undefined) s = 1.70158;
		if ((t/=d/2) < 1) return c/2*(t*t*(((s*=(1.525))+1)*t - s)) + b;
		return c/2*((t-=2)*t*(((s*=(1.525))+1)*t + s) + 2) + b;
	}

	this.elasticIn = function (t, b, e, d) {
		var c = e - b;
		var s=1.70158;var p=0;var a=c;
		if (t==0) return b;  if ((t/=d)==1) return b+c;  if (!p) p=d*.3;
		if (a < Math.abs(c)) { a=c; var s=p/4; }
		else var s = p/(2*Math.PI) * Math.asin (c/a);
		return -(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
	}
	this.elasticOut = function (t, b, e, d) {
		var c = e - b;
		var s=1.70158;var p=0;var a=c;
		if (t==0) return b;  if ((t/=d)==1) return b+c;  if (!p) p=d*.3;
		if (a < Math.abs(c)) { a=c; var s=p/4; }
		else var s = p/(2*Math.PI) * Math.asin (c/a);
		return a*Math.pow(2,-10*t) * Math.sin( (t*d-s)*(2*Math.PI)/p ) + c + b;
	}
	this.elasticInOut = function (t, b, e, d) {
		var c = e - b;
		var s=1.70158;var p=0;var a=c;
		if (t==0) return b;  if ((t/=d/2)==2) return b+c;  if (!p) p=d*(.3*1.5);
		if (a < Math.abs(c)) { a=c; var s=p/4; }
		else var s = p/(2*Math.PI) * Math.asin (c/a);
		if (t < 1) return -.5*(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
		return a*Math.pow(2,-10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )*.5 + c + b;
	}

	this.sineIn = function (t, b, e, d) {
		var c = e - b;
    return -c * Math.cos(t/d * (Math.PI/2)) + c + b;
  }
	this.sineOut = function (t, b, e, d) {
		var c = e - b;
		return c * Math.sin(t/d * (Math.PI/2)) + b;
	}
	this.sineInOut = function (t, b, e, d) {
		var c = e - b;
		return -c/2 * (Math.cos(Math.PI*t/d) - 1) + b;
	}

	this.expoIn = function (t, b, e, d) {
		var c = e - b;
		return (t==0) ? b : c * Math.pow(2, 10 * (t/d - 1)) + b;
	}
	this.expoOut = function (t, b, e, d) {
		var c = e - b;
		return (t==d) ? b+c : c * (-Math.pow(2, -10 * t/d) + 1) + b;
	}
	this.expoInOut = function (t, b, e, d) {
		var c = e - b;
		if (t==0) return b;
		if (t==d) return b+c;
		if ((t/=d/2) < 1) return c/2 * Math.pow(2, 10 * (t - 1)) + b;
		return c/2 * (-Math.pow(2, -10 * --t) + 2) + b;
	}

	this.circIn = function (t, b, e, d) {
		var c = e - b;
		return -c * (Math.sqrt(1 - (t/=d)*t) - 1) + b;
	}
	this.circOut = function (t, b, e, d) {
		var c = e - b;
		return c * Math.sqrt(1 - (t=t/d-1)*t) + b;
	}
	this.circInOut = function (t, b, e, d) {
		var c = e - b;
		if ((t/=d/2) < 1) return -c/2 * (Math.sqrt(1 - t*t) - 1) + b;
		return c/2 * (Math.sqrt(1 - (t-=2)*t) + 1) + b;
	}

	this.bounceIn = function (t, b, e, d) {
		var c = e - b;
		return c - this.bounceOut(d-t, 0, c, d) + b;
	}
	this.bounceOut = function (t, b, e, d) {
		var c = e - b,val;
		if ((t/=d) < (1/2.75)) {
			val = c*(7.5625*t*t) + b;
		} else if (t < (2/2.75)) {
			val = c*(7.5625*(t-=(1.5/2.75))*t + .75) + b;
		} else if (t < (2.5/2.75)) {
			val = c*(7.5625*(t-=(2.25/2.75))*t + .9375) + b;
		} else {
			val = c*(7.5625*(t-=(2.625/2.75))*t + .984375) + b;
		}
		return val;
	}
	this.bounceInOut = function (t, b, e, d) {
		var c = e - b;
		if (t < d/2) return this.bounceIn (t*2, 0, c, d) * .5 + b;
		return this.bounceOut (t*2-d, 0, c, d) * .5 + c*.5 + b;
	}
}

})();
