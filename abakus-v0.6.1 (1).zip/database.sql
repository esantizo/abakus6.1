-- MySQL dump 10.13  Distrib 5.1.63, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: abakus
-- ------------------------------------------------------
-- Server version	5.1.63-0ubuntu0.10.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_client` int(10) unsigned NOT NULL,
  `type` varchar(20) NOT NULL,
  `id_item` int(10) unsigned NOT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `due_date` date DEFAULT NULL,
  `reference` varchar(100) NOT NULL,
  `id_currency` int(10) unsigned NOT NULL,
  `credit` float(20,4) NOT NULL,
  `debit` float(20,4) NOT NULL,
  `balance` float(20,4) NOT NULL,
  `currencies` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_client` (`id_client`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_entities`
--

DROP TABLE IF EXISTS `bank_entities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_entities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_entities`
--

LOCK TABLES `bank_entities` WRITE;
/*!40000 ALTER TABLE `bank_entities` DISABLE KEYS */;
INSERT INTO `bank_entities` VALUES (23,'American Express Bank'),(22,'ABN AMRO Bank'),(4,'Ciudad de Buenos Aires'),(5,'Comafi'),(6,'Crediccop Coop. Ltdo.'),(7,'Banco de Formosa S.A.'),(8,'Banco de Inversión y Comercio Exterior'),(9,'Banco de la Nación Argentina'),(10,'Banco de Provincia de Buenos Aires'),(11,'Banco de Tierra del Fuego'),(13,'Banco del Chubut'),(14,'Banco Empresario de Tucumán Cooperativo Limitado'),(15,'Banco Francés BBVA'),(16,'Banco Galicia'),(17,'Banco Hipotecario S.A.'),(18,'Banco Itaú S.A.'),(19,'Banco Julio S.A.'),(20,'Banco Piano'),(21,'Banco Regional de Cuyo'),(24,'BACS'),(25,'Bradesco'),(26,'Banco Columbia'),(27,'Banco de Córdoba'),(28,'Banco de Corrientes'),(31,'Banco de la Pampa'),(32,'Banco de San Juan'),(33,'Banco de Santiago del Estero'),(34,'Banco de Servicios y Transacciones'),(35,'Banco de Valores'),(36,'Banco del Sol'),(37,'Banco del Uruguay'),(38,'Banco do Brasil'),(39,'Banco Finansur'),(40,'Banco Industrial');
/*!40000 ALTER TABLE `bank_entities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cashbox_actions`
--

DROP TABLE IF EXISTS `cashbox_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashbox_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) unsigned NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `amount` float(20,4) NOT NULL,
  `taxes` float(20,4) NOT NULL,
  `type` varchar(10) NOT NULL,
  `comment` text NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date_added` (`date_added`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashbox_actions`
--

LOCK TABLES `cashbox_actions` WRITE;
/*!40000 ALTER TABLE `cashbox_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `cashbox_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `description` text NOT NULL,
  `parent` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent` (`parent`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Familia de Muestra','Texto de ejemplo',0);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `check_statuses`
--

DROP TABLE IF EXISTS `check_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_statuses` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `check_statuses`
--

LOCK TABLES `check_statuses` WRITE;
/*!40000 ALTER TABLE `check_statuses` DISABLE KEYS */;
INSERT INTO `check_statuses` VALUES (1,'Pending'),(2,'Rejected'),(3,'Payed'),(4,'Transfered'),(5,'Due'),(6,'Bad');
/*!40000 ALTER TABLE `check_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checks`
--

DROP TABLE IF EXISTS `checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_client` int(10) unsigned DEFAULT NULL,
  `id_provider` int(10) unsigned DEFAULT NULL,
  `id_bank` int(10) unsigned NOT NULL,
  `serial_number` varchar(50) NOT NULL,
  `id_currency` int(10) unsigned NOT NULL,
  `value` float(20,2) NOT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `cashing_date` date NOT NULL,
  `notes` text NOT NULL,
  `currencies` varchar(250) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `id_client` (`id_client`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checks`
--

LOCK TABLES `checks` WRITE;
/*!40000 ALTER TABLE `checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `taxpayer_id` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `id_state` int(11) unsigned NOT NULL DEFAULT '0',
  `city` varchar(100) NOT NULL,
  `id_payment_type` int(11) unsigned NOT NULL DEFAULT '0',
  `id_price_scale` int(10) unsigned NOT NULL,
  `id_bank_entity` int(11) unsigned NOT NULL DEFAULT '0',
  `bank_account` varchar(100) NOT NULL,
  `id_tax_condition` int(10) unsigned NOT NULL,
  `postcode` varchar(20) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `web` varchar(150) NOT NULL,
  `credit_limit` float(10,4) NOT NULL,
  `credit_limit_interval` int(11) NOT NULL,
  `credit_limit_currency` int(10) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `id_image` int(10) unsigned NOT NULL,
  `license_plate` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `activo` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collections`
--

DROP TABLE IF EXISTS `collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_client` int(10) unsigned NOT NULL,
  `receipt` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `id_item` int(10) unsigned DEFAULT NULL,
  `id_currency` int(10) unsigned NOT NULL,
  `value` float(20,4) NOT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `notes` text NOT NULL,
  `currencies` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_client` (`id_client`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collections`
--

LOCK TABLES `collections` WRITE;
/*!40000 ALTER TABLE `collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `name` varchar(100) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES ('company_name',''),('company_cuit',''),('company_address',''),('company_phone',''),('company_city','Mar del Plata'),('company_state','Buenos Aires'),('company_country','Argentina'),('company_tax_condition','IVA Responsable Inscripto'),('company_logo',''),('company_iibb',''),('company_actstart',''),('company_zip','7600'),('company_web',''),('invoice_search_field','manufacturers_code'),('invoices_print_template','2'),('quotes_print_template','3'),('barcodes_print_template','4'),('dispatch_notes_print_template','6'),('notes_print_template','5'),('pack_js',''),('ignore_stock',''),('serial_number_prefix',''),('invoice_number_format','FC 0001-%08d'),('receipt_number_format','RC 0001-%08d'),('credit_note_number_format',''),('qrs_print_template','0'),('catalog_print_template','0'),('system_template','0'),('use_barcode','on'),('use_qrcode',''),('company_taxpayer_id',''),('company_gross_income_tax_id','');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `relation` varchar(50) NOT NULL,
  `id_relation` int(10) unsigned NOT NULL,
  `name` varchar(250) NOT NULL,
  `telephone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(250) NOT NULL,
  `postcode` varchar(20) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `notes` text NOT NULL,
  `id_image` int(10) unsigned NOT NULL,
  `is_branch` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'Argentina'),(2,'Brasil'),(3,'Alemania'),(4,'Uruguay'),(5,'Mexico'),(6,'Chile'),(7,'Paraguay'),(8,'Bolivia'),(9,'Perú'),(10,'Ecuador'),(11,'Venezuela'),(12,'Estados Unidos'),(13,'España'),(14,'Francia'),(15,'Italia');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_note_items`
--

DROP TABLE IF EXISTS `credit_note_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_note_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_credit_note` int(10) unsigned NOT NULL,
  `id_product` int(10) unsigned NOT NULL,
  `reference` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `selected_stock` varchar(500) NOT NULL,
  `price` float(20,4) NOT NULL,
  `tax` float(10,4) NOT NULL,
  `total` float(20,4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_credit_note` (`id_credit_note`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_note_items`
--

LOCK TABLES `credit_note_items` WRITE;
/*!40000 ALTER TABLE `credit_note_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_note_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_notes`
--

DROP TABLE IF EXISTS `credit_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_type` int(10) unsigned NOT NULL,
  `number` int(8) unsigned NOT NULL,
  `date` date NOT NULL,
  `insert_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `due_date` date DEFAULT NULL,
  `salesman` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `client_name` varchar(200) NOT NULL,
  `client_address` varchar(200) NOT NULL,
  `client_taxpayer_id` varchar(100) NOT NULL,
  `client_postcode` varchar(50) NOT NULL,
  `client_city` varchar(200) NOT NULL,
  `client_state` varchar(200) NOT NULL,
  `client_country` varchar(200) NOT NULL,
  `id_tax_condition` int(10) unsigned NOT NULL,
  `id_payment_type` int(10) unsigned NOT NULL,
  `id_price_scale` int(10) unsigned NOT NULL,
  `id_currency` int(10) unsigned NOT NULL,
  `currencies` varchar(250) NOT NULL,
  `subtotal` float(20,4) NOT NULL,
  `discount` float(20,4) NOT NULL,
  `taxes` varchar(200) NOT NULL,
  `total` float(20,4) NOT NULL,
  `notes` text,
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `id_invoice` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `date` (`date`),
  KEY `pending` (`pending`),
  KEY `invoice_type` (`invoice_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_notes`
--

LOCK TABLES `credit_notes` WRITE;
/*!40000 ALTER TABLE `credit_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `symbol` varchar(10) NOT NULL,
  `rate` float(10,4) NOT NULL,
  `reference_url` varchar(250) NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES (1,'Peso Argentino','$',1.0000,'',1),(2,'Dólar','U$S',4.3200,'http://www.jonestur.com/es/valores-pizarra/#botonera-principal',0);
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliverymen`
--

DROP TABLE IF EXISTS `deliverymen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliverymen` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(60) NOT NULL,
  `active` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliverymen`
--

LOCK TABLES `deliverymen` WRITE;
/*!40000 ALTER TABLE `deliverymen` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliverymen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dispatch_note_items`
--

DROP TABLE IF EXISTS `dispatch_note_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dispatch_note_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_dispatch_note` int(10) unsigned NOT NULL,
  `id_product` int(10) unsigned NOT NULL,
  `reference` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_quote` (`id_dispatch_note`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispatch_note_items`
--

LOCK TABLES `dispatch_note_items` WRITE;
/*!40000 ALTER TABLE `dispatch_note_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `dispatch_note_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dispatch_notes`
--

DROP TABLE IF EXISTS `dispatch_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dispatch_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `number` int(8) unsigned NOT NULL,
  `date` date NOT NULL,
  `salesman` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `client_name` varchar(200) NOT NULL,
  `client_address` varchar(200) NOT NULL,
  `client_taxpayer_id` varchar(100) NOT NULL,
  `client_postcode` varchar(50) NOT NULL,
  `client_city` varchar(200) NOT NULL,
  `client_state` varchar(250) NOT NULL,
  `client_country` varchar(250) NOT NULL,
  `notes` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `id_invoice` int(11) NOT NULL,
  `from_invoice` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispatch_notes`
--

LOCK TABLES `dispatch_notes` WRITE;
/*!40000 ALTER TABLE `dispatch_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `dispatch_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dispatch_notes_statuses`
--

DROP TABLE IF EXISTS `dispatch_notes_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dispatch_notes_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispatch_notes_statuses`
--

LOCK TABLES `dispatch_notes_statuses` WRITE;
/*!40000 ALTER TABLE `dispatch_notes_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `dispatch_notes_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(200) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_invoice` int(10) unsigned NOT NULL,
  `id_product` int(10) unsigned NOT NULL,
  `reference` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `selected_stock` varchar(500) NOT NULL,
  `price` float(20,4) NOT NULL,
  `tax` float(10,4) NOT NULL,
  `total` float(20,4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_invoice` (`id_invoice`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_items`
--

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_types`
--

DROP TABLE IF EXISTS `invoice_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `symbol` varchar(20) NOT NULL,
  `discriminates_taxes` tinyint(1) NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_types`
--

LOCK TABLES `invoice_types` WRITE;
/*!40000 ALTER TABLE `invoice_types` DISABLE KEYS */;
INSERT INTO `invoice_types` VALUES (1,'Factura A','',1,0),(2,'Presupuesto','',0,0),(3,'Remito','',0,0),(4,'Recibo','',0,0),(5,'Factura B','',0,0),(6,'Factura C','',0,0);
/*!40000 ALTER TABLE `invoice_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_type` int(10) unsigned NOT NULL,
  `number` int(8) unsigned NOT NULL,
  `date` date NOT NULL,
  `insert_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `due_date` date DEFAULT NULL,
  `salesman` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `client_name` varchar(200) NOT NULL,
  `client_address` varchar(200) NOT NULL,
  `client_taxpayer_id` varchar(100) NOT NULL,
  `client_postcode` varchar(50) NOT NULL,
  `client_city` varchar(200) NOT NULL,
  `client_state` varchar(200) NOT NULL,
  `client_country` varchar(200) NOT NULL,
  `id_tax_condition` int(10) unsigned NOT NULL,
  `id_payment_type` int(10) unsigned NOT NULL,
  `id_price_scale` int(10) unsigned NOT NULL,
  `id_currency` int(10) unsigned NOT NULL,
  `currencies` varchar(250) NOT NULL,
  `subtotal` float(20,4) NOT NULL,
  `discount` float(20,4) NOT NULL,
  `taxes` varchar(200) NOT NULL,
  `total` float(20,4) NOT NULL,
  `notes` text,
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `payed` tinyint(1) DEFAULT '0',
  `amount_payed` float(20,4) DEFAULT '0.0000',
  `from_dispatch_note` tinyint(1) NOT NULL DEFAULT '0',
  `id_dispatch_note` int(11) NOT NULL,
  `id_quote` int(11) NOT NULL,
  `pos_opened` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `number` (`number`),
  KEY `client_id` (`client_id`),
  KEY `date` (`date`),
  KEY `pending` (`pending`),
  KEY `payed` (`payed`),
  KEY `invoice_type` (`invoice_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'Punto de Venta'),(2,'Depósito');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `parent` int(10) unsigned DEFAULT '0',
  `order` int(11) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `type` varchar(20) NOT NULL,
  `value` varchar(200) DEFAULT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent` (`parent`)
) ENGINE=MyISAM AUTO_INCREMENT=107 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'Entities',0,1,1,'','','entidades.png'),(2,'Products',0,2,1,'','','productos.png'),(3,'Purchases',0,5,1,'','','compras.png'),(4,'Sales',0,4,1,'','','ventas.png'),(5,'Treasury',0,6,1,'','','tesoreria.png'),(6,'Lists',0,7,1,'','','printing_lists.png'),(7,'Configurations',0,8,1,'','','config.png'),(8,'System',0,9,1,'','','sistema.png'),(9,'Providers',1,0,1,'module','providers','providers.png'),(10,'Clients',1,0,1,'module','clients','clients.png'),(11,'Products',2,0,1,'module','products',''),(12,'Categories',2,0,1,'module','categories','family'),(13,'Production',2,0,0,'','',''),(14,'Supplies',2,0,0,'','',''),(15,'Orders',3,0,1,'module','orders',''),(16,'Purchases',3,0,1,'module','purchases',''),(17,'Dispatch notes',3,0,1,'','',''),(18,'Monthly',3,0,0,'','',''),(19,'Repairs',3,0,1,'module','repairs_in',''),(20,'Direct sales',4,1,1,'link','sales.php','sales.png'),(21,'Quotes',4,6,1,'module','quotes','quotes.png'),(22,'Invoices',4,5,1,'module','invoices','sale.png'),(23,'Dispatch notes',4,7,1,'module','dispatch_notes',''),(73,'Repairs statuses',7,9,1,'module','repairs_statuses','repairs.png'),(25,'Monthly',4,10,0,'','',''),(26,'Receipts',4,9,1,'module','receipts',''),(27,'Repairs',87,2,1,'module','repairs','repairs.png'),(28,'Collections',5,0,1,'module','receipts',''),(29,'Payments',5,0,0,'','',''),(30,'Balance',5,0,1,'link','balance.php',''),(31,'Daily cashbox',5,0,0,'','',''),(32,'Day book',5,0,0,'','',''),(33,'Banks status',5,0,0,'','',''),(34,'Printing lists',6,0,1,'link','printing_lists.php','printing_lists.png'),(35,'Clients',6,0,1,'link','printing_lists.php?type=clients','customer_list.png'),(36,'Providers',6,0,1,'link','printing_lists.php?type=providers',''),(37,'Salesmen',6,0,1,'link','printing_lists.php?type=salesmen','salesman_list.png'),(39,'Labels',6,0,1,'link','printing_lists.php?type=labels',''),(40,'Shipping Labels',6,0,1,'','',''),(41,'Emails',6,0,0,'','',''),(42,'Users',8,1,1,'module','users','user.png'),(43,'Locations',7,13,1,'module','locations','address.png'),(44,'Price scales',7,11,1,'module','price_scales',''),(45,'Product types',7,12,1,'module','product_types',''),(46,'Taxes',7,4,1,'module','taxes',''),(47,'Bank entities',7,7,1,'module','bank_entities',''),(48,'Packagings',7,10,0,'module','packagings',''),(49,'Payment types',7,8,0,'module','payment_types',''),(50,'Countries',7,15,1,'module','countries',''),(51,'Updates',8,5,0,'','',''),(52,'Configuration',8,2,1,'link','configuration.php','config.png'),(53,'Backup',8,4,1,'link','backup.php',''),(54,'Credits',8,6,1,'link','about.php',''),(56,'Menus',8,0,0,'link','menus.php',''),(59,'States',7,16,1,'module','states',''),(62,'Tax conditions',7,5,1,'module','tax_conditions',''),(61,'Origins',7,14,1,'module','origins',''),(63,'Invoice types',7,6,1,'module','invoice_types',''),(64,'Currencies',7,3,1,'module','currency',''),(65,'Stock',2,0,1,'module','stock',''),(66,'Contacts',1,0,1,'module','contacts',''),(67,'Translations',8,3,1,'link','dictionary.php',''),(68,'Help',8,7,1,'link','help.php',''),(69,'Notes',6,0,1,'module','notes',''),(70,'Price change',2,0,1,'link','price_change.php',''),(72,'Print templates',7,2,1,'module','print_templates',''),(74,'Checks',5,0,1,'module','checks',''),(75,'Payments',3,0,1,'module','payments',''),(76,'User Templates',7,1,1,'module','user_permissions_templates',''),(77,'Logout',8,8,1,'link','login.php?logout',''),(78,'User Preferences',8,0,1,'link','user_preferences.php',''),(79,'New Quote',4,2,1,'link','quotes.php',''),(80,'New Dispatch Note',4,3,1,'link','dispatch_notes.php',''),(81,'Repairs Types',7,17,1,'module','repairs_types',''),(82,'Repais Failures',7,18,1,'module','repairs_failures',''),(83,'Repair Shop',87,4,1,'module','repair_shop',''),(84,'Sellers',7,2,1,'module','sellers',''),(85,'Repair Assignation',87,3,1,'link','repair_assignation.php',''),(86,'Users Skills',7,19,1,'link','users_skills.php',''),(87,'Repairs',0,3,1,'',NULL,''),(88,'New Repair',87,1,1,'link','repairs.php',''),(89,'Delivery Men',7,15,1,'module','deliverymen',''),(90,'Delivery Assignation',87,5,1,'link','repair_delivery_assignation.php',''),(91,'Product Models',2,10,1,'module','product_models',''),(92,'POS',0,0,1,'',NULL,''),(93,'Venta en POS',92,0,1,'link','pos.php',''),(94,'Cashbox Close',92,2,1,'link','cashbox_close.php',''),(95,'New credit note',4,4,1,'link','credit_notes.php',''),(96,'Credit notes',4,8,1,'link','search.php?module=credit_notes',''),(97,'Cashbox open',92,1,1,'link','cashbox_open.php',''),(98,'Cashbox actions',92,5,1,'link','search.php?module=cashbox_actions',''),(99,'Parking Configurations',7,20,1,'link','parking_configuration.php',''),(100,'Parking',0,-1,1,'','',''),(101,'Parking',100,0,1,'link','parking.php',''),(102,'History',100,1,1,'module','parking',''),(103,'Stats',0,0,1,'link','stats.php',''),(104,'Ventas',103,1,1,'link','stats_sales.php','');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_order` int(10) unsigned NOT NULL,
  `id_product` int(10) unsigned NOT NULL,
  `reference` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` float(20,4) NOT NULL,
  `tax` float(10,4) NOT NULL,
  `total` float(20,4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_quote` (`id_order`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `number` int(8) unsigned NOT NULL,
  `date` date NOT NULL,
  `buyer` int(10) unsigned NOT NULL,
  `provider_id` int(10) unsigned NOT NULL,
  `provider_name` varchar(200) NOT NULL,
  `provider_address` varchar(200) NOT NULL,
  `provider_taxpayer_id` varchar(100) NOT NULL,
  `provider_postcode` varchar(50) NOT NULL,
  `provider_city` varchar(200) NOT NULL,
  `provider_state` varchar(250) NOT NULL,
  `provider_country` varchar(250) NOT NULL,
  `id_currency` int(10) unsigned NOT NULL,
  `currencies` varchar(250) NOT NULL,
  `subtotal` float(20,4) NOT NULL,
  `discount` float(20,4) NOT NULL DEFAULT '0.0000',
  `taxes` varchar(200) NOT NULL,
  `total` float(20,4) NOT NULL,
  `order_duration` varchar(50) NOT NULL,
  `notes` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `origins`
--

DROP TABLE IF EXISTS `origins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `origins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `origins`
--

LOCK TABLES `origins` WRITE;
/*!40000 ALTER TABLE `origins` DISABLE KEYS */;
INSERT INTO `origins` VALUES (1,'China'),(2,'Japon'),(3,'Taiwan'),(4,'Corea'),(6,'USA'),(7,'Italia '),(8,'Brazil'),(9,'Argentina'),(5,'India'),(10,'Indonesia');
/*!40000 ALTER TABLE `origins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packagings`
--

DROP TABLE IF EXISTS `packagings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packagings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packagings`
--

LOCK TABLES `packagings` WRITE;
/*!40000 ALTER TABLE `packagings` DISABLE KEYS */;
INSERT INTO `packagings` VALUES (1,'Blister dos unidades'),(2,'Caja independiente'),(3,'Sueltos');
/*!40000 ALTER TABLE `packagings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parking`
--

DROP TABLE IF EXISTS `parking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parking` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `license_plate` varchar(12) NOT NULL,
  `notes` text NOT NULL,
  `type` varchar(15) NOT NULL,
  `time_in` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time_out` timestamp NULL DEFAULT NULL,
  `price` float DEFAULT NULL,
  `extra_data` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parking`
--

LOCK TABLES `parking` WRITE;
/*!40000 ALTER TABLE `parking` DISABLE KEYS */;
/*!40000 ALTER TABLE `parking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_checks`
--

DROP TABLE IF EXISTS `payment_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_checks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_payment` int(10) unsigned NOT NULL,
  `id_check` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_receipt` (`id_payment`,`id_check`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_checks`
--

LOCK TABLES `payment_checks` WRITE;
/*!40000 ALTER TABLE `payment_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_invoices`
--

DROP TABLE IF EXISTS `payment_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_payment` int(10) unsigned NOT NULL,
  `id_invoice` int(10) unsigned NOT NULL,
  `amount` float(20,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_receipt` (`id_payment`,`id_invoice`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_invoices`
--

LOCK TABLES `payment_invoices` WRITE;
/*!40000 ALTER TABLE `payment_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_types`
--

DROP TABLE IF EXISTS `payment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_types`
--

LOCK TABLES `payment_types` WRITE;
/*!40000 ALTER TABLE `payment_types` DISABLE KEYS */;
INSERT INTO `payment_types` VALUES (1,'Contado efectivo'),(2,'Cuenta Corriente'),(3,'Cheque Personal'),(4,'Cheque de Terceros'),(5,'Contado contra-entrega'),(6,'Contado');
/*!40000 ALTER TABLE `payment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_provider` int(10) unsigned NOT NULL,
  `buyer` int(10) unsigned NOT NULL,
  `number` varchar(50) NOT NULL,
  `balance_in_favor_used` float(20,4) NOT NULL DEFAULT '0.0000',
  `cash_currency` int(10) unsigned NOT NULL,
  `cash` float(20,4) NOT NULL,
  `check_qty` int(11) unsigned NOT NULL,
  `invoice_qty` int(10) unsigned NOT NULL,
  `payment_currency` int(10) unsigned NOT NULL,
  `total` float(20,4) NOT NULL,
  `total_invoices` float(20,4) NOT NULL DEFAULT '0.0000',
  `credit` float(20,4) NOT NULL DEFAULT '0.0000',
  `currencies` varchar(250) NOT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_client` (`id_provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_scales`
--

DROP TABLE IF EXISTS `price_scales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price_scales` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `percentage` float(10,4) NOT NULL DEFAULT '0.0000',
  `default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_scales`
--

LOCK TABLES `price_scales` WRITE;
/*!40000 ALTER TABLE `price_scales` DISABLE KEYS */;
INSERT INTO `price_scales` VALUES (14,'Publico',100.0000,1);
/*!40000 ALTER TABLE `price_scales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `print_templates`
--

DROP TABLE IF EXISTS `print_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `print_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(250) NOT NULL,
  `content` text NOT NULL,
  `assigned_to` int(11) unsigned NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL,
  `last_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_templates`
--

LOCK TABLES `print_templates` WRITE;
/*!40000 ALTER TABLE `print_templates` DISABLE KEYS */;
INSERT INTO `print_templates` VALUES (2,'Invoice','Invoice print template','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n<html>\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-15\">\r\n<title></title>\r\n<style type=\'text/css\'>\r\n*{ font-family:arial, sans;font-size:11px; }\r\n.header_cliente{ position:absolute;left:83mm;top:7mm;width:104mm;height:25mm;padding-left:5px;border:none;font-size:15px; }\r\n.datos_cliente { position:absolute;top:50mm;left:83mm;width:106mm;height:4mm;overflow:hidden;padding-left:2px; }\r\n.datos_cliente_inside{ display:inline-block;width:26mm;padding:0 2mm;overflow:visible;border:none; }\r\n.main_table{ position:absolute;left:0mm;top:65mm;padding:0;margin:0 }\r\n.main_table tr,.main_table td{ padding:0;margin:0 }\r\ntd.tbl_ref{ width:40mm;text-align:left;vertical-align:top }\r\ntd.tbl_desc{ width:78mm;text-align:left;vertical-align:top }\r\ntd.tbl_cant{ width:17mm;text-align:center;vertical-align:top }\r\ntd.tbl_precio{ width:16mm;text-align:right;vertical-align:top }\r\ntd.tbl_iva{ width:19mm;text-align:center;vertical-align:top }\r\ntd.tbl_importe{ width:18mm;text-align:right;vertical-align:top }\r\ntd .symbol{ float:left }\r\n.cond_venta{ position:absolute;left:27mm;top:217mm;width:40mm;height:6mm;border:none; }\r\n.Remito{ position:absolute;left:27mm;top:223mm;width:40mm;height:6mm;border:none; }\r\n.Presupuesto{ position:absolute;left:27mm;top:229mm;width:40mm;height:6mm;border:none; }\r\n.impuestos{ position:absolute;top:220mm;left:78mm;width:120mm;height:4mm;overflow:hidden;padding-left:2px;border:none; }\r\n.impuestos_inside{ width:30mm;overflow:hidden;border:none;display:inline-block;text-align:center }\r\n#subtotal{ width:24mm }\r\n#tax1050{ width:30mm }\r\n#tax2100{ width:30mm }\r\n#total{ width:26mm }\r\n</style>\r\n</head>\r\n<body>\r\n<div id=\'header_cliente\' class=\'header_cliente\'>\r\n{$invoice.client_name}<br>\r\n{$invoice.client_address}<br>\r\n{$invoice.client_city} <br>\r\n{$invoice.client_state} | {$invoice.client_country}\r\n</div>\r\n<div id=\'datos_cliente\' class=\'datos_cliente\'>\r\n   <textarea class=\'datos_cliente_inside\'>{$invoice.client_taxpayer_id}</textarea>\r\n   <textarea class=\'datos_cliente_inside\'>{sprintf(\'%08d\',$invoice.client_id)}</textarea>\r\n   <textarea class=\'datos_cliente_inside\'>{$invoice.tax_condition}</textarea>\r\n   <textarea style=\'width:18mm;padding:0 1mm;\' class=\'datos_cliente_inside\'>{$invoice.date}</textarea>\r\n</div>\r\n<table class=\'main_table\'>\r\n{foreach $items as $i}\r\n<tr><td class=\'tbl_ref\'>{$i.reference}</td><td class=\'tbl_desc\'>{$i.description}</td><td class=\'tbl_cant\'>{$i.quantity}</td><td class=\'tbl_precio\'>{$i.price}</td><td class=\'tbl_iva\'>{$i.tax}%</td><td class=\'tbl_importe\'>{$i.total}</td></tr>\r\n{/foreach}\r\n</table>\r\n<div class=\'cond_venta\'>{$invoice.payment_type}</div>\r\n<div class=\'Remito\'>{$invoice.dispatch_note_number}</div>\r\n<div class=\'Presupuesto\'>{$invoice.quote_number}</div>\r\n<div id=\'impuestos\' class=\'impuestos\'>\r\n   <div id=\"subtotal\" class=\'impuestos_inside\'>{$invoice.subtotal}</div>\r\n   <div id=\"tax1050\" class=\'impuestos_inside\'>{$taxes.tax_1050}</div>\r\n   <div id=\"tax2100\" class=\'impuestos_inside\'>{$taxes.tax_2100}</div>\r\n   <div id=\"total\" class=\'impuestos_inside\'>{$invoice.total}</div>\r\n</div>\r\n</body>\r\n</html>\r\n',22,'2011-08-29 00:04:25','2011-08-29 03:04:25'),(3,'Quote','Quote print template','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n<html>\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-15\">\r\n<title></title>\r\n<style type=\'text/css\'>\r\n*{ font-family:arial, sans;font-size:11px; }\r\np{ margin:0;padding:0 }\r\n#company{ position:absolute;font-size:1.3em;top:22mm;left:5mm;color:gray; }\r\n.header_cliente{ position:absolute;left:83mm;top:7mm;width:108mm;height:24mm;padding:2mm 2mm;border:none;font-size:15px;border:2px solid black;-moz-border-radius: 15px;-webkit-border-radius: 15px; }\r\n.datos_cliente { position:absolute;top:47mm;left:83mm;width:111mm;height:8mm;overflow:hidden;padding-left:2px;border:1px solid black;-moz-border-radius: 5px;-webkit-border-radius: 5px; }\r\n.datos_cliente_titulo { position:absolute;top:46mm;left:83mm;width:111mm;background-color:orange;height:4mm;overflow:hidden;padding-left:2px;border:1px solid black;-moz-border-radius: 5px;-webkit-border-radius: 5px; }\r\n.iva{ position:absolute;top:55mm;left:12mm;font-size:1.4em;font-weight:bold; }\r\n#legal_data{ position:absolute;left:94mm;top:37mm;font-size:1.2em;text-align:center; }\r\n.datos_cliente_inside{ display:inline-block;margin-top:4mm;width:26mm;padding:0 2mm;overflow:visible;border:none; }\r\n.datos_cliente_title{ display:inline-block;margin-bottom:3mm;background-color:orange;margin-left:2mm;width:24mm;padding:0 2mm;overflow:visible;border:none; }\r\n.data_container{ position:absolute;display:block;left:0mm;top:58mm;margin-top:2mm;padding:0;margin:4mm }\r\n.main_table{ border:2px solid black;-moz-border-radius: 12px;-webkit-border-radius: 12px; }\r\n.main_table tr,.main_table td{ padding:0;margin:0 }\r\nth{ background-color:orange;border:0px solid black;-moz-border-radius: 8px;-webkit-border-radius: 8px; }\r\ntd.tbl_ref{ top:1mm;width:36mm;text-align:left;height:5mm;padding:0 2mm }\r\ntd.tbl_desc{ width:78mm;text-align:left;height:5mm }\r\ntd.tbl_cant{ width:17mm;text-align:center;height:5mm }\r\ntd.tbl_precio{ width:16mm;text-align:right;height:5mm }\r\ntd.tbl_iva{ width:19mm;text-align:center;height:5mm }\r\ntd.tbl_importe{ width:18mm;text-align:right;height:5mm }\r\ntd .symbol{ float:left }\r\n\r\n#footer{ position:relative;clear:both }\r\n\r\n.notes{ margin:0;padding:0;position:relative;margin:3mm 5mm;width:180mm;padding:1mm; }\r\n\r\n#footer_left{ display:inline-block;vertical-align:top }\r\n#footer_left div{ line-height:6mm }\r\n#footer_left div span{ position:relative;display:inline-block;width:22mm }\r\n#footer_left div span.title{ color:orange }\r\n#footer_left div span.value{ width:39mm }\r\n\r\n{if $quote.discount > 0}\r\n.impuestos{ display:inline-block;position:relative;margin-left:-15mm;width:145mm;height:10mm;overflow:hidden;border:2px solid black;-moz-border-radius: 5px;-webkit-border-radius: 5px;vertical-align:top }\r\n.impuestos_titulos{ position:relative;width:145mm;top:-10mm;left:0;background-color:orange;height:5mm;overflow:hidden }\r\n.impuestos_inside{ width:10mm;overflow:hidden;margin:6mm 1mm 0 1mm;border:none;display:inline-block;text-align:center; }\r\n.impuestos_inside_title{ width:30mm;margin:1mm 1mm;overflow:hidden;border:none;display:inline-block;text-align:center; }\r\n.subtotal{ width:24mm }\r\n.tax1050{ width:30mm }\r\n.tax2100{ width:30mm }\r\n.discount{ width:20mm }\r\n.total{ width:26mm }\r\n.currency{ font-size:0.8em }\r\n{else}\r\n.impuestos{ display:inline-block;position:relative;margin-left:9mm;width:121mm;height:10mm;overflow:hidden;border:2px solid black;-moz-border-radius: 5px;-webkit-border-radius: 5px;vertical-align:top }\r\n.impuestos_titulos{ position:relative;width:125mm;top:-10mm;left:0;background-color:orange;height:5mm;overflow:hidden }\r\n.impuestos_inside{ width:10mm;overflow:hidden;margin:6mm 1mm 0 1mm;border:none;display:inline-block;text-align:center; }\r\n.impuestos_inside_title{ width:30mm;margin:1mm 1mm;overflow:hidden;border:none;display:inline-block;text-align:center; }\r\n.subtotal{ width:24mm }\r\n.tax1050{ width:30mm }\r\n.tax2100{ width:30mm }\r\n.total{ width:26mm }\r\n.currency{ font-size:0.8em }\r\n{/if}\r\n</style>\r\n</head>\r\n<body>\r\n<div style=\"font-size:1.5em;width:194mm;text-decoration:bold;margin-top:-1mm;text-align:right\">\r\nPRESUPUESTO N&ordm; {$quote.number}\r\n</div>\r\n<div id=\'legal_data\'>\r\n<b>Cuit:</b> {$company_taxpayer_id}<b> | Ingresos Brutos:</b> {$company_gross_income_tax_id}<br><b>Inicio de Actividades:</b> {$company_actstart}\r\n</div>\r\n<img src=\"uploads/images/company_logo.jpg\" width=\"220px\" style=\"margin-top:-5mm;margin-left:20px;\";>\r\n<div id=\'company\'>\r\n{$company_name}<br>\r\n{$company_address}<br>\r\n{$company_city} | {$company_zip}<br>\r\n{$company_state}<br>\r\n{$company_country}<br><br>\r\n{$company_web}\r\n</div>\r\n<div id=\'header_cliente\' class=\'header_cliente\'>\r\n{$quote.client_name}<br>\r\n{$quote.client_address}<br>\r\n{if $quote.client_city && $quote.client_postcode}\r\n{$quote.client_city} | {$quote.client_postcode}<br>\r\n{elseif $quote.client_city}\r\n{$quote.client_city}<br>\r\n{elseif $quote.client_postcode}\r\n{$quote.client_postcode}<br>\r\n{/if}\r\n{if $quote.client_state && $quote.client_country}\r\n{$quote.client_state} | {$quote.client_country}\r\n{elseif $quote.client_state}\r\n{$quote.client_state}\r\n{elseif $quote.client_country}\r\n{$quote.client_country}\r\n{/if}\r\n</div>\r\n<div id=\'iva\' class=\'iva\'>\r\n{$quote.tax_condition}\r\n</div>\r\n<div id=\'datos_cliente\' class=\'datos_cliente\'>\r\n   <textarea class=\'datos_cliente_inside\'>{$quote.client_taxpayer_id}</textarea>\r\n   <textarea class=\'datos_cliente_inside\'>{sprintf(\'%08d\',$quote.client_id)}</textarea>\r\n   <textarea class=\'datos_cliente_inside\'>{$quote.tax_condition}</textarea>\r\n   <textarea style=\'width:16mm;padding:0 1mm;\' class=\'datos_cliente_inside\'>{$quote.date}</textarea>\r\n</div>\r\n<div id=\'datos_cliente\' class=\'datos_cliente_titulo\'>\r\n   <textarea class=\'datos_cliente_title\'>Cuit</textarea>\r\n   <textarea class=\'datos_cliente_title\'>Cliente</textarea>\r\n   <textarea class=\'datos_cliente_title\'>IVA</textarea>\r\n   <textarea style=\'width:9mm;left:-1mm;\' class=\'datos_cliente_title\'>Fecha</textarea>\r\n</div>\r\n<div class=\"data_container\">\r\n	<table class=\'main_table\'>\r\n		<tr><th>Referencia</th><th>Descripci&oacute;n</th><th>Cantidad</th><th>Valor</th><th>IVA</th><th>Total</th></tr>\r\n		{foreach $items as $i}\r\n		<tr><td class=\'tbl_ref\'>{$i.reference}</td><td class=\'tbl_desc\'>{$i.description}</td><td class=\'tbl_cant\'>{$i.quantity}</td><td class=\'tbl_precio\'>{$i.price}</td><td class=\'tbl_iva\'>{$i.tax}%</td><td class=\'tbl_importe\'>{$i.total}</td></tr>\r\n		{/foreach}\r\n	</table>\r\n	<div id=\"footer\">\r\n		<pre class=\"notes\">\r\nNota: Este presupuesto se haya expresado en la siguiente moneda: {$quote.currency} | Válido por: {$quote.quote_duration}\r\n<br>{$quote.notes}\r\n		</pre>\r\n		<div id=\"footer_left\">\r\n			<div><span class=\'title\'>Forma de Pago:</span><span class=\'value\'>{$quote.payment_type}</span></div>\r\n			<div><span class=\'title\'>Remito:</span><span class=\'value\'>{$quote.dispatch_note}</span></div>\r\n		</div>\r\n		<div id=\'impuestos\' class=\'impuestos\'>\r\n			 <div class=\'impuestos_inside subtotal\'>{$quote.symbol} {$quote.subtotal}</div>\r\n			 <div class=\'impuestos_inside tax1050\'>{if $taxes.tax_1050 > 0}{$quote.symbol} {$taxes.tax_1050}{/if}</div>\r\n			 <div class=\'impuestos_inside tax2100\'>{if $taxes.tax_2100 > 0}{$quote.symbol} {$taxes.tax_2100}{/if}</div>\r\n{if $quote.discount > 0}\r\n			 <div class=\'impuestos_inside discount\'>{$quote.symbol} {$quote.discount}</div>\r\n{/if}\r\n			 <div class=\'impuestos_inside total\'>{$quote.symbol} {$quote.total}</div>\r\n			 <div class=\'impuestos_titulos\'>\r\n				 <div class=\'impuestos_inside_title subtotal\'>Subtotal</div>\r\n				 <div class=\'impuestos_inside_title tax1050\'>IVA 10.5%</div>\r\n				 <div class=\'impuestos_inside_title tax2100\'>IVA 21%</div>\r\n{if $quote.discount > 0}\r\n				 <div class=\'impuestos_inside_title discount\'>DESCUENTO</div>\r\n{/if}\r\n				 <div class=\'impuestos_inside_title total\'>TOTAL</div>\r\n				</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n</body>\r\n</html>\r\n',21,'2011-08-29 00:04:25','2011-09-22 13:46:32'),(4,'Barcodes','Barcodes template','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n<html>\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-15\">\r\n<title>Abakus Barcode</title>\r\n<style type=\'text/css\'>\r\n	*{font-family:arial, sans;font-size:10px;}\r\n	.barcode{font-size:10px;border:1px solid #ccc;padding:7px;float:left;text-align:center;}\r\n	.barcode img:nth-child(3){padding:3px 0 3px 0}\r\n	.desc{float:right;box-sizing:border-box;width:50%;height:34px;font-family:Arial, tahoma, verdana,san;font-size:9px;}\r\n</style>\r\n</head>\r\n<body onload=\'printCodes()\'>\r\n	<div id=\"search_result\">\r\n		<div id=\"search_result_wrapper\">\r\n<!-- {[BARCODES]} -->\r\n			<div class=\"barcode\">\r\n				<img src=\"inc/barcode/html/image.php?code=code128&o=1&t=30&r=1.7&text={BARCODES.REF}&f=2&a1=A&a2=\" >\r\n				<div style=\"width:180px;padding:4px;\">\r\n				<div class=\"desc\">{BARCODES.DESC}</div>\r\n				<div class=\"desc\">\r\n					<img src=\"uploads/images/company_logo.jpg?{BARCODES.REF}\" width=\"80px\" style=\"position:relative;text-align:center;margin-top:4px;\">\r\n				</div>\r\n				</div>\r\n			</div>\r\n<!-- {[/BARCODES]} -->\r\n		</div>\r\n	</div>\r\n	<script type=\"text/javascript\">\r\n		function printCodes(){\r\n			//window.print();\r\n			//window.close();\r\n		}\r\n	</script>\r\n</body>\r\n</html>\r\n',0,'2011-08-29 00:04:25','2011-08-29 03:04:25'),(5,'Notes','Notes Template','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n<html>\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-15\">\r\n<title>Abakus-Notes</title>\r\n<style type=\'text/css\'>\r\n*{ font-family:arial, sans;font-size:11px; }\r\np{ margin:0;padding:0 }\r\n#company{ position:absolute;font-size:1.3em;top:22mm;left:5mm;color:gray; }\r\n.data_container{ position:absolute;display:block;left:0mm;top:15mm;margin-top:2mm;padding:0;margin:4mm }\r\n.main_table{ border:2px solid black;-moz-border-radius: 12px;-webkit-border-radius: 12px; }\r\n.main_table tr,.main_table td{ padding:0;margin:0 }\r\nth{ background-color:orange;border:0px solid black;-moz-border-radius: 8px;-webkit-border-radius: 8px; }\r\ntd.tbl_ref{ top:1mm;width:36mm;text-align:left;height:5mm;padding:0 2mm }\r\ntd.tbl_desc{ width:78mm;text-align:left;height:5mm }\r\ntd.tbl_cant{ width:17mm;text-align:center;height:5mm }\r\ntd.tbl_precio{ width:16mm;text-align:right;height:5mm }\r\ntd.tbl_iva{ width:19mm;text-align:center;height:5mm }\r\ntd.tbl_importe{ width:18mm;text-align:right;height:5mm }\r\ntd .symbol{ float:left }\r\n\r\n.notes{ margin:0;position:relative;margin:3mm 5mm;width:175mm;padding:3mm;\r\nwhite-space: pre-wrap;       /* css-3 */\r\nwhite-space: -moz-pre-wrap !important;  /* Mozilla, since 1999 */\r\nwhite-space: -pre-wrap;      /* Opera 4-6 */\r\nwhite-space: -o-pre-wrap;    /* Opera 7 */\r\nword-wrap: break-word;       /* Internet Explorer 5.5+ */\r\n}\r\n\r\n</style>\r\n</head>\r\n<body>\r\n<div style=\"font-size:1.5em;width:194mm;text-decoration:bold;margin-top:-1mm\">\r\n<div style=\"position:relative;text-align:right;margin-top:4mm;\">Nota N&deg; {$note.id}</div>\r\n<img src=\"uploads/images/company_logo.jpg\" width=\"220px\" style=\"position:left;margin-top:-5mm;margin-left:20px\";>\r\n<div style=\"position:relative;text-align:right;margin-top:-9mm;\">\r\n{$company_address} | {$company_city} | {$company_web}\r\n</div>\r\n<div class=\"data_container\">\r\n	<table class=\'main_table\'>\r\n	<tr><td class=\'tbl_ref\'>\r\n	    <pre class=\"notes\">{$note.text}</pre>\r\n	</td></tr>\r\n	</table>\r\n</div>\r\n</div>\r\n</body>\r\n</html>\r\n',69,'2011-08-29 00:04:25','2011-08-29 03:04:25'),(6,'Dispatch Note','Dispatch Notes Templates','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n<html>\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-15\">\r\n<title></title>\r\n<style type=\'text/css\'>\r\n*{font-family:arial, sans;font-size:11px;}\r\n.header_cliente{position:absolute;left:83mm;top:7mm;width:104mm;height:25mm;padding-left:5px;border:none;font-size:15px;}\r\n.datos_cliente {position:absolute;top:50mm;left:83mm;width:106mm;height:4mm;overflow:hidden;padding-left:2px;}\r\n.datos_cliente_inside{display:inline-block;width:26mm;padding:0 2mm;overflow:visible;border:none;}\r\n.main_table{position:absolute;left:0mm;top:65mm;width:185mm;padding-left:2px;}\r\ntd.tbl_ref{width:41mm;}\r\ntd.tbl_desc{width:78mm;}\r\ntd.tbl_cant{width:17mm;}\r\ntd.tbl_precio{width:16mm;}\r\ntd.tbl_iva{width:19mm;}\r\ntd.tbl_importe{width:18mm;}\r\n.cond_venta{position:absolute;left:27mm;top:214mm;width:40mm;height: 6mm;border:none;}\r\n.Remito{position:absolute;left:27mm;top:220mm;width:40mm;height: 6mm;border:none;}\r\n.Presupuesto{position:absolute;left:27mm;top:226mm;width:40mm;height: 6mm;border:none;}\r\n.impuestos{position:absolute;top:218mm;left:78mm;width:109mm;height: 4mm;overflow:hidden;padding-left:2px;border:none;}\r\n.impuestos_inside{width:30mm;overflow:hidden;border:none;display:inline-block;}\r\n</style>\r\n</head>\r\n<body>\r\n<div id=\'header_cliente\' class=\'header_cliente\'>\r\n{CLIENT_NAME}<br>\r\n{CLIENT_ADDRESS}<br>\r\n({CLIENT_POSTCODE}) {CLIENT_CITY}<br>\r\n</div>\r\n<div id=\'datos_cliente\' class=\'datos_cliente\'>\r\n   <textarea class=\'datos_cliente_inside\'>{CLIENT_CUIT}</textarea>\r\n   <textarea class=\'datos_cliente_inside\'>{CLIENT_CODE}</textarea>\r\n   <textarea class=\'datos_cliente_inside\'>{TAX_CONDITION}</textarea>\r\n   <textarea style=\'width:18mm;padding:0 1mm;\' class=\'datos_cliente_inside\'>{DATE}</textarea>\r\n</div>\r\n<table class=\'main_table\'>\r\n{[ITEMS]}\r\n<tr><td class=\'tbl_cant\'>{ITEMS.QUANTITY}</td><td class=\'tbl_ref\'>{ITEMS.REFERENCE}</td><td class=\'tbl_desc\'>{ITEMS.DESCRIPTION}</td></tr>\r\n{[/ITEMS]}\r\n</table>\r\n<!--\r\n<div class=\'cond_venta\'>{PAYMENT_TYPE}</div>\r\n<div class=\'Remito\'>&nbsp;</div>\r\n<div class=\'Presupuesto\'>&nbsp;</div>\r\n-->\r\n</body>\r\n</html>\r\n',23,'2011-08-29 00:04:25','2011-08-29 03:04:25'),(8,'Catalog','Print template for product catalogs','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n<html>\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-15\">\r\n<title></title>\r\n<style type=\'text/css\'>\r\n*{ font-family:arial, sans;font-size:11px; }\r\np{ margin:0;padding:0 }\r\n#company{ position:absolute;font-size:1.3em;top:22mm;left:5mm;color:gray; }\r\n.header_cliente{ position:absolute;left:83mm;top:7mm;width:108mm;height:24mm;padding:2mm 2mm;border:none;font-size:15px;border:2px solid black;-moz-border-radius: 15px;-webkit-border-radius: 15px; }\r\n.datos_cliente { position:absolute;top:47mm;left:83mm;width:111mm;height:8mm;overflow:hidden;padding-left:2px;border:1px solid black;-moz-border-radius: 5px;-webkit-border-radius: 5px; }\r\n.datos_cliente_titulo { position:absolute;top:46mm;left:83mm;width:111mm;background-color:orange;height:4mm;overflow:hidden;padding-left:2px;border:1px solid black;-moz-border-radius: 5px;-webkit-border-radius: 5px; }\r\n.iva{ position:absolute;top:55mm;left:12mm;font-size:1.4em;font-weight:bold; }\r\n#legal_data{ position:absolute;left:94mm;top:37mm;font-size:1.2em;text-align:center; }\r\n.datos_cliente_inside{ display:inline-block;margin-top:4mm;width:26mm;padding:0 2mm;overflow:visible;border:none; }\r\n.datos_cliente_title{ display:inline-block;margin-bottom:3mm;background-color:orange;margin-left:2mm;width:24mm;padding:0 2mm;overflow:visible;border:none; }\r\n.data_container{ position:absolute;display:block;left:0mm;top:58mm;margin-top:2mm;padding:0;margin:4mm }\r\n\r\n#catalog_items{ width:191mm;padding:0;margin:0;list-style:none; background:#eee;border:2px solid black;-moz-border-radius: 12px;-webkit-border-radius: 12px;  }\r\n.item{ margin:0;padding:10px 0; border-bottom:2px solid #ccc; -moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box; }\r\n.data{ width:145mm; display:inline-block;vertical-align:top; -moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box; }\r\n.image{ width:40mm; text-align:center;display:inline-block;vertical-align:top; -moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box; }\r\n.image img{    border-radius:10px;box-shadow:0 0 5px #000; }\r\n\r\n.data div{ font-weight: 700; text-align:right }\r\n.data span{ font-weight: 400; width: 100mm; display:inline-block; text-align:left }\r\n.name span{ font-size:1.1em }\r\n\r\n</style>\r\n</head>\r\n<body>\r\n<div style=\"font-size:1.5em;width:194mm;text-decoration:bold;margin-top:-1mm;text-align:right\">\r\nCat&aacute;logo para el presupuesto N&ordm; {$quote.number}\r\n</div>\r\n<div id=\'legal_data\'>\r\n<b>Cuit:</b> {$config.company_taxpayer_id}<b> | Ingresos Brutos:</b> {$config.company_gross_income_tax_id}<br><b>Inicio de Actividades:</b> {$config.company_actstart}\r\n</div>\r\n<img src=\"uploads/images/company_logo.jpg\" width=\"220px\" style=\"margin-top:-5mm;margin-left:20px;\";>\r\n<div id=\'company\'>\r\n{$config.company_name}<br>\r\n{$config.company_address}<br>\r\n{$config.company_city} | {$config.company_zip}<br>\r\n{$config.company_state}<br>\r\n{$config.company_country}<br><br>\r\n{$config.company_web}\r\n</div>\r\n<div id=\'header_cliente\' class=\'header_cliente\'>\r\n{$quote.client_name}<br>\r\n{$quote.client_address}<br>\r\n{if $quote.client_city && $quote.client_postcode}\r\n{$quote.client_city} | {$quote.client_postcode}<br>\r\n{elseif $quote.client_city}\r\n{$quote.client_city}<br>\r\n{elseif $quote.client_postcode}\r\n{$quote.client_postcode}<br>\r\n{/if}\r\n{if $quote.client_state && $quote.client_country}\r\n{$quote.client_state} | {$quote.client_country}\r\n{elseif $quote.client_state}\r\n{$quote.client_state}\r\n{elseif $quote.client_country}\r\n{$quote.client_country}\r\n{/if}\r\n</div>\r\n<div id=\'iva\' class=\'iva\'>\r\n{$quote.tax_condition}\r\n</div>\r\n<div id=\'datos_cliente\' class=\'datos_cliente\'>\r\n   <textarea class=\'datos_cliente_inside\'>{$quote.client_taxpayer_id}</textarea>\r\n   <textarea class=\'datos_cliente_inside\'>{sprintf(\'%08d\',$quote.client_id)}</textarea>\r\n   <textarea class=\'datos_cliente_inside\'>{$quote.tax_condition}</textarea>\r\n   <textarea style=\'width:16mm;padding:0 1mm;\' class=\'datos_cliente_inside\'>{$quote.date}</textarea>\r\n</div>\r\n<div id=\'datos_cliente\' class=\'datos_cliente_titulo\'>\r\n   <textarea class=\'datos_cliente_title\'>Cuit</textarea>\r\n   <textarea class=\'datos_cliente_title\'>Cliente</textarea>\r\n   <textarea class=\'datos_cliente_title\'>IVA</textarea>\r\n   <textarea style=\'width:9mm;left:-1mm;\' class=\'datos_cliente_title\'>Fecha</textarea>\r\n</div>\r\n<div class=\"data_container\">\r\n		<ul id=\"catalog_items\">\r\n{foreach $items as $i}\r\n			<li class=\"item\">\r\n				{if $i@iteration is even and $i.image}\r\n				<div class=\"image\"><img src=\"uploads/images/{$i.image}\" height=\"100\" alt=\"\"></div>\r\n				{/if}\r\n				<div class=\"data\">\r\n					<div class=\"name\">Nombre: <span>{$i.name}</span></div>\r\n					{if $i.category}\r\n					<div class=\"category\">Familia: <span>{$i.category}</span></div>\r\n					{/if}\r\n					{if $i.manufacturers_code}\r\n					<div class=\"manufacturers_code\">C&oacute;digo del fabricante: <span>{$i.manufacturers_code}</span></div>\r\n					{/if}\r\n					<div class=\"description\">Descripci&oacute;n: <span>{$i.description}</span></div>\r\n					{if $i.packaging}\r\n					<div class=\"packaging\">Packaging: <span>{$i.packaging}</span></div>\r\n					{/if}\r\n					{if $i.notes}\r\n					<div class=\"notes\">Notas: <span>{$i.notes}</span></div>\r\n					{/if}\r\n					{if $i.origin}\r\n					<div class=\"origin\">Origen: <span>{$i.origin}</span></div>\r\n					{/if}\r\n					{if $i.color}\r\n					<div class=\"color\">Color: <span>{$i.color}</span></div>\r\n					{/if}\r\n				</div>\r\n				{if $i@iteration is odd and $i.image}\r\n				<div class=\"image\"><img src=\"uploads/images/{$i.image}\" height=\"100\" alt=\"\"></div>\r\n				{/if}\r\n			</li>\r\n{/foreach}\r\n		</ul>\r\n</div>\r\n</body>\r\n</html>',0,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(9,'Qrs','Plantilla de impresion de qrs del producto','<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n<html>\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-15\">\r\n<title>Abakus Barcode</title>\r\n<style type=\'text/css\'>\r\n	*{font-family:arial, sans;font-size:10px;}\r\n	.barcode{font-size:10px;border:1px solid #ccc;padding:0 0 5px 0;float:left;text-align:center;}\r\n	.barcode img:nth-child(3){padding:3px 0 3px 0}\r\n	.desc{text-align:center;box-sizing:border-box;font-family:Arial, tahoma, verdana,san;font-size:9px;}\r\n</style>\r\n</head>\r\n<body onload=\'printCodes()\'>\r\n	<div id=\"search_result\">\r\n		<div id=\"search_result_wrapper\">\r\n<!-- {[BARCODES]} -->\r\n			<div class=\"barcode\">\r\n				<img src=\"qr_gen.php?id={BARCODES.ID}\" >\r\n<div class=\"desc\">{BARCODES.REF}</div>\r\n			</div>\r\n<!-- {[/BARCODES]} -->\r\n		</div>\r\n	</div>\r\n	<script type=\"text/javascript\">\r\n		function printCodes(){\r\n			//window.print();\r\n			//window.close();\r\n		}\r\n	</script>\r\n</body>\r\n</html>',0,'0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `print_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_models`
--

DROP TABLE IF EXISTS `product_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_models` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `id_provider` int(10) unsigned NOT NULL,
  `id_category` int(10) unsigned NOT NULL,
  `reference` varchar(50) NOT NULL,
  `internal_code` varchar(6) NOT NULL,
  `manufacturers_code` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `insert_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `short_description` varchar(200) NOT NULL,
  `notes` text NOT NULL,
  `id_origin` int(10) unsigned NOT NULL,
  `color` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_models`
--

LOCK TABLES `product_models` WRITE;
/*!40000 ALTER TABLE `product_models` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_types`
--

DROP TABLE IF EXISTS `product_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_types`
--

LOCK TABLES `product_types` WRITE;
/*!40000 ALTER TABLE `product_types` DISABLE KEYS */;
INSERT INTO `product_types` VALUES (1,'Insumo'),(2,'Materia Prima'),(3,'Producto Final'),(4,'Materia + Producto');
/*!40000 ALTER TABLE `product_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL COMMENT '{"validation":"required|notEmpty"}',
  `cost` float(20,4) NOT NULL,
  `id_provider` int(10) unsigned NOT NULL,
  `id_category` int(10) unsigned NOT NULL,
  `id_product_type` int(10) unsigned NOT NULL,
  `id_tax` int(10) unsigned NOT NULL,
  `id_currency` int(10) unsigned NOT NULL COMMENT '{"validation":"required|notEmpty"}',
  `reference` varchar(50) NOT NULL COMMENT '{"validation":"required_ifempty(internal_code,manufacturers_code)"}',
  `internal_code` varchar(6) NOT NULL COMMENT '{"validation":"required_ifempty(reference,manufacturers_code)"}',
  `manufacturers_code` varchar(200) NOT NULL COMMENT '{"validation":"required_ifempty(reference,internal_code)"}',
  `description` text NOT NULL,
  `insert_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `short_description` varchar(200) NOT NULL COMMENT '{"validation":"required|not_empty"}',
  `min_stock` int(10) unsigned NOT NULL,
  `min_stock_alert` tinyint(1) NOT NULL,
  `id_packaging` int(10) unsigned NOT NULL,
  `units_per_package` int(10) unsigned NOT NULL,
  `notes` text NOT NULL,
  `id_origin` int(10) unsigned NOT NULL,
  `color` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cod_fabricante` (`manufacturers_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_prices`
--

DROP TABLE IF EXISTS `products_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_prices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_product` int(10) unsigned NOT NULL,
  `id_price_scale` int(10) unsigned NOT NULL,
  `price` float(20,4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_product` (`id_product`,`id_price_scale`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_prices`
--

LOCK TABLES `products_prices` WRITE;
/*!40000 ALTER TABLE `products_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_stock`
--

DROP TABLE IF EXISTS `products_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_stock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_product` int(10) unsigned NOT NULL,
  `id_location` int(10) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `order_number` varchar(100) DEFAULT NULL,
  `cost` float(20,4) DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `relation` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_product` (`id_product`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_stock`
--

LOCK TABLES `products_stock` WRITE;
/*!40000 ALTER TABLE `products_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_to_images`
--

DROP TABLE IF EXISTS `products_to_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_to_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_product` int(10) unsigned NOT NULL,
  `id_image` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_product` (`id_product`,`id_image`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_to_images`
--

LOCK TABLES `products_to_images` WRITE;
/*!40000 ALTER TABLE `products_to_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_to_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_accounts`
--

DROP TABLE IF EXISTS `provider_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provider_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_provider` int(10) unsigned NOT NULL,
  `type` varchar(20) NOT NULL,
  `id_item` int(10) unsigned NOT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `due_date` date DEFAULT NULL,
  `reference` varchar(100) NOT NULL,
  `id_currency` int(10) unsigned NOT NULL,
  `credit` float(20,4) NOT NULL,
  `debit` float(20,4) NOT NULL,
  `balance` float(20,4) NOT NULL,
  `currencies` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_client` (`id_provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_accounts`
--

LOCK TABLES `provider_accounts` WRITE;
/*!40000 ALTER TABLE `provider_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `provider_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providers`
--

DROP TABLE IF EXISTS `providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `taxpayer_id` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `id_country` int(10) unsigned NOT NULL,
  `id_state` int(10) unsigned NOT NULL,
  `city` varchar(100) NOT NULL,
  `id_bank_entity` int(10) unsigned NOT NULL,
  `bank_account` varchar(100) NOT NULL,
  `postcode` varchar(20) NOT NULL,
  `telephone` varchar(100) NOT NULL,
  `cellphone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `web` varchar(150) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `id_image` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `activo` (`active`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providers`
--

LOCK TABLES `providers` WRITE;
/*!40000 ALTER TABLE `providers` DISABLE KEYS */;
INSERT INTO `providers` VALUES (1,'Proveedor de Muestra','','Independencia 123',1,1,'Mar del Plata',0,'','7600','123456','234567','proveedor@email.com','proveedor.com',1,0);
/*!40000 ALTER TABLE `providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_items`
--

DROP TABLE IF EXISTS `purchase_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_purchase` int(10) unsigned NOT NULL,
  `id_product` int(10) unsigned NOT NULL,
  `reference` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `selected_stock` varchar(500) NOT NULL,
  `price` float(20,4) NOT NULL,
  `tax` float(10,4) NOT NULL,
  `total` float(20,4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_invoice` (`id_purchase`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_items`
--

LOCK TABLES `purchase_items` WRITE;
/*!40000 ALTER TABLE `purchase_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `number` int(8) unsigned NOT NULL,
  `date` date NOT NULL,
  `insert_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `due_date` date DEFAULT NULL,
  `buyer` int(10) unsigned NOT NULL,
  `provider_id` int(10) unsigned NOT NULL,
  `provider_name` varchar(200) NOT NULL,
  `provider_address` varchar(200) NOT NULL,
  `provider_taxpayer_id` varchar(100) NOT NULL,
  `provider_postcode` varchar(50) NOT NULL,
  `provider_city` varchar(200) NOT NULL,
  `provider_state` varchar(200) NOT NULL,
  `provider_country` varchar(200) NOT NULL,
  `id_currency` int(10) unsigned NOT NULL,
  `currencies` varchar(250) NOT NULL,
  `subtotal` float(20,4) NOT NULL,
  `discount` float(20,4) NOT NULL,
  `taxes` varchar(200) NOT NULL,
  `total` float(20,4) NOT NULL,
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `payed` tinyint(1) DEFAULT '0',
  `amount_payed` float(20,4) DEFAULT '0.0000',
  PRIMARY KEY (`id`),
  KEY `client_id` (`provider_id`),
  KEY `date` (`date`),
  KEY `pending` (`pending`),
  KEY `payed` (`payed`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_items`
--

DROP TABLE IF EXISTS `quote_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_quote` int(10) unsigned NOT NULL,
  `id_product` int(10) unsigned NOT NULL,
  `reference` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` float(20,4) NOT NULL,
  `tax` float(10,4) NOT NULL,
  `total` float(20,4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_quote` (`id_quote`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_items`
--

LOCK TABLES `quote_items` WRITE;
/*!40000 ALTER TABLE `quote_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotes`
--

DROP TABLE IF EXISTS `quotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `number` int(8) unsigned NOT NULL,
  `date` date NOT NULL,
  `salesman` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `client_name` varchar(200) NOT NULL,
  `client_address` varchar(200) NOT NULL,
  `client_taxpayer_id` varchar(100) NOT NULL,
  `client_postcode` varchar(50) NOT NULL,
  `client_city` varchar(200) NOT NULL,
  `client_state` varchar(250) NOT NULL,
  `client_country` varchar(250) NOT NULL,
  `id_tax_condition` int(10) unsigned NOT NULL,
  `id_payment_type` int(10) unsigned NOT NULL,
  `id_price_scale` int(10) unsigned NOT NULL,
  `id_currency` int(10) unsigned NOT NULL,
  `currencies` varchar(250) NOT NULL,
  `subtotal` float(20,4) NOT NULL,
  `discount` float(20,4) NOT NULL DEFAULT '0.0000',
  `taxes` varchar(200) NOT NULL,
  `total` float(20,4) NOT NULL,
  `quote_duration` varchar(50) NOT NULL,
  `notes` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `discriminate_taxes` tinyint(1) NOT NULL DEFAULT '1',
  `id_invoice` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotes`
--

LOCK TABLES `quotes` WRITE;
/*!40000 ALTER TABLE `quotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotes_statuses`
--

DROP TABLE IF EXISTS `quotes_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotes_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotes_statuses`
--

LOCK TABLES `quotes_statuses` WRITE;
/*!40000 ALTER TABLE `quotes_statuses` DISABLE KEYS */;
INSERT INTO `quotes_statuses` VALUES (1,'Ingresado'),(2,'Accepted'),(3,'Rejected');
/*!40000 ALTER TABLE `quotes_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipt_invoices`
--

DROP TABLE IF EXISTS `receipt_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_receipt` int(10) unsigned NOT NULL,
  `id_invoice` int(10) unsigned NOT NULL,
  `amount` float(20,4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_receipt` (`id_receipt`,`id_invoice`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipt_invoices`
--

LOCK TABLES `receipt_invoices` WRITE;
/*!40000 ALTER TABLE `receipt_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_client` int(10) unsigned NOT NULL,
  `salesman` int(10) unsigned NOT NULL,
  `number` varchar(50) NOT NULL,
  `balance_in_favor_used` float(20,4) NOT NULL DEFAULT '0.0000',
  `cash_currency` int(10) unsigned NOT NULL,
  `cash` float(20,4) NOT NULL,
  `check_qty` int(11) unsigned NOT NULL,
  `invoice_qty` int(10) unsigned NOT NULL,
  `receipt_currency` int(10) unsigned NOT NULL,
  `total` float(20,4) NOT NULL,
  `total_invoices` float(20,4) NOT NULL DEFAULT '0.0000',
  `credit` float(20,4) NOT NULL DEFAULT '0.0000',
  `currencies` varchar(250) NOT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_client` (`id_client`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts_checks`
--

DROP TABLE IF EXISTS `receipts_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipts_checks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_receipt` int(10) unsigned NOT NULL,
  `id_check` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_receipt` (`id_receipt`,`id_check`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts_checks`
--

LOCK TABLES `receipts_checks` WRITE;
/*!40000 ALTER TABLE `receipts_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipts_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurrent`
--

DROP TABLE IF EXISTS `recurrent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurrent` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_client` int(11) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `period` float(20,2) NOT NULL,
  `period_unit` varchar(10) NOT NULL,
  `start` date NOT NULL,
  `action_name` varchar(50) NOT NULL,
  `action_rel` varchar(20) NOT NULL,
  `autorenew` int(11) NOT NULL,
  `renovation_number` int(10) unsigned DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `notes` text NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_client` (`id_client`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurrent`
--

LOCK TABLES `recurrent` WRITE;
/*!40000 ALTER TABLE `recurrent` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurrent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repair_shop`
--

DROP TABLE IF EXISTS `repair_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repair_shop` (
  `id_repair` int(10) unsigned NOT NULL,
  `repair_cost` float(20,4) NOT NULL,
  `repair_price` float(20,4) NOT NULL,
  `id_status` int(10) unsigned NOT NULL,
  `notice_date` date NOT NULL,
  `delivery_date` date NOT NULL,
  `delivery_charge` float(20,4) NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id_repair`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repair_shop`
--

LOCK TABLES `repair_shop` WRITE;
/*!40000 ALTER TABLE `repair_shop` DISABLE KEYS */;
/*!40000 ALTER TABLE `repair_shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repairs`
--

DROP TABLE IF EXISTS `repairs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repairs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_client` int(10) unsigned NOT NULL,
  `id_contact` int(10) unsigned NOT NULL,
  `number` int(10) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `id_product` int(10) unsigned NOT NULL,
  `serial_number` varchar(100) NOT NULL,
  `id_seller` int(10) unsigned NOT NULL,
  `purchase_date` date NOT NULL,
  `warranty_number` varchar(100) NOT NULL,
  `id_repair_type` int(10) unsigned NOT NULL,
  `unit_condition` text NOT NULL,
  `expected_behaviour` text NOT NULL,
  `obtained_behaviour` text NOT NULL,
  `steps_to_reproduce` text NOT NULL,
  `estimated_notice_date` date NOT NULL,
  `estimated_repair_date` date NOT NULL,
  `estimated_pickup_date` date NOT NULL,
  `estimated_delivery_date` date NOT NULL,
  `testing_cost` float(20,4) NOT NULL,
  `quote_generated` tinyint(1) NOT NULL DEFAULT '0',
  `quote_accepted` tinyint(1) NOT NULL DEFAULT '0',
  `quote_description` text NOT NULL,
  `quote_acceptance_date` date NOT NULL,
  `notes` text NOT NULL,
  `delivery_address` varchar(250) NOT NULL,
  `pickup_address` varchar(250) NOT NULL,
  `id_image` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_client` (`id_client`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repairs`
--

LOCK TABLES `repairs` WRITE;
/*!40000 ALTER TABLE `repairs` DISABLE KEYS */;
/*!40000 ALTER TABLE `repairs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repairs_annotations`
--

DROP TABLE IF EXISTS `repairs_annotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repairs_annotations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_repair` int(10) unsigned NOT NULL,
  `id_user` int(10) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `problem` text NOT NULL,
  `solved` tinyint(1) NOT NULL DEFAULT '0',
  `solution` text NOT NULL,
  `notes` text NOT NULL,
  `time_spent` time NOT NULL,
  `cost` float(20,4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_repair` (`id_repair`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repairs_annotations`
--

LOCK TABLES `repairs_annotations` WRITE;
/*!40000 ALTER TABLE `repairs_annotations` DISABLE KEYS */;
/*!40000 ALTER TABLE `repairs_annotations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repairs_assignations`
--

DROP TABLE IF EXISTS `repairs_assignations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repairs_assignations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) unsigned NOT NULL,
  `id_repair` int(10) unsigned NOT NULL,
  `assignation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `notes` text NOT NULL,
  `id_admin` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repairs_assignations`
--

LOCK TABLES `repairs_assignations` WRITE;
/*!40000 ALTER TABLE `repairs_assignations` DISABLE KEYS */;
/*!40000 ALTER TABLE `repairs_assignations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repairs_delivery_assignations`
--

DROP TABLE IF EXISTS `repairs_delivery_assignations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repairs_delivery_assignations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_deliveryman` int(10) unsigned NOT NULL,
  `id_repair` int(10) unsigned NOT NULL,
  `assignation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `notes` text NOT NULL,
  `id_admin` int(10) unsigned NOT NULL,
  `order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repairs_delivery_assignations`
--

LOCK TABLES `repairs_delivery_assignations` WRITE;
/*!40000 ALTER TABLE `repairs_delivery_assignations` DISABLE KEYS */;
/*!40000 ALTER TABLE `repairs_delivery_assignations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repairs_failures`
--

DROP TABLE IF EXISTS `repairs_failures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repairs_failures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `cost` float(10,4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repairs_failures`
--

LOCK TABLES `repairs_failures` WRITE;
/*!40000 ALTER TABLE `repairs_failures` DISABLE KEYS */;
/*!40000 ALTER TABLE `repairs_failures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repairs_in`
--

DROP TABLE IF EXISTS `repairs_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repairs_in` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_provider` int(10) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `id_category` int(10) unsigned NOT NULL,
  `item` varchar(250) NOT NULL,
  `expected_behaviour` text NOT NULL,
  `obtained_behaviour` text NOT NULL,
  `steps_to_reproduce` text NOT NULL,
  `estimated_notice_date` date NOT NULL,
  `notice_date` datetime DEFAULT NULL,
  `found_failures` text NOT NULL,
  `repair_value` float(20,4) NOT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `id_status` int(10) unsigned NOT NULL DEFAULT '0',
  `id_image` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_client` (`id_provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repairs_in`
--

LOCK TABLES `repairs_in` WRITE;
/*!40000 ALTER TABLE `repairs_in` DISABLE KEYS */;
/*!40000 ALTER TABLE `repairs_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repairs_statuses`
--

DROP TABLE IF EXISTS `repairs_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repairs_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `finished` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repairs_statuses`
--

LOCK TABLES `repairs_statuses` WRITE;
/*!40000 ALTER TABLE `repairs_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `repairs_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repairs_types`
--

DROP TABLE IF EXISTS `repairs_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repairs_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repairs_types`
--

LOCK TABLES `repairs_types` WRITE;
/*!40000 ALTER TABLE `repairs_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `repairs_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sellers`
--

DROP TABLE IF EXISTS `sellers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sellers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sellers`
--

LOCK TABLES `sellers` WRITE;
/*!40000 ALTER TABLE `sellers` DISABLE KEYS */;
/*!40000 ALTER TABLE `sellers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `states` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `id_country` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES (1,'Buenos Aires',1),(2,'Catamarca',1),(3,'Chaco',1),(4,'Chubut',1),(5,'Córdoba',1),(6,'Corrientes',1),(7,'Entre Ríos',1),(8,'Formosa',1),(9,'Jujuy',1),(10,'La Pampa',1),(11,'La Rioja',1),(12,'Mendoza',1),(13,'Misiones',1),(14,'Neuquén',1),(15,'Río Negro',1),(16,'Salta',1),(17,'San Juan',1),(18,'San Luis',1),(19,'Santa Cruz',1),(20,'Santa Fe',1),(21,'Santiago del Estero',1),(22,'Tierra del Fuego',1),(23,'Tucumán',1);
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_conditions`
--

DROP TABLE IF EXISTS `tax_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tax_conditions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `printer_code` char(1) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_conditions`
--

LOCK TABLES `tax_conditions` WRITE;
/*!40000 ALTER TABLE `tax_conditions` DISABLE KEYS */;
INSERT INTO `tax_conditions` VALUES (1,'Monotributo','C'),(2,'Responsable Inscripto','I'),(3,'Iva Excento','I'),(4,'Consumidor Final','C');
/*!40000 ALTER TABLE `tax_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxes`
--

DROP TABLE IF EXISTS `taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `percentage` float(10,4) NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxes`
--

LOCK TABLES `taxes` WRITE;
/*!40000 ALTER TABLE `taxes` DISABLE KEYS */;
INSERT INTO `taxes` VALUES (1,'Iva General',21.0000),(2,'Iva reducido de electrónica',10.5000),(3,'Iva Incluido',0.0000);
/*!40000 ALTER TABLE `taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permissions_templates`
--

DROP TABLE IF EXISTS `user_permissions_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_permissions_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permissions_templates`
--

LOCK TABLES `user_permissions_templates` WRITE;
/*!40000 ALTER TABLE `user_permissions_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_permissions_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_preferences`
--

DROP TABLE IF EXISTS `user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_preferences` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) unsigned NOT NULL,
  `module` varchar(100) NOT NULL,
  `attribute` varchar(250) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_user` (`id_user`,`module`,`attribute`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_preferences`
--

LOCK TABLES `user_preferences` WRITE;
/*!40000 ALTER TABLE `user_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_skills`
--

DROP TABLE IF EXISTS `user_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_skills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) unsigned NOT NULL,
  `id_category` int(10) unsigned NOT NULL,
  `level` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_user` (`id_user`,`id_category`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_skills`
--

LOCK TABLES `user_skills` WRITE;
/*!40000 ALTER TABLE `user_skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(80) NOT NULL,
  `name` varchar(150) NOT NULL,
  `active` tinyint(1) DEFAULT '1',
  `superadmin` tinyint(1) NOT NULL DEFAULT '0',
  `can_sell` tinyint(1) NOT NULL DEFAULT '0',
  `can_buy` tinyint(1) NOT NULL DEFAULT '0',
  `discount_limit` float(5,2) NOT NULL DEFAULT '0.00',
  `id_image` int(10) unsigned NOT NULL DEFAULT '0',
  `first_login` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `userkey` varchar(128) DEFAULT NULL,
  `permissions` text NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','d033e22ae348aeb5660fc2140aec35850c4da997','admin@abakus.com','Administrador',1,1,1,1,0.00,0,'2011-12-23 20:23:47','2012-10-16 15:14:36','','',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-02-01 11:57:14
