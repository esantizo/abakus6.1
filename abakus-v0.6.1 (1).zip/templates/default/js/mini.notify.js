(function(){

window.Notify = function(options){
	var defaultOptions = {
		'modal': false,
		'layout': 'center',
		'textAlign': 'center',
		'animation': 'fade', // Fade, slide
		'onShow': null,
		'onClose': null
	};
	self.options = merge(defaultOptions,options);

	this.alert = function(text,type){
		alert(text);
		return this;
	};

	this.confirm = function(text,type){
		var ret = confirm(text);
		return ret;
	};

	this.prompt = function(text,defValue,type){
		var ret = prompt(text,defValue);
		return ret;
	};
};

})();
