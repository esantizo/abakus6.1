var waiting = false;

function searchNavigationListener(ev){
	if(calculator && calculator.opened) return false;
	if(navigateItems==true){
		$$('#items_results_table_body tr').each(function(e){e.removeClass('selected');});
		if(ev.target==$('search_item_input')){
			if(ev.keyCode==40 || ev.keyCode==38){
				$('search_item_input').blur();
			}
		}
		if(ev.keyCode==40){
			if(current == null){
				current = $('items_results_table_body').getFirst('tr');
			} else {
				current = nextItem(current,'TR');
				if(!current) current = $('items_results_table_body').getFirst('tr');
			}
		} else if(ev.keyCode==38){
			if(current == null){
				current = $('items_results_table_body').getLast('tr');
			} else {
				current = previousItem(current,'TR');
				if(!current) current = $('items_results_table_body').getLast('tr');
			}
		} else if(ev.keyCode==13) {
			if(current){
				$('pos_input').value = current.getElements('td')[0].innerHTML;
				searchLightbox.close();
				searchItem();
				navigateItems = false;
				return false;
			}
		}
		if(current){
			current.addClass('selected');
			var curPos = current.getPosition();
			if($('items_results_table')){
				var contHeight = $('search_item_response').getPosition().height;
				var maxScroll = $('items_results_table').getPosition().totalHeight - contHeight;
			}
			var scroll = curPos.top + curPos.height - contHeight / 2;
			if(scroll < 0) scroll = 0;
			if(scroll > maxScroll) scroll = maxScroll;
			if($('items_results_table')){
				$('search_item_response').scrollTop = scroll;
			}
			if(ev.preventDefault) ev.preventDefault();
			if(ev.preventBubble) ev.preventBubble();
			return false;
		}
	}
}

function keyboardListener(ev){
	if(!waiting){
		if(ev.keyCode == 112){ //F1
			ev.preventDefault();
			show_park_in();
		} else if(ev.keyCode == 113) { //F2
			ev.preventDefault();
			show_park_out();
		} else if(ev.keyCode == 27) { //ESC
			ev.preventDefault();
			park_cancel();
		}
	}
}

function openClient(id){
	$('client').value = id;
	$('client').set('rel',id);
	searchClientData(id,function(){
		setFocus('pos_input');
		$('invoice_type').setSelected(default_invoice_type);
		updateInvoiceType();
		changeInvoiceType(discriminate_taxes);

		$('invoice_table').setStyle('display','block');
	});
}

function setClientData(data){
	$('client').set('rel',0);
	$('client_name_input').value='##NG_POS_GENERAL_CLIENT_NAME##';
	$('client_address_input').value=data.client_address;
	$('client_city_input').value=data.client_city;
	$('client_state_input').value=data.client_state;
	$('client_country_input').value=data.client_country;
	$('client_taxpayer_id_input').value=data.client_taxpayer_id;
	$('client_tax_condition_input').value='';
	$('client_payment_type_input').value='';
	$('client_price_scale_input').value = data.id_price_scale;

	$('client_name').set('text','');
	$('client_address').set('text','');
	$('client_city').set('text','');
	$('client_state').set('text','');
	$('client_country').set('text','');
	$('client_taxpayer_id').set('text','');
	$('client_tax_condition').set('text','');
	$('client_payment_type').set('text','');
	$('client_price_scale').set('text',data.price_scale_name);

	$('client_name_input').set('type','text');
	$('client_address_input').set('type','text');
	$('client_city_input').set('type','text');
	$('client_state_input').set('type','text');
	$('client_country_input').set('type','text');
	$('client_taxpayer_id_input').set('type','text');

	$('client_tax_condition_select').setStyle('display','inline');
	$('client_payment_type_select').setStyle('display','inline');

	$('client_tax_condition_input').set('name','');
	$('client_tax_condition_input').removeAttribute('data-printer-code');
	$('client_tax_condition_select').set('name','client_tax_condition');

	$('client_payment_type_input').set('name','');
	$('client_payment_type_select').set('name','client_payment_type');

	$('client_tax_condition_select').setSelected(data.id_tax_condition);
	$('client_payment_type_select').setSelected(data.id_payment_type);

	$('invoice_type').setSelected(default_invoice_type);
	updateInvoiceType();
	changeInvoiceType(discriminate_taxes);

	$('invoice_table').setStyle('display','block');
}

function showDate(){
	var currentTime = new Date();

	var date = currentTime.getDate().toString().lpad('0',2);
	var month = currentTime.getMonth().toString().lpad('0',2);
	var year = currentTime.getYear();
	var hour = currentTime.getHours().toString().lpad('0',2);
	var minutes = currentTime.getMinutes().toString().lpad('0',2);

	$$('.show_date').set('text',date+'/'+month+'/'+(year+1900)+' '+hour+':'+minutes);

	setTimeout(showDate,10000);
}

function show_park_out(){
	$('main_buttons').setStyle('display','none');
	$('park_in').setStyle('display','none');
	$('park_out').setStyle('display','block');
	setFocus($$('#park_out .license_plate_input')[0].set('value',''));
}

function show_park_in(){
	$('main_buttons').setStyle('display','none');
	$('park_out').setStyle('display','none');
	$('park_in').setStyle('display','block');
	setFocus($$('#park_in .license_plate_input')[0].set('value',''));
}

function clearParkInForm(){
	$$('.license_plate_input').set('value','');
	$$('.license_plate_notes').set('value','');
	$$('.stay_type').set('checked',false);
	$$('.stay_type')[0].set('checked',true);
	$$('.options_block').setStyle('display','none');
	$$('#park_in .license_plate_input')[0].focus();
}

function clearParkOutForm(){
	$$('.license_plate_input').set('value','');
	$$('#park_out .license_plate_input')[0].focus();
}

function displayOptionsBlock(type){
}

function park_in_ok(force){
	if($$('#park_in .license_plate_input')[0].value.trim().length == 0){
		msgBox("##NG_LICENSEPLATE_MUST_NOT_BE_EMPTY##");
		return false;
	}

	var force = (force?1:0);

	var type = $$('.stay_type:checked')[0].value;
	if( type == 'shift' && ($('shift_options').getStyle('display') == 'none' || $('shift_name').get('value')=='0' )){
		$('shift_options').setStyle('display','block')
		return;
	}

	if( type == 'monthly' && ($('monthly_options').getStyle('display') == 'none' || $('monthly_name').get('value')=='0' )){
		$('monthly_options').setStyle('display','block')
		return;
	}

	var license_plate = $$('#park_in .license_plate_input')[0].get('value');
	var license_plate_notes = $('license_plate_notes').value;

	$('invoice_form').startWaiting();
	waiting = true;

	var options = '';
	var bl = $$('.options_block[rel="'+type+'"]');
	if(bl && bl.length > 0){
		var opts = {};
		var els = bl[0].getElements('input,select');
		var with_opts = false;
		for(var i=0,len=els.length; i<len; i++){
			var $e = els[i];
			opts[$e.get('name')] = $e.get('value');
			with_opts = true;
		}
		if(with_opts) options = JSON.stringify(opts);
	}

	Request({
		'url': 'ajax/parking.php',
		'method': 'post',
		'data': { 'action':'park_in', 'license_plate': license_plate, 'notes': license_plate_notes, 'type': type, 'options': options, 'force': force },
		'onSuccess': function(response){
			var res = parseJSON(response);
			if(res.success){
				if(type == 'monthly'){
					showMonthlyParkingRate(res.monthly);
				} else {
					clearParkInForm();
					$('invoice_form').stopWaiting();
					waiting = false;
				}
			} else {
				$('invoice_form').stopWaiting();
				waiting = false;
				if(confirmBox(res.error+' ##NG_DO_IT_ANYWAYS##')){
					park_in_ok(true);
				} else {
					clearParkInForm();
				}
			}
		},
		'onError': function(){
			clearParkInForm();
			$('invoice_form').stopWaiting();
			waiting = false;
		}
	});
}

function park_out_ok(id){
	$('invoice_form').startWaiting();
	waiting = true;
	Request({
		'url': 'ajax/parking.php',
		'method': 'post',
		'data': { 'action':'park_out', 'id': id },
		'onSuccess': function(response){
			var data = parseJSON(response);
			if(data){
				if(data.type != 'monthly'){
					$cont = $('stayPriceLightbox');
					$cont.getFirst('.stay_price_license_plate').set('text',data.license_plate);
					$cont.getFirst('.stay_price_notes').set('text',data.notes);
					$cont.getFirst('.stay_price_type').set('text',data.type_name);
					$cont.getFirst('.stay_price').set('text',data.price);

					stayPriceLightbox.open();
				} else {
					$cont = $('infoLightbox');
					$cont.getFirst('.stay_price_license_plate').set('text',data.license_plate);
					$cont.getFirst('.stay_price_notes').set('text',data.notes);
					$cont.getFirst('.stay_price_type').set('text',data.type_name);
					$cont.getFirst('.stay_price').set('text',data.price);

					infoLightbox.open();
				}
			}
			clearParkOutForm();
			$('invoice_form').stopWaiting();
			waiting = false;
		},
		'onError': function(){
			$('invoice_form').stopWaiting();
			waiting = false;
		}
	});
}

function showMonthlyParkingRate(data){
	$('invoice_form').startWaiting();
	if(data){
		$cont = $('stayPriceLightbox');
		$cont.getFirst('.stay_price_license_plate').set('text',data.license_plate);
		$cont.getFirst('.stay_price_notes').set('text',data.notes);
		$cont.getFirst('.stay_price_type').set('text',data.type_name);
		$cont.getFirst('.stay_price').set('text',data.price);

		stayPriceLightbox.open();
	}
	clearParkInForm();
	$('invoice_form').stopWaiting();
	waiting = false;
}

function checkClient(license_plate,cbFunction){
	$('park_in').startWaiting();
	$('client_info').setStyle('display','none');
	$('no_client_info').setStyle('display','none');
	waiting = true;
	Request({
		'url': 'ajax/parking.php',
		'method': 'post',
		'data': { 'action':'check_client', 'license_plate': license_plate },
		'onSuccess': function(response){
			var data = parseJSON(response);
			if(data){
				$('client_name').set('text',data.name);
				$('client_address').set('text',data.address);
				$('client_phone').set('text',data.phone);
				$('client_mobile').set('text',data.mobile);
				$('client_email').set('text',data.email);

				$$('.must_be_client').setStyle('display','block');

				$('client_info').setStyle('display','block');
				$('no_client_info').setStyle('display','none');
				$('parking_data').setStyle('display','block');
				$('already_parked_in_message').setStyle('display','none');
				if(data.already_parked_in){
					$('already_parked_in_message').setStyle('display','block');
					$('parking_data').setStyle('display','none');
				}
			} else {
				$$('.must_be_client').setStyle('display','none');

				$('already_parked_in_message').setStyle('display','none');
				$('client_info').setStyle('display','none');
				$('no_client_info').setStyle('display','block');
				$('parking_data').setStyle('display','block');
			}
			$('park_in').stopWaiting();
			setFocus('license_plate_notes');
			if(typeof cbfunction=='function'){
				cbFunction.call(this,(data?true:false));
			}
			waiting = false;
		},
		'onError': function(){
			$('park_in').stopWaiting();
			waiting = false;
		}
	});
}

function parking_check(){
	var license_plate = $$('#park_out .license_plate_input')[0].get('value');

	$('invoice_form').startWaiting();
	waiting = true;
	Request({
		'url': 'ajax/parking.php',
		'method': 'post',
		'data': { 'action':'parking_check', 'license_plate': license_plate },
		'onSuccess': function(response){
			var res = parseJSON(response);
			if(res){
				$('park_out_confirm_list').empty();
				if(res.length > 0){
					$('park_out_confirm_error').setStyle('display','none');
					for(var i=0,len=res.length; i<len; i++){
						var $d = res[i];
						var $c = $('park_out_confirm_template').clone().unset('id');

						$c.getFirst('.confirmation_item_license_plate').set('text',$d.license_plate);
						$c.getFirst('.confirmation_item_notes').set('text',$d.notes);
						$c.getFirst('.confirmation_item_type').set('text',$d.type_name);
						$c.getFirst('.confirmation_item_time_in').set('text',$d.time_in_formatted);
						$c.getFirst('.confirmation_item_id').set('text',$d.id);
						$c.setData('rel',$d.id);
						$c.inject('park_out_confirm_list');

						$c.addEvent('click', (function(id){ return function(){ parkOutLightbox.close(); park_out_ok(id); } })($d.id));
					}
				} else {
					$('park_out_confirm_error').set('text','##NG_NO_LICENSE_PLATES_MATCHING_SEARCH##').setStyle('display','block');
				}
				parkOutLightbox.open();
			}
			$('invoice_form').stopWaiting();
			waiting = false;
		},
		'onError': function(){
			$('invoice_form').stopWaiting();
			waiting = false;
		}
	});
}

function park_cancel(){
	$('main_buttons').setStyle('display','block');
	$('park_in').setStyle('display','none');
	$('park_out').setStyle('display','none');
}

function parkOutConfirmationCancel(){
	parkOutLightbox.close();
}
