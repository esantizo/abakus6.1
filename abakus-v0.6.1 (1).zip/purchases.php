<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'purchases.php';

	$module_name = 'purchases';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	if($_POST['save']){
		$pending = ($_POST['save']=='pending'?1:0);
		$number = (int)$_POST['number'];
		$date = date2sqldate($_POST['date']);
		$buyer = (int)$_POST['buyer'];
		$provider_id = (int)$_POST['provider_id'];
		$provider_name = $db->escape_string($_POST['provider_name']);
		$provider_address = $db->escape_string($_POST['provider_address']);
		$provider_taxpayer_id = $db->escape_string($_POST['provider_taxpayer_id']);
		$provider_city = $db->escape_string($_POST['provider_city']);
		$provider_state = $db->escape_string($_POST['provider_state']);
		$provider_country = $db->escape_string($_POST['provider_country']);
		$provider_postcode = $db->escape_string($_POST['provider_postcode']);
		$id_currency = (int)$_POST['currency'];
		if(is_array($_POST['currency_rates'])){
			$currencies = stringifyCurrencies($_POST['currency_rates']);
		}
		$subtotal = float($_POST['subtotal']);
		if(is_array($_POST['total_taxes'])){
			$taxes = stringifyTaxes($_POST['total_taxes']);
		}
		$discount = float($_POST['discount']);
		$total = float($_POST['total']);

		// The invoice has items
		if(is_array($_POST['ref'])){
			$purchase_id = $db->insert("
				INSERT INTO purchases SET
					number='$number',
					`date`='$date',
					buyer='$buyer',
					provider_id='$provider_id',
					provider_name='$provider_name',
					provider_address='$provider_address',
					provider_taxpayer_id='$provider_taxpayer_id',
					provider_city='$provider_city',
					provider_postcode='$provider_postcode',
					provider_state='$provider_state',
					provider_country='$provider_country',
					id_currency='$id_currency',
					currencies='$currencies',
					subtotal='$subtotal',
					taxes='$taxes',
					discount='$discount',
					total='$total',
					pending=$pending
			");

			if($purchase_id){
				foreach($_POST['ref'] as $k => $ref){
					$product_id = (int)$_POST['product_id'][$k];
					$ref = $db->escape_string($ref);
					$desc = $db->escape_string($_POST['desc'][$k]);
					$qty = $db->escape_string($_POST['qty'][$k]);
					$price = $db->escape_string($_POST['price'][$k]);
					$tax = $db->escape_string($_POST['tax'][$k]);
					$item_total = $db->escape_string($_POST['item_total'][$k]);
					$selected_stock = $db->escape_string($_POST['sel_stock'][$k]);
					$db->insert("
						INSERT INTO purchase_items SET
							id_purchase=$purchase_id,
							id_product=$product_id,
							reference='$ref',
							description='$desc',
							quantity='$qty',
							selected_stock='$selected_stock',
							price='$price',
							tax='$tax',
							total='$item_total'
					");
					if(!$pending){
						$sel_stock = explode('|',$_POST['sel_stock'][$k]);
						if(is_array($sel_stock)){
							foreach($sel_stock as $st){
								list($id,$qty) = explode(':',$st);
								if((int)$id > 0 && (int)$qty > 0){
									$db->insert("INSERT INTO products_stock SET
										id_product=$product_id,
										id_location=".(int)$id.",
										quantity=(".(int)$qty."),
										relation='purchase|$purchase_id'
									");
								}
							}
						} else {
						}
					}
				}

				redirect("purchase_details.php?id=$purchase_id");
			}

			// INSERT error
			else{
			}

		}

		// The invoice doesn't have any item
		else {
		}
	}

	$buyers = $db->fetch_all("
		SELECT u.*, IF(u.id='{$user->getId()}','selected=\"selected\"','') AS selected
		FROM users AS u
		WHERE u.can_buy=1
			AND u.deleted=0
	");
	$purchase_number = max(1,$db->fetch_item_field("SELECT (MAX(number)+1) FROM purchases"));
	$tax_values = $db->fetch_all("SELECT percentage FROM taxes ORDER BY percentage",'percentage');
	$locations = $db->fetch_all("SELECT CONCAT(id,':',name) as data FROM locations ORDER BY id",'data');
	$currency = $db->fetch_all("SELECT * FROM currency ORDER BY rate");

	switch($config['invoice_search_field']){
		case 'internal_code': $first_field = __("Internal Code"); break;
		case 'manufacturers_code': $first_field = __("Manufacturers Code"); break;
		default: $first_field = __("Reference");
	}

	$return_url = return_to_module_url($module_name);

	$smarty->assign('return_url',$return_url);
	$smarty->assign('purchase_number',$purchase_number);
	$smarty->assign('currency',$currency);
	$smarty->assign('buyers',$buyers);
	$smarty->assign('first_field',$first_field);
	$smarty->assign('tax_values',implode(',',$tax_values));
	$smarty->assign('locations',implode("|",$locations));
	$smarty->assign('ignore_stock',($config['ignore_stock']?1:0));

	$smarty->display('purchases.tpl');
?>
