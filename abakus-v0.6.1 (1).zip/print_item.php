<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = $_GET['module'];

	// We load the module
	$module = loadModule($module_name,$db);

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	require 'inc/smarty.php';

	if($_GET['id']){
		$tmp = $module->getPrintData($_GET['id']);
		$template = $tmp['template']['content'];
		$data = $tmp['data'];
	} else {
		$foo = $module->getPrintTemplate();
		$template = $foo['content'];
	}

	if(empty($template)){
		print __("##NG_ERR_MUST_CHOOSE_TEMPLATE##");
	} else {
		$company_info = $db->fetch_all("SELECT * FROM config WHERE name LIKE 'company_%'",'value','name');
		if(is_array($company_info) && is_array($data)){
			$data = array_merge($company_info,$data);
		} elseif(is_array($company_info)) {
			$data = $company_info;
		}

		if(is_array($data)) foreach($data as $key=>$value){
			$smarty->assign($key, $value);
		}

		$template = 'string:'.$template;
		if(!$_GET['view'] && !$_GET['preview']){
			$smarty->display($template.'<script type="text/javascript">window.print();</script>');
		} elseif($_GET['preview']) {
			$smarty->display($template);
		} else {
			$content = $smarty->fetch($template);
			require_once("inc/dompdf/dompdf_config.inc.php");
			$dompdf = new DOMPDF();
			$dompdf->set_paper("A4");
			$dompdf->load_html($content);
			$dompdf->render();
			$dompdf->stream("item_{$data['id']}.pdf");
		}
	}
?>