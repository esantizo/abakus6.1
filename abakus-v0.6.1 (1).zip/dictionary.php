<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = "dictionary.php";
	$module_name = "dictionary.php";

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	require 'inc/smarty.php';

	$lang_dir = $smarty->getLanguagesDir();
	$curr_lang = $smarty->language->getCurrentLocale();
	$smarty->language->loadCurrentTranslationTable();

	if($_GET['search_new_words']){
		$fixed_words = array('Fields','Global','Images','Menus');

		$directories = array(
			'.',
			'ajax',
			'inc',
			'inc/modules',
			'inc/plugins',
			'inc/controllers',
			$template_dir,
			$template_dir.'js',
		);
		$extensions = array(
			'php',
			'tpl',
			'.js'
		);
		$skip_tables = array(
			'config',
			'images',
			'menu',
			'products_to_images',
			'user_permissions_templates',
			'user_preferences'
		);
		$statuses_tables = array(
			'quotes_statuses'
		);

		$matches = array();
		foreach($directories as $d){
			$files = scandir($d);
			foreach($files as $f){
				if(in_array(substr($f,-3),$extensions) && substr($f,0,1)!='.'){
					$fname = $d.'/'.$f;
					$content = file_get_contents($fname);
					preg_match_all("|##([\w_-]*?)##|",$content,$match);
					if(!empty($match[1])){
						$matches = array_merge_recursive($matches,$match[1]);
					}
					if($d == 'inc/modules' && substr($f,0,4) == 'mod_'){
						preg_match_all("|item_name(?:.*?)[\"\'](.*)[\"\']|",$content,$match);
						if(!empty($match[1])){
							$matches = array_merge_recursive($matches,$match[1]);
						}
					}
				}
			}
		}

		/* We add the fields from the database */
		$tables_arr = $db->getTables();
		foreach($tables_arr as $table){
			if(in_array($table,$skip_tables) || substr($table,0,4)=='_bkp'){
				continue;
			}
			$table_fields = $db->fetch_all("SHOW COLUMNS FROM $table",'Field');
			foreach($table_fields as $f){
				if(substr($f,0,2)!='id'){
					$fields[] = beautifyFieldName($f);
				}
			}
		}

		/* We add the registers from the statuses tables */
		if(is_array($statuses_tables)) foreach($statuses_tables as $table){
			$rows = $db->fetch_all("SELECT name FROM $table",'name');
			if(is_array($rows)) foreach($rows as $f){
				$fields[] = beautifyFieldName($f);
				$fields[] = 'IMG_'.strtoupper($table).'_'.strtoupper(strtoascii($f,'_'));
			}
		}

		if(is_array($fields)){
			$matches = array_merge($matches,$fields);
		}

		$matches = array_merge($matches,$fixed_words);

		$matches = array_unique($matches);

		// Get Menu Items
		sort($matches);

		$forbidden_words = array('(.*?)');
		$non_translated_img = array();
		$non_translated_ng = array();
		$non_translated_field = array();
		if(is_array($matches)) foreach($matches as $m){
			$str = str_replace('##','',$m);
			if(!in_array($m,$forbidden_words)){
				if(!$smarty->language->translationExists($str)){
					$str2 = "$str=\n";
				} else {
					$str2 = "$str=".__($str)."\n";
				}
				if(substr($str,0,4)=='IMG_'){
					$tr = __($str);
					$tr = substr($tr,strrpos($tr,'/')+1);
					$str2 = "$str=$tr\n";
					$non_translated_img[] = $str2;
				} elseif(substr($str,0,3)=='NG_') {
					$non_translated_ng[] = $str2;
				} else {
					$non_translated_field[] = $str2;
				}
			}
		}

		$menu_names = $db->fetch_all("SELECT name FROM menu",'name');
		$non_translated_menu_img = array();
		$non_translated_menu_ng = array();
		if(is_array($menu_names)) foreach($menu_names as $m){
			$str = strtoupper(strtoascii(str_replace('##','',$m),'_'));
			if(!$smarty->language->translationExists('NG_MENU_'.$str)){
				$str2 = "NG_MENU_{$str}=\n";
			} else {
				$str2 = "NG_MENU_{$str}=".__('NG_MENU_'.$str)."\n";
			}
			$non_translated_menu_ng[] = $str2;
			if(!$smarty->language->translationExists('IMG_MENU_'.$str)){
				$str2 = "IMG_MENU_{$str}=\n";
			} else {
					$tr = __('IMG_MENU_'.$str);
					$tr = substr($tr,strrpos($tr,'/')+1);
				$str2 = "IMG_MENU_{$str}=$tr\n";
			}
			$non_translated_menu_img[] = $str2;
		}

		if(!is_writable($lang_dir.$curr_lang)){
			die("Cannot write in dir: ".$lang_dir.$curr_lang);
		} else if (file_exists($lang_dir.$curr_lang.'/images.lng') && !is_writable($lang_dir.$curr_lang.'/images.lng')) {
			die("Cannot write in file: ".$lang_dir.$curr_lang.'/images.lng');
		} else if (file_exists($lang_dir.$curr_lang.'/global.lng') && !is_writable($lang_dir.$curr_lang.'/global.lng')) {
			die("Cannot write in file: ".$lang_dir.$curr_lang.'/global.lng');
		} else if (file_exists($lang_dir.$curr_lang.'/menus.lng') && !is_writable($lang_dir.$curr_lang.'/menus.lng')) {
			die("Cannot write in file: ".$lang_dir.$curr_lang.'/menus.lng');
		} else if (file_exists($lang_dir.$curr_lang.'/fields.lng') && !is_writable($lang_dir.$curr_lang.'/fields.lng')) {
			die("Cannot write in file: ".$lang_dir.$curr_lang.'/fields.lng');
		}

		if(is_array($non_translated_img)){
			$fh = fopen($lang_dir.$curr_lang.'/images.lng','w');
			foreach($non_translated_img as $t){
				fwrite($fh,"$t");
			}
			foreach($non_translated_menu_img as $t){
				fwrite($fh,"$t");
			}
			fclose($fh);
			@chmod($lang_dir.$curr_lang.'/images.lng', 0666);
		}

		if(is_array($non_translated_ng)){
			$fh = fopen($lang_dir.$curr_lang.'/global.lng','w');
			foreach($non_translated_ng as $t){
				fwrite($fh,"$t");
			}
			fclose($fh);
			@chmod($lang_dir.$curr_lang.'/global.lng', 0666);
		}

		if(is_array($non_translated_menu_ng)){
			$fh = fopen($lang_dir.$curr_lang.'/menus.lng','w');
			foreach($non_translated_menu_ng as $t){
				fwrite($fh,"$t");
			}
			fclose($fh);
			@chmod($lang_dir.$curr_lang.'/menus.lng', 0666);
		}

		if(is_array($non_translated_field)) {
			$fh = fopen($lang_dir.$curr_lang.'/fields.lng','w');
			foreach($non_translated_field as $t){
				fwrite($fh,"$t");
			}
			fclose($fh);
			@chmod($lang_dir.$curr_lang.'/fields.lng', 0666);
		}

		redirect($thispage);
		die();
	}

	if($_POST['save']){
		if(is_array($_POST['translations'])){

			if(!is_writable($lang_dir.$curr_lang)){
				die("Cannot write in dir: ".$lang_dir.$curr_lang);
			} else if (!is_writable($lang_dir.$curr_lang.'/images.lng')) {
				die("Cannot write in file: ".$lang_dir.$curr_lang.'/images.lng');
			} else if (!is_writable($lang_dir.$curr_lang.'/global.lng')) {
				die("Cannot write in file: ".$lang_dir.$curr_lang.'/global.lng');
			} else if (!is_writable($lang_dir.$curr_lang.'/menus.lng')) {
				die("Cannot write in file: ".$lang_dir.$curr_lang.'/menus.lng');
			} else if (!is_writable($lang_dir.$curr_lang.'/fields.lng')) {
				die("Cannot write in file: ".$lang_dir.$curr_lang.'/fields.lng');
			}

			$imgs_fh = fopen($lang_dir.$curr_lang.'/images.lng','w');
			$menus_fh = fopen($lang_dir.$curr_lang.'/menus.lng','w');
			$ngs_fh = fopen($lang_dir.$curr_lang.'/global.lng','w');
			$fields_fh = fopen($lang_dir.$curr_lang.'/fields.lng','w');
			foreach($_POST['translations'] as $k => $t){
				if(substr($k,0,4)=='IMG_'){
					fwrite($imgs_fh,"$k=$t\n");
				} elseif(substr($k,0,8)=='NG_MENU_') {
					fwrite($menus_fh,"$k=$t\n");
				} elseif(substr($k,0,3)=='NG_') {
					fwrite($ngs_fh,"$k=$t\n");
				} else {
					fwrite($fields_fh,"$k=$t\n");
				}
			}
			fclose($imgs_fh);
			fclose($menus_fh);
			fclose($ngs_fh);
			fclose($fields_fh);
		}
		redirect($thispage);
	}

	$translations = $smarty->language->getTranslationTable();
	if($_GET['ref_lang']){
		$smarty->language->loadTranslationTable($_GET['ref_lang']);
		$ref_translations = $smarty->language->getTranslationTable($_GET['ref_lang']);
	}

	$languages = $smarty->language->getAvailableLanguages();

	foreach($translations as $key => $tt){
		$smarty->assign("translations_{$tt[$key]}",$tt);
	}
	$smarty->assign("languages",$languages);
	$smarty->assign("translations",$translations);
	$smarty->assign("ref_translations",$ref_translations);

	$smarty->display('dictionary.tpl');
?>
