<?
	if(preg_match('/MSIE|Opera/i',$_SERVER['HTTP_USER_AGENT'])) {
		header("Location: ienotsupported.php");
		die();
	}

	require_once "class.user.php";

	$autologin_cookie_name = strtoascii($autologin_cookie_name,'_');

	// Sets session options
	session_set_cookie_params(time()+60*60*24,'/');
	ini_set("session.gc_maxlifetime","86400"); // 1 D�a

	session_name(strtoascii($site_name,'_')."_id");
	// Start the session :-)
	session_start();

	if(!empty($_SESSION['username']) && !empty($_SESSION['password'])){
		$user = new User($db,$_SESSION['username'],$_SESSION['password']);
		if(!$user->isValid())
			unset($user);
	}
	else {
		// Check if the cookie exists
		if(isset($_COOKIE[$autologin_cookie_name])){
			parse_str($_COOKIE[$autologin_cookie_name]);
			$user = new User($db);
			$user->autologin($usr,$hash,$autologin_salt);
			if(!$user->isValid())
				unset($user);
		}
	}

	if(!$user && !$login && !$js_parser && !$no_session) redirect('login.php');

	$default_preferences = array(
		'display_menu_on_click' => 0,
		'pager_max_per_page' => 10
	);

	if($user && $user->isValid())
		$user_preferences = $db->fetch_all("SELECT * FROM user_preferences WHERE id_user=".$user->getId()." AND module='general'",'value','attribute');
