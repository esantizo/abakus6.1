var globalStorage = {};

function getURLParams(url){
	if(!url){
		url = location.href;
	}
	var params = {};

	if (url) {
		url = url.split('?')[1];
		if(!url) return null;
		var parts = url.split('&');

		for (var i = 0; i < parts.length; i++) {
			var nv = parts[i].split('=');
			if (!nv[0]) continue;
			params[decodeURIComponent(nv[0])] = decodeURIComponent(nv[1]) || true;
		}
	}
	return params;
}

function ArrayToURL(array) {
	var pairs = [];
	for (var key in array)
		if (array.hasOwnProperty(key))
			pairs.push(encodeURIComponent(key) + '=' + encodeURIComponent(array[key]));
	return pairs.join('&');
}

function createUUID() {
    // http://www.ietf.org/rfc/rfc4122.txt
    var s = [];
    var hexDigits = "0123456789abcdef";
    for (var i = 0; i < 36; i++) {
        s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
    }
    s[14] = "4";  // bits 12-15 of the time_hi_and_version field to 0010
    s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);  // bits 6-7 of the clock_seq_hi_and_reserved to 01
    s[8] = s[13] = s[18] = s[23] = "-";

    var uuid = s.join("");
    return uuid;
}

String.prototype.toInt = function(){
	var str = this.trim();
	if(!str.match(/^[\d-]/)) return 0;
	var val = str.replace(/[^\d\.-]/g,' ');
	return parseInt(val * 1,10);
};
String.prototype.toFloat = function(){
	var str = this.trim();
	if(!str.match(/^[\d-]/)) return 0;
	var val = str.replace(/[^\d\.-]/g,' ');
	return parseFloat(val * 1);
};
String.prototype.round = function(resolution){
	return this.toFloat().round(resolution);
};
String.prototype.trim = function(){
	return this.replace(/^\s+|\s+$/g,'');
};

//pads left
String.prototype.lpad = function(padString, length) {
	var str = this;
	while (str.length < length)
		str = padString + str;
	return str;
}

//pads right
String.prototype.rpad = function(padString, length) {
	var str = ''+this;
	while (str.length < length)
		str = str + padString;
	return str;
}

Number.prototype.toInt = function(){
	var val = this + '';
	return val.toInt();
};
Number.prototype.toFloat = function(){
	var val = this + '';
	return val.toFloat();
};
Number.prototype.round = function(resolution){
	if(typeof resolution == 'undefined') resolution = 2;
	var val = this * 1;
	var exp = Math.pow(10,resolution);
	// Method 1
	//~ if(val > 0){
		//~ val = val * exp + (exp-1)/exp;
	//~ } else {
		//~ val = val * exp - (exp-1)/exp;
	//~ }
	//~ var tmp = (val.toInt()/exp);

	// Method 2
	var tmp = Math.round(val * exp) / exp;
	return (parseFloat(tmp) * 1);
};

Array.prototype.each = function(callback){
	for (var i = 0; i < this.length; i++){
		if(typeof this[i]!='undefined')
			callback(this[i],i);
	}
	return this;
};
Array.prototype.remove = function(index){
	this.splice(index,1);
	return this;
};
Array.prototype.removeValue = function(val){
	for(var i=this.length-1; i>=0; i--){
		if(this[i] == val){
			this.remove(i);
		}
	}
	return this;
};
Array.prototype.contains = function(obj) {
	var i = this.length;
	while (i--) {
		if (this[i] == obj) {
			return true;
		}
	}
	return false;
};

function in_array(item,arr){
	var i;
	if(typeof arr=='object'){
		if(arr.length > 0){
			for(i=0,len=arr.length; i<len; i++){
				if(arr[i] == item) return true;
			}
		} else {
			for(i in arr){
				if(arr[i] == item) return true;
			}
		}
	}
	return false;
}

function array_pos(item,arr){
	var i;
	if(typeof arr=='object'){
		if(arr.length > 0){
			for(i=0,len=arr.length; i<len; i++){
				if(arr[i] == item) return i;
			}
		} else {
			for(i in arr){
				if(arr[i] == item) return i;
			}
		}
	}
	return -1;
}

function setFocus(el){
	setTimeout(function(){
		$(el).focus();
		if($(el).select) $(el).select();
	},200);
}

var getStyleProperty = (function(){
	var prefixes = ['Webkit', 'Moz', 'Khtml', 'O', 'Ms'];

	function getStyleProperty(propName, element) {
		element = element || document.documentElement;
		var style = element.style, prefixed;

		if(!style) return null;

		// test standard property first
		if (typeof style[propName] == 'string') return propName;

		// capitalize
		propName = propName.charAt(0).toUpperCase() + propName.slice(1);

		// test vendor specific properties
		for (var i=0, l=prefixes.length; i<l; i++) {
			prefixed = prefixes[i] + propName;
			if (typeof style[prefixed] == 'string') return prefixed;
		}
		return null;
	}
	return getStyleProperty;
})();

function merge(obj1,obj2){
	var obj3 = {};
	for (var attrname in obj1) { obj3[attrname] = obj1[attrname]; }
	for (var attrname in obj2) { obj3[attrname] = obj2[attrname]; }
	return obj3;
};

function Storage(obj){
	if(typeof globalStorage[obj.uuid] == 'undefined'){
		globalStorage[obj.uuid] = {};
	}
	var attributes = globalStorage[obj.uuid];

	this.get = function(name){
		if(typeof attributes[name] != 'undefined'){
			return attributes[name];
		}
		return null;
	};
	this.set = function(name,value){
		attributes[name] = value;
		return this;
	};
	this.remove = function(value){
		if(typeof attributes[name] != 'undefined'){
			delete attributes[name];
		}
		return this;
	};
}

function $$(selectors){
	var arr = [];
	if(typeof selectors == 'string'){
		var els = document.querySelectorAll(selectors);
		for(var i=0, len=els.length; i < len; i++){
			if(els[i] && els[i].tagName && els[i].tagName.length > 0)
				arr.push($(els[i]));
		}
	} else if (typeof selectors == 'object'){
		arr = selectors;
	}

	if(arr && typeof arr.length == 'number'){
		arr.each = function(func){
			for(var i=0, len=arr.length; i<len; i++){
				if(arr[i] && arr[i].tagName && arr[i].tagName.length > 0)
					func(arr[i],i);
			};
			return this;
		};

		arr.set = function(prop,val){
			this.each(function(el){
				el.set(prop,val);
			});
			return this;
		};
		arr.unset = function(prop,val){
			this.each(function(el){
				el.unset(prop,val);
			});
			return this;
		};
		arr.setStyle = function(name,value){
			this.each(function(el){
				el.setStyle(name,value);
			});
			return this;
		};
		arr.setStyles = function(styles){
			this.each(function(el){
				el.setStyles(styles);
			});
			return this;
		};
		arr.addEvent = function(ev,cb){
			this.each(function(el){
				el.addEvent(ev,cb);
			});
			return this;
		};
		arr.addEvents = function(evs){
			this.each(function(el){
				el.addEvents(evs);
			});
			return this;
		};
		arr.addClass = function(cls){
			this.each(function(el){
				el.addClass(cls);
			});
			return this;
		};
		arr.removeClass = function(cls){
			this.each(function(el){
				el.removeClass(cls);
			});
			return this;
		};
	}

	return arr;
};

function $(obj){
	var el = null;

	if(obj && obj.isObject) return obj;

	if(typeof(obj)=='string')
		el = document.getElementById(obj);
	else if(typeof(obj)=='object')
		el = obj;

	if(el){
		el.storage = null;
		el.isObject = true;
		el.events = {};
		el.setStyle = function(name,value){
			name = name.replace(/(-\w)/g, function($1){return $1.substr(1,1).toUpperCase();});
			name = getStyleProperty(name,this);
			if(!name) return this;
			if(!isNaN(value) && name != 'opacity' && name != 'zIndex')
				value += 'px';
			this.style[name] = value;
			return this;
		};
		el.getStyle = function(name){
			name = name.replace(/(-\w)/g, function($1){return $1.substr(1,1).toUpperCase();});
			name = getStyleProperty(name,this);
			if(!name) return null;
			if (this.currentStyle)
				var y = this.currentStyle[name];
			else if (window.getComputedStyle)
				var y = document.defaultView.getComputedStyle(this,null)[name];
			return y;
		};
		el.setStyles = function(styles){
			for(var j in styles){
				this.setStyle(j,styles[j]);
			}
			return this;
		};
		el.get = function(prop){
			if(prop == 'html'){
				var ret = this.innerHTML;
			} else if(prop == 'text'){
				var ret = this.innerHTML.replace(/<\/?(?!\!)[^>]*>/gi, '');
			} else if(prop == 'tag'){
				var ret = this.tagName;
			} else if(prop == 'value'){
				var ret = this.value;
			} else if(prop == 'disabled'){
				var ret = (this.disabled?true:false);
			} else if(prop == 'checked'){
				var ret = (this.checked?true:false);
			} else if(prop == 'selected'){
				var ret = (this.selected?true:false);
			} else if(typeof this.getAttribute == 'function') {
				var ret = this.getAttribute(prop);
			}
			if(!ret)
				ret = this[prop];
			return ret;
		};
		el.set = function(property,val){
			var ops = {};
			if(typeof(property)=='string'){
				ops[property] = val;
			} else {
				ops = property;
			}
			if(typeof(ops)=='object'){
				for(var prop in ops){
					if(prop=='styles'){
						this.setStyles(ops[prop]);
					} else if(prop=='events') {
						this.addEvents(ops[prop]);
					} else {
						if(prop == 'html'){
							this.innerHTML = '';
							this.innerHTML = ops[prop];
						} else if(prop == 'text'){
							this.innerHTML = '';
							this.innerHTML = (ops[prop]+'').replace(/<\/?(?!\!)[^>]*>/gi, '');
						} else if(prop == 'value'){
							this.value = ops[prop];
						} else if(prop == 'disabled' || prop == 'checked' || prop == 'selected'){
							this[prop] = ops[prop];
							if(ops[prop] && typeof this.setAttribute == 'function'){
								this.setAttribute(prop,ops[prop]);
							} else if(typeof this.removeAttribute == 'function'){
								this.removeAttribute(prop);
							}
						} else if(typeof this.setAttribute == 'function') {
							this.setAttribute(prop,ops[prop]);
						}
					}
				}
			}
			return this;
		};
		el.unset = function(prop){
			if(prop == 'html' || prop == 'text'){
				this.innerHTML = '';
			} else {
				this.removeAttribute(prop);
			}
			return this;
		};
		el.setData = function(name,value){
			this.set('data-'+name,value);
			return this;
		};
		el.getData = function(name){
			return this.get('data-'+name);
		};
		el.matchesSelector = function(selector){
			if(this.webkitMatchesSelector){
				return this.webkitMatchesSelector(selector);
			} else if(this.mozMatchesSelector) {
				return this.mozMatchesSelector(selector);
			}
			return true;
		};
		el.getParent = function(selector){
			if(!selector && this.parentNode){
				return $(this.parentNode);
			} else if(this.parentNode) {
				parent = $(this.parentNode);
				while(parent){
					if(parent.matchesSelector(selector))
						break;
					parent = $(parent.parentNode);
				}
				if(parent != document)
					return parent;
			}
			return false;
		};
		el.addEvent = function(name,cb_func){
			if(name == 'domready' && this == $(document)){
				name = 'DOMContentLoaded';
			}
			if(!this.events[name]) this.events[name] = [];
			this.events[name].push(cb_func);
			if(this.addEventListener){
				this.addEventListener(name,cb_func,false);
				return this;
			}
			return this;
		};
		el.addEvents = function(events){
			for(var j in events){
				this.addEvent(j,events[j]);
			}
			return this;
		};
		el.removeEvent = function(name,cb_ref){
			if(name == 'domready' && this == $(document)){
				name = 'DOMContentLoaded';
			}
			if(!cb_ref && this.events[name] && this.events[name].length > 0) cb_ref = this.events[name].pop();
			if(this.removeEventListener){
				this.removeEventListener(name,cb_ref,false);
				delete this.events[name][cb_ref];
				return this;
			}
			return this;
		};
		el.fireEvent = function(ev){
			if (document.createEvent) {
				var evt = document.createEvent('Event');
				evt.initEvent( ev, false, false);
				this.dispatchEvent(evt);
			} else if (document.createEventObject) {
				this.fireEvent('on' + evttype);
			}
		};
		el.inject = function(el,pos){
			var nextpos = null;
			if(pos){
				var childs = $(el).getElements();
				if(pos == 'first' || pos == 1){
					nextpos = 0;
				} else if(pos == 'last' || pos == -1){
					pos = 0;
				} else if(!isNaN(pos)){ // Position is numeric
					pos = pos.toInt();
					var nextpos = 0;
					if(pos > 0){
						nextpos = pos - 1;
					} else if(pos < -1){
						nextpos = childs.length + pos + 1;
					}
				}
				if(nextpos < 0) nextpos = 0;
				if(nextpos >= childs.length) pos = 0;
			}
			if(!pos || pos === 0){
				$(el).appendChild(this);
			} else if(nextpos !== null){
				$(el).insertBefore(this,childs[nextpos]);
			}
			return this;
		};
		el.injectBefore = function(el){
			var parent = el.parentNode;
			parent.insertBefore(this,el);
			return this;
		};
		el.adopt = function(el){
			this.appendChild(el);
			return this;
		};
		el.hasClass = function(cls) {
			if(!this.get('class')) return false;
			return this.get('class').match(new RegExp('(\\s|^)'+cls+'(\\s|$)'));
		};
		el.addClass = function(cls) {
			if(this.get('class') && !this.hasClass(cls)){
				cls = this.get('class') + " " + cls;
			} else if(this.get('class')) {
				cls = this.get('class');
			}
			this.set('class', cls.replace(/\s+/,' ').trim());
			return this;
		};
		el.removeClass = function(cls) {
			if (this.hasClass(cls)) {
				var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
				this.set('class', this.get('class').replace(reg,' ').replace(/\s+/,' ').trim());
			}
			return this;
		};
		el.getElements = function(selectors){
			if(selectors)
				var els = this.querySelectorAll(selectors);
			else
				var els = this.childNodes;
			var arr = [];
			for(var i=0, len=els.length; i<len; i++){
				if(els[i] && els[i].tagName && els[i].tagName.length > 0)
					arr.push($(els[i]));
			}
			return $$(arr);
		};
		el.getFirst = function(selectors){
			var tmp;
			if(selectors){
				tmp = $(this.querySelector(selectors));
			} else {
				tmp = $(this.childNodes[0]);
			}
			if(tmp && tmp.tagName && tmp.tagName.length > 0)
				return tmp;
			else
				return null;
		};
		el.getLast = function(selectors){
			var els;
			if(selectors){
				els = this.getElements(selectors);
			} else {
				els = this.childNodes;
			}
			var tmp = $(els[els.length-1]);
			if(tmp && tmp.tagName && tmp.tagName.length > 0)
				return tmp;
			else
				return null;
		};
		el.getPosition = function(absolute){
			var obj = this;
			if(obj == window){
				return {
					'width':window.innerWidth,
					'height': window.innerHeight,
					'totalWidth': window.outerWidth,
					'totalHeight': window.outerHeight
				}
			}
			var totalWidth = obj.clientWidth + obj.getStyle('margin-left').toInt() + obj.getStyle('margin-right').toInt() + obj.getStyle('border-left-width').toInt() + obj.getStyle('border-right-width').toInt();
			var totalHeight = obj.clientHeight + obj.getStyle('margin-top').toInt() + obj.getStyle('margin-bottom').toInt() + obj.getStyle('border-top-width').toInt() + obj.getStyle('border-bottom-width').toInt();
			if(!absolute){
				return {
					'left': obj.offsetLeft,
					'top': obj.offsetTop,
					'width': obj.clientWidth,
					'height': obj.clientHeight,
					'totalWidth': totalWidth,
					'totalHeight': totalHeight,
					'scrollTop': this.scrollTop,
					'scrollLeft': this.scrollLeft
				};
			} else {
				var curleft=0, curtop=0;
				if (obj.offsetParent) {
					do {
							curleft += obj.offsetLeft;
							curtop += obj.offsetTop;
					} while (obj = obj.offsetParent);
				}
				return {
					'left':curleft,
					'top':curtop,
					'width': this.clientWidth,
					'height': this.clientHeight,
					'totalWidth': totalWidth,
					'totalHeight': totalHeight,
					'scrollTop': this.scrollTop,
					'scrollLeft': this.scrollLeft
				};
			}
		};
		el.measure = function(){
			var prevDisplay = el.getStyle('display');
			var prevMarginL = el.getStyle('margin-left');
			var prevMarginR = el.getStyle('margin-right');
			if(prevMarginL.toInt() == 0 && el.offsetLeft != 0){
				prevMarginL = 'auto';
			}
			if(prevMarginR.toInt() == 0 && el.offsetRight != 0){
				prevMarginR = 'auto';
			}
			el.setStyles({
				'margin-left':'-9999px',
				'margin-right':'auto',
				'display':'block'
			});
			var pos = el.getPosition();
			el.setStyles({
				'margin-left': prevMarginL,
				'margin-right': prevMarginR,
				'display':prevDisplay
			});
			return pos;
		}
		el.destroy = function(){
			this.getParent().removeChild(this);
		};
		el.empty = function(){
			while(this.firstChild)
				this.removeChild(this.firstChild);
			return this;
		};
		el.clone = function(){
			return $(this.cloneNode(true));
		};

		el.store = function(name,value){
			if(this.storage == null){
				this.storage = new Storage(this);
			}
			this.storage.set(name,value);
			return this;
		};

		el.retrieve = function(name){
			if(this.storage == null){
				this.storage = new Storage(this);
			}
			var ret = this.storage.get(name);
			return ret;
		};

		el.eliminate = function(name){
			if(this.storage == null){
				this.storage = new Storage(this);
			}
			this.storage.remove(name);
			return this;
		};

		el.startWaiting = function(){
			if(!this.overlay){
				this.prevPosition = el.getStyle('position');
				el.style.position = 'relative';
				var ovl = new Element('div');
				ovl.setStyles({
					'position':'absolute',
					'top':0,
					'bottom':0,
					'left':0,
					'right':0,
					'background':'#000 url(img/wait2.gif) center center no-repeat',
					'opacity':'0.5',
					'border-top-left-radius':el.getStyle('border-top-left-radius'),
					'border-bottom-left-radius':el.getStyle('border-bottom-left-radius'),
					'border-top-right-radius':el.getStyle('border-top-right-radius'),
					'border-bottom-right-radius':el.getStyle('border-bottom-right-radius')

				}).inject(this);
				this.overlay = ovl;
			}
			return this;
		};

		el.stopWaiting = function(){
			if(this.overlay && this.overlay.tagName){
				this.removeChild(this.overlay);
			}
			if(this.prevPosition){
				el.style.position = this.prevPosition;
			}
			this.overlay=null;
			this.prevPosition = null;
			return this;
		};

		if(el.options){
			el.getSelected = function(){
				if(typeof el.selectedIndex == 'number')
					return $(el.options[el.selectedIndex]);
				return null;
			};

			el.setSelected = function(val,attr){
				for(var k=0,len=el.options.length; k<len; k++){
					if(attr && $(el.options[k]).get(attr)==val){
						el.options[k].selected = true;
					} else {
						if( (el.options[k].value && el.options[k].value==val) || (el.options[k].innerHTML == val) ){
							el.options[k].selected = true;
						} else {
							el.options[k].selected = false;
						}
					}
				}
				return el;
			};
		}

		if(!el.getData('uuid')){
			el.setData('uuid',createUUID());
		}
		el.uuid = el.getData('uuid');

		return el;
	}
	return null;
};

function Element(tag,options){
	this.constructor = function(tagName,ops){
		var el = null;
		if(tagName=='text') {
			el = $(document.createTextNode(ops));
		} else {
			el = $(document.createElement(tagName)).set(ops);
		}
		return el;
	};

	return this.constructor(tag,options);
};

/*
 * Uso: Request({
 *      method: 'post',
 *      data: 'var=val&var2=val2',
 *      url: 'page.php',
 *      onRequest: function(){},
 *      onSuccess: function(response){},
 *      onError: function(){}
 * });
 */
function Request(options){
	var xhr;
	var self = this;
	var defaults = {
		autosend: true,
		method: 'get',
		data: null,
		url: '',
		async: true,
		onRequest: null,
		onSuccess: null,
		onError: null,
		timeout: null
	};

	if(options.url.trim().length == 0 || options.method.trim().length == 0) return false;

	self.options = merge(defaults,options);
	self.xhrObject = null;

	var init = function(){
		// Genero el objeto XMLHttpRequest
		try {
			xhr = new ActiveXObject('Msxml2.XMLHTTP');
		} catch (e) {
			try {
				xhr = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (e2) {
				try {
					xhr = new XMLHttpRequest();
				} catch (e3){
					xhr = false;
				}
			}
		}

		if(self.options.onRequest) options.onRequest();

		var method = self.options.method.toUpperCase();
		var params;
		if(typeof(self.options.data)=='string'){
			params = self.options.data;
		} else if(typeof(self.options.data)=='object'){
			var tmp = [];
			for(i in self.options.data){
				tmp.push(encodeURIComponent(i)+'='+encodeURIComponent(options.data[i]));
			}
			params = tmp.join('&');
			tmp = null;
		}

		if(method=="POST"){
			xhr.open('POST', self.options.url, self.options.async);
			xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			//xhr.setRequestHeader("Content-length", params.length);
			//xhr.setRequestHeader("Connection", "close");
			send_params = params;
		} else {
			send_params = null;
			xhr.open('GET', self.options.url+'?'+params, self.options.async);
		}

		xhr.onreadystatechange  = function() {
			if(xhr.readyState  == 4) {
				if(xhr.status  == 200){
					if(options.onSuccess) options.onSuccess(xhr.responseText);
				} else {
					if(options.onError) options.onError(xhr.status,xhr.responseText);
				}
			}
		};

		self.xhrObject = xhr;

		if(options.timeout){
			self.xhrObject.timeout = options.timeout;
		}

		if(self.options.autosend){
			self.send();
		}

		return self;
	}

	self.send = function(){
		self.xhrObject.send(send_params);
		return self;
	}

	init();
	return true;
};
