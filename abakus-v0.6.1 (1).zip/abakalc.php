<?php
	include 'inc/config.php';

	require 'inc/smarty.php';

	$smarty->assign('new_window',true);
	$smarty->display('abakalc_newwindow.tpl');
?>