<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = 'recurrent';
	// We load the module
	$module = loadModule($module_name,$db);
	$thispage = 'recurrent.php';

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$fields = $module->getFields();
	//$product = $module->getElement($_GET['id']);
	$product = $db->fetch_item("
		SELECT p.*,c.symbol
		FROM products AS p
		JOIN currency AS c
			ON c.id=p.id_currency
		WHERE p.id=".(int)$_GET['id']
	);
	$product_id = $product['id'];

	$return = 'search';
	if($_GET['return']) $return = $_GET['return'];

	if($_POST['save'] && $product){
		$location_id = (int)$_POST['location'];
		$qty = (int)$_POST['quantity'];
		if(preg_match("/(\d+)\/(\d+)\/(\d+)/",$_POST['date'],$m)){
			$date = "{$m[3]}-{$m[2]}-{$m[1]}";
		} else {
			$error = __("##NG_DATE_ERROR##");
		}
		$order_number = $db->escape_string($_POST['order_number']);
		$cost = float($_POST['cost']);

		$db->insert("
			INSERT INTO products_stock SET
				id_product=$product_id,
				id_location=$location_id,
				quantity='$qty',
				order_number='$order_number',
				cost='$cost',
				`date`='$date'
		");

		if($product_id) {
			if($_POST['next']=='new'){
				$redirect_url = "stock.php?id=$product_id&return=$return";
			} else {
				if($return=='item'){
					$redirect_url = "products.php?id=$product_id";
				} elseif($return == 'articles') {
					$redirect_url = return_to_module('products');
				} else {
					$redirect_url = return_to_module($module_name);
				}
			}
			redirect($redirect_url);
		}
	}

	$locations = $db->fetch_all("SELECT * FROM locations ORDER BY name");
	$stock = $module->db->fetch_all("
		SELECT l.name AS location, SUM(ps.quantity) AS quantity,cur.symbol
		FROM locations AS l
		JOIN products_stock AS ps
			ON ps.id_location=l.id
		JOIN products AS p
			ON p.id=ps.id_product
		JOIN currency AS cur
			ON cur.id=p.id_currency
		WHERE ps.id_product=$product_id
		GROUP BY l.id
	");

	if($return=='item'){
		$redirect_url = 'products.php?id='.$product_id;
	} else {
		$redirect_url = return_to_module_url($module_name);
	}

	$helpers = getPluginsHelpers($module);
	print_pre($helpers);
	$smarty->assign('plugins_css',$helpers['css']);
	$smarty->assign('plugins_javascript',$helpers['javascript']);

	$smarty->assign('product',$product);
	$smarty->assign('return',$return);
	$smarty->assign('locations',$locations);
	$smarty->assign('stock',$stock);
	$smarty->assign('redirect_url',$redirect_url);

	$smarty->display('recurrent.tpl');
?>
