<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'cashbox_close.php';

	$module_name = 'cashbox_closes';
	// We load the module
	//$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$last_action = $db->fetch_item("
		SELECT ca.*,u.name
		FROM cashbox_actions AS ca
		JOIN users AS u
			ON u.id=ca.id_user
		ORDER BY date_added DESC LIMIT 1
	");

	switch($last_action['type']){
		case 'R':
		case 'O':
			$message = __('##NG_CASHBOX_IS_OPEN##');
			$can_close = true;
			break;

		case 'C':
			$message = __('##NG_LAST_CASHBOX_ACTION_WAS_CASHBOX_CLOSE##');
			$message.= '<br>'.__('##NG_CASHBOX_IS_CLOSED##');
			$can_close = false;
			break;

		case 'X':
			$message = __('##NG_LAST_CASHBOX_ACTION_WAS_X_CLOSE##');
			$message.= '<br>'.__('##NG_CASHBOX_IS_OPEN##');
			$can_close = true;
			break;

		case 'Z':
			$message = __('##NG_LAST_CASHBOX_ACTION_WAS_Z_CLOSE##');
			$message.= '<br>'.__('##NG_CASHBOX_IS_OPEN##');
			$can_close = true;
			break;
	}

	$smarty->assign('last_action',$last_action);
	$smarty->assign('can_close',$can_close);
	$smarty->assign('message',$message);
	$smarty->display('cashbox_close.tpl');
?>
