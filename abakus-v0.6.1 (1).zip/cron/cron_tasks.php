<?php
	//CRON Handler
	chdir(dirname(__FILE__));
	$nologin = true;

	include '../inc/config.php';

	include 'recurrent.php';

