var addNewAnnotationForm=null;

function cancel(){
	if(confirmBox(html_entity_decode('##NG_CANCEL_CONFIRMATION##'))){
		location.href=redirect_url;
	}
}

function cleanFormErrors(){
	$$('.hasError').removeClass('hasError');
	$$('.error_indicator').each(function(el){
		el.destroy();
	});
}

function setErrorIndicator(err){
	cleanErrorIndicator(err);
	if(!err.isValid){
		createErrorIndicator(err);
	}
}

function cleanErrorIndicator(err){
	for(var j=0,len2=err.affected_elements.length; j<len2; j++){
		if($(err.affected_elements[j])) $(err.affected_elements[j]).removeClass('hasError');
	}
	var parent = $(err.element).getParent();
	parent.getElements('.error_indicator').each(function(el){
		el.destroy();
	});
}

function createErrorIndicator(err){
	for(var j=0,len2=err.affected_elements.length; j<len2; j++){
		if($(err.affected_elements[j])) $(err.affected_elements[j]).addClass('hasError');
	}
	var parent = $(err.element).getParent();
	if(!parent.getFirst('.error_indicator')){
		parent.adopt(
			new Element('span',{
				'rel': 'error_indicator',
				'class': 'error_indicator',
				'title': err.message
			}).adopt(new Element('img',{ 'src':'##IMG_WARNING_ICON##', 'width':16, 'height':16 }))
		);
	}
}

function checkForm(){
	cleanFormErrors();
	validator.check();
	if(validator.valid == true){
		return true;
	} else {
		for(var i=0,len=validator.errors.length; i<len; i++){
			var err = validator.errors[i];
			createErrorIndicator(err);
		}
		setFocus($(document).getFirst('.hasError'));
	}
}

function save(){
	if(checkForm()){
		$('add_fields_form').submit();
	}
}

function keyboardListener(ev){
	if(calculator && calculator.opened) return false;
	if(ev.keyCode==27){ // Esc key
		if(!search_notes.opened && !addNewAnnotationForm.opened){
			cancel();
		}
	} else if(ev.keyCode==83 && ev.ctrlKey){ //CTRL+S
		save();
		if(ev.cancelBubble) ev.cancelBubble();
		if(ev.preventDefault) ev.preventDefault();
	} else if(ev.keyCode==107 || ev.keyCode==187){ // +
		if(!addNewAnnotationForm.opened){
			addNewAnnotationForm.open();
		}
		if(ev.cancelBubble) ev.cancelBubble();
		if(ev.preventDefault) ev.preventDefault();
	}
}

function addNewAnnotation(){
	var uid = ($("new_annotation_user_id")?$("new_annotation_user_id").get('value'):0);
	var username;
	if($("new_annotation_user_id").get('tag') == 'SELECT'){
		username = $("new_annotation_user_id").getSelected().get('text');
	} else {
		username = $("new_annotation_user_id").getData('username');
	}
	var date = $("new_annotation_date").get('value');
	var problem = $("new_annotation_problem").get('value');
	var solved = ($("new_annotation_solved").get('checked')?true:false);
	var solution = $("new_annotation_solution").get('value');
	var notes = $("new_annotation_notes").get('value');
	var cost = $("new_annotation_cost").get('value');
	var time_spent = $("new_annotation_time_spent").get('value');

	var li = $('new_annotation_template').clone().unset('id');

	li.getFirst('.annotation_user').set('text',username);
	li.getFirst('.annotation_date').set('text',date);
	li.getFirst('.annotation_problem').set('text',problem);
	li.getFirst('.annotation_solved').set('text',solved);
	li.getFirst('.annotation_solution').set('text',solution);
	li.getFirst('.annotation_notes').set('text',notes);
	li.getFirst('.annotation_cost').set('text',cost);
	li.getFirst('.annotation_time_spent').set('text',time_spent);

	new Element('input',{ 'type':'hidden', 'name':'annotations_uid[]', 'value':uid }).inject(li);
	new Element('input',{ 'type':'hidden', 'name':'annotations_date[]', 'value':date }).inject(li);
	new Element('input',{ 'type':'hidden', 'name':'annotations_problem[]', 'value':problem }).inject(li);
	new Element('input',{ 'type':'hidden', 'name':'annotations_solved[]', 'value':(solved?'1':'0') }).inject(li);
	new Element('input',{ 'type':'hidden', 'name':'annotations_solution[]', 'value':solution }).inject(li);
	new Element('input',{ 'type':'hidden', 'name':'annotations_notes[]', 'value':notes }).inject(li);
	new Element('input',{ 'type':'hidden', 'name':'annotations_cost[]', 'value':cost }).inject(li);
	new Element('input',{ 'type':'hidden', 'name':'annotations_time_spent[]', 'value':time_spent }).inject(li);

	$("new_annotation_problem").set('value','');
	$("new_annotation_solved").set('checked',false);
	$("new_annotation_solution").set('value','');
	$("new_annotation_notes").set('value','');
	$("new_annotation_cost").set('value','');
	$("new_annotation_time_spent").set('value','');

	li.inject('annotations_list').setStyle('display','block');

	li.slide = new Slide(li.getFirst('.annotation_extended_info'));

	li.getFirst('.annotation_extend_info').addEvent('click',function(){
		var parent = this.getParent();
		if(parent.slide.opened){
			parent.slide.slideOut();
		} else {
			parent.slide.slideIn();
		}
	});

	addNewAnnotationForm.close();
}

$(document).addEvent('domready',function(){
	$(window).addEvent('keydown',keyboardListener);

	if(typeof Validator != 'undefined'){
		var validator = new Validator({
			'dateFormat': date_format,
			'dateTimeFormat': datetime_format
		}).scan('add_fields_form',{
			'applyEventsToAffectedElements':true,
			'events':{
				'blur': function(){
					var err = this.validate();
					setErrorIndicator(err);
				}
			}
		});
	}

	if($('add_annotation')){
		addNewAnnotationForm = new Lightbox('new_annotation_form',{ onOpen: function(){ setFocus('new_annotation_problem'); } } );
		$('add_annotation').addEvent('click',function(){ addNewAnnotationForm.open(); });

		var search_notes = new SearchItemsBox({
			requestUrl: 'ajax/search_notes.php?json=1',
			returnField: 'id',
			returnContainer: null,
			secondaryField: null,
			secondaryFieldContainer: null,
			defaultValueContainer: null,
			fields: [ 'id','name' ],
			bindButtonEvents: [ 'search_notes_btn' ],
			onSelect: function(res){
				var text = '';
				if($('notes').value.length){
					text = $('notes').value + "\n\n";
				}
				text += res.text;
				$('notes').set('text', text);
			}
		});
	}

	$$('select,input').addEvent('keydown',function(ev){
		if(ev.keyCode == 13){
			var next = nextInput(this);
			if(next){
				setFocus(next);
				if(ev.preventDefault) ev.preventDefault();
				if(ev.preventBubble) ev.preventBubble();
			} else {
				addNewAnnotation();
			}
		}
	});

	$$('.annotation').each(function(li){
		if(li.get('id') == 'new_annotation_template') return;

		li.slide = new Slide(li.getFirst('.annotation_extended_info')).hide();

		li.getFirst('.annotation_extend_info').addEvent('click',function(){
			var parent = this.getParent('li');
			if(parent.slide.visible){
				parent.slide.slideOut();
				this.set('html','\\/');
			} else {
				parent.slide.slideIn();
				this.set('html','/\\');
			}
		});

		if(li.getFirst('.annotation_delete')){
			li.getFirst('.annotation_delete').addEvent('click',function(){
				li.destroy();
			});
		}
	});

});
