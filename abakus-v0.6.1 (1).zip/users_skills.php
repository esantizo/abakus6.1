<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';
	include 'inc/class.upload_image.php';

	$module_name = 'users_skills.php';
	$thispage = 'users_skills.php';

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$redirect_url = $thispage;

	if($_POST['save']){
		if(is_array($_POST['user_skills'])) foreach($_POST['user_skills'] as $user_id => $skills){
			if(is_array($skills)) foreach($skills as $category_id => $level){
				$user_id = (int)$user_id;
				$category_id = (int)$category_id;
				$level = (int)$level;
				$db->insert("
					INSERT INTO user_skills SET id_user=$user_id,id_category=$category_id,level=$level
					ON DUPLICATE KEY UPDATE level=$level
				");
			}
		}
		$_SESSION['save_message'] = __('##NG_CHANGES_SAVED##');
		redirect($redirect_url);
	}

	$categories = $db->fetch_all("SELECT * FROM categories ORDER BY name");

	$users = $db->fetch_all("
		SELECT u.*
		FROM users AS u
		WHERE active=1
			AND deleted=0
		ORDER BY name
	");

	if(is_array($users)) foreach($users as $k => $u){
		$users[$k]['skills'] = $db->fetch_all("SELECT id_category,level FROM user_skills WHERE id_user={$u['id']}",'level','id_category');
	}

	$smarty->assign('save_message',$_SESSION['save_message']);
	unset($_SESSION['save_message']);

	$smarty->assign('users',$users);
	$smarty->assign('categories',$categories);
	$smarty->assign('redirect_url',$redirect_url);

	$smarty->display('users_skills.tpl');
?>
