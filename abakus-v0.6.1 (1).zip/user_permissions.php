<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = "user_permissions.php";
	$module_name = 'users';
	// We load the module
	$module = loadModule($module_name,$db);

	$_GET['loaded'] = (int)$_GET['loaded'];

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$uid = (int)$_GET['uid'];
	$this_user = $db->fetch_item("SELECT * FROM users WHERE id=$uid AND deleted=0");
	if(!$this_user) die();

	$permissions = json_decode($this_user['permissions'],true);

	if($_POST['load_template']){
		$id = (int)$_POST['template_id'];
		if($id){
			$template = $db->fetch_item("SELECT * FROM user_permissions_templates WHERE id=$id LIMIT 1");
			$loaded_template = $template['name'];
			$permissions = $template['data'];
		}
		if($permissions) $db->update("UPDATE users SET permissions='$permissions' WHERE id=$uid");
		redirect("user_permissions.php?uid=$uid&loaded=$loaded_template");
	}

	if($_POST['save_template'] || $_POST['save']){
		$permissions = $_POST['permissions'];
		foreach ($menu as $r){
			$permissions[$r['id']]['read'] = ($_POST['permissions'][$r['id']]['read']?1:0);
			$permissions[$r['id']]['write'] = ($_POST['permissions'][$r['id']]['write']?1:0);
			foreach ($r['submenus'] as $r2){
				$permissions[$r2['id']]['read'] = ($_POST['permissions'][$r2['id']]['read']?1:0);
				$permissions[$r2['id']]['write'] = ($_POST['permissions'][$r2['id']]['write']?1:0);
			}
		}

		$permissions_json = json_encode($permissions);

		$db->update("UPDATE users SET permissions='$permissions_json' WHERE id=$uid");
		if($_POST['save']){
			redirect('search.php?module=users');
		} else {
			$name = $db->escape_string($_POST['template_name']);
			if(!empty($name)){
				$db->insert("
					INSERT INTO user_permissions_templates SET
						name='$name',
						data='{$permissions_json}'
					ON DUPLICATE KEY UPDATE
						data='{$permissions_json}'
				");
			}
			print $db->error();
			//redirect($thispage."?uid=$uid");
		}

	}

	$templates = $db->fetch_all("SELECT * FROM user_permissions_templates ORDER BY name");
	$t_names = array();
	foreach($templates as $t){
		$t_names[] = $t;
	}
	$templates_names = "'".implode("','",$t_names)."'";

	$smarty->assign('this_user',$this_user);
	$smarty->assign('uid',$uid);
	$smarty->assign('permissions',$permissions);
	$smarty->assign('loaded',$_GET['loaded']);
	$smarty->assign('templates',$templates);

	$smarty->display('user_permissions.tpl');
?>