<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';
	include 'inc/class.upload_image.php';

	$module_name = 'providers';
	$thispage = "providers.php";

	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();


	$item = $module->getElement($_GET['id']);
	$image = $db->fetch_item("SELECT * FROM images WHERE id={$item['id_image']}");

	$upload_image = new UploadImage($db,'entity');

	if($_POST['save']){
		$id = (int)$_POST['id'];
		if($module->validate($_POST,$errors)){
			if($id){
				$module->updateElement($id,$_POST);
			} else {
				$id = $module->insertElement($_POST);
			}
			$image_id = $upload_image->process_upload($_POST,$_FILES);
			if($upload_image->deleted) $db->delete("UPDATE providers SET id_image=0 WHERE id=$id");
			if($image_id) $db->insert("UPDATE providers SET id_image=$image_id WHERE id=$id");
			return_to_module($module_name);
		} else {
			if(is_string($errors) && !empty($errors)){
				$errors[] = $errors;
			}
		}
	}

	$contacts = $db->fetch_all("SELECT * FROM contacts WHERE relation='provider' AND id_relation=".(int)$_GET['id']);

	$fields = $module->getFields();
	$fixed_fields = $module->getFixedFieldsNames();

	$formatted_fields = array();
	if(is_array($fields) && !empty($fields)) foreach($fields as $f) if(!$module->isHiddenField($f['Field'])) {
		$tmp['field'] = $f['Field'];
		$tmp['name'] = beautifyFieldName($f['Name']);
		if(!$module->isFixedField($f['Field'])){
			$tmp['input'] =  getFieldInput($module,$f['Field'],($_POST[$f['Field']]?$_POST[$f['Field']]:$item[$f['Field']]));
		} else {
			$tmp['input'] =  $item[$f['Field']];
		}
		$formatted_fields[] = $tmp;
	}

	$return_url = return_to_module_url($module_name);

	$smarty->assign('return_url',$return_url);
	$smarty->assign('module',$module);
	$smarty->assign('errors',$errors);
	$smarty->assign('fields',$formatted_fields);
	$smarty->assign('upload_image',$upload_image);
	$smarty->assign('image',$image);
	$smarty->assign('contacts',$contacts);
	$smarty->assign('item',$item);

	$smarty->display('providers.tpl');
?>