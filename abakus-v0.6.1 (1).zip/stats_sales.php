<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = "stats_sales.php";

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	if($_REQUEST['date_from'] && $_REQUEST['date_to']){
		$start_date = date2sqldate($_REQUEST['date_from']);
		$end_date = date2sqldate($_REQUEST['date_to']);
	} else {
		$start_date = date('Y-m-d',mktime(0,0,0,1,1,date('Y')));
		$end_date = date('Y-m-d');
	}

	if($_REQUEST['id_provider']){
		$id_provider = (int)$_REQUEST['id_provider'];
		$provider = $db->fetch_item("SELECT * FROM providers WHERE id=$id_provider");
	} elseif($_REQUEST['id_category']){
		$id_category = (int)$_REQUEST['id_category'];
		$category = $db->fetch_item("SELECT * FROM categories WHERE id=$id_category");
	} elseif($_REQUEST['id_user']){
		$id_user = (int)$_REQUEST['id_user'];
		$stats_user = $db->fetch_item("SELECT * FROM users WHERE id=$id_user");
	} elseif($_REQUEST['id_product']){
		$id_product = (int)$_REQUEST['id_product'];
		$product = $db->fetch_item("SELECT * FROM products WHERE id=$id_product");
	}

	$link_url = $thispage.'?';
	if($_REQUEST['date_from'] && $_REQUEST['date_to']){
		$link_url .= 'date_from='.urlencode($_REQUEST['date_from']).'&amp;date_to='.urlencode($_REQUEST['date_to']).'&amp;';
	}

	if($category){

		$sql = "
			SELECT p.*,SUM(ii.quantity) AS quantity, AVG(ii.total) AS price, AVG(ii.total-p.cost*ii.quantity) AS average_gain, SUM(ii.total-p.cost*ii.quantity) AS gain, pr.name AS provider, '{$category['name']}' AS category
			FROM products AS p
			JOIN invoice_items AS ii
				ON ii.id_product=p.id
			JOIN invoices AS i
				ON i.id=ii.id_invoice
			LEFT JOIN providers AS pr
				ON pr.id=p.id_provider
			WHERE p.id > 0
				AND i.`date` >= '$start_date'
				AND i.`date` <= '$end_date'
				AND p.id_category={$category['id']}
			GROUP BY p.id
			ORDER BY name
		";

	} elseif($provider){

		$sql = "
			SELECT p.*,SUM(ii.quantity) AS quantity, AVG(ii.total) AS price, AVG(ii.total-p.cost*ii.quantity) AS average_gain, SUM(ii.total-p.cost*ii.quantity) AS gain, pr.name AS provider, cat.name AS category
			FROM products AS p
			JOIN invoice_items AS ii
				ON ii.id_product=p.id
			JOIN invoices AS i
				ON i.id=ii.id_invoice
			LEFT JOIN categories AS cat
				ON cat.id=p.id_category
			WHERE p.id > 0
				AND i.`date` >= '$start_date'
				AND i.`date` <= '$end_date'
				AND p.id_provider={$provider['id']}
			GROUP BY p.id
			ORDER BY name
		";

	} elseif($stats_user){

		$sql = "
			SELECT p.*,SUM(ii.quantity) AS quantity, AVG(ii.total) AS price, AVG(ii.total-p.cost*ii.quantity) AS average_gain, SUM(ii.total-p.cost*ii.quantity) AS gain, pr.name AS provider, cat.name AS category
			FROM products AS p
			JOIN invoice_items AS ii
				ON ii.id_product=p.id
			JOIN invoices AS i
				ON i.id=ii.id_invoice
			LEFT JOIN categories AS cat
				ON cat.id=p.id_category
			LEFT JOIN providers AS pr
				ON pr.id=p.id_provider
			WHERE p.id > 0
				AND i.`date` >= '$start_date'
				AND i.`date` <= '$end_date'
				AND i.salesman={$stats_user['id']}
			GROUP BY p.id
			ORDER BY name
		";

	} elseif($product){
		$return_url = urlencode($thispage."?".$_SERVER['QUERY_STRING']);

		$sql = "
			SELECT p.*, i.`date`, i.id AS invoice_id, i.number AS invoice_number, u.name AS salesman, ii.quantity, ii.total AS price, (ii.total-p.cost*ii.quantity) AS gain, pr.name AS provider, cat.name AS category
			FROM products AS p
			JOIN invoice_items AS ii
				ON ii.id_product=p.id
			JOIN invoices AS i
				ON i.id=ii.id_invoice
			LEFT JOIN providers AS pr
				ON pr.id=p.id_provider
			LEFT JOIN categories AS cat
				ON cat.id=p.id_category
			LEFT JOIN users AS u
				ON u.id = i.salesman
			WHERE p.id = {$product['id']}
				AND i.`date` >= '$start_date'
				AND i.`date` <= '$end_date'
			ORDER BY i.`date`, i.number
		";

	} else {

		$sql = "
			SELECT p.*,SUM(ii.quantity) AS quantity, AVG(ii.total) AS price, AVG(ii.total-p.cost*ii.quantity) AS average_gain, SUM(ii.total-p.cost*ii.quantity) AS gain, pr.name AS provider, cat.name AS category
			FROM products AS p
			JOIN invoice_items AS ii
				ON ii.id_product=p.id
			JOIN invoices AS i
				ON i.id=ii.id_invoice
			LEFT JOIN categories AS cat
				ON cat.id=p.id_category
			LEFT JOIN providers AS pr
				ON pr.id=p.id_provider
			WHERE p.id > 0
				AND i.`date` >= '$start_date'
				AND i.`date` <= '$end_date'
			GROUP BY p.id
			ORDER BY name
		";

	}

	if($user_preferences['paging_style']=='fixed'){
		$pager = new ImagePager($sql, $_GET['page'], $user_preferences['pager_max_per_page'], $link_template);
		// We generate the search result by executing the query;
		$results = $db->fetch_all($pager->result());
	} else {
		$results = $db->fetch_all($sql);
	}

	if(isset($_REQUEST['ajax'])){
		echo json_encode(utf8_encode_all($results));
	} else {
		$smarty->assign('stats_user',$stats_user);
		$smarty->assign('provider',$provider);
		$smarty->assign('product',$product);
		$smarty->assign('results',$results);
		$smarty->assign('pager',$pager);
		$smarty->assign('paging_style',$user_preferences['paging_style']);
		$smarty->assign('start_date',$start_date);
		$smarty->assign('end_date',$end_date);
		$smarty->assign('return_url',$return_url);
		$smarty->assign('link_url',$link_url);

		$smarty->display('stats_sales.tpl');
	}
?>
