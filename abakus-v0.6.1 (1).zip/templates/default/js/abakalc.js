function add_num(num){
	if(parseInt($('abakalc_display').value)==0){
		$('abakalc_display').value=num;
	}else{
		$('abakalc_display').value+=num;
	}
	$('abakalc_display').value = sanity_check($('abakalc_display').value);
}
function wipe_display(){
	$('abakalc_display').value='0';
}
function do_calc(){
	calculation=sanity_check($('abakalc_display').value);
	calculation=calculation.replace(/x/g,"*");
	if(calculation.match("\%")){
		foo=calculation.split('*');
		left=eval(foo[0]);
		right=foo[1].split('%');
		result=(left/100)*right[0];
	}else{
		result=eval(calculation);
	}
	if(result!='undefined'){
		$('abakalc_display').value=result;
	}
}
function sanity_check(mystring){
	mystring=mystring.toLowerCase();
	mystring=mystring.replace(/[\*]/g,"x");
	mystring=mystring.replace(/[\,]/g,".");
	mystring=mystring.replace(/([\+-\/x\*\%])([\+-\/x\*\%])/g,"$2");
	return (mystring.replace(/[^0-9\+-\/x\*\%]/g,""));
}