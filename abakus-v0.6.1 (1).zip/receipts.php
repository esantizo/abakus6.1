<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = 'receipts';
	// We load the module
	$module = loadModule($module_name,$db);
	$thispage = 'receipts.php';

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$receipt_id = (int)$_REQUEST['id'];
	$id_invoice = (int)$_GET['id_invoice'];

	if($receipt_id) {
		$receipt = $db->fetch_item("SELECT * FROM receipts WHERE id=$receipt_id");
		if($receipt){
			$id_client = (int)$receipt['id_client'];
			$checks = $db->fetch_all("SELECT c.* FROM receipt_checks AS rc JOIN checks AS c ON c.id=rc.id_check WHERE rc.id_receipt={$receipt['id']}");
			$invoices = $db->fetch_all("SELECT i.* FROM receipt_invoices AS ri JOIN invoices AS i ON i.id=ri.id_invoice WHERE ri.id_receipt={$receipt['id']}");
		}
	} else {
		$id_client = (int)$_REQUEST['id_client'];
	}

	if($id_client){
		$client = $db->fetch_item("SELECT * FROM clients WHERE id=$id_client");
	}

	$return = 'search';
	if($_GET['return']) $return = $_GET['return'];

	$currencies = $db->fetch_all("SELECT * FROM currency ORDER BY id",false,'id');
	$currencies_rates = stringifyCurrencies($currencies);

	if($client['credit_limit_currency'] > 0){
		$symbol = $currencies[$client['credit_limit_currency']]['symbol'];
		$currency = (int)$currencies[$client['credit_limit_currency']]['id'];
	} else {
		$currencies_values = array_values($currencies);
		$symbol = $currencies_values[0]['symbol'];
		$currency = (int)$currencies_values[0]['id'];
	}

	if($client){
		switch($_GET['return']){
			case 'account': $return_url = "account.php?id_client={$client['id']}"; break;
			case 'invoice': $return_url = "invoice_details.php?id=".(int)$_GET['id_invoice']; break;
			default: $return_url = return_to_module_url($module_name);
		}
	}

	if($_POST['save'] && $client){
		$id_client = $client['id'];
		$id_salesman = $user->getId();
		$receipt_currency = $currency;
		$number = $_POST['receipt_number'];
		$cash_currency = (int)$_POST['cash_currency'];
		$cash = float($_POST['cash']);
		$check_qty = count($_POST['checks_amount']);
		$total = float($_POST['total_payments']);
		$total_invoices = float($_POST['total_invoices']);
		$credit = float($_POST['credit']);

		if($_POST['use_current_balance_in_favor']){
			$current_balance_in_favor = float($_POST['current_balance_in_favor']);
			$total = $total - $current_balance_in_favor;
		} else {
			$current_balance_in_favor = 0;
		}
		$used_available = float($_POST['use_available']);

		/* I build the invoices array, with updated information (payed, amount_payed) to later update the db */
		$invoices = array();
		if(is_array($_POST['invoices_amounts'])) foreach($_POST['invoices_amounts'] as $key => $amount){
			$id_i = (int)$_POST['invoices'][$key];
			$inv = $db->fetch_item("SELECT * FROM invoices WHERE id={$id_i}");
			if($inv && $amount > 0){
				$inv['amount'] = $amount;
				$inv_currencies = parseCurrencies($inv['currencies']);
				$inv['currencies_arr'] = $inv_currencies;

				if($currency != $inv['id_currency']){
					$inv_amount = round($amount * $inv_currencies[$currency] / $inv_currencies[$inv['id_currency']],4);
				} else {
					$inv_amount = $amount;
				}
				$inv['amount_payed_now'] = $inv_amount;
				if($inv['total']<$inv['amount_payed_now']){
					$inv['amount_payed_now'] = $inv['total'];
				}
				$inv['new_amount_payed'] = $inv['amount_payed'] + $inv_amount;
				if($inv['total']<$inv['new_amount_payed']){
					$inv['new_amount_payed'] = $inv['total'];
				}
				$inv['new_payed'] = ($inv['total']==$inv['new_amount_payed']?1:0);

				$invoices[$id_i] = $inv;
			}
		}

		/* If we are including previous receipts, we first do it and we leave the rest for the new payments */
		if($used_available > 0){
			if($total_invoices < $used_available){
				$used_available = $total_invoices;
				$total = 0;
			} else {
				$total_invoices -= $used_available;
			}
			$old_receipts = $db->fetch_all("SELECT * FROM receipts WHERE id_client=$id_client AND credit > 0 ORDER BY `date`,id");
			foreach($invoices as $i => $inv){
				$amount_to_pay = $inv['amount_payed_now'];
				foreach($old_receipts as $j => $rec){
					if($rec['id_currency'] != $inv['id_currency']){
						$rec_credit = round($rec['credit'] * $inv['currencies_arr'][$rec['receipt_currency']] / $inv['currencies_arr'][$inv['id_currency']],4);
					} else {
						$rec_credit = $rec['credit'];
					}
					if($rec_credit == 0) next;
					if($rec_credit >= $amount_to_pay){
						if($rec['id_currency'] != $inv['id_currency']){
							$old_receipts[$j]['credit'] -= round($amount_to_pay / $inv['currencies_arr'][$rec['receipt_currency']] * $inv['currencies_arr'][$inv['id_currency']],4);
						} else {
							$old_receipts[$j]['credit'] -= $amount_to_pay;
						}
						$db->insert("INSERT INTO receipt_invoices (id_receipt,id_invoice,amount) VALUES ({$rec['id']},{$inv['id']},'$amount_to_pay')");
						$db->update("UPDATE receipts SET credit={$old_receipts[$j]['credit']},invoice_qty=invoice_qty+1 WHERE id={$rec['id']} LIMIT 1");
						$amount_payed = $inv['amount_payed'] + $amount_to_pay;
						$payed = ($amount_payed >= $inv['total']?1:0);
						$db->update("UPDATE invoices SET amount_payed={$amount_payed},payed={$payed} WHERE id={$inv['id']} LIMIT 1");
						$ignore_invoices[] = $inv['id'];
						break;
					} else {
						$amount = $rec['credit'];
						if($currency != $inv['id_currency']){
							$inv_amount = round($amount * $inv_currencies[$currency] / $inv_currencies[$inv['id_currency']],4);
						} else {
							$inv_amount = $amount;
						}
						$old_receipts[$j]['credit'] = 0;
						$db->insert("INSERT INTO receipt_invoices (id_receipt,id_invoice,amount) VALUES ({$rec['id']},{$inv['id']},'$inv_amount')");
						$db->update("UPDATE receipts SET credit={$old_receipts[$j]['credit']},invoice_qty=invoice_qty+1 WHERE id={$rec['id']} LIMIT 1");
						$db->update("UPDATE invoices SET amount_payed=amount_payed+$inv_amount,payed=0 WHERE id={$inv['id']} LIMIT 1");
						$amount_to_pay -= $amount;
						$invoices[$i]['amount_payed_now'] = $amount_to_pay;
					}
				}
			}
		}

		if($total > 0){
			$id_receipt = $db->insert("
				INSERT INTO receipts SET
					id_client=$id_client,
					salesman=$id_salesman,
					number='$number',
					balance_in_favor_used=$current_balance_in_favor,
					cash_currency=$cash_currency,
					cash='$cash',
					check_qty=0,
					invoice_qty=0,
					receipt_currency=$currency,
					total='$total',
					total_invoices='$total_invoices',
					credit='$credit',
					currencies='$currencies_rates'
			");

			if($id_receipt){

				// Process Checks
				$check_qty = 0;
				if(is_array($_POST['checks_amount'])) foreach($_POST['checks_amount'] as $key => $amount){
					$amount = float($amount);
					if($amount > 0){
						$check_qty++;
						$id_bank = (int)$_POST['checks_bank'][$key];
						$serial = $db->escape_string($_POST['checks_serial'][$key]);
						$cashing_date = date2sqldate($_POST['checks_due_date'][$key]);
						$notes = $db->escape_string($_POST['checks_notes'][$key]);
						$check_currency = (int)$_POST['checks_currency'][$key];

						$id_check = $db->insert("INSERT INTO checks SET
							id_client=$id_client,
							id_bank=$id_bank,
							serial_number='$serial',
							id_currency=$check_currency,
							value='$amount',
							cashing_date='$cashing_date',
							notes='$notes',
							currencies='$currencies_rates'
						");

						$db->insert("INSERT INTO receipt_checks (id_receipt,id_check) VALUES ($id_receipt,$id_check)");
					}
				}

/*
				$invoice_qty = 0;
				if(is_array($_POST['invoices_amounts'])) foreach($_POST['invoices_amounts'] as $key => $amount){
					$id_i = (int)$_POST['invoices'][$key];
					if($id_i && $amount > 0){
						$invoice_qty++;
						$db->insert("INSERT INTO receipt_invoices (id_receipt,id_invoice,amount) VALUES ($id_receipt,$id_i,'$amount')");
						$inv = $db->fetch_item("SELECT * FROM invoices WHERE id={$id_i}");
						if($inv){
							$inv_currencies = parseCurrencies($inv['currencies']);
							$inv_amount = round($amount * $inv_currencies[$currency] / $inv_currencies[$inv['id_currency']],4);
							$amount_payed = $inv['amount_payed'] + $inv_amount;
							if($inv['total']<$amount_payed) $amount_payed = $inv['total'];
							$payed = ($inv['total']==$amount_payed?1:0);
							$db->update("UPDATE invoices SET payed=$payed,amount_payed=$amount_payed WHERE id={$inv['id']} LIMIT 1");


						}
					}
				}
*/

				// Process remaining invoices (some may have been processed earlier, when using previous balance)
				$invoice_qty = 0;
				if(is_array($invoices)){
					foreach($invoices as $inv){
						if(!in_array($inv['id'],$ignore_invoices)){
							$invoice_qty++;
							$db->insert("INSERT INTO receipt_invoices (id_receipt,id_invoice,amount) VALUES ($id_receipt,{$inv['id']},'{$inv['amount_payed_now']}')");
							$db->update("UPDATE invoices SET payed={$inv['new_payed']},amount_payed={$inv['new_amount_payed']} WHERE id={$inv['id']} LIMIT 1");
						}
					}
				}

				// update receipt information, set check_qty and invoice_qty
				$db->update("UPDATE receipts SET check_qty=$check_qty,invoice_qty=$invoice_qty WHERE id=$id_receipt LIMIT 1");

				// Insert data in accounts table, to keep balance updated
				$curr_balance = float($db->fetch_item_field("SELECT balance FROM accounts WHERE id_client=$id_client ORDER BY date DESC,id DESC LIMIT 1"));
				$balance = $curr_balance + $total;
				$db->insert("INSERT INTO accounts SET
					id_client=$id_client,
					type='receipt',
					id_item=$id_receipt,
					date=NOW(),
					due_date=NULL,
					reference='$number',
					id_currency=$currency,
					credit='0',
					debit='$total',
					balance='$balance',
					currencies='$currencies_rates'
				");

			}
		}
		redirect($return_url);
		die();
	}

	if($client) {
		$invoices_arr = $db->fetch_all("SELECT *,IF(payed=0,(total-amount_payed),0) AS total_due FROM invoices WHERE client_id={$client['id']} AND pending=0 ORDER BY `date`,id");
		$invoices_total_payed = 0;
		if(is_array($invoices_arr)) foreach($invoices_arr as $i){
			$invoice_currencies = array();
			$i['total_due'] = ($i['payed']!=0?0:$i['total']-$i['amount_payed']);
			$i['symbol'] = $symbols[$i['id_currency']];
			if($i['id_currency']!=$currency){
				$invoice_currencies = parseCurrencies($i['currencies']);
				//print_pre($invoice_currencies);
				$multiplier = $invoice_currencies[$i['id_currency']] / $invoice_currencies[$currency];
				$i['total'] = round($i['total'] * $multiplier,4);
				$i['total_due'] = round($multiplier * $i['total_due'],4);
				$i['symbol'] = $symbols[$currency];
				$i['amount_payed'] = round($i['amount_payed'] * $multiplier,4);
			}
			$i['checked'] = ($_REQUEST['id_invoice']==$i['id']?1:0);
			$i['date'] = fecha($i['date']);
			$i['due_date'] = fecha($i['due_date']);
			$i['number'] = sprintf($config['invoice_number_format'],$i['number']);
			$invoices_total_payed += $i['amount_payed'];
			$invoices[] = $i;
		}
		unset($invoice_currencies);
		$curr_balance = float($db->fetch_item_field("SELECT balance FROM accounts WHERE id_client=$id_client ORDER BY date DESC,id DESC LIMIT 1"));

		$available_to_include = float($db->fetch_item_field("SELECT SUM(credit) FROM receipts WHERE id_client=$id_client"));
	}

	$number = (int)$db->fetch_item_field("SELECT number FROM receipts ORDER BY number DESC LIMIT 1") + 1;
	$banks = $db->fetch_all("SELECT * FROM bank_entities ORDER BY name");

	$smarty->assign('return',$return);
	$smarty->assign('return_url',$return_url);
	$smarty->assign('client',$client);
	$smarty->assign('number',$number);
	$smarty->assign('currency',$currency);
	$smarty->assign('banks',$banks);
	$smarty->assign('currencies',$currencies);
	$smarty->assign('currencies_json',json_encode($currencies));
	$smarty->assign('checks',$checks);
	$smarty->assign('symbol',$symbol);
	$smarty->assign('invoices',$invoices);
	$smarty->assign('id_invoice',$id_invoice);
	$smarty->assign('current_balance',$curr_balance);
	$smarty->assign('available_to_include',$available_to_include);
	$smarty->assign('receipt',$receipt);
	$smarty->assign('double_confirm_delete',$user_preferences['double_confirm_delete']);

	$smarty->display('receipts.tpl');
?>
