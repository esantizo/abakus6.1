var pos_locked = false;
var printer_server_url = 'ajax/printer_server.php';

function clearPosData(){
	location.href = location.href;
}

function lockClient(){
	var inputs = ['#client_data input','#client_data select','#invoice_data input','#invoice_data select'];
	disableInputs(inputs);
	$('search_item_icon').setStyle('display','none');
}

function lockPos(){
	pos_locked = true;
	var inputs = ['#pos_input'];
	disableInputs(inputs);
	$('save_btn').setStyle('display','none');
	if($('save_pending_btn')) $('save_pending_btn').setStyle('display','none');
	if($('save_and_new')) $('save_and_new').setStyle('display','none');
}

function unlockPos(){
	pos_locked = false;
	var inputs = ['#pos_input'];
	enableInputs(inputs);
	$('save_btn').setStyle('display','inline');
	if($('save_pending_btn')) $('save_pending_btn').setStyle('display','inline');
	if($('save_and_new')) $('save_and_new').setStyle('display','inline');
}

function updateInvoiceType(){
	var code = $('client_tax_condition_input').get('data-printer-code');
	if(!code){
		code = $('client_tax_condition_select').getSelected().get('data-printer-code');
	}
	if(code=='I'){
		$('invoice_type').setSelected('A','data-symbol');
	} else {
		$('invoice_type').setSelected('B','data-symbol');
	}
}

function searchClient(id){
	if(id==0) {
		setFocus('pos_input');
		return false;
	}
	searchClientData(id,function(){
		setFocus('pos_input');
		$('invoice_type').setSelected(default_invoice_type);
		updateInvoiceType();
		changeInvoiceType(discriminate_taxes);

		$('invoice_table').setStyle('display','block');
	});
}

function posInputKeydown(ev){
	if(pos_locked) return;
	var $input = $('pos_input');
	var $val = $input.value;
	if(ev.keyCode==13){
		if($input.get('data-payment')=='1'){
			if($val > 0){
				cashPayment(true);
			} else {
				$('pos_last_status').set;('text','##NG_MUST_INSERT_PAYMENT##');
			}
		} else if($val >= -99 && $val <= 99){
			$('pos_quantity').value = $val;
			$('pos_data_quantity').set('text',$val);
			$input.set('value','').focus();
		} else if( $val.match(/^\$/) ) {
			$val = $val.replace(',','.').replace(/[^0-9\.\-]/,'');
			$('pos_override_price').value = $val;
			$('pos_data_override_price').set('text', '$ '+$val);
			$input.set('value','').focus();
		} else if( $val.match(/^\%/) ) {
			$val = $val.replace(',','.').replace(/[^0-9\.\-]/,'');
			$('pos_product_discount').value = $val;
			$('pos_data_product_discount').set('text', $val+'%');
			$input.set('value','').focus();
		} else {

			if(this.value===''){
				openSearchItemBox();
			} else {
				searchItem();
			}

		}
	}
}

function addItemToList(item){
	var id_invoice_currency = $('currency').value;
	var id_currency = $('curr_input').value;
	if(!id_currency) id_currency = $('currency').value;

	var item_currency_value = $('curr_'+id_currency).value.toFloat();
	var invoice_currency_value = $('curr_'+$('currency').value).value.toFloat();

	var product_id = item.product_id;
	var reference = item.reference;
	var description = item.short_description;
	var quantity = item.quantity;
	var tax_val = item.tax;
	var unit_price = item.unit_price;
	var unit_price_taxed = item.unit_price_taxed;

	var item_edit = false;
	var item_delete = true;

	var tr = new Element('tr');
	var td = new Element('td')
		.adopt(new Element('input',{'type':'hidden','name':'curr[]','value':id_currency}))
		.adopt(new Element('input',{'type':'hidden','name':'product_id[]','value':product_id}));
	if(item_delete){
		td.adopt(new Element('a',{'href':'javascript:;','html':'<img src="##IMG_DELETE##" width="20" height="20">','events':{'click':function(){deleteItem($(this).getParent('tr'));}}}));
		if(item_edit){
			td.adopt(new Element('text',' '));
		}
	}
	if(item_edit){
		td.adopt(new Element('a',{'href':'javascript:;','html':'<img src="##IMG_EDIT##" width="20" height="20">','events':{'click':function(){editItem($(this).getParent('tr'));}}}));
	}
		td.inject(tr);
	td = new Element('td')
		.adopt(new Element('input',{'type':'hidden','name':'ref[]','value':html_entity_decode(reference)}))
		.adopt(new Element('text',reference))
		.inject(tr);
	td = new Element('td')
		.adopt(new Element('input',{'type':'hidden','name':'desc[]','value':html_entity_decode(description)}))
		.adopt(new Element('text',description))
		.inject(tr);
	td = new Element('td')
		.adopt(new Element('input',{'type':'hidden','name':'qty[]','value':quantity}));
	td.adopt(new Element('text',quantity))
		.inject(tr);

	if(discriminate_taxes){
		var unit_price = unit_price;
		var unit_price_taxed = unit_price * (1 + tax_val / 100);
	} else {
		var unit_price_taxed = unit_price_taxed;
		var unit_price = unit_price_taxed / (1 + tax_val / 100);
	}

	if(id_currency != id_invoice_currency){
		var currency_mult = item_currency_value / invoice_currency_value;
		var orig_price = unit_price / currency_mult;
	} else {
		var orig_price = unit_price;
	}

	td = new Element('td',{'class':'unit_price_cell'})
		.adopt(new Element('input',{'type':'hidden','name':'price[]','alt':orig_price,'value':unit_price}))
		.adopt(new Element('text',unit_price))
		.inject(tr);
	td = new Element('td',{'class':'tax_cell'})
		.adopt(new Element('input',{'type':'hidden','name':'tax[]','value':tax_val}))
		.adopt(new Element('text',tax_val))
		.inject(tr);

	td = new Element('td',{'class':'unit_price_taxed_cell' })
		.adopt(new Element('text',unit_price_taxed.round(4)))
		.inject(tr);
	td = new Element('td',{'class':'amount_single_cell'})
		.adopt(new Element('input',{'type':'hidden','name':'item_total[]','value':(quantity*unit_price)}))
		.adopt(new Element('text',(quantity*unit_price).round(4)))
		.inject(tr);
	td = new Element('td',{'class':'amount_taxed_cell'})
		.adopt(new Element('text',(quantity*unit_price_taxed).round(4)))
		.inject(tr);
	$('table_body').insertBefore(tr,$('insert_row'));

	updateTotals();

	$('pos_input').value = '';

	$('pos_quantity').value = 1;
	$('pos_override_price').value = '';
	$('pos_product_discount').value = '';

	$('pos_data_quantity').set('text','1');
	$('pos_data_override_price').set('text','');
	$('pos_data_product_discount').set('text','');

	unlockPos();

	changeInvoiceType(discriminate_taxes);
	setFocus('pos_input');
}

function cancelTicket(){
	$('invoice_form').startWaiting();
	lockPos();
	new Request({
		'url': printer_server_url,
		'method': 'get',
		'data': {
			'action': 'cancel'
		},
		'onSuccess': function(data){
		    cancelTicketFromDatabase();
		},
		'onError': function(){
			$('invoice_form').stopWaiting();
			$('pos_inputs').stopWaiting();
		}
	});

}

function cancelTicketFromDatabase(){
	new Request({
		url: 'ajax/pos.php',
		'method': 'post',
		'data': {
				'action': 'cancel_ticket',
				'notes': $('notes').value,
				'invoice_number': $('invoice_number').value
		},
			'onSuccess': function(data){
					$('invoice_form').stopWaiting();
					$('pos_inputs').stopWaiting();
					location.reload();
			},
		'onError': function(){
				$('invoice_form').stopWaiting();
				$('pos_inputs').stopWaiting();
		}
	});
}

function searchItem(){
	lockPos();
	var invoice_currencies = [];
	$$('.invoice_currencies').each(function(el){
		var t = el.get('data-currency');
		var v = el.value;
		invoice_currencies.push({ 'name': t, 'value': v });
	});
	Request({
		'url':'ajax/search_item.php',
		'method':'post',
		'data':'ref='+$("pos_input").value+'&psid='+$('client_price_scale_input').value+'&convert_currency='+$('currency').value+'&currencies='+JSON.stringify(invoice_currencies),
		'onSuccess':function(res){
			if(res.length > 0){
				var json = parseJSON(res);
				//var id_currency = (json.id_currency?json.id_currency:0) * 1;

				json.price = json.price.replace(',','.').toFloat();
				json.tax = json.tax.replace(',','.').toFloat();
				//var currency_mult = $('curr_'+id_currency).value.toFloat();
				//var current_mult = $('curr_'+$('currency').value).value.toFloat();
				//price = (json.price * currency_mult / current_mult);
				price = json.price_converted;

				json.unit_price = price;
				//json.unit_price_taxed = (json.price_taxed * currency_mult / current_mult);
				json.unit_price_taxed = json.price_taxed_converted;

				json.quantity = $('pos_quantity').value;
				json.reference = $('pos_input').value;

				var $override_price = $('pos_override_price').value.toFloat();
				if($override_price > 0){
					json.unit_price = $override_price * 100 / ( 100 + json.tax );
					json.unit_price_taxed = $override_price;
				}

				var $pos_product_discount = $('pos_product_discount').value.toFloat();
				if($pos_product_discount > 0){
					json.unit_price = json.unit_price * (1 - $pos_product_discount / 100);
					json.unit_price_taxed = json.unit_price_taxed * (1 - $pos_product_discount / 100);
				}

				if(json.short_description.trim().length == 0){
					json.short_description = json.reference;
				}

				document.body.focus();
				$('pos_inputs').startWaiting();
				lockPos();

				if(!ticketOpened){
					openTicket((function(json){
						return function(){
							addTicketItem(json);
						}
					})(json));
				} else {
					addTicketItem(json);
				}
			} else {
				openSearchItemBox();
			}
		}
	});
}

function searchNavigationListener(ev){
	if(calculator && calculator.opened) return false;
	if(navigateItems==true){
		$$('#items_results_table_body tr').each(function(e){e.removeClass('selected');});
		if(ev.target==$('search_item_input')){
			if(ev.keyCode==40 || ev.keyCode==38){
				$('search_item_input').blur();
			}
		}
		if(ev.keyCode==40){
			if(current == null){
				current = $('items_results_table_body').getFirst('tr');
			} else {
				current = nextItem(current,'TR');
				if(!current) current = $('items_results_table_body').getFirst('tr');
			}
		} else if(ev.keyCode==38){
			if(current == null){
				current = $('items_results_table_body').getLast('tr');
			} else {
				current = previousItem(current,'TR');
				if(!current) current = $('items_results_table_body').getLast('tr');
			}
		} else if(ev.keyCode==13) {
			if(current){
				$('pos_input').value = current.getElements('td')[0].innerHTML;
				searchLightbox.close();
				searchItem();
				navigateItems = false;
				return false;
			}
		}
		if(current){
			current.addClass('selected');
			var curPos = current.getPosition();
			if($('items_results_table')){
				var contHeight = $('search_item_response').getPosition().height;
				var maxScroll = $('items_results_table').getPosition().totalHeight - contHeight;
			}
			var scroll = curPos.top + curPos.height - contHeight / 2;
			if(scroll < 0) scroll = 0;
			if(scroll > maxScroll) scroll = maxScroll;
			if($('items_results_table')){
				$('search_item_response').scrollTop = scroll;
			}
			if(ev.preventDefault) ev.preventDefault();
			if(ev.preventBubble) ev.preventBubble();
			return false;
		}
	}
}

function addTicketToDatabase(){
	var invoice_currencies = [];
	$$('.invoice_currencies').each(function(el){
		var t = el.get('data-currency');
		var v = el.value;
		invoice_currencies.push(t+':'+v);
	});

	new Request({
		url: 'ajax/pos.php',
		'method': 'post',
		'data': {
			'action': 'new_ticket',
			'invoice_type': $('invoice_type').value,
			'invoice_number': $('invoice_number').value,
			'date': $('invoice_date').value,
			'due_date': $('invoice_date').value,
			'salesman': $('salesman').value,
			'client_id': $('client').value,
			'client_name': $('client_name_input').value,
			'client_address': $('client_address_input').value,
			'client_taxpayer_id': $('client_taxpayer_id_input').value,
			'client_postcode': $('client_postcode_input').value,
			'client_city': $('client_city_input').value,
			'client_state': $('client_state_input').value,
			'client_country': $('client_country_input').value,
			'id_tax_condition': $('client_tax_condition_select').value,
			'id_payment_type': $('client_payment_type_select').value,
			'id_price_scale': $('client_price_scale_input').value,
			'id_currency': $('currency').value,
			'currencies': invoice_currencies.join('|')
		},
		'onSuccess': function(data){
			$('new_ticket_id').value = data;
			$('invoice_form').stopWaiting();
			setFocus('pos_input');
		},
		'onError': function(){
			$('invoice_form').stopWaiting();
			$('pos_inputs').stopWaiting();
		}
	});
}
function saveItemToDatabase(json){
	new Request({
		url: 'ajax/pos.php',
		'method': 'post',
		'data': {
			'action': 'add_item',
			'product_id': json.product_id,
			'ref': json.reference,
			'desc': json.short_description,
			'qty': json.quantity,
			'price': json.unit_price,
			'tax': json.tax,
			'item_total': json.unit_price * (1 + json.tax / 100),
			'selected_stock': ''
		},
		'onSuccess': function(data){
			addItemToList(json);
			setFocus("pos_input");
			$('pos_inputs').stopWaiting();
			unlockPos();
		},
		'onError': function(){
			$('invoice_form').stopWaiting();
			$('pos_inputs').stopWaiting();
		}
	});
}
function closeTicketFromDatabase(){
	var taxes = [];
	$$('.invoice_taxes').each(function(el){
		var t = el.get('data-tax');
		var v = el.value;
		taxes.push(t+':'+v);
	});
	var discount = 0;
	new Request({
		url: 'ajax/pos.php',
		'method': 'post',
		'data': {
			'action': 'close_ticket',
			'subtotal': $('invoice_subtotal').value,
			'discount': discount,
			'taxes': taxes.join('|'),
			'total': $('invoice_total').value,
			'notes': $('notes').value,
			'invoice_number': $('invoice_number').value
		},
		'onSuccess': function(data){
			alreadyPayed = true;
			displayPaymentInfo();
			$('invoice_form').stopWaiting();
		},
		'onError': function(){
			$('invoice_form').stopWaiting();
			$('pos_inputs').stopWaiting();
		}
	});
}


function openTicket(cbFunction){
	$('invoice_form').startWaiting();
	var code = $('client_tax_condition_input').get('data-printer-code');
	if(!code){
		code = $('client_tax_condition_select').getSelected().get('data-printer-code');
	}
	var empresa = $('client_name_input').value;
	var cuit = $('client_taxpayer_id_input').value;
	var domicilio = $('client_address_input').value;
	lockPos();
	lockClient();
	new Request({
		'url': printer_server_url,
		'method': 'get',
		'data':{
			'action': 'factura',
			'data': JSON.stringify({
				"empresa": empresa,
				"cuit": cuit,
				"domicilio": domicilio,
				"inscripto": code,
				"tipo": $('invoice_type').getSelected().get('data-symbol')
			})
		},
		'onSuccess': function(data){
			ticketOpened = true;
			var $status = parseJSON(data);
			if($status && $status['errors'] && $status['errors'].contains('ACCEPTED')){
				$('invoice_number').value = $status.nro;
				addTicketToDatabase();
				if(typeof cbFunction == 'function'){
					cbFunction.call(this);
				}
			} else {
				$('invoice_form').stopWaiting();
			}
			$('pos_last_status').set('text',$status['errors'][0]);
		},
		'onError': function(){
			$('invoice_form').stopWaiting();
			$('pos_inputs').stopWaiting();
		}
	});
}

function closeTicket(){
	$('invoice_form').startWaiting();
	lockPos();
	if(!cash_payment){
		return prepareCashPayment(true);
	}
	new Request({
		'url': printer_server_url,
		'method': 'get',
		'data': {
			'action': 'fin'
		},
		'onSuccess': function(data){
			var $status = parseJSON(data);
			if($status && $status['errors'].contains('ACCEPTED')){
				if($status.nro){
					$('invoice_number').value = $status.nro;
				}
				closeTicketFromDatabase();
			} else {
				$('invoice_form').stopWaiting();
				unlockPos();
			}
			$('pos_last_status').set('text',$status['errors'][0]);
		},
		'onError': function(){
			$('invoice_form').stopWaiting();
			$('pos_inputs').stopWaiting();
		}
	});
}

function addTicketItem(json){
	new Request({
		'url': printer_server_url,
		'method': 'get',
		'data': {
			action: 'item',
			data: JSON.stringify({
				'tipo': 'b', // Lo necesita la impresora, para saber si es factura o nota de credito
				'cant': json.quantity.toFloat(),
				'precio': json.unit_price,
				'desc': json.short_description,
				'iva': json.tax
			})
		},
		'onSuccess': function(data){
			var $status = parseJSON(data);
			if($status && $status['errors'].contains('ACCEPTED')){
				saveItemToDatabase(json);
			} else {
				$('pos_inputs').stopWaiting();
				unlockPos();
			}
			$('pos_last_status').set('text',$status['errors'][0]);
		},
		'onError': function(){
			$('invoice_form').stopWaiting();
			$('pos_inputs').stopWaiting();
		}
	});
}

function cashPayment(close){
	$('invoice_form').startWaiting();
	cashAmount = $('cashLightboxPayment').value;
	cashLightbox.options.closeOnEsc = false;
	new Request({
		'url': printer_server_url,
		'method': 'get',
		'data': {
			'action': 'efectivo',
			'data': JSON.stringify({"efectivo":cashAmount})
		},
		'onSuccess': function(data){
			var $status = parseJSON(data);
			if($status && $status['errors'].contains('ACCEPTED')){
				cash_payment = true;
				if($status.vuelto){
					$('cashLightboxChange').set('text',$status.vuelto);
				}
				if(close){
					closeTicket();
				} else {
					$('invoice_form').stopWaiting();
					unlockPos();
				}
			} else {
				$('invoice_form').stopWaiting();
				unlockPos();
			}
			$('pos_last_status').set('text',$status['errors'][0]);
		},
		'onError': function(){
			$('invoice_form').stopWaiting();
			$('pos_inputs').stopWaiting();
		}
	});
}

function prepareCashPayment(){
	$('invoice_form').stopWaiting();
	$('cashLightboxTotal').set('text',$('invoice_total').value);
	cashLightbox.options.closeOnEsc = true;
	cashLightbox.open().autoHeight();
	lockPos();
	setFocus('cashLightboxPayment');
}

function displayPaymentInfo(){
	$('box_cash').stopWaiting();
	$('cancel_cash_btn').setStyle('display','none');
	$('accept_cash_btn').setStyle('display','none');
	$('new_ticket_btn').setStyle('display','inline');
	$('cashLightboxPayment_container').set('text',$('cashLightboxPayment').value);
}

function keyboardListener(ev){
	if(ev.keyCode == 112){ //F1
		ev.preventDefault();
		closeTicket();
	//~ } else if(ev.keyCode == 113) { //F2
		//~ cashPayment();
		//~ ev.preventDefault();
	}
}


function openClient(id){
	$('client').value = id;
	$('client').set('rel',id);
	searchClientData(id,function(){
		setFocus('pos_input');
		$('invoice_type').setSelected(default_invoice_type);
		updateInvoiceType();
		changeInvoiceType(discriminate_taxes);

		$('invoice_table').setStyle('display','block');
	});
}

function setClientData(data){
	$('client').set('rel',0);
	$('client_name_input').value='##NG_POS_GENERAL_CLIENT_NAME##';
	$('client_address_input').value=data.client_address;
	$('client_city_input').value=data.client_city;
	$('client_state_input').value=data.client_state;
	$('client_country_input').value=data.client_country;
	$('client_taxpayer_id_input').value=data.client_taxpayer_id;
	$('client_tax_condition_input').value='';
	$('client_payment_type_input').value='';
	$('client_price_scale_input').value = data.id_price_scale;

	$('client_name').set('text','');
	$('client_address').set('text','');
	$('client_city').set('text','');
	$('client_state').set('text','');
	$('client_country').set('text','');
	$('client_taxpayer_id').set('text','');
	$('client_tax_condition').set('text','');
	$('client_payment_type').set('text','');
	$('client_price_scale').set('text',data.price_scale_name);

	$('client_name_input').set('type','text');
	$('client_address_input').set('type','text');
	$('client_city_input').set('type','text');
	$('client_state_input').set('type','text');
	$('client_country_input').set('type','text');
	$('client_taxpayer_id_input').set('type','text');

	$('client_tax_condition_select').setStyle('display','inline');
	$('client_payment_type_select').setStyle('display','inline');

	$('client_tax_condition_input').set('name','');
	$('client_tax_condition_input').removeAttribute('data-printer-code');
	$('client_tax_condition_select').set('name','client_tax_condition');

	$('client_payment_type_input').set('name','');
	$('client_payment_type_select').set('name','client_payment_type');

	$('client_tax_condition_select').setSelected(data.id_tax_condition);
	$('client_payment_type_select').setSelected(data.id_payment_type);

	$('invoice_type').setSelected(default_invoice_type);
	updateInvoiceType();
	changeInvoiceType(discriminate_taxes);

	$('invoice_table').setStyle('display','block');
}

function setInvoiceData(invoice){
	$('currency').setSelected(invoice.id_currency);
	$('salesman').setSelected(invoice.salesman);
	$('notes').value = invoice.notes;
}
