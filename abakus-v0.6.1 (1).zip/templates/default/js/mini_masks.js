$.prototype.mask = function(mask,options){
	var self = this;
	var defaultOptions = {
	};

	this.options = merge(defaultOptions,options);

}
