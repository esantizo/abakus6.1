<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = $_GET['module'];
	// We load the module
	$module = loadModule($module_name,$db);

	$thispage = "search.php?module=".$module_name;

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	function canShowField($field, $pre, $arr){
		if(empty($arr)){
			return true;
		}
		return in_array($pre.'_'.$field,$arr);
	}

	//Save user preferences
	if(is_array($_POST['box_search_terms'])){
		$db->delete("DELETE FROM user_preferences WHERE id_user=".$user->getId()." AND module='$module_name' AND attribute LIKE 'box_search_terms_%'");
		foreach($_POST['box_search_terms'] as $i){
			$db->insert("INSERT INTO user_preferences SET id_user=".$user->getId().", module='$module_name', attribute='box_search_terms_{$i}', value='1'");
		}
		redirect($thispage);
	}

	if(is_array($_POST['box_table_fields'])){
		$db->delete("DELETE FROM user_preferences WHERE id_user=".$user->getId()." AND module='$module_name' AND attribute LIKE 'box_table_fields_%'");
		foreach($_POST['box_table_fields'] as $i){
			$db->insert("INSERT INTO user_preferences SET id_user=".$user->getId().", module='$module_name', attribute='box_table_fields_{$i}', value='1'");
		}
		redirect($thispage);
	}

	if(($_GET['return'] && is_array($_SESSION['post']) && $_SESSION['module_name']==$module_name) || $_GET['page'] > 0){
		$_POST = unserialize($_SESSION['post']);
	} elseif(is_array($_POST)) {
		$_SESSION['post'] = serialize($_POST);
		$_SESSION['module_name'] = $module_name;
	}

	$box_search_terms = $db->fetch_all("SELECT * FROM user_preferences WHERE id_user=".$user->getId()." AND module='$module_name' AND attribute LIKE 'box_search_terms_%'",'attribute');
	$box_table_fields = $db->fetch_all("SELECT * FROM user_preferences WHERE id_user=".$user->getId()." AND module='$module_name' AND attribute LIKE 'box_table_fields_%'",'attribute');

	// We get the SQL Query for the search
	$sql = $module->getSearchQuery($_POST);

	// We instantiate the pager using the query. It will return a limited query.
	$link_template = $thispage.'&amp;page=__page__';

	if($user_preferences['paging_style']=='fixed'){
		$pager = new ImagePager($sql, $_GET['page'], $user_preferences['pager_max_per_page'], $link_template);
		// We generate the search result by executing the query;
		$module->search($pager->result());
	} else {
		$module->search($sql);
	}

	// We get the results for latter use
	$results = $module->getSearchResults();

	$fields = $module->getFields();

	$search_limit=3;
	$display_limit=5;
	$search=0;
	$display=0;

	if(is_array($fields) && !empty($fields)) foreach($fields as $f) if(!$module->isHiddenField($f['Field'])){
		//$tmp = $f;
		$tmp['field'] = $f['Field'];
		$tmp['name'] = beautifyFieldName($f['Name']);
		$tmp['input'] = getFieldInput($module,$f['Field'],$_POST[$f['Field']],'search');
		if($search < $search_limit && canShowField($f['Field'],'box_search_terms',$box_search_terms)){
			$tmp['search'] = true;
			$search++;
		} else {
			$tmp['search'] = false;
		}
		if($display < $display_limit && canShowField($f['Field'],'box_table_fields',$box_table_fields)){
			$tmp['display'] = true;
			$display++;
		} else {
			$tmp['display'] = false;
		}
		$printable_fields[] = $tmp;
	}

	if(is_array($results)) foreach($results as $key => $r){
		foreach($fields as $f){
			if($f['RelField']){
				$value = $r[$f['Name']];
			} else {
				$value = $r[$f['Field']];
			}
			if(is_array($module->formats) && $module->formats[$f['Field']]){
				$value = sprintf($module->formats[$f['Field']],$value);
			}
			$results[$key][$f['Field']]=sanitize(cutText($value,117,'...'));
		}
	}

	$helpers = getPluginsHelpers($module);

	$smarty->assign('plugins_css',$helpers['css']);
	$smarty->assign('plugins_javascript',$helpers['javascript']);

	$smarty->assign('fields',$printable_fields);
	$smarty->assign('results',$results);
	$smarty->assign('pager',$pager);
	$smarty->assign('collapse',($user_preferences['search_collapse'] && !empty($_POST)?1:0));
	$smarty->assign('paging_style',$user_preferences['paging_style']);
	$smarty->assign('double_confirm_delete',($user_preferences['double_confirm_delete']?1:0));

	$smarty->display('search.tpl');
?>
