function cleanFormErrors(){
	$$('.hasError').removeClass('hasError');
	$$('.error_indicator').each(function(el){
		el.destroy();
	});
}

function setErrorIndicator(err){
	cleanErrorIndicator(err);
	if(!err.isValid){
		createErrorIndicator(err);
	}
}

function cleanErrorIndicator(err){
	for(var j=0,len2=err.affected_elements.length; j<len2; j++){
		if($(err.affected_elements[j])) $(err.affected_elements[j]).removeClass('hasError');
	}
	var parent = $(err.element).getParent();
	parent.getElements('.error_indicator').each(function(el){
		el.destroy();
	});
}

function createErrorIndicator(err){
	for(var j=0,len2=err.affected_elements.length; j<len2; j++){
		if($(err.affected_elements[j])) $(err.affected_elements[j]).addClass('hasError');
	}
	var parent = $(err.element).getParent();
	if(!parent.getFirst('.error_indicator')){
		parent.adopt(
			new Element('span',{
				'rel': 'error_indicator',
				'class': 'error_indicator',
				'title': err.message
			}).adopt(new Element('img',{ 'src':'##IMG_WARNING_ICON##', 'width':16, 'height':16 }))
		);
	}
}

(function(){

window.Validator = function(options){
	var self = this;
	var dateRegex = null;
	var dateTimeRegex = null;

	this.valid = true;
	this.elements = [];
	this.errors = [];

	function dateRegexBuilder(strftimeStr){
		lookup_table = {
			'%a' : "(\\w{3})", // locale's abbrev day name
			'%A' : "(\\w{6,8})", // locale's full day name
			'%d' : "(3[0-1]|[1-2][0-9]|0[1-9]|[1-9])", // day of month
			'%e' : "(3[0-1]|[1-2][0-9]|0[1-9]|[1-9])", // day of month, no leader
			'%#d': "(3[0-1]|[1-2][0-9]|0[1-9]|[1-9])", // day of month, no leader
			'%j' : "(36[0-6]|3[0-5][0-9]|[1-2][0-9][0-9]|0[1-9][0-9]|00[1-9])", // Day of year
			'%u' : "([1-7])", // Weekday (Sun = 0)
			'%w' : "([0-6])", // Weekday (Sun = 0)

			'%b' : "(\\w{3})", // abbrev month name
			'%B' : "(\\w{4,9})", // full month name
			'%m' : "(1[0-2]|0[1-9]|[1-9])", // Month as decimal

			'%y' : "([0-9]{2}|[0-9]{4})", // Year (no century)
			'%Y' : "([0-9]{2}|[0-9]{4})", // Year with 4 digits

			'%H' : "(2[0-3]|[0-1][0-9]|[0-9])", // Hour (24h clock)
			'%I' : "(1[0-2]|0[1-9]|[0-9])", // Hour (12h clock)
			'%l' : "(1[0-2]|0[1-9]|[0-9])", // Hour (12h clock no leading zero)
			'%M' : "([0-5][0-9]|[0-9])", // Minute
			'%p' : "(AM|PM|am|pm)",
			'%P' : "(AM|PM|am|pm)",
			'%S' : "([0-9]|[0-5][0-9])", // Second
		}
		var regexstring = strftimeStr.replace(/(%\w)/g, function(c){ var ret = lookup_table[c]; if(ret.length == 0) ret = "(.*?)"; return ret; }).replace(/\//g,'\\/');
		return new RegExp(regexstring);
	};

	function getInputValue(el){
		return $(el).value.trim();
	};

	function trueValue(str){
		var ret = false;
		if(typeof str == 'string'){
			str = str.trim();
			if(str=='0'){
				ret = false;
			} else if(str == 'false') {
				ret = false;
			} else if(str.length==0) {
				ret = false;
			} else {
				ret = true;
			}
		} else if(typeof str=='number'){
			ret = (str==0?false:true);
		} else {
			ret = (str?true:false)
		}
		return ret;
	};

	var defaults = {
		dateFormat: '%d/%m/%Y',
		dateTimeFormat: '%d/%m/%Y %H:%M:%S'
	};

	this.options = merge(defaults,options);

	this.add = function(element,type,required,message,affected_elements){
		if(typeof affected_elements == 'object' && typeof affected_elements.length != 'undefined') {
			affected_elements.push(element);
		} else if(typeof affected_elements == 'string' && affected_elements.length) {
			affected_elements = [ affected_elements ];
		} else {
			affected_elements = [ element ];
		}

		var type_options = null;

		var typematch = type.match(/^required_ifempty\((.*)\)/);
		if(typematch){
			type = 'required_ifempty';
			type_options = typematch[1];
		}

		var el = {
			'element': $(element),
			'type': type,
			'type_options': type_options,
			'required': required,
			'message': message,
			'affected_elements': affected_elements
		};
		self.elements.push(el);
		element.validate = function(){
			var valid = false;
			var ret = el;
			if(self.checkElement(ret)){
				valid = true;
			}
			ret.isValid = valid;
			return ret;
		};

		return el;
	};

	this.check = function(){
		self.errors = [];
		if(self.elements.length){
			for(var i=0,len=self.elements.length; i<len; i++){
				var el = self.elements[i];
				if(!el.element.disabled && typeof self[el.type] == 'function'){
					if(!self[el.type].call(self,el.element,el.required,el.type_options)){
						self.errors.push({
							'element': el.element,
							'type': el.type,
							'type_options': el.type_options,
							'required': el.required,
							'message': el.message,
							'affected_elements': el.affected_elements
						});
					}
				}
			}
		}
		self.valid = (self.errors.length > 0?false:true);
		return self.valid;
	};

	this.checkElement = function(el){
		if(el.element.disabled) return true;
		if(typeof self[el.type] == 'function'){
			if(self[el.type].call(self,el.element,el.required,el.type_options)){
				return true;
			}
		}
		return false;
	};

	this.scan = function(form,opts){
		var form = $(form);
		var elements = [];
		var opts = (opts || []);
		if(form){
			elements = form.getElements('input,textarea,select,button');
		} else {
			elements = $$('input,textarea,select,button');
		}
		elements.each(function(el){
			if(el.getData('validation-type')){
				var type = el.getData('validation-type');
				var required = trueValue(el.get('required'));
				var message = el.getData('validation-message');
				var affectedElements = (typeof el.getData('validation-affected-elements')=='string'?el.getData('validation-affected-elements').split(','):'');

				var element = self.add(el,type,required,message,affectedElements);
				if(opts.events && opts.applyEventsToAffectedElements){
					for(var i=0,len=element.affected_elements.length; i<len;i++){
						var ee = $(element.affected_elements[i]);
						if(ee && ee.addEvents){
							ee.addEvents(opts.events);
							if(ee != el){
								ee.validate = function(){
									return el.validate();
								}
							}
						}
					}
				} else if(opts.events){
					el.addEvents(opts.events);
				}

			}
		});
		return this;
	};

	this.date = function(el,required){
		var str = getInputValue(el);
		if(!required && str.length == 0){
			ret = true;
		} else {
			if(!dateRegex){
				dateRegex = dateRegexBuilder(this.options.dateFormat);
			}
			var ret = dateRegex.test(str);
			if(ret == false){
				this.valid = false;
			}
		}
		return ret;
	};

	this.time = function(el,required){
		var str = getInputValue(el);
		if(!required && str.length == 0){
			ret = true;
		} else {
			var ret = /^\d+\:\d{2}$/.test(str);
			if(ret == false){
				this.valid = false;
			}
		}
		return ret;
	};

	this.dateTime = function(el,required){
		var str = getInputValue(el);
		if(!required && str.length == 0){
			ret = true;
		} else {
			if(!dateTimeRegex){
				dateTimeRegex = dateRegexBuilder(this.options.dateTimeFormat);
			}
			var ret = dateTimeRegex.test(str);
			if(ret == false){
				this.valid = false;
			}
		}
		return ret;
	};

	this.email = function(el,required){
		var str = getInputValue(el);
		if(!required && str.length == 0){
			ret = true;
		} else {
			var filter=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i
			var ret = filter.test(str);
			if(ret == false){
				this.valid = false;
			}
		}
		return ret;
	};

	this.number = function(el,required,decimal_places){
		var str = getInputValue(el);
		if(!required && str.length == 0){
			ret = true;
		} else {
			var myregex;
			if(decimal_places > 0){
				myregex = RegExp('^\\d+([\\.|\\,]\\d{1,'+decimal_places+'})?$');
			} else {
				myregex = /^\d+$/;
			}
			var ret = myregex.test(str,required);
			if(ret == false){
				this.valid = false;
			}
		}
		return ret;
	};

	this.integer = function(el,required){
		return this.number(el,required,0);
	};

	this.float = function(el,required){
		return this.number(el,required,4);
	};

	this.isTrue = function(el,required){
		var str = getInputValue(el);
		var ret = false;
		if(!required && str.length == 0){
			ret = true;
		} else {
			ret = trueValue(str);
		}
		if(ret == false){
			this.valid = false;
		}
		return ret;
	};

	this.isFalse = function(el,required){
		var ret = !this.isTrue(el,required);
		if(ret == false){
			this.valid = false;
		}
		return ret;
	};

	this.notEmpty = function(el,required){
		var str = getInputValue(el);
		var ret = false;
		if(str.length > 0){
			ret = true;
		}
		if(ret == false){
			this.valid = false;
		}
		return ret;
	};

	this.isEmpty = function(el,required){
		var ret = !this.notEmpty(el,required);
		if(ret == false){
			this.valid = false;
		}
		return ret;
	};

	this.required_ifempty = function(el,required,options){
		var ret = false;
		var els = options.split(',');
		for(var i=0,len=els.length; i<len; i++){
			if($(els[i]) && $(els[i]).value && $(els[i]).value.length > 0){
				ret = true;
			}
		}

		if(ret == false){
			this.valid = false;
		}

		return ret;
	}

}

})();
