<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'orders.php';

	$module_name = 'orders';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	$qid = (int)$_GET['id'];

	$sql = "
		SELECT o.*,
			u.name AS buyer,
			c.symbol,
			c.name AS currency,
			s.id AS status_id,
			s.name AS status
		FROM orders AS o
		JOIN users AS u
			ON u.id=o.buyer
		LEFT JOIN quotes_statuses AS s
			ON s.id=o.status
		JOIN currency AS c
			ON c.id=o.id_currency
		WHERE o.id=$qid
	";
	$order = $db->fetch_item($sql);
	$order['status_image'] = __("IMG_QUOTES_STATUSES_".strtoupper(strtoascii($order['status'],'_')));
	if(!file_exists($order['status_image'])){
		$order['status_image'] = null;
	}
	$order['status'] = __($order['status']);

	if($_GET['delete']=='1' && $_GET['reallysure']=='1' && $order){
		$db->delete("DELETE FROM order_items WHERE id_order={$order['id']}");
		$db->delete("DELETE FROM orders WHERE id={$order['id']}");
		redirect_to_module_url('orders');
		return_to_module('orders');
	}

	if($_GET['change_status'] && $_GET['current_status'] && $order){
		$status = (int)$_GET['current_status'];
		$new_status = $db->fetch_item_field("(SELECT id FROM quotes_statuses WHERE id > $status LIMIT 1) UNION (SELECT MIN(id) FROM quotes_statuses LIMIT 1) LIMIT 1");
		if($new_status)
			$db->update("UPDATE orders SET status=$new_status WHERE id={$order['id']}");
		redirect("order_details.php?id={$order['id']}");
	}

	if($order){
		$order_items = $db->fetch_all("
			SELECT *,
				IF(LENGTH(reference)>0,reference,'&nbsp;') AS reference
			FROM order_items
			WHERE id_order={$order['id']}
			ORDER BY id
		");

		$order['number'] = str_pad($order['number'],8,'0',STR_PAD_LEFT);
	} else {
		$error = __("##NG_INCORRECT_ORDER_ID##");
	}

	$taxes = parseTaxes($order['taxes']);

	$return_url = return_to_module_url($module_name);

	$smarty->assign('order',$order);
	$smarty->assign('order_items',$order_items);
	$smarty->assign('taxes',$taxes);
	$smarty->assign('double_confirm_delete',$user_preferences['double_confirm_delete']);
	$smarty->assign('return_url',$return_url);

	$smarty->display('order_details.tpl');
?>