<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'account.php';
	$module_name = 'payments';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$currencies = $db->fetch_all("SELECT * FROM currency ORDER BY id",null,'id');

	if(!$foo = $currencies[$_GET['currency']]){
		$bar = array_keys($currencies);
		$foo = $currencies[$bar[0]];
	}
	$currency_id = $foo['id'];
	$symbol = $foo['symbol'];

	if(!$_GET['filter']){
		$invoices = $db->fetch_all("
			(
			SELECT 'invoice' as type,id,id_currency,taxes,total,client_name as name,number,`date`,currencies
			FROM invoices WHERE pending=0 ORDER BY `date`,id
			)
			UNION
			(
			SELECT 'purchase' as type,id,id_currency,taxes,total,provider_name as name,number,`date`,currencies
			FROM purchases ORDER BY `date`,id
			)
		");
	} else {
		$from_date = getDbDate($_GET['from_month'],$_GET['from_day'],$_GET['from_year']);
		$to_date = getDbDate($_GET['to_month'],$_GET['to_day']+1,$_GET['to_year']);
		$invoices = $db->fetch_all("
			SELECT 'invoice' as type,id,id_currency,taxes,total,client_name,number,`date`,currencies
			FROM invoices
			WHERE pending = 0
				AND date >= '$from_date'
				AND date < '$to_date'
			ORDER BY `date`,id
		");
	}

	$balance = array();
	$total_cost = 0;
	$total_sales = 0;
	$total_taxes = 0;
	$total_gain = 0;
	if(is_array($invoices)) foreach($invoices as $i){
		$invoice_currencies = parseCurrencies($i['currencies']);
		$invoice_currency = $invoice_currencies[$i['id_currency']];
		if($i['type']=='invoice'){
			$items = $db->fetch_all("
				SELECT p.cost,p.id_currency
				FROM invoice_items AS ii
				JOIN products AS p
					ON p.id = ii.id_product
				WHERE ii.id_invoice={$i['id']}");
			$cost = 0;
			if(is_array($items)) foreach($items as $it){
				if($it['id_currency'] != $currency_id){
					$it_currency = $invoice_currencies[$it['id_currency']];
					$it_cost = round($it['cost'] * $it_currency['rate'] / $invoice_currencies[$currency_id]['rate'],4);
				} else {
					$it_cost = $it['cost'];
				}
				$cost += $it_cost;
			}
		}

		$invoice_taxes = 0;
		$taxes = parseTaxes($i['taxes']);
		if(is_array($taxes)) foreach($taxes as $value){
			if($invoice_currency['id'] != $currency_id){
				$invoice_taxes += round($value * $invoice_currency['rate'] / $invoice_currencies[$currency_id]['rate'],4);
			} else {
				$invoice_taxes += $value;
			}
		}

		if($invoice_currency['id'] != $currency_id){
			$invoice_total = round($i['total'] * $invoice_currency['rate'] / $invoice_currencies[$currency_id]['rate'],4);
		} else {
			$invoice_total = $i['total'];
		}

		if($i['type']!='invoice') {
			$cost = $invoice_total - $invoice_taxes;
		}

		$invoice_gain = $invoice_total - $invoice_taxes - $cost;

		if($i['type']=='invoice') {
			$tmp['number'] = sprintf($config['invoice_number_format'],$i['number']);
			$tmp['ref_url'] = "invoice_details.php?id={$i['id']}&return=balance";
		} else {
			$tmp['number'] = sprintf($config['purchase_number_format'],$i['number']);
			$tmp['ref_url'] = "purchase_details.php?id={$i['id']}&return=balance";
		}
		$tmp['client'] = $i['name'];
		$tmp['date'] = fecha($i['date']);

		$total_cost += $cost;
		$total_sales += $invoice_total;
		$total_taxes += $invoice_taxes;
		$total_gain += $invoice_gain;

		$tmp['cost'] = number_format($cost,2);
		$tmp['sale'] = number_format($invoice_total,2);
		$tmp['taxes'] = number_format($invoice_taxes,2);
		$tmp['gain'] = number_format($invoice_gain,2);


		array_push($balance,$tmp);
	}

	if($filter){
		$dates['from_day'] = $_GET['from_day'];
		$dates['from_month'] = $_GET['from_month'];
		$dates['from_year'] = $_GET['from_year'];
		$dates['to_day'] = $_GET['to_day'];
		$dates['to_month'] = $_GET['to_month'];
		$dates['to_year'] = $_GET['to_year'];
	} else {
		$dates['from_day'] = date('d');
		$dates['from_month'] = date('m');
		$dates['from_year'] = date('Y');
		$dates['to_day'] = date('d');
		$dates['to_month'] = date('m');
		$dates['to_year'] = date('Y');
	}

	$smarty->assign('total_cost',number_format($total_cost,2));
	$smarty->assign('total_sales',number_format($total_sales,2));
	$smarty->assign('total_taxes',number_format($total_taxes,2));
	$smarty->assign('total_gain',number_format($total_gain,2));

	$smarty->assign('currencies',$currencies);
	$smarty->assign('dates',$dates);
	$smarty->assign('balance',$balance);
	$smarty->assign('symbol',$symbol);
	$smarty->display('balance.tpl');
?>
