<?php
	include 'inc/config.php';

	include 'inc/smarty.php';

	$thispage = "backup.php";

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($thispage),'read')) noPermissionsError();

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($thispage),'write')){
		if($_GET['delete'] || $_GET['backup'] || $_GET['restore']){
			noPermissionsError();
		}
		$write = false;
	} else {
		$write = true;
	}

	$backups_dir = 'backups/';

	if($_GET['delete'] || $_GET['backup'] || $_GET['restore'] || $_GET['download']){
		$filename = $_GET['filename'];
		if($_GET['backup']){
			$filename = 'db-backup-'.time().'.sql';
		} else {
			preg_match("#^([^/]*)\.sql$#",$filename,$matches);
			$filename = $matches[1].'.sql';
		}

		$file = $backups_dir.$filename;
		if(empty($filename)){
			$error = __("##NG_ERR_INVALID_FILENAME##");
		} elseif(!$_GET['backup'] && !(is_readable($file) && is_file($file))) {
			$error = __("##NG_ERR_CANNOT_READ_FILE##");
		} else {
			if($_GET['download']){
				if(file_exists($file) && is_readable($file) && is_file($file)){
					header('Content-disposition: attachment; filename='.$filename);
					header('Content-type: text/plain');
					readfile($file);
					die();
				} else {
					$error = __("##NG_ERR_COULD_NOT_OPEN_FILE_FOR_READING##");
				}
			}
			elseif($_GET['delete']){
				if(!(@unlink($file))){
					$error = __("##NG_ERR_COULD_NOT_DELETE_FILE##");
				} else {
					$message = __("##NG_BACKUP_DELETED_OK##");
				}
			}
			elseif($_GET['backup']){
				$ret = $db->exportSql();
				//save file
				$handle = @fopen($file,'w');
				if($handle){
					fwrite($handle,utf8_encode($ret));
					fclose($handle);
					$message = __("##NG_BACKUP_OK##");
				} else {
					$error = __("##NG_ERR_COULD_NOT_OPEN_FILE_FOR_WRITING##");
				}
			}
			elseif($_GET['restore']){
				if(file_exists($file) && is_readable($file) && is_file($file)){
					$db->importSql($file);
					$message = __("##NG_RESTORE_OK##");
				} else {
					$error = __("##NG_ERR_COULD_NOT_OPEN_FILE_FOR_READING##");
				}
			}
		}
	}

	$backups_tmp = scandir($backups_dir);
	$backups = array();
	if(is_array($backups_tmp)) foreach($backups_tmp as $b){
		$file = $backups_dir.$b;
		if(is_file($file) && is_readable($file)){
			if(preg_match('/^db-backup-(\d+).sql$/',$b,$matches)){
				$backups[] = array('filepath'=>$file, 'filename'=>$b, 'timestamp'=>$matches[1], 'date'=>date('d/m/Y h:i:s',$matches[1]));
			}
		}
	}
	usort($backups,function($a,$b){
		if($a['timestamp']==$b['timestamp']) return 0;
		return ($a['timestamp']>$b['timestamp'] ? -1 : 1);
	});

	$smarty->assign('error',$error);
	$smarty->assign('message',$message);
	$smarty->assign('write_permission',$write);
	$smarty->assign('backups',$backups);

	$smarty->display('backup.tpl');
?>