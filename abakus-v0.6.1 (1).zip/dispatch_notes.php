<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'dispatch_notes.php';

	$module_name = 'dispatch_notes';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	function saveNewDispatchNote($db,$data,$items,$deduct_items){
		$dispatch_note_id = $db->insert("
			INSERT INTO dispatch_notes SET
				number=".(int)$data['number'].",
				date='".$db->escape_string($data['date'])."',
				salesman=".(int)$data['salesman'].",
				client_id=".(int)$data['client_id'].",
				client_name='".$db->escape_string($data['client_name'])."',
				client_address='".$db->escape_string($data['client_address'])."',
				client_taxpayer_id='".$db->escape_string($data['client_taxpayer_id'])."',
				client_postcode='".$db->escape_string($data['client_postcode'])."',
				client_city='".$db->escape_string($data['client_city'])."',
				client_state='".$db->escape_string($data['client_state'])."',
				client_country='".$db->escape_string($data['client_country'])."',
				notes='".$db->escape_string($data['notes'])."',
				status='".$db->escape_string($data['status'])."',
				id_invoice='".(int)$data['id_invoice']."',
				from_invoice='".(int)$data['from_invoice']."'
		");

		if(is_array($items) && $dispatch_note_id) foreach($items as $k => $ii){
			$db->insert("
				INSERT INTO dispatch_note_items SET
					id_dispatch_note=$dispatch_note_id,
					id_product=".(int)$ii['id_product'].",
					reference='".$db->escape_string($ii['reference'])."',
					description='".$db->escape_string($ii['description'])."',
					quantity=".(int)$ii['quantity']."
			");
			if($deduct_items && !empty($ii['selected_stock'])){
				$sel_stock = explode('|',$ii['selected_stock']);
				if(is_array($sel_stock)){
					foreach($sel_stock as $st){
						list($id_location,$qty) = explode(';',$st);
						if((int)$id_location > 0 && (int)$qty > 0){
							$db->insert("INSERT INTO products_stock SET
								id_product=".(int)$ii['id_product'].",
								id_location=".(int)$id.",
								quantity=(".(int)$qty." * -1),
								relation='dispatch_note|$dispatch_note_id'
							");
						}
					}
				} else {
				}
			}
			return $dispatch_note_id;
		} else {
			return false;
		}
	}

	if($_GET['from_invoice']){
		$invoice_id = (int)$_GET['from_invoice'];
		$data = $db->fetch_item("SELECT * FROM invoices WHERE id=$invoice_id LIMIT 1");
		if($data){
			$invoice_items = $db->fetch_all("SELECT * FROM invoice_items WHERE id_invoice={$data['id']}");

			$data['notes'] = '';
			$data['status'] = 1;
			$data['id_invoice'] = $invoice_id;
			$data['from_invoice'] = 1;
			$data['number'] = max(1,$db->fetch_item_field("SELECT (MAX(number)+1) FROM dispatch_notes"));
			$data['date'] = date('Y-m-d');

			if($dispatch_note_id = saveNewDispatchNote($db,$data,$invoice_items)){
				$db->update("UPDATE invoices SET id_dispatch_note=$dispatch_note_id WHERE id=$invoice_id");
			}
		}

		redirect("dispatch_note_edit.php?id=$dispatch_note_id");
	}

	if($_POST['save']){
		$_POST['date'] = date2db($_POST['date'],$date_format);
		$_POST['client_id'] = (int)$_POST['client'];
		$_POST['id_invoice'] = 0;
		$_POST['from_invoice'] = 0;
		$_POST['status'] = 1;

    // The invoice has items
    if(is_array($_POST['ref'])){
			$items = array();
			foreach($_POST['ref'] as $k => $ref){
				$items[] = array(
					'id_product'=>$_POST['product_id'][$k],
					'reference'=>$ref,
					'description'=>$_POST['desc'][$k],
					'quantity'=>$_POST['qty'][$k],
					'selected_stock'=>$_POST['sel_stock'][$k]
				);
			}
			if($dispatch_note_id = saveNewDispatchNote($db,$_POST,$items)){
				redirect("dispatch_note_details.php?id=$dispatch_note_id");
			}
			// INSERT error
			else{
				$error = __("##NG_ERR_DISPATCH_NOTE_SAVING_ERROR##");
			}
		}

		// The invoice doesn't have any item
		else {
			$error = __("##NG_ERR_DISPATCH_NOTE_HAS_NO_ITEMS##");
		}
	}

	$salesmen = $db->fetch_all("SELECT * FROM users WHERE can_sell=1 AND deleted=0");
	$dispatch_note_number = max(1,$db->fetch_item_field("SELECT (MAX(number)+1) FROM dispatch_notes"));

	$return_url = return_to_module_url($module_name);

	$smarty->assign('error',$error);
	$smarty->assign('return_url',$return_url);
	$smarty->assign('invoice_number',$dispatch_note_number);
	$smarty->assign('salesmen',$salesmen);
	$smarty->assign('ignore_stock',($config['ignore_stock']?1:0));

	$smarty->display('dispatch_notes.tpl');
?>