<?php
	$nologin = true;

	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = 'products';
	// We load the module
	$module = loadModule($module_name,$db);
	$thispage = 'product_details.php';

	include 'inc/smarty.php';

	$fields = $module->getFields('addform');

	$excluded_fields = array('cost','id_category','id_product_type','id_tax','id_currency','min_stock','min_stock_alert','id_packaging','units_per_package','id_origin','short_description','manufacturers_code','reference');

	$item = $module->getElement((int)$_GET['id']);
	if($item){
		if($item['id_provider']){
			$item['id_provider'] = $db->fetch_item_field("SELECT name FROM providers WHERE id={$item['id_provider']}");
		}

		$image = $db->fetch_item("SELECT i.* FROM products_to_images AS pti JOIN images AS i ON i.id=pti.id_image WHERE pti.id_product={$item['id']}");

		$price_scale = $db->fetch_item("SELECT * FROM price_scales ORDER BY `default` DESC, id ASC LIMIT 1");

		if($price_scale){
			$price = round($db->fetch_item_field("SELECT * FROM products_prices WHERE id_product={$item['id']} AND id_price_scale={$price_scale['id']} LIMIT 1",'price'),2);
		}
		$stock = (int)$module->db->fetch_item_field("
			SELECT IF(SUM(ps.quantity) > 0,1,0)
			FROM products_stock AS ps
			WHERE ps.id_product={$item['id']}
			GROUP
		");

		$formatted_fields = array();
		if(is_array($fields) && !empty($fields)){
			foreach($fields as $f){
				if(!$module->isFixedField($f['Field']) && !$module->isHiddenField($f['Field']) && !in_array($f['Field'],$excluded_fields)) {
					$tmp['field'] =  $f['Field'];
					$tmp['name'] = beautifyFieldName(__($f['Name']));
					$tmp['input'] = $item[$f['Field']];
					$formatted_fields[] = $tmp;
				}
			}
		}
	}

	$smarty->assign('uploads_path', $uploads_path);
	$smarty->assign('iframe', true);
	$smarty->assign('fields',$formatted_fields);
	$smarty->assign('item',$item);
	$smarty->assign('image',$image);
	$smarty->assign('price',$price);
	$smarty->assign('stock',$stock);

	$smarty->display('product_details.tpl');
?>
