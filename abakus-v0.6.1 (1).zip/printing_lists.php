<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = 'printing_lists.php';
	$thispage = "printing_lists.php";

	// We load the module
	//$module = loadModule($module_name,$db);

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	include 'inc/smarty.php';

	$type = $_GET['type'];

	$form_action = $thispage;
	if($type){
		$form_action.="?type=$type";
		$smarty->assign('selected',$type);
	}


	$currencies = $db->fetch_all("SELECT * FROM currency ORDER BY id",null,'id');
	$selected_currency = (int)$_POST['balance_currency'];
	$currency = $currencies[$selected_currency];
	if(!$currency){
		$foo = array_keys($currencies);
		$currency = $currencies[$foo[0]];
		$selected_currency = $currency['id'];
	}

	switch($type){
		case 'clients':
			$client = $db->fetch_item("SELECT * FROM clients WHERE id=".(int)$_POST['id_client']);

			if($_POST['date_type'] == 'period'){
				$days = (int)$_POST['period'];
				$from_date = date('Y-m-d',mktime(0,0,0,date('m'),date('d')-$days,date('Y')));
				$to_date = date('Y-m-d');
			} else {
				$from_date = date2sqldate($_POST['from_date']);
				$to_date = date2sqldate($_POST['to_date']);
			}

			if($_POST['opt_account']){
				$account = $db->fetch_all("
					SELECT *,DATE(`date`) as reddate, '$from_date' as fdate, '$to_date' as tdate
					FROM accounts
					WHERE id_client={$client['id']}
						AND DATE(`date`) >= '$from_date'
						AND DATE(`date`) <= '$to_date'
					ORDER BY date,id
				");
				$movements = array();
				if(is_array($account) && !empty($account)){
					if(is_array($account)) foreach($account as $movement){
						if($movement['reference']){
							$reference = str_pad($movement['reference'],10,'0',STR_PAD_LEFT);
						} else {
							$reference = '';
						}
						$movement['credit'] = str_replace('-','',$movement['credit']);
						switch($movement['type']){
							case 'invoice':
								if($reference){
									$reference = sprintf($config['invoice_number_format'],$reference);
								} else {
									$reference = 'No Number';
								}
								$ref_url = "invoice_details.php?id={$movement['id_item']}&amp;return=account";
								break;
							case 'receipt':
								if($reference){
									$reference = sprintf($config['receipt_number_format'],$reference);
								} else {
									$reference = 'No Number';
								}
								$ref_url = "javascript: viewReceipt({$movement['id_item']});";
								//$ref_url = "javascript: payments.php?id={$movement['id_item']}";
								break;
						}
						$tmp['date'] = fecha($movement['date']);
						$tmp['type'] = __($movement['type']);
						$tmp['ref_url'] = $ref_url;
						$tmp['reference'] = $reference;
						$tmp['due_date'] = ($movement['due_date']?fecha($movement['due_date']):'');
						$tmp['credit'] = ($movement['credit']!=0?$symbol.' '.$movement['credit']:'');
						$tmp['debit'] = ($movement['debit']!=0?$symbol.' '.$movement['debit']:'');
						$tmp['balance'] = $symbol.' '.$movement['balance'];
						$movements[] = $tmp;
					}
				}
				$smarty->assign('client_account',$movements);
			}

			if($_POST['opt_quotes']){
				$quotes = $db->fetch_all("
					SELECT q.*,cur.symbol,cur.name AS currency,qs.name as status,u.name AS salesman
					FROM quotes AS q
					JOIN currency AS cur
						ON cur.id=q.id_currency
					LEFT JOIN quotes_statuses As qs
						ON qs.id=q.status
					LEFT JOIN users AS u
						ON u.id=q.salesman
					WHERE q.client_id={$client['id']}
						AND DATE(`date`) >= '$from_date'
						AND DATE(`date`) <= '$to_date'
					ORDER BY `date`
				");
				foreach($quotes as $key => $q){
					$taxes = parseTaxes($q['taxes']);
					$total_taxes = 0;
					foreach($taxes as $t){
						$total_taxes += $t;
					}
					$quotes[$key]['taxes'] = $total_taxes;
				}
				$smarty->assign('client_quotes',$quotes);
			}

			if($_POST['opt_invoices']){
				$invoices_totals = array();
				$invoices = $db->fetch_all("
					SELECT i.*,cur.symbol,cur.name AS currency,u.name AS salesman
					FROM invoices AS i
					JOIN currency AS cur
						ON cur.id=i.id_currency
					LEFT JOIN users AS u
						ON u.id=i.salesman
					WHERE i.client_id={$client['id']}
						AND DATE(`date`) >= '$from_date'
						AND DATE(`date`) <= '$to_date'
					ORDER BY `date`
				");
				foreach($invoices as $key => $i){
					$taxes = parseTaxes($i['taxes']);
					$total_taxes = 0;
					foreach($taxes as $t){
						$total_taxes += $t;
					}
					$invoices[$key]['taxes'] = $total_taxes;

					if($i['id_currency']==$selected_currency){
						$invoices_totals['subtotal'] += $i['subtotal'];
						$invoices_totals['discount'] += $i['discount'];
						$invoices_totals['taxes'] += $total_taxes;
						$invoices_totals['total'] += $i['total'];
					} else {
						$currs = parseCurrencies($i['currencies']);
						$invoices_totals['subtotal'] += $i['subtotal']*$currs[$i['id_currency']]/$currency['rate'];
						$invoices_totals['discount'] += $i['discount']*$currs[$i['id_currency']]/$currency['rate'];
						$invoices_totals['taxes'] += $total_taxes*$currs[$i['id_currency']]/$currency['rate'];
						$invoices_totals['total'] += $i['total']*$currs[$i['id_currency']]/$currency['rate'];
					}
				}
				$invoices_totals['subtotal'] = round($invoices_totals['subtotal'],4);
				$invoices_totals['discount'] = round($invoices_totals['discount'],4);
				$invoices_totals['taxes'] = round($invoices_totals['taxes'],4);
				$invoices_totals['total'] = round($invoices_totals['total'],4);

				$smarty->assign('client_invoices',$invoices);
				$smarty->assign('client_invoices_totals',$invoices_totals);
			}

			if($_POST['opt_receipts']){
				$receipts_totals = array();
				$receipts = $db->fetch_all("
					SELECT r.*,cur.symbol,cur.name AS currency,ccur.symbol AS cash_symbol,u.name AS salesman
					FROM receipts AS r
					JOIN currency AS cur
						ON cur.id=r.receipt_currency
					JOIN currency AS ccur
						ON cur.id = r.cash_currency
					LEFT JOIN users AS u
						ON u.id=r.salesman
					WHERE r.id_client={$client['id']}
						AND DATE(`date`) >= '$from_date'
						AND DATE(`date`) <= '$to_date'
					GROUP BY r.id
					ORDER BY `date`
				");
				foreach($receipts as $key => $r){
					$receipts_totals['total'] += $r['total'];
				}
				$smarty->assign('client_receipts',$receipts);
				$smarty->assign('client_receipts_totals',$receipts_totals);
			}

			if($_POST['opt_contacts']){
				$contacts = $db->fetch_all("SELECT * FROM contacts WHERE relation='client' AND id_relation={$client['id']}");
				$smarty->assign('client_contacts',$contacts);
			}
			break;

		case 'providers':
			$provider = $db->fetch_item("SELECT * FROM providers WHERE id=".(int)$_POST['id_provider']);

			if($_POST['date_type'] == 'period'){
				$days = (int)$_POST['period'];
				$from_date = date('Y-m-d',mktime(0,0,0,date('m'),date('d')-$days,date('Y')));
				$to_date = date('Y-m-d');
			} else {
				$from_date = date2sqldate($_POST['from_date']);
				$to_date = date2sqldate($_POST['to_date']);
			}

			if($_POST['opt_account']){
				$account = $db->fetch_all("
					SELECT *
					FROM provider_accounts
					WHERE id_provider={$provider['id']}
						AND DATE(`date`) >= '$from_date'
						AND DATE(`date`) <= '$to_date'
					ORDER BY date,id
				");
				$movements = array();
				if(is_array($account) && !empty($account)){
					if(is_array($account)) foreach($account as $movement){
						if($movement['reference']){
							$reference = str_pad($movement['reference'],10,'0',STR_PAD_LEFT);
						} else {
							$reference = '';
						}
						$movement['credit'] = str_replace('-','',$movement['credit']);
						switch($movement['type']){
							case 'purchase':
								if($reference){
									$reference = sprintf($config['purchase_number_format'],$reference);
								} else {
									$reference = 'No Number';
								}
								$ref_url = "purchase_details.php?id={$movement['id_item']}&amp;return=printing_lists";
								break;
							case 'payment':
								if($reference){
									$reference = sprintf($config['payment_number_format'],$reference);
								} else {
									$reference = 'No Number';
								}
								$ref_url = "javascript: viewReceipt({$movement['id_item']});";
								//$ref_url = "javascript: payments.php?id={$movement['id_item']}";
								break;
						}
						$tmp['date'] = fecha($movement['date']);
						$tmp['type'] = __($movement['type']);
						$tmp['ref_url'] = $ref_url;
						$tmp['reference'] = $reference;
						$tmp['due_date'] = ($movement['due_date']?fecha($movement['due_date']):'');
						$tmp['credit'] = ($movement['credit']!=0?$symbol.' '.$movement['credit']:'');
						$tmp['debit'] = ($movement['debit']!=0?$symbol.' '.$movement['debit']:'');
						$tmp['balance'] = $symbol.' '.$movement['balance'];
						$movements[] = $tmp;
					}
				}
				$smarty->assign('provider_account',$movements);
			}

			if($_POST['opt_orders']){
				$orders = $db->fetch_all("
					SELECT o.*,cur.symbol,cur.name AS currency,qs.name as status,u.name AS buyer
					FROM orders AS o
					JOIN currency AS cur
						ON cur.id=o.id_currency
					LEFT JOIN quotes_statuses As qs
						ON qs.id=o.status
					LEFT JOIN users AS u
						ON u.id=o.buyer
					WHERE o.provider_id={$provider['id']}
						AND DATE(p.`date`) >= '$from_date'
						AND DATE(p.`date`) <= '$to_date'
					ORDER BY p.`date`
				");
				if(is_array($orders)) foreach($orders as $key => $o){
					$taxes = parseTaxes($o['taxes']);
					$total_taxes = 0;
					foreach($taxes as $t){
						$total_taxes += $t;
					}
					$orders[$key]['taxes'] = $total_taxes;
				}
				$smarty->assign('provider_orders',$orders);
			}

			if($_POST['opt_purchases']){
				$purchases = $db->fetch_all("
					SELECT p.*,cur.symbol,cur.name AS currency,u.name AS buyer
					FROM purchases AS p
					JOIN currency AS cur
						ON cur.id=p.id_currency
					LEFT JOIN users AS u
						ON u.id=p.buyer
					WHERE p.provider_id={$provider['id']}
						AND DATE(p.`date`) >= '$from_date'
						AND DATE(p.`date`) <= '$to_date'
					ORDER BY p.`date`
				");
				foreach($purchases as $key => $p){
					$taxes = parseTaxes($p['taxes']);
					$total_taxes = 0;
					foreach($taxes as $t){
						$total_taxes += $t;
					}
					$purchases[$key]['taxes'] = $total_taxes;

					if($p['id_currency']==$selected_currency){
						$totals['subtotal'] += $p['subtotal'];
						$totals['discount'] += $p['discount'];
						$totals['taxes'] += $total_taxes;
						$totals['total'] += $p['total'];
					} else {
						$currs = parseCurrencies($p['currencies']);
						$totals['subtotal'] += $p['subtotal']*$currs[$p['id_currency']]/$currency['rate'];
						$totals['discount'] += $p['discount']*$currs[$p['id_currency']]/$currency['rate'];
						$totals['taxes'] += $total_taxes*$currs[$p['id_currency']]/$currency['rate'];
						$totals['total'] += $p['total']*$currs[$p['id_currency']]/$currency['rate'];
					}
				}
				$totals['subtotal'] = round($totals['subtotal'],4);
				$totals['discount'] = round($totals['discount'],4);
				$totals['taxes'] = round($totals['taxes'],4);
				$totals['total'] = round($totals['total'],4);

				$smarty->assign('provider_purchases',$purchases);
				$smarty->assign('provider_purchases_totals',$totals);
			}

			if($_POST['opt_payments']){
				$payments = $db->fetch_all("
					SELECT p.*,cur.symbol,cur.name AS currency,ccur.symbol AS cash_symbol,u.name AS buyer
					FROM payments AS p
					JOIN currency AS cur
						ON cur.id = p.payment_currency
					JOIN currency AS ccur
						ON cur.id = p.cash_currency
					LEFT JOIN users AS u
						ON u.id = p.buyer
					WHERE p.id_provider={$provider['id']}
						AND DATE(p.`date`) >= '$from_date'
						AND DATE(p.`date`) <= '$to_date'
					GROUP BY p.id
					ORDER BY `date`
				");
				foreach($payments as $key => $p){
					$totals['total'] += $p['total'];
				}
				$smarty->assign('provider_payments',$payments);
				$smarty->assign('provider_payments_totals',$totals);
			}

			if($_POST['opt_contacts']){
				$contacts = $db->fetch_all("SELECT * FROM contacts WHERE relation='provider' AND id_relation={$provider['id']}");
				$smarty->assign('provider_contacts',$contacts);
			}
			break;

		case 'salesmen':
			$salesman = $db->fetch_item("SELECT * FROM users WHERE deleted=0 AND id=".(int)$_POST['id_salesman']);
			if($_POST['date_type'] == 'period'){
				$days = (int)$_POST['period'];
				$from_date = date('Y-m-d',mktime(0,0,0,date('m'),date('d')-$days,date('Y')));
				$to_date = date('Y-m-d');
			} else {
				$from_date = date2sqldate($_POST['from_date']);
				$to_date = date2sqldate($_POST['to_date']);
			}
			if($_POST['opt_sales']){
				$invoices = $db->fetch_all("
					SELECT i.*,cur.symbol,cur.name AS currency,u.name AS salesman
					FROM invoices AS i
					JOIN currency AS cur
						ON cur.id=i.id_currency
					LEFT JOIN users AS u
						ON u.id=i.salesman
					WHERE i.salesman={$salesman['id']}
						AND DATE(`date`) >= '$from_date'
						AND DATE(`date`) <= '$to_date'
						AND pending = 0
					ORDER BY `date`
				");
				foreach($invoices as $key => $i){
					$taxes = parseTaxes($i['taxes']);
					$total_taxes = 0;
					foreach($taxes as $t){
						$total_taxes += $t;
					}
					$invoices[$key]['taxes'] = $total_taxes;
					if($i['id_currency']==$selected_currency){
						$totals['subtotal'] += $i['subtotal'];
						$totals['discount'] += $i['discount'];
						$totals['taxes'] += $total_taxes;
						$totals['total'] += $i['total'];
					} else {
						$currs = parseCurrencies($i['currencies']);
						$totals['subtotal'] += $i['subtotal']*$currs[$i['id_currency']]/$currency['rate'];
						$totals['discount'] += $i['discount']*$currs[$i['id_currency']]/$currency['rate'];
						$totals['taxes'] += $total_taxes*$currs[$i['id_currency']]/$currency['rate'];
						$totals['total'] += $i['total']*$currs[$i['id_currency']]/$currency['rate'];
					}
				}
				$totals['subtotal'] = round($totals['subtotal'],4);
				$totals['discount'] = round($totals['discount'],4);
				$totals['taxes'] = round($totals['taxes'],4);
				$totals['total'] = round($totals['total'],4);

				$smarty->assign('salesman_sales',$invoices);
				$smarty->assign('salesman_sales_totals',$totals);
			}
			break;

		case 'labels':
			if(is_array($_POST['labels_items'])){
				foreach($_POST['labels_items'] as $key => $i){
					$item = $db->fetch_item("SELECT * FROM products WHERE id=".(int)$i);
					if(!$item) continue;
					switch($config['invoice_search_field']){
						case 'internal_code': $search_field = 'internal_code'; break;
						case 'manufacturers_code': $search_field = 'manufacturers_code'; break;
						default: $search_field = 'reference';
					}
					$ref = strtoupper(strtoascii($item[$search_field],' '));
					$desc = $item['short_description'];
					$qty = $_POST['labels_items_qty'][$key];
					$time = time();

					for($i=0; $i < $qty; $i++){
						$labels[] = array(
							'ref' => $ref,
							'desc' => $desc,
							'id' => (int)$item['id']
						);
					}
					$selected[] = array(
						'id' => $item['id'],
						'ref' => $ref,
						'desc' => $desc,
						'qty' => $qty
					);
				}
				$smarty->assign('label_type',$_POST['label_type']);
				$smarty->assign('selected_labels',$selected);
				$smarty->assign('labels',$labels);
			}
			break;

		case 'notes':
			if(is_array($_POST['notes_items'])){
				foreach($_POST['notes_items'] as $key => $i){
					$item = $db->fetch_item("SELECT * FROM notes WHERE id=".(int)$i);
					if(!$item) continue;
					$name = $item['name'];
					$text = $item['text'];
					$qty = $_POST['notes_items_qty'][$key];

					for($i=0; $i < $qty; $i++){
						$notes[] = array(
							'name' => $name,
							'text' => $text
						);
					}
					$selected[] = array(
						'id' => $item['id'],
						'name' => $name,
						'text' => $text,
						'qty' => $qty
					);
				}
				$smarty->assign('selected_notes',$selected);
				$smarty->assign('notes',$notes);
			}
			break;

		case 'shipping_labels':
			if(is_array($_POST['shipping_labels_items'])){
				foreach($_POST['shipping_labels_items'] as $key => $i){
					$item = $db->fetch_item("
						SELECT c.*, co.name AS country, s.name AS state
						FROM clients AS c
						LEFT JOIN states AS s
							ON s.id = c.id_state
						LEFT JOIN countries AS co
							ON co.id = s.id_country
						WHERE c.id=".(int)$i
					);
					if(!$item) continue;
					$qty = $_POST['shipping_labels_items_qty'][$key];
					$time = time();

					for($i=0; $i < $qty; $i++){
						$shipping_labels[] = $item;
					}
					$selected_shipping_labels[] = array(
						'client' => $item,
						'qty' => $qty
					);
				}
				$smarty->assign('selected_shipping_labels',$selected_shipping_labels);
				$smarty->assign('shipping_labels',$shipping_labels);
			}
			break;

		default:
			$type=false;
	}

	if($type){
		$favs = $db->fetch_all("SELECT * FROM user_preferences WHERE id_user=".$user->getId()." AND module='$module_name' AND attribute LIKE 'favorites\_$type\_% ORDER BY id");
		$favorites = array();
		if(is_array($favs)) foreach($favs as $f){
			list($name,$data) = explode("|",$f['value']);
			$favorites[] = array('id'=>$f['id'],'name'=>$name,'data'=>$data);
		}
		$smarty->assign('favorites',$favorites);
	}

	$smarty->assign('form_action',$form_action);
	$smarty->assign('currencies',$currencies);
	$smarty->assign('currency',$currency);

	$smarty->display('printing_lists.tpl');
?>
