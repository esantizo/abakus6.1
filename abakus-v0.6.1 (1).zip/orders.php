<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'orders.php';

	$module_name = 'orders';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	if($_POST['save']){
    $number = (int)$_POST['number'];
    $date = date2db($_POST['date'],$date_format);
    $buyer = (int)$_POST['buyer'];
    $provider = (int)$_POST['provider_id'];
    $provider_name = $db->escape_string($_POST['provider_name']);
    $provider_address = $db->escape_string($_POST['provider_address']);
    $provider_taxpayer_id = $db->escape_string($_POST['provider_taxpayer_id']);
    $provider_city = $db->escape_string($_POST['provider_city']);
    $provider_state = $db->escape_string($_POST['provider_state']);
    $provider_country = $db->escape_string($_POST['provider_country']);
    $provider_postcode = $db->escape_string($_POST['provider_postcode']);
    $id_currency = (int)$_POST['currency'];
		$currencies = stringifyCurrencies($_POST['currency_rates']);

    $subtotal = float($_POST['subtotal']);
    $taxes = stringifyTaxes($_POST['total_taxes']);
		$discount = float($_POST['discount']);
    $total = float($_POST['total']);
    $order_duration = $db->escape_string($_POST['order_duration']);
    $notes = $db->escape_string($_POST['notes']);

    // The invoice has items
    if(is_array($_POST['ref'])){
			$order_id = $db->insert("
				INSERT INTO orders SET
					number='$number',
					`date`='$date',
					buyer='$buyer',
					provider_id='$provider',
					provider_name='$provider_name',
					provider_address='$provider_address',
					provider_taxpayer_id='$provider_taxpayer_id',
					provider_city='$provider_city',
					provider_state='$provider_state',
					provider_country='$provider_country',
					provider_postcode='$provider_postcode',
					id_currency='$id_currency',
					currencies='$currencies',
					subtotal='$subtotal',
					taxes='$taxes',
					discount='$discount',
					total='$total',
					order_duration='$order_duration',
					notes='$notes'
			");

			if($order_id){
				foreach($_POST['ref'] as $k => $ref){
					$product_id = (int)$_POST['product_id'][$k];
					$ref = $db->escape_string($ref);
					$desc = $db->escape_string($_POST['desc'][$k]);
					$qty = $db->escape_string($_POST['qty'][$k]);
					$price = $db->escape_string($_POST['price'][$k]);
					$tax = $db->escape_string($_POST['tax'][$k]);
					$item_total = $db->escape_string($_POST['item_total'][$k]);
					$db->insert("
						INSERT INTO order_items SET
							id_order=$order_id,
							id_product=$product_id,
							reference='$ref',
							description='$desc',
							quantity='$qty',
							price='$price',
							tax='$tax',
							total='$item_total'
					");
				}
				redirect("order_details.php?id=$order_id");
			}

			// INSERT error
			else{
				//echo $db->error();
			}

		}

		// The invoice doesn't have any item
		else {
		}
	}

	$buyers = $db->fetch_all("SELECT * FROM users WHERE can_buy=1 AND deleted=0");
	$order_number = max(1,$db->fetch_item_field("SELECT (MAX(number)+1) FROM orders"));
	$tax_values = $db->fetch_all("SELECT percentage FROM taxes ORDER BY percentage",'percentage');
	$currency = $db->fetch_all("SELECT * FROM currency ORDER BY rate");

	$price_scale = $db->fetch_item("SELECT id,name FROM price_scales ORDER BY `default` DESC,id DESC LIMIT 1");
	$tax_conditions = $db->fetch_all("SELECT * FROM tax_conditions ORDER BY name");
	$payment_types = $db->fetch_all("SELECT * FROM payment_types ORDER BY name");

	$return_url = return_to_module_url($module_name);

	$smarty->assign('return_url',$return_url);
	$smarty->assign('order_number',$order_number);
	$smarty->assign('currency',$currency);
	$smarty->assign('buyers',$buyers);
	$smarty->assign('tax_values',implode(',',$tax_values));
	$smarty->assign('ignore_stock',($config['ignore_stock']?1:0));

	$smarty->display('orders.tpl');
?>
