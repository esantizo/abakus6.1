(function(){

window.Lightbox = function(obj,options){
	var self = this;
	this.window = $(obj);
	this.winevents = null;
	this.options = merge({
		'autoposition':true,
		'autoHeight':false,
		'reloadOnClose':false,
		'focusOnClose':false,
		'onClose':null,
		'onOpen':null,
		'onReposition':null,
		'closeButton':true,
		'closeOnEsc': true,
		'overlay': true
	},options);
	this.parentOverflow = {};
	this.overlay = null;
	this.opened = false;
	this.closebtn = null;
	//if(this.options && this.options.wrapper){
	//	this.wrapper = $(this.options.wrapper);
	//	this.centerInObject = this.wrapper;
	//} else {
		this.wrapper = $(document.body);
		this.centerInObject = $(window);
	//}

	if(this.window.getParent())	this.window.getParent().removeChild(this.window);
	this.window.inject(this.wrapper);

	function documentKeyUpEvent(ev){
		if(!self.options.closeOnEsc) return;
		if(ev.keyCode==27 && self && self.overlay){
			self.close();
			if(ev.cancelBubble) ev.cancelBubble();
			if(ev.stopPropagation) ev.stopPropagation();
			if(ev.preventDefault) ev.preventDefault();
		}
	};

	function documentResize(ev){
		if(self && self.overlay){
			self.overlay.setStyles({
				width: window.innerWidth,
				height: window.innerHeight
			});
			self.reposition();
		}
	};

	this.open = function(){
		var body = $(document.body);
		this.parentOverflow = { x:body.getStyle('overflow-x'), y:body.getStyle('overflow-y') };
		if(self.options.overlay){
			this.overlay = new Element('div',{
				'class':'lightbox_overlay',
				'styles':{
					position: 'fixed',
					top: 0,
					left: 0,
					width: window.innerWidth,
					height: window.innerHeight
				},
				'events': { 'click': function(){self.close();} }
			})
			this.overlay.inject(body);
		}

		if(this.options.closeButton){
			this.closebtn = new Element('a',{
				'href':'javascript:;',
				'class':'lightbox_closebtn',
				'html':'X',
				events: {
					'click':function(){self.close();}
				}
			}).inject(self.window);
		}

		self.winevents = $(window).events['keydown'];

		for(var i=0,len=self.winevents.length; i<len; i++){
			$(window).removeEvent('keydown',self.winevents[i]);
		}
		if(this.options.closeOnEsc){
			$(window).addEvent('keydown',documentKeyUpEvent);
		}
		$(window).addEvent('resize',documentResize);
		$(window).addEvent('scroll',documentResize);

		self.window
			.setStyle('transition','none')
			.removeClass('lightbox')
			.addClass('lightbox_open');
		if(this.options.autoHeight){
			this.autoHeight();
		}
		if(this.options.autoposition){
			this.reposition();
		}

		if(body.offsetHeight > window.innerHeight) body.setStyle('overflow','hidden');
		if(this.options.onOpen) this.options.onOpen.call(this);

		this.opened = true;
		return this;
	};

	this.close = function(reload){
		if(this.options.closeOnEsc){
			$(window).removeEvent('keydown',documentKeyUpEvent);
		}
		$(window).removeEvent('resize',documentResize);
		$(window).removeEvent('scroll',documentResize);
		for(var i=0,len=self.winevents.length; i<len; i++){
			$(window).addEvent('keydown',self.winevents[i]);
		}

		self.window
			.removeClass('lightbox_open')
			.addClass('lightbox');
		this.wrapper.setStyles({'overflow-x':this.parentOverflow.x,'overflow-y':this.parentOverflow.y});
		if(self.overlay){
			this.wrapper.removeChild(self.overlay);
			self.overlay = null;
		}

		if(this.options.reloadOnClose) location.href=location.href;
		if(this.options.focusOnClose) setFocus(this.options.focusOnClose);
		if(this.options.onClose) this.options.onClose();
		this.opened = false;
		return this;
	};

	this.reposition = function(){
		var pos = self.window.getPosition();
		var top = ((this.centerInObject.innerHeight - pos.height)/2).round();
		if(this.centerInObject.pageYOffset) top += this.centerInObject.pageYOffset;
		var left = ((this.centerInObject.innerWidth - pos.width)/2).round();
		if(this.centerInObject.pageXOffset) left+= this.centerInObject.pageXOffset;
		top = Math.max(0,top);
		left = Math.max(0,left);
		self.window.setStyles({'position':'absolute','top':top,'left':left});
		if(typeof self.options.onReposition == 'function'){
			self.options.onReposition.call(self,{ 'top':top,'left':left,'width':pos.totalWidth,'height':pos.totalHeight, 'parentWidth': this.centerInObject.innerWidth, 'parentHeight': this.centerInObject.innerHeight, 'parentScrollX': this.centerInObject.pageXOffset, 'parentScrollY': this.centerInObject.pageYOffset });
		}
		return this;
	};

	this.autoHeight = function(){
		var height = 0;
		this.window.getElements().each(function(el){
			if(el != self.closebtn){
				var pos = el.getPosition();
				height += pos.totalHeight;
			}
		});
		var max_height = this.window.getStyle('max-height').toInt();
		if(this.window.getStyle('max-height') > 0 && this.window.getStyle('max-height') < height){
			this.window.setStyle('height',this.window.getStyle('max-height'));
		} else {
			this.window.setStyle('height',height);
		}
		this.reposition();
		return this;
	};

	//~ this.updatePosition = function(){
		//~ var parentPos = this.window.getParent().getPosition();
		//~ var thisPos = this.window.getPosition();
		//~ if(this.options.autoposition){
			//~ var top = ((parentPos.height - thisPos.height)/2).round() + parentPos.scrollTop;
			//~ var left = ((parentPos.width - thisPos.width)/2).round() + parentPos.scrollLeft;
			//~ var screenRelativeTop = ((window.innerHeight - thisPos.height)/2).round() + window.pageYOffset;
			//~ var screenRelativeLeft = ((window.innerWidth - thisPos.width)/2).round() + window.pageXOffset;
			//~ if(top > screenRelativeTop) top = screenRelativeTop;
			//~ if(left > screenRelativeLeft) left = screenRelativeLeft;
			//~ if(top < 0) top = 0;
			//~ if(left < 0) left = 0;
			//~ var transition = this.window.getStyle('transition');
			//~ this.window.setStyle('transition','none').setStyles({'position':'absolute','top':top,'left':left});
			//~ this.window.setStyle('transition',transition);
		//~ }
	//~ }
}

})();
