<?php
	include 'inc/config.php';
	require 'inc/smarty.php';

	if(!$user || !$user->isValid()) noPermissionsError();

	$dialer_data = $db->fetch_all("SELECT value FROM user_preferences WHERE id_user={$user->getId()} AND module='general' AND attribute LIKE 'dialer_%' AND value > 0 GROUP BY attribute ORDER BY LENGTH(attribute),attribute",'value');

	$dialer = array();
	$count = count($dialer_data);
	for($i=0; $i<$count; $i++){
		$id = $dialer_data[$i];
		$index = $i;
		$image = $menu_items[$id]['image'];

		$tmp['link'] = $menu_items[$id]['link'];
		$tmp['image'] = $image;
		$tmp['name'] = $menu_items[$id]['name'];
		$tmp['number'] = ($index+1)%10;

		$tmp['break'] = 0;
		if($count > 4 && ceil($count/2)==$index){ $tmp['break']=1; };

		$dialer[] = $tmp;
	}

	$smarty->assign('dialer',$dialer);
	$smarty->display('index.tpl');
?>