<?php
	include 'inc/config.php';

	$thispage = "parking_configuration.php";
	if(!$_GET['section']) $_GET['section'] = 'parking_config';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	function getDayName($day_num,$type='short'){
		$daysOfWeek = array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
		$day = $daysOfWeek[$day_num];
		if($type=='short'){
			return strftime('%a', strtotime("last $day"));
		}
		return strftime('%A', strtotime("last $day"));
	}

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($thispage),'write')) noPermissionsError();

	if($_GET['section']=='parking_config' && $_POST['save']){
		$fields = array(
			'parking_hourly_tolerance','parking_hourly_price','parking_hourly_to_daily',
			'parking_daily_tolerance','parking_daily_price','parking_daily_early_checkinx1','parking_daily_early_checkinx2','parking_daily_early_checkinx3','parking_daily_scales',
			'parking_shift_scales','parking_monthly_scales'
		);

		foreach($fields as $f){
			$val = $db->escape_string($_POST[$f]);
			$sql = "INSERT INTO config (name,value) VALUES ('$f','$val') ON DUPLICATE KEY UPDATE value='$val'";
			$db->insert($sql);
		}

		redirect($thispage."?section=".$_GET['section']);
	}

	$smarty->assign('section',$_GET['section']);
	$smarty->display('parking_configuration.tpl');
?>
