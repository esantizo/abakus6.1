$(document).addEvent('domready',function(){

});
