<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';
	include 'inc/class.upload_image.php';

	$module_name = 'repair_assignation.php';
	$thispage = 'repair_assignation.php';

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$redirect_url = $thispage;

	$users = $db->fetch_all("
		SELECT *
		FROM deliverymen AS u
		WHERE active=1
		GROUP BY u.id
		ORDER BY name
	");

	$pending_repairs = $db->fetch_all("
		SELECT r.*,p.name AS product_name
		FROM repairs AS r
		JOIN product_models AS p
			ON p.id=r.id_product
		LEFT JOIN repairs_delivery_assignations AS ra
			ON ra.id_repair=r.id
		WHERE ra.id_deliveryman IS NULL
			AND r.delivery_address != ''
	");

	if(is_array($users)) foreach($users as $k => $u){
		$users[$k]['pending_jobs'] = $db->fetch_all("
			SELECT r.*,p.name AS product_name
			FROM repairs AS r
			JOIN product_models AS p
				ON p.id=r.id_product
			JOIN repairs_delivery_assignations AS ra
				ON ra.id_repair=r.id
			WHERE ra.id_deliveryman = {$u['id']}
			ORDER BY ra.`order`ASC
		");
	}

	$smarty->assign('users',$users);
	$smarty->assign('pending_repairs',$pending_repairs);
	$smarty->assign('redirect_url',$redirect_url);

	$smarty->display('repair_delivery_assignation.tpl');
?>
