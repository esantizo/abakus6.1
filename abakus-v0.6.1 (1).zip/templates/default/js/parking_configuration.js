var validator;

function dailyScaleTypeChange(){
	var $this = $(this);
	var $parent = $this.getParent('li');

	if($this.value == 'range'){
		$parent.getFirst('input[rel="val1"]').setStyle('display','inline');
		$parent.getFirst('.daily_scale_operator').set('text','-');
	} else if($this.value == 'exact'){
		$parent.getFirst('input[rel="val1"]').setStyle('display','none');
		$parent.getFirst('.daily_scale_operator').set('text','=');
	} else if($this.value == 'lt'){
		$parent.getFirst('input[rel="val1"]').setStyle('display','none');
		$parent.getFirst('.daily_scale_operator').set('text','<');
	} else if($this.value == 'gt'){
		$parent.getFirst('input[rel="val1"]').setStyle('display','none');
		$parent.getFirst('.daily_scale_operator').set('text','>');
	}
}

function getDailyScalesData(){
	var scales = [];
	$$('#daily_scales .scale_item').each(function(el){
		if(el.getFirst('select[rel="type"]').get('value') != 'ignore'){
			var tmp = {
				val1: el.getFirst('input[rel="val1"]').get('value'),
				val2: el.getFirst('input[rel="val2"]').get('value'),
				price: el.getFirst('input[rel="price"]').get('value'),
				type: el.getFirst('select[rel="type"]').get('value')
			};
			scales.push(tmp);
		}
	});
	return scales;
}

function getShiftScalesData(){
	var scales = [];
	$$('#shift_scales .scale_item').each(function(el){
		if(el.getFirst('input[rel="name"]').get('value').length > 0){
			var tmp = {
				name: el.getFirst('input[rel="name"]').get('value'),
				day_0: (el.getFirst('input[rel="day_0"]').checked?1:0),
				day_1: (el.getFirst('input[rel="day_1"]').checked?1:0),
				day_2: (el.getFirst('input[rel="day_2"]').checked?1:0),
				day_3: (el.getFirst('input[rel="day_3"]').checked?1:0),
				day_4: (el.getFirst('input[rel="day_4"]').checked?1:0),
				day_5: (el.getFirst('input[rel="day_5"]').checked?1:0),
				day_6: (el.getFirst('input[rel="day_6"]').checked?1:0),
				time_from: el.getFirst('input[rel="time_from"]').get('value'),
				time_to: el.getFirst('input[rel="time_to"]').get('value'),
				price: el.getFirst('input[rel="price"]').get('value'),
				tolerance: el.getFirst('input[rel="tolerance"]').get('value'),
				type: el.getFirst('select[rel="type"]').get('value')
			};
			scales.push(tmp);
		};
	});
	return scales;
}

function getMonthlyScalesData(){
	var scales = [];
	$$('#monthly_scales .scale_item').each(function(el){
		if(el.getFirst('input[rel="name"]').get('value').length > 0){
			var tmp = {
				name: el.getFirst('input[rel="name"]').get('value'),
				date_from: el.getFirst('input[rel="date_from"]').get('value'),
				date_to: el.getFirst('input[rel="date_to"]').get('value'),
				price: el.getFirst('input[rel="price"]').get('value'),
				tolerance: el.getFirst('input[rel="tolerance"]').get('value')
			};
			scales.push(tmp);
		}
	});
	return scales;
}

function newDailyScale(ev){
	var $c = $('daily_scale_template').clone().unset('id');

	dailyScaleTypeChange.call($c.getFirst('select').addEvent('change',dailyScaleTypeChange));

	$c.getElements(':disabled').unset('disabled');

	$c.inject('daily_scales');

	if(ev && ev.preventDefault) ev.preventDefault();

	return $c;
}

function newShiftScale(ev){
	var $c = $('shift_scale_template').clone().unset('id');

	$c.getFirst('.scale_item_delete').addEvent('click',function(){ $(this).getParent('li').destroy(); });

	$c.getElements(':disabled').unset('disabled');

	$c.inject('shift_scales');

	if(ev && ev.preventDefault) ev.preventDefault();

	return $c;
}

function newMonthlyScale(ev){
	var $c = $('monthly_scale_template').clone().unset('id');

	$c.getFirst('.scale_item_delete').addEvent('click',function(){ $(this).getParent('li').destroy(); });

	$c.getElements(':disabled').unset('disabled');

	$c.inject('monthly_scales');

	if(ev && ev.preventDefault) ev.preventDefault();

	return $c;
}

function loadDailyScales(data){
	if(data && data.length > 0){
		for(var i=0,len=data.length; i<len; i++){
			var $d = data[i];
			var $el = newDailyScale();
			$el.getFirst('select[rel="type"]').setSelected($d.type);
			$el.getFirst('input[rel="val1"]').set('value',$d.val1);
			$el.getFirst('input[rel="val2"]').set('value',$d.val2);
			$el.getFirst('input[rel="price"]').set('value',$d.price);
			dailyScaleTypeChange.call($el.getFirst('select'));
		}
	}
}

function loadShiftScales(data){
	if(data && data.length > 0){
		for(var i=0,len=data.length; i<len; i++){
			var $d = data[i];
			var $el = newShiftScale();
			$el.getFirst('input[rel="name"]').set('value',$d.name);
			$el.getFirst('input[rel="day_0"]').set('checked',$d.day_0);
			$el.getFirst('input[rel="day_1"]').set('checked',$d.day_1);
			$el.getFirst('input[rel="day_2"]').set('checked',$d.day_2);
			$el.getFirst('input[rel="day_3"]').set('checked',$d.day_3);
			$el.getFirst('input[rel="day_4"]').set('checked',$d.day_4);
			$el.getFirst('input[rel="day_5"]').set('checked',$d.day_5);
			$el.getFirst('input[rel="day_6"]').set('checked',$d.day_6);
			$el.getFirst('input[rel="time_from"]').set('value',$d.time_from);
			$el.getFirst('input[rel="time_to"]').set('value',$d.time_to);
			$el.getFirst('input[rel="price"]').set('value',$d.price);
			$el.getFirst('input[rel="tolerance"]').set('value',$d.tolerance);
			$el.getFirst('select[rel="type"]').setSelected($d.type);
			dailyScaleTypeChange.call($el.getFirst('select'));
		}
	}
}

function loadMonthlyScales(data){
	if(data && data.length > 0){
		for(var i=0,len=data.length; i<len; i++){
			var $d = data[i];
			var $el = newMonthlyScale();
			$el.getFirst('input[rel="name"]').set('value',$d.name);
			$el.getFirst('input[rel="date_from"]').set('value',$d.date_from);
			$el.getFirst('input[rel="date_to"]').set('value',$d.date_to);
			$el.getFirst('input[rel="price"]').set('value',$d.price);
			$el.getFirst('input[rel="tolerance"]').set('value',$d.tolerance);
		}
	}
}

function cleanFormErrors(){
	$$('.hasError').removeClass('hasError');
	$$('.error_indicator').each(function(el){
		el.destroy();
	});
}

function setErrorIndicator(err){
	cleanErrorIndicator(err);
	if(!err.isValid){
		createErrorIndicator(err);
	}
}

function cleanErrorIndicator(err){
	for(var j=0,len2=err.affected_elements.length; j<len2; j++){
		if($(err.affected_elements[j])) $(err.affected_elements[j]).removeClass('hasError');
	}
	var parent = $(err.element).getParent();
	parent.getElements('.error_indicator').each(function(el){
		el.destroy();
	});
}

function createErrorIndicator(err){
	for(var j=0,len2=err.affected_elements.length; j<len2; j++){
		if($(err.affected_elements[j])) $(err.affected_elements[j]).addClass('hasError');
	}
	var parent = $(err.element).getParent();
	if(!parent.getFirst('.error_indicator')){
		parent.adopt(
			new Element('span',{
				'rel': 'error_indicator',
				'class': 'error_indicator',
				'title': err.message
			}).adopt(new Element('img',{ 'src':'##IMG_WARNING_ICON##', 'width':16, 'height':16 }))
		);
	}
}

function checkForm(){
	cleanFormErrors();
	validator.check();
	if(validator.valid == true){
		return true;
	} else {
		for(var i=0,len=validator.errors.length; i<len; i++){
			var err = validator.errors[i];
			createErrorIndicator(err);
		}
		setFocus($(document).getFirst('.hasError'));
	}
}

function saveForm(ev){
	if(!checkForm()){
		msgBox('##NG_PLEASE_FIX_THE_ERRORS##');
		return false;
	}

	var dailyScalesData = getDailyScalesData();
	new Element('input',{ 'type': 'hidden', 'name': 'parking_daily_scales', 'value': JSON.stringify(dailyScalesData) }).inject($$('.controls')[0]);

	var shiftScalesData = getShiftScalesData();
	new Element('input',{ 'type': 'hidden', 'name': 'parking_shift_scales', 'value': JSON.stringify(shiftScalesData) }).inject($$('.controls')[0]);

	var monthlyScalesData = getMonthlyScalesData();
	new Element('input',{ 'type': 'hidden', 'name': 'parking_monthly_scales', 'value': JSON.stringify(monthlyScalesData) }).inject($$('.controls')[0]);

	$(this).getParent('form').submit();
	return false;
}

$(document).addEvent('domready',function(){
	validator = new Validator();
	$('new_daily_scale').addEvent('click',function(ev){ newDailyScale(ev); validator.scan(); });
	$('new_shift_scale').addEvent('click',function(ev){ newShiftScale(ev); validator.scan(); });
	$('new_monthly_scale').addEvent('click',function(ev){ newMonthlyScale(ev); validator.scan(); });

	loadDailyScales(dailyScalesData);
	loadShiftScales(shiftScalesData);
	loadMonthlyScales(monthlyScalesData);
	validator.scan(null,{
		'applyEventsToAffectedElements':true,
		'events':{
			'blur': function(){
				var err = this.validate();
				setErrorIndicator(err);
			}
		}
	});
});
