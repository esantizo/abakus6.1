<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'credit_note_details.php';

	$module_name = 'credit_notes';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	$cnid = (int)$_GET['id'];

	$sql = "
		SELECT i.*,
			CONCAT_WS(' ',c.symbol,i.subtotal) AS subtotal,
			CONCAT_WS(' ',c.symbol,i.total) AS total,
			u.name AS salesman,
			tc.name AS tax_condition,
			pt.name AS payment_type,
			ps.name AS price_scale,
			c.symbol,
			IF(LENGTH(i.client_postcode)>0,CONCAT('(',i.client_postcode,') ',i.client_city),i.client_city) AS client_city,
			it.name AS invoice_type,
			q.number AS invoice_number
		FROM credit_notes AS i
		LEFT JOIN users AS u
			ON u.id=i.salesman
		LEFT JOIN tax_conditions AS tc
			ON tc.id=i.id_tax_condition
		LEFT JOIN payment_types AS pt
			ON pt.id=i.id_payment_type
		LEFT JOIN price_scales AS ps
			ON ps.id=i.id_price_scale
		JOIN currency AS c
			ON c.id=i.id_currency
		JOIN invoice_types AS it
			ON i.invoice_type=it.id
		LEFT JOIN invoices AS q
			ON q.id=i.id_invoice
		WHERE i.id=$cnid
	";
	$credit_note = $db->fetch_item($sql);

	switch($_GET['return']){
		case 'account': $return_url = "account.php?id_client={$credit_note['client_id']}"; break;
		default: $return_url = return_to_module_url($module_name);
	}

	if($_GET['delete']=='1' && $_GET['reallysure']=='1' && $invoice){
		$db->delete("DELETE FROM credit_note_items WHERE id_invoice={$credit_note['id']}");
		$db->delete("DELETE FROM credit_note WHERE id={$credit_note['id']}");
		$db->delete("DELETE FROM accounts WHERE type='invoice' && id_item={$credit_note['id']}");

		$account = $db->fetch_all("SELECT * FROM accounts WHERE id_client={$credit_note['id_client']} ORDER BY `date`, id");

		// Update account balances
		$balance = 0;
		if(is_array($account)) foreach($account as $movement){
			$balance -= ($movement['credit'] + $movement['debit']);
			$db->update("UPDATE accounts SET balance='$balance' WHERE id={$movement['id']}");
		}
		if($_GET['return_url']){
			redirect(urldecode($_GET['return_url']));
		} else {
			return_to_module_url($module_name);
		}
	}

	if($credit_note){
		$credit_note_items = $db->fetch_all("
			SELECT *, IF(reference LIKE '0','&nbsp;',reference) AS reference, CONCAT('<span class=\"symbol\">{$credit_note['symbol']}</span> ',price) AS price,CONCAT('<span class=\"symbol\">{$credit_note['symbol']}</span> ',total) AS total
			FROM credit_note_items
			WHERE id_credit_note={$credit_note['id']}
			ORDER BY id
		");
	} else {
		$error = __("##NG_INCORRECT_INVOICE_ID##");
	}

	$taxes = parseTaxes($credit_note['taxes']);

	$smarty->assign('credit_note',$credit_note);
	$smarty->assign('credit_note_items',$credit_note_items);
	$smarty->assign('taxes',$taxes);
	$smarty->assign('double_confirm_delete',$user_preferences['double_confirm_delete']);
	$smarty->assign('return_url',$return_url);

	$smarty->display('credit_note_details.tpl');
?>
