<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'payments.php';

	$module_name = 'payments';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	$payment_id = (int)$_REQUEST['id'];

	$return = 'search';
	if($_GET['return']) $return = $_GET['return'];

	$currencies = $db->fetch_all("SELECT * FROM currency ORDER BY id",false,'id');

	if($payment_id){
		$payment = $db->fetch_item("SELECT * FROM payments WHERE id=$payment_id");
		if($payment){
			$id_provider = (int)$payment['id_provider'];
			$checks = $db->fetch_all("SELECT c.* FROM payment_checks AS rc JOIN checks AS c ON c.id=rc.id_check WHERE rc.id_payment={$payment['id']}");
			$invoices = $db->fetch_all("
				SELECT p.*,pi.amount FROM payment_invoices AS pi JOIN purchases AS p ON p.id=pi.id_invoice WHERE pi.id_payment={$payment['id']}
			");
			foreach($invoices as $k => $i){
				$invoices[$k]['number'] = sprintf($config['invoice_number_format'],$i['number']);
				$invoices[$k]['date'] = fecha($i['date']);
				$invoices[$k]['symbol'] = $currencies[$i['id_currency']]['symbol'];
			}

			$provider = $db->fetch_item("SELECT * FROM providers WHERE id={$payment['id_provider']}");
			$symbol = $currencies[$payment['payment_currency']]['symbol'];
			$currency = (int)$currencies[$payment['payment_currency']]['id'];
		}
	}

	switch($_GET['return']){
		case 'account': $return_url = "account.php?id_provider={$provider['id']}"; break;
		case 'invoice': $return_url = "invoice_details.php?id=".(int)$_GET['id_invoice']; break;
		default: $return_url = return_to_module_url($module_name);
	}

	if((int)$_GET['id'] > 0 && $_GET['delete']==1 && $_GET['reallysure']==1){
		$module->deleteElement($_GET['id']);
		redirect($return_url);
	}

	$number = (int)$db->fetch_item_field("SELECT number FROM payments ORDER BY number DESC LIMIT 1") + 1;
	$banks = $db->fetch_all("SELECT * FROM bank_entities ORDER BY name");

	$smarty->assign('return_url',$return_url);
	$smarty->assign('provider',$provider);
	$smarty->assign('payment',$payment);
	$smarty->assign('currencies',$currencies);
	$smarty->assign('checks',$checks);
	$smarty->assign('symbol',$symbol);
	$smarty->assign('invoices',$invoices);
	$smarty->assign('double_confirm_delete',$user_preferences['double_confirm_delete']);

	$smarty->display('payment_details.tpl');
?>