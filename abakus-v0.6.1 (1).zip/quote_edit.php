<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$id = (int)$_GET['id'];
	$thispage = "quote_edit.php?id=$id";

	$module_name = 'quotes';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	if((int)$_GET['id'] > 0){
		$quote = $db->fetch_item("
			SELECT q.*,
				tc.name AS client_tax_condition,
				pt.name AS client_payment_type,
				cur.symbol AS currency_symbol,
				cur.name AS currency_name,
				u.name AS salesman_name,
				u.discount_limit AS salesman_discount_limit
			FROM quotes AS q
			JOIN currency AS cur
				ON cur.id=q.id_currency
			JOIN users AS u
				ON u.id=q.salesman
			LEFT JOIN tax_conditions AS tc
				ON tc.id=q.id_tax_condition
			LEFT JOIN payment_types AS pt
				ON pt.id=q.id_payment_type
			WHERE q.id=$id
		");
		$quote_items = $db->fetch_all("SELECT * FROM quote_items WHERE id_quote={$quote['id']} ORDER BY id");
	}

	if(!$quote) die('error');

	if($_POST['save']){
    $number = (int)$_POST['number'];
    $date = date2db($_POST['date'],$date_format);
    $salesman = (int)$_POST['salesman'];
    $client = (int)$_POST['client'];
    $client_name = $db->escape_string($_POST['client_name']);
    $client_address = $db->escape_string($_POST['client_address']);
    $client_taxpayer_id = $db->escape_string($_POST['client_taxpayer_id']);
    $client_city = $db->escape_string($_POST['client_city']);
    $client_state = $db->escape_string($_POST['client_state']);
    $client_country = $db->escape_string($_POST['client_country']);
    $client_postcode = $db->escape_string($_POST['client_postcode']);
    $client_tax_condition = (int)$_POST['client_tax_condition'];
    $client_payment_type = (int)$_POST['client_payment_type'];
    $client_price_scale = (int)$_POST['client_price_scale'];
    $id_currency = (int)$_POST['currency'];

    $currencies = stringifyCurrencies($_POST['currency_rates']);

    $subtotal = float($_POST['subtotal']);
    if(is_array($_POST['total_taxes'])){
			foreach($_POST['total_taxes'] as $t => $v){
				$taxes_array[] = float($t).":".float($v);
			}
			$taxes = implode('|',$taxes_array);
		}
    $total = float($_POST['total']);
    $discount = float($_POST['discount']);
    $quote_duration = $db->escape_string($_POST['quote_duration']);
    $notes = $db->escape_string($_POST['notes']);

    // The invoice has items
    if(is_array($_POST['ref'])){
			$quote_id = $db->insert("
				UPDATE quotes SET
					number='$number',
					date='$date',
					salesman='$salesman',
					client_id='$client',
					client_name='$client_name',
					client_address='$client_address',
					client_taxpayer_id='$client_taxpayer_id',
					client_city='$client_city',
					client_state='$client_state',
					client_country='$client_country',
					client_postcode='$client_postcode',
					id_tax_condition='$client_tax_condition',
					id_payment_type='$client_payment_type',
					id_price_scale='$client_price_scale',
					id_currency='$id_currency',
					currencies='$currencies',
					subtotal='$subtotal',
					taxes='$taxes',
					discount='$discount',
					total='$total',
					quote_duration='$quote_duration',
					notes='$notes'
				WHERE id={$quote['id']}
			");
			$db->delete("DELETE FROM quote_items WHERE id_quote={$quote['id']}");
			foreach($_POST['ref'] as $k => $ref){
				$product_id = (int)$_POST['product_id'][$k];
				$ref = $db->escape_string($ref);
				$desc = $db->escape_string($_POST['desc'][$k]);
				$qty = $db->escape_string($_POST['qty'][$k]);
				$price = $db->escape_string($_POST['price'][$k]);
				$tax = $db->escape_string($_POST['tax'][$k]);
				$item_total = $db->escape_string($_POST['item_total'][$k]);
				$db->insert("
					INSERT INTO quote_items SET
						id_quote={$quote['id']},
						id_product=$product_id,
						reference='$ref',
						description='$desc',
						quantity='$qty',
						price='$price',
						tax='$tax',
						total='$item_total'
				");
			}
			redirect("quote_details.php?id={$quote['id']}");

		}

		// The invoice doesn't have any item
		else {
		}
		//print_pre($_POST);
		die();
	}

	$client = $db->fetch_all("SELECT * FROM clients WHERE id='{$quote['client_id']}'");

	$tax_values = $db->fetch_all("SELECT percentage FROM taxes ORDER BY percentage",'percentage');
	$currency = $db->fetch_all("SELECT * FROM currency ORDER BY rate");
	$quote_currency = array();
	$tmp = explode('|',$quote['currencies']);
	if(is_array($tmp)) foreach($tmp as $t){
		list($id,$val) = explode(":",$t);
		$quote_currency[$id] = $val;
	}
	unset($tmp);

	if($client){
		$price_scale = $db->fetch_item("SELECT id,name FROM price_scales WHERE id={$client['id_price_scale']} LIMIT 1");
	}
	if(!$price_scale) {
		$price_scale = $db->fetch_item("SELECT id,name FROM price_scales ORDER BY `default` DESC,id DESC LIMIT 1");
	}

	if($quote['discount'] > 0){
		$discount_p = round($quote['discount'] * 100 / ($quote['total']+$quote['discount']),4);
	}

	switch($config['invoice_search_field']){
		case 'internal_code': $first_field = __("Internal Code"); break;
		case 'manufacturers_code': $first_field = __("Manufacturers Code"); break;
		default: $first_field = __("Reference");
	}

	$smarty->assign('quote',$quote);
	$smarty->assign('price_scale',$price_scale);
	$smarty->assign('currency',$currency);
	$smarty->assign('discount',$discount_p);
	$smarty->assign('quote_items',$quote_items);
	$smarty->assign('tax_values',implode(',',$tax_values));
	$smarty->assign('ignore_stock',($config['ignore_stock']?1:0));
	$smarty->assign('first_field',$first_field);

	$smarty->display('quote_edit.tpl');
?>
