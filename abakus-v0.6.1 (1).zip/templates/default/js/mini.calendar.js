(function(){

window.Calendar = function(container,options){
	var container = $(container);
	var self = $(this);
	var defaultOptions = {
		onDayClick: null
	};
	self.options = merge(defaultOptions,options);

	var loading = false;
	self.loaded = false;
	var must_render = false;

	var calendar_data = null;

	var initialize = function(){
		$$('.calendar .day').addEvent('click',function(){
			if(typeof self.options.onDayClick == 'function'){
				var calendar_data = null;
				if(this.hasClass('disabled')){
					calendar_data = {
						'disabled': 1
					}
				} else {
					calendar_data = {
						'date': this.getData('date'),
						'month': this.getData('month'),
						'year': this.getData('year')
					}
				}
				self.options.onDayClick.call(self,this,calendar_data);
			}
			return false;
		});
	}

	self.load = function(month,year,day){
		loading = true;
		new Request({
			'url': 'ajax/calendar.php',
			'method': 'get',
			'data': { 'month':month, 'year':year, 'day': day, 'format':'json' },
			'onSuccess': function(res){
				if(res && res.substr(0,1)=='{'){
					calendar_data = parseJSON(res);
					self.loaded = true;
					loading = false;
					//if(must_render){
						self.render();
					//}
				}
			}
		});

		return self;
	}

	self.render = function(){
		if(container){
			container.empty();

			if(!self.loaded){
				must_render = true;
				if(!loading){
					self.load();
				}
				return;
			}

			if(!calendar_data) return;

			var head = new Element('div',{ 'class':'month_container' })
				.adopt(new Element('a', { 'class':'prev_month' }).addEvent('click',function(){ self.load(calendar_data.prev_month,calendar_data.prev_year); }))
				.adopt(new Element('span', { 'class':'month', 'text': calendar_data.month_name + ', ' + calendar_data.year }))
				.adopt(new Element('a', { 'class':'next_month' }).addEvent('click',function(){ self.load(calendar_data.next_month,calendar_data.next_year); }));

			var days_names = new Element('div',{ 'class':'weekdays' });
			for(var i=0,len=calendar_data.days_names.length; i<len;i++) {
				days_names.adopt(new Element('span',{ 'class':'dayname', 'text': calendar_data.days_names[i] }));
			};

			var body = new Element('div',{ 'class':'days' });

			var weekn = 0;
			var week_row = null;

			for(var i=0,len=calendar_data.days.length; i<len; i++){
				var day = calendar_data.days[i];
				var day_cell = null;
				if(day.week != weekn){
					if(week_row){
						week_row.inject(body);
					}
					weekn = day.week;
					week_row = new Element('div', { 'class':'days_row' });
				}

				if(!day.in_current_month){
					day_cell = new Element('span', { 'class':'day disabled', 'text': day.date });
					if(day.month < calendar_data.month){
						day_cell.addEvent('click',function(){ self.load(calendar_data.prev_month,calendar_data.prev_year); })
					} else {
						day_cell.addEvent('click',function(){ self.load(calendar_data.next_month,calendar_data.next_year); })
					}
				} else {
					day_cell = new Element('a', {
						'class':'day',
						'href':'javascript:;',
						'text': day.date,
						'data-date': day.date,
						'data-month': day.month,
						'data-year': day.year
					});
					if(day.is_today){
						day_cell.addClass('current');
					}
					if(day.is_selected){
						day_cell.addClass('selected');
					}
				}

				week_row.adopt(day_cell);
			}
			if(week_row){
				week_row.inject(body);
			}

			container.adopt(head).adopt(days_names).adopt(body);

			initialize();
		}
		must_render = false;

		return self;
	}

	self.load();

	return self;
}

})();
