var mapLightbox;
var map;

function generateSerial(){
	new Request({
		'url':'ajax/generate_serial.php',
		'method':'post',
		'onRequest': function(){
			$('serial_number_container').startWaiting();
		},
		'onSuccess': function(res){
			$('serial_number_container').stopWaiting();
			if(res.substr(0,2)=='OK'){
				$('serial_number').value = serial_number_prefix+res.substr(3).lpad('0',8);
			}
		}
	});
}

function cancel(){
	if(confirmBox(html_entity_decode('##NG_CANCEL_CONFIRMATION##'))){
		location.href=redirect_url;
	}
}

function cleanFormErrors(){
	$$('.hasError').removeClass('hasError');
	$$('.error_indicator').each(function(el){
		el.destroy();
	});
}

function setErrorIndicator(err){
	cleanErrorIndicator(err);
	if(!err.isValid){
		createErrorIndicator(err);
	}
}

function cleanErrorIndicator(err){
	for(var j=0,len2=err.affected_elements.length; j<len2; j++){
		if($(err.affected_elements[j])) $(err.affected_elements[j]).removeClass('hasError');
	}
	var parent = $(err.element).getParent();
	parent.getElements('.error_indicator').each(function(el){
		el.destroy();
	});
}

function createErrorIndicator(err){
	for(var j=0,len2=err.affected_elements.length; j<len2; j++){
		if($(err.affected_elements[j])) $(err.affected_elements[j]).addClass('hasError');
	}
	var parent = $(err.element).getParent();
	if(!parent.getFirst('.error_indicator')){
		parent.adopt(
			new Element('span',{
				'rel': 'error_indicator',
				'class': 'error_indicator',
				'title': err.message
			}).adopt(new Element('img',{ 'src':'##IMG_WARNING_ICON##', 'width':16, 'height':16 }))
		);
	}
}

function checkForm(){
	cleanFormErrors();
	validator.check();
	if(validator.valid == true){
		return true;
	} else {
		for(var i=0,len=validator.errors.length; i<len; i++){
			var err = validator.errors[i];
			createErrorIndicator(err);
		}
		setFocus($(document).getFirst('.hasError'));
	}
}

function save(isNew){
	if(checkForm()){
		if(isNew) $('next').value = 'new';
		uploadAndSubmit();
	}
}

function keyboardListener(ev){
	if(calculator && calculator.opened) return false;
	if(ev.keyCode==27){ // Esc key
		if(!search_product.opened && !search_client.opened && !search_notes.opened){
			cancel();
		}
	} else if(ev.keyCode==83 && ev.ctrlKey){ //CTRL+S
		save();
		if(ev.cancelBubble) ev.cancelBubble();
		if(ev.preventDefault) ev.preventDefault();
	}
}

function viewInMap(el){
	if(!mapLightbox || !mapLightbox.opened){
		var el = $(el);
		$('map_container').setStyles({
			width : 800,
			height: 'auto'
		});
		$('map_canvas').setStyles({
			width : 800,
			height : 500
		});
		$('current_address').set('text',el.get('value'));
		$('new_address_input').set({
			'value':el.get('value'),
			'data-original-input': el.get('id')
		});
		mapLightbox = new Lightbox('map_container',{
			'autoposition':true,
			'focusOnClose':el,
			'onClose':function(){
				$('map_canvas').empty();
				delete map;
				map = null;
			},
			'closeButton':true,
			'overlay': true
		}).open();

		map = new gMaps({
			'map_canvas': 'map_canvas',
			'region':'AR',
			'language':'es',
			'mapStartPosition': 'mar del plata, argentina',
			'mapStartZoom': 10,
			'panControl': false,
			'zoomControl': true,
			'mapTypeControl': true,
			'scaleControl': true,
			'streetViewControl': false,
			'overviewMapControl': false,
			'onLoadedMarkers': function(){
				this.map.setZoom(16);
			},
			'markerEvents': {
				'dragend': function(){
					var myData = { 'location': this.getPosition() };
					map.geocoder.geocode(myData, function(result,index){
						$('new_address_input').set('value',result[0].formatted_address);
					});
				}
			}
		}).renderMap().loadMarkers([ { 'address':el.get('value'), 'visible':true, 'draggable': true } ]);
	}
}

function updateAddress(){
	var orig = $($('new_address_input').getData('original-input'));
	if(orig){
		orig.set('value',$('new_address_input').get('value'));
	}
	$('new_address_input').set('value','');
	closeMap();
}

function closeMap(){
	mapLightbox.close();
}

$(document).addEvent('domready',function(){
	window.validator = new Validator({
		'dateFormat': date_format,
		'dateTimeFormat': datetime_format
	}).scan('add_fields_form',{
		'applyEventsToAffectedElements':true,
		'events':{
			'blur': function(){
				var err = this.validate();
				setErrorIndicator(err);
			}
		}
	});

	var search_product = new SearchItemsBox({
		requestUrl: 'ajax/search_model.php',
		newItemUrl: 'add.php?module=product_models',
		returnField: 'id',
		returnContainer: 'id_product',
		secondaryField: 'name',
		secondaryFieldContainer: 'product_name',
		defaultValueContainer: 'product_name',
		fields: [ 'id','reference','name','short_description','stock' ],
		bindInputEvents: [ 'id_product' ],
		bindButtonEvents: [ 'search_item_icon' ],
		onClose: function(error){
			var el = $('product_checked');
			if(!error){
				el.value = '1';
				$('id_product').set('rel',$('id_product').value);
				setFocus('serial_number');
			} else {
				el.value = '0';
				$('id_product').value = '';
				setFocus('id_product');
			}
			setErrorIndicator(el.validate());
		}
	});

	var search_client = new SearchItemsBox({
		requestUrl: 'ajax/search_client.php',
		newItemUrl: 'clients.php?iframe=1',
		returnField: 'id',
		returnContainer: 'id_client',
		secondaryField: 'name',
		secondaryFieldContainer: 'client_name',
		defaultValueContainer: 'client_name',
		fields: [ 'id','name','taxpayer_id','address','city','postcode' ],
		bindInputEvents: [ 'id_client' ],
		bindButtonEvents: [ 'search_client_icon' ],
		onSelect: function(res){
			var address = res.address+', '+res.city+', '+res.country;
			$('home_delivery_address').value = address;
			$('home_pickup_address').value = address;
			$('contact_container').set('display','none');
			$('contact').empty();
			new Request({
				'url':'ajax/get_contacts.php',
				'method':'post',
				'data': { 'type':'client', 'id': res.id },
				'onSuccess': function(response){
					if(response.length){
						var res = parseJSON(response);
						if(res.length){
							for(var i=0,len=res.length;i<len;i++){
								$('contact').adopt(new Element('option',{ 'text':res[i].name, 'value': res[i].id }));
							}
							$('contact_container').set('display','block');
						}
					}
				}
			});
		},
		onClose: function(error){
			var el = $('client_checked');
			if(!error){
				el.value = '1';
				$('id_client').set('rel',$('id_client').value);
				setFocus('contact');
			} else {
				el.value = '0';
				$('id_client').value = '';
				setFocus('id_client');
			}
			setErrorIndicator(el.validate());
		}
	});

	var search_notes = new SearchItemsBox({
		requestUrl: 'ajax/search_notes.php?json=1',
		returnField: 'id',
		returnContainer: null,
		secondaryField: null,
		secondaryFieldContainer: null,
		defaultValueContainer: null,
		fields: [ 'id','name' ],
		bindButtonEvents: [ 'search_notes_btn' ],
		onSelect: function(res){
			var text = '';
			if($('notes').value.length){
				text = $('notes').value + "\n\n";
			}
			text += res.text;
			$('notes').set('text', text);
		}
	});

	$(window).addEvent('keydown',keyboardListener);

	if($('id_product')) $('id_product').addEvent('blur',function(){
		if(this.get('rel') && $('product_checked').value == '1'){
			this.value = this.get('rel');
		}
	});

	if($('id_client')) $('id_client').addEvent('blur',function(){
		if(this.get('rel') && $('client_checked').value == '1'){
			this.value = this.get('rel');
		}
	});

	$$('#home_delivery,#home_pickup,#warranty').each(function(e){
		var rel_els = e.getData('related').split(',');
		e.addEvents({
			'change':function(){
				for(var i=0,len=rel_els.length; i<len; i++){
					var el = $(rel_els[i]);
					if(!el) return;
					if(this.checked){
						e.set('checked',true);
						if(el.disabled == undefined){
							el.setStyle('display','inline')
						} else {
							el.unset('disabled');
						}
					} else {
						if(el.disabled == undefined){
							el.setStyle('display','none')
						} else {
							el.set('disabled',true);
						}
					}
				}
			}
		});

		for(var i=0,len=rel_els.length; i<len; i++){
			var el = $(rel_els[i]);
			if(!el) continue;
			if($(rel_els[0]).value != ''){
				e.set('checked',true);
				if(el.disabled == undefined){
					el.setStyle('display','inline')
				} else {
					el.unset('disabled');
				}
			} else {
				if(el.disabled == undefined){
					el.setStyle('display','none')
				} else {
					el.set('disabled',true);
				}
			}
		}
	});

	$('quote_generated').addEvent('change', function(){
		var checked = this.checked;
		$$('.quote_generation_dependant').each(function(el){
			if(checked){
				el.setStyle('display','block');
			} else {
				el.setStyle('display','none');
			}
		});
	});

	$('quote_accepted').addEvent('change', function(){
		var checked = this.checked;
		$$('.quote_acceptance_dependant').each(function(el){
			if(checked){
				el.setStyle('display','block');
			} else {
				el.setStyle('display','none');
			}
		});
	});

	var checked = $('quote_generated').checked;
	$$('.quote_generation_dependant').each(function(el){
		if(checked){
			el.setStyle('display','block');
		} else {
			el.setStyle('display','none');
		}
	});

	var checked = $('quote_accepted').checked;
	$$('.quote_acceptance_dependant').each(function(el){
		if(checked){
			el.setStyle('display','block');
		} else {
			el.setStyle('display','none');
		}
	});

});
