<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'dispatch_note_details.php';

	$module_name = 'dispatch_notes';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	$qid = (int)$_GET['id'];

	$sql = "
		SELECT q.*,
			u.name AS salesman
		FROM dispatch_notes AS q
		JOIN users AS u
			ON u.id=q.salesman
		WHERE q.id=$qid
	";
	$dispatch_note = $db->fetch_item($sql);

	if($_GET['delete']=='1' && $_GET['reallysure']=='1' && $dispatch_note){
		if(!$dispatch_note['from_invoice']){
			$db->delete("DELETE FROM products_stock WHERE relation='dispatch_note|{$dispatch_note['id']}'");
		}
		$db->delete("DELETE FROM dispatch_note_items WHERE id_dispatch_note={$dispatch_note['id']}");
		$db->delete("DELETE FROM dispatch_notes WHERE id={$dispatch_note['id']}");
		return_to_module($module_name);
	}

	if($dispatch_note){
		$dispatch_note_items = $db->fetch_all("
			SELECT *,
				IF(LENGTH(reference)>0,reference,'&nbsp;') AS reference
			FROM dispatch_note_items
			WHERE id_dispatch_note={$dispatch_note['id']}
			ORDER BY id
		");
		print $db->error();

		$dispatch_note['number'] = str_pad($dispatch_note['number'],8,'0',STR_PAD_LEFT);
	} else {
		$error = __("##NG_INCORRECT_DISPATCH_NOTE_ID##");
	}

	$taxes = parseTaxes($dispatch_note['taxes']);

	$return_url = return_to_module_url($module_name);

	$smarty->assign('dispatch_note',$dispatch_note);
	$smarty->assign('dispatch_note_items',$dispatch_note_items);
	$smarty->assign('double_confirm_delete',$user_preferences['double_confirm_delete']);
	$smarty->assign('return_url',$return_url);

	$smarty->display('dispatch_note_details.tpl');
?>