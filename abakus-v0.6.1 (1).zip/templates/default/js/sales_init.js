if(typeof ask_price_change == 'undefined'){
	var ask_price_change = 0;
}

$(document).addEvent('domready',function(){

	$('client').addEvent('keydown',function(ev){
		if(ev.keyCode==13){
			if(this.value===0 || this.value==='0') {
				var price_scale_name = $('default_price_scale').get('alt');
				var price_scale_value = $('default_price_scale').value;

				$('client').set('rel',0);
				$('client_name_input').value='';
				$('client_address_input').value='';
				$('client_city_input').value='';
				$('client_state_input').value='';
				$('client_country_input').value='';
				$('client_taxpayer_id_input').value='';
				$('client_tax_condition_input').value='';
				$('client_payment_type_input').value='';
				$('client_price_scale_input').value = price_scale_value;

				$('client_name').set('text','');
				$('client_address').set('text','');
				$('client_city').set('text','');
				$('client_state').set('text','');
				$('client_country').set('text','');
				$('client_taxpayer_id').set('text','');
				$('client_tax_condition').set('text','');
				$('client_payment_type').set('text','');
				$('client_price_scale').set('text',price_scale_name);

				$('client_name_input').set('type','text');
				$('client_address_input').set('type','text');
				$('client_city_input').set('type','text');
				$('client_state_input').set('type','text');
				$('client_country_input').set('type','text');
				$('client_taxpayer_id_input').set('type','text');

				$('client_tax_condition_select').setStyle('display','inline');
				$('client_payment_type_select').setStyle('display','inline');

				$('client_tax_condition_input').set('name','');
				$('client_tax_condition_select').set('name','client_tax_condition');

				$('client_payment_type_input').set('name','');
				$('client_payment_type_select').set('name','client_payment_type');

				$('invoice_table').setStyle('display','block');
			} else if(!isNaN(this.value)){
				$('client_name_input').value='';
				$('client_address_input').value='';
				$('client_city_input').value='';
				$('client_state_input').value='';
				$('client_country_input').value='';
				$('client_taxpayer_id_input').value='';
				$('client_tax_condition_input').value='';
				$('client_payment_type_input').value='';
				$('client_price_scale_input').value = '';

				$('client_name').set('text','');
				$('client_address').set('text','');
				$('client_city').set('text','');
				$('client_state').set('text','');
				$('client_country').set('text','');
				$('client_taxpayer_id').set('text','');
				$('client_tax_condition').set('text','');
				$('client_payment_type').set('text','');
				$('client_price_scale').set('text','');

				$('client_name_input').set('type','hidden');
				$('client_address_input').set('type','hidden');
				$('client_city_input').set('type','hidden');
				$('client_state_input').set('type','hidden');
				$('client_country_input').set('type','hidden');
				$('client_taxpayer_id_input').set('type','hidden');
				$('client_tax_condition_select').setStyle('display','none');
				$('client_payment_type_select').setStyle('display','none');

				$('client_tax_condition_input').set('name','client_tax_condition');
				$('client_tax_condition_select').set('name','');

				$('client_payment_type_input').set('name','client_payment_type');
				$('client_payment_type_select').set('name','');

				$('invoice_table').setStyle('display','none');
				//~ if(this.value===''){
					//~ openSearchClientBox();
				//~ } else {
					//~ searchClient(this.value);
				//~ }
			//~ } else {
				//~ openSearchClientBox();
			}
		}
	});/*.addEvent('blur',function(){
		if(!isNaN(this.get('rel')))
			this.value = this.get('rel');
	});*/

	$("ref_input").addEvent('keydown',function(ev){
		if(ev.keyCode==13){
			if(this.value==='0' || this.value===0){
				var cols = $(this.getParent('tr')).getElements('td');
				$(cols[5]).empty();
				var sel = new Element('select',{'id':'tax_select'})
					.addEvents({
						'keydown': function(ev){if(ev.keyCode==13){itemOk();}}
					})
					.inject(cols[5]);
				var opt = new Element('option',{'text':''}).inject(sel);
				for(i in tax_values){
					if(!isNaN(tax_values[i]))
						opt = new Element('option',{'text':tax_values[i]+'%'}).inject(sel);
				}
				$("qty_input").value = 1;
				$("unit_price").value = 0;
				$("unit_price").set('rel','');
				unlockDescription();
				lockCurrency();
				setFocus("desc_input");
				$('desc_input').select();
			} else if(this.value===''){
				openSearchItemBox();
			} else {
				searchItem();
			}
		}
	});

	$("desc_input").addEvent('keydown',function(ev){
		if(ev.keyCode==13){
			setFocus("qty_input");
			$("qty_input").select();
		}
	});

	if($('invoice_type')){
		changeInvoiceType($('invoice_type').getSelected().get('data-separates-taxes'));
		$('invoice_type').addEvent('change',function(){changeInvoiceType($('invoice_type').getSelected().get('data-separates-taxes'))});
	}

	if($('discriminate_taxes')){
		changeInvoiceType(($('discriminate_taxes').checked?1:0));
		$('discriminate_taxes').addEvent('change',function(){changeInvoiceType(($('discriminate_taxes').checked?true:false))});
	}

	$("qty_input").addEvent('keydown',function(ev){
		if(discriminate_taxes){
			var price_field = 'unit_price';
		} else {
			var price_field = 'unit_price_taxed';
		}
		quantityHandler(ev,'stock_input','selected_stock','qty_input',price_field);
	});

	$("unit_price").addEvent('keydown',function(ev){
		if(ev.keyCode==13){
			if($('tax_select')){
				setFocus("tax_select");
			} else {
				var c = $('curr_input').value;
				var val = this.get('alt');
				if(c != $('currency').value){
					var currency_mult = $('curr_'+c).value.toFloat() / $('curr_'+$('currency').value).value.toFloat();
					var val = (val * currency_mult).round(4);
				}
				if(ask_price_change && this.value.toFloat() != val.toFloat() && confirmBox('##NG_CONFIRM_PRICE_CHANGE##')){
					new Request({
						'method':'post',
						'url':'ajax/change_price.php',
						'data': {
							'item_id': $('prod_id_input').value,
							'price': this.value,
							'currency_id': $('currency').value,
							'price_scale_id': $('client_price_scale_input').value,
							'currency_price': $('curr_'+$('currency').value).value,
							'currency_item': $('curr_'+c).value
						},
						'onSuccess': function(res){
							if(res == 'ok'){
								msgBox('##NG_ITEM_PRICE_CHANGED_OK##');
							} else {
								msgBox('##NG_ERR_COULD_NOT_CHANGE_ITEM_PRICE##');
							}
							itemOk();
						}
					});
				} else {
					itemOk();
				}
			}
		}
	});

	$("unit_price_taxed").addEvent('keydown',function(ev){
		if(ev.keyCode==13){
			if($('tax_select') && discriminate_taxes){
				setFocus("tax_select");
			} else if($('ref_input').value==0) {
				itemOk();
			} else {
				var c = $('curr_input').value;
				var val = this.get('alt');
				if(c != $('currency').value){
					var currency_mult = $('curr_'+c).value.toFloat() / $('curr_'+$('currency').value).value.toFloat();
					var val = (val * currency_mult).round(4);
				}
				if(ask_price_change && this.value != val && confirmBox('##NG_CONFIRM_PRICE_CHANGE##')){
					new Request({
						'method':'post',
						'url':'ajax/change_price.php',
						'data': {
							'item_id': $('prod_id_input').value,
							'price': this.value,
							'currency_id': $('currency').value,
							'price_scale_id': $('client_price_scale_input').value,
							'currency_price': $('curr_'+$('currency').value).value,
							'currency_item': $('curr_'+c).value
						},
						'onSuccess': function(res){
							if(res == 'ok'){
								msgBox('##NG_ITEM_PRICE_CHANGED_OK##');
							} else {
								msgBox('##NG_ERR_COULD_NOT_CHANGE_ITEM_PRICE##');
							}
							itemOk();
						}
					});
				} else {
					itemOk();
				}
			}
		}
	});

	lockDescription();
	unlockCurrency();

	$('search_item_input').addEvent('keydown',function(ev){ if(ev.keyCode==13){ executeItemSearch(); } });
	$('search_item_btn').addEvent('click',function(){executeItemSearch();});
	$(window).addEvent('keydown',searchNavigationListener);
	setFocus('client');
});
