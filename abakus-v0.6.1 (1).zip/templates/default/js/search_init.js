var pager = null;
if($('search_result')){
	pager = $('search_result').getFirst('.pager');
}
var order = null;
var fieldsLightbox = null;

$(document).addEvent('domready',function(){
	if(pager){
		var first = pager.getFirst('a');
		if(first && first.getFirst('img')){
			prevPage = first.get('href')+'&collapse=1';
		}
		var last = pager.getLast('a');
		if(last && last.getFirst('img')){
			nextPage = last.get('href')+'&collapse=1';
		}
	}

	$$('#search_form input').each(function(el){
		if (el && el.get('type') == 'text'){
			el.addEvent('keyup',function(ev){
				if(ev.keyCode==13){
					$('search_form').submit();
				}
			});
		}
	});

	$$('#search_form select').each(function(el){
		if (el){
			el.addEvent('keyup',function(ev){
				if(ev.keyCode==13){
					$('search_form').submit();
				}
			});
		}
	});

	$$('#search_result_body tr').each(function(el){
		if(el==null) return;
		var thisitem = el;
		el.setStyle('cursor','pointer');
		el.addEvent('click',function(ev){
			if(ev.target.tagName.toLowerCase() != 'a' && ev.target.tagName.toLowerCase() != 'img'){
				enterKeyAction(module_name,thisitem.get('rel'));
				current = thisitem;
				searchNavigationListener(null);
			}
		});
	});

	if($('table_caption')) $('table_caption').setStyle('cursor','pointer').addEvent('click',function(){
		fieldsLightbox = new Lightbox('box_table_fields',{reloadOnClose:true}).open().autoHeight();
	});
	if($('form_caption')) $('form_caption').setStyle('cursor','pointer').addEvent('click',function(){
		fieldsLightbox = new Lightbox('box_search_terms',{reloadOnClose:true}).open().autoHeight();
	});

	if($('collapse_icon')) $('collapse_icon').addEvent('click',collapseSearch);

	if(isSearching){
		$('search_form').setStyle('display','none');
		$('collapse_icon').set('src','##IMG_DOWN##');
		current = $('search_result_body').getFirst('tr');
		searchNavigationListener();
	} else if($('search_form')){
		setFocus($('search_form').getFirst('input'));
	}

	if(paging_style=='scroll'){
		$(document.body).setStyle('overflow','hidden');
		$(window).addEvent('resize',function(){resizeResultsWrapper();});
		resizeResultsWrapper();
	} else {
		$(document.body).setStyle('overflow','auto');
	}

	var count = 0;
	$$('#search_result_head th').each(function(th){
		th
			.set({ 'id':'th_'+count, 'rel':count })
			.setStyles({ 'cursor':'pointer' })
			.addEvent('click',function(ev){
				orderList(this.get('rel'));
			});
		count++;
	});

	$(window).addEvent('keydown',searchNavigationListener);

	if(preview > 0){
		previewItem(module_name,'item_'+preview);
	}
});
