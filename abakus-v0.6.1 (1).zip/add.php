<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = $_GET['module'];
	$thispage = "add.php?module=".$module_name;

	// We load the module
	$module = loadModule($module_name,$db);

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$module->init('add');

	include 'inc/smarty.php';

	if($_POST['save']){
		if($module->validate($_POST,$errors)){
			$el_id = $module->insertElement($_POST);
			if($_POST['next']=='new'){
				redirect('add.php?module='.$module_name);
			} elseif($_REQUEST['next']=='edit') {
				redirect('edit.php?module='.$module_name.'&id='.$el_id);
			} else {
				return_to_module($module_name);
			}
		}
	}

	$fields = $module->getFields();

	$formatted_fields = array();
	if(is_array($fields) && !empty($fields)){
		foreach($fields as $f){
			if(!$module->isFixedField($f['Field']) && !$module->isHiddenField($f['Field'])) {
				$tmp['field'] = $f['Field'];
				$tmp['name'] = __(beautifyFieldName($f['Name']));
				$tmp['input'] = getFieldInput($module,$f['Field'],$_POST[$f['Field']]);
				$formatted_fields[] = $tmp;
			}
		}
	}

	$return_url = return_to_module_url($module_name);

	$helpers = getPluginsHelpers($module);

	$smarty->assign('plugins_css',$helpers['css']);
	$smarty->assign('plugins_javascript',$helpers['javascript']);

	$smarty->assign('return_url',$return_url);
	$smarty->assign('fields',$formatted_fields);
	$smarty->assign('errors',$errors);
	$smarty->display('add.tpl');
