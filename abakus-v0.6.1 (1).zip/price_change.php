<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = 'price_change.php';
	// We load the module
	$thispage = 'price_change.php';

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$provider = (int)$_REQUEST['id_provider'];

	if($_POST['save']){
		$matrix = array();
		if(is_array($_POST)) foreach($_POST as $key => $val){
			if(float($val) && preg_match("/^price_(\d+)-(\d+)$/",$key,$matches)){
				$price_list = (int)$matches[1];
				$category = (int)$matches[2];
				$multiplier = 1 + (float($val)/100);
				if($provider)
					$where_provider = "AND id_provider=$provider";
				if($price_list && $category && $multiplier){
					$products = $db->fetch_all("SELECT * FROM products WHERE id_category=$category $where_provider");
					if(is_array($products)) foreach($products as $prod){
						$db->update("
							UPDATE products_prices
								SET price=ROUND(price*$multiplier,2)
							WHERE id_product={$prod['id']}
								AND id_price_scale={$price_list}
							LIMIT 1
						");
					}
				}
			}
		}
		return_to_module('products');
	}

	$return = 'search';
	if($_GET['return']) $return = $_GET['return'];

	$price_scales = $db->fetch_all("SELECT * FROM price_scales ORDER BY id");
	$providers = $db->fetch_all("SELECT id,name FROM providers ORDER BY name");
	if($provider){
		$categories = $db->fetch_all("
			SELECT c.*,COUNT(DISTINCT p.id) AS cant
			FROM categories AS c
			JOIN products AS p
				ON p.id_category=c.id
				AND p.id_provider=$provider
			JOIN products_prices AS pp
				ON pp.id_product=p.id
			GROUP BY c.id
			ORDER BY name
		");

		$all_products = $db->fetch_all("
			SELECT p.*,GROUP_CONCAT(CONCAT(pp.id_price_scale,':',pp.price) SEPARATOR '|') AS prices
			FROM products AS p
			JOIN products_prices AS pp
				ON pp.id_product = p.id
			WHERE p.id_provider=$provider
			GROUP BY p.id
			ORDER BY p.name
		");
	} else {
		$categories = $db->fetch_all("SELECT * FROM categories ORDER BY name");

		$all_products = $db->fetch_all("
			SELECT p.*,GROUP_CONCAT(CONCAT(pp.id_price_scale,':',pp.price) SEPARATOR '|') AS prices
			FROM products AS p
			JOIN products_prices AS pp
				ON pp.id_product = p.id
			GROUP BY p.id
			ORDER BY p.name
		");
	}

	$return_url = return_to_module_url('products');

	$smarty->assign('return',$return);
	$smarty->assign('return_url',$return_url);
	$smarty->assign('provider',$provider);
	$smarty->assign('providers',$providers);
	$smarty->assign('price_scales',$price_scales);
	$smarty->assign('categories',$categories);
	$smarty->assign('all_products',$all_products);

	$smarty->display('price_change.tpl');
?>
