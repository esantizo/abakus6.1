var checkLightbox;
function checkCancel(){
	checkLightbox.close();
}

function newCheck(){
	$('check_bank').selectedIndex = 0;
	$('check_serial').value = '';
	$('check_currency').selectedIndex = 0;
	$('check_amount').value = '';
	$('check_due_date').value = '';
	$('check_notes').value = '';
	$('new_check').setStyle('display','block');
	$('save_check_btn').removeEvent('click',editCheckOk);
	$('save_check_btn').addEvent('click',addCheck);
	checkLightbox = new Lightbox('check_adder',{'autoresize':true}).open();
	setFocus('check_bank');
}

function addCheck(){
	var newcheck = new Element('li')
		.adopt(new Element('strong',{'text': 'Nro: '}))
		.adopt(new Element('span',{'text': $('check_serial').value}))
		.adopt(new Element('text',' - '))
		.adopt(new Element('strong',{'text': 'Banco: '}))
		.adopt(new Element('span',{'text': $('check_bank').getSelected().get('text')}))
		.adopt(new Element('text',' - '))
		.adopt(new Element('text',currencies[$('check_currency').value.toInt()].symbol+' '))
		.adopt(new Element('span',{'text': $('check_amount').value}))
		.adopt(new Element('input',{ type:'hidden', name:'checks_bank[]', value:$('check_bank').value }))
		.adopt(new Element('input',{ type:'hidden', name:'checks_serial[]', value:$('check_serial').value }))
		.adopt(new Element('input',{ type:'hidden', name:'checks_currency[]', value:$('check_currency').value }))
		.adopt(new Element('input',{ type:'hidden', name:'checks_amount[]', value:$('check_amount').value, 'class':'check_amount', 'data-currency':$('check_currency').value }))
		.adopt(new Element('input',{ type:'hidden', name:'checks_due_date[]', value:$('check_due_date').value }))
		.adopt(new Element('input',{ type:'hidden', name:'checks_notes[]', value:$('check_notes').value }))
		.adopt(new Element('text',' - '))
		.adopt(new Element('a',{ href:'javascript:;', text: 'Edit', events: { 'click': function(){ editCheck(newcheck); } } }))
		.adopt(new Element('text',' - '))
		.adopt(new Element('a',{ href:'javascript:;', text: 'Delete', events: { 'click': function(){this.getParent('li').destroy(); } } }))
		.inject('checks');
	checkLightbox.close();
	updateTotals();
}

function addExistingCheck(c){
	var newcheck = new Element('li')
		.adopt(new Element('strong',{'text': 'Nro: '}))
		.adopt(new Element('span',{'text': c.serial_number}))
		.adopt(new Element('text',' - '))
		.adopt(new Element('strong',{'text': 'Banco: '}))
		.adopt(new Element('span',{'text': c.bank}))
		.adopt(new Element('text',' - '))
		.adopt(new Element('text',currencies[c.id_currency].symbol+' '))
		.adopt(new Element('span',{'text': c.value}))
		.adopt(new Element('input',{ type:'hidden', name:'existing_checks_ids[]', value:c.id }))
		.adopt(new Element('input',{ type:'hidden', value:c.value, 'class':'existing_check_amount', 'data-currency':c.id_currency }))
		.adopt(new Element('text',' - '))
		.adopt(new Element('a',{ href:'javascript:;', text: 'Delete', events: { 'click': function(){this.getParent('li').destroy(); } } }))
		.inject('checks');
	updateTotals();
}

function editCheck(li){
	var inputs = $(li).getElements('input[type=hidden]');
	$('check_bank').setSelected(inputs[0].value);
	$('check_serial').value = inputs[1].value;
	$('check_currency').setSelected(inputs[2].value);
	$('check_amount').value = inputs[3].value;
	$('check_due_date').value = inputs[4].value;
	$('check_notes').value = inputs[5].value;
	$('new_check').setStyle('display','block');
	$('save_check_btn').removeEvent('click',addCheck);
	$('save_check_btn').addEvent('click',function(){ editCheckOk(li); });
	checkLightbox = new Lightbox('check_adder',{'autoresize':true}).open();
	setFocus('check_bank');
}

function editCheckOk(li){
	li = $(li);
	li.empty();
	li.adopt(new Element('strong',{ 'text': '##Number##: ' }))
		.adopt(new Element('span',{ 'text': $('check_serial').value }))
		.adopt(new Element('text',' - '))
		.adopt(new Element('strong',{ 'text': '##Bank#: ' }))
		.adopt(new Element('span',{ 'text': $('check_bank').getSelected().get('text') }))
		.adopt(new Element('text',' - '))
		.adopt(new Element('text',currencies[$('check_currency').value.toInt()].symbol+' '))
		.adopt(new Element('span',{'text': $('check_amount').value}))
		.adopt(new Element('input',{ type:'hidden', name:'checks_bank[]', value:$('check_bank').value }))
		.adopt(new Element('input',{ type:'hidden', name:'checks_serial[]', value:$('check_serial').value }))
		.adopt(new Element('input',{ type:'hidden', name:'checks_currency[]', value:$('check_currency').value }))
		.adopt(new Element('input',{ type:'hidden', name:'checks_amount[]', value:$('check_amount').value, 'class':'check_amount', 'data-currency':$('check_currency').value }))
		.adopt(new Element('input',{ type:'hidden', name:'checks_due_date[]', value:$('check_due_date').value }))
		.adopt(new Element('input',{ type:'hidden', name:'checks_notes[]', value:$('check_notes').value }))
		.adopt(new Element('text',' - '))
		.adopt(new Element('a',{ href:'javascript:;', text: '##NG_EDIT##', events: { 'click': function(){ editCheck(li); } } }))
		.adopt(new Element('text',' - '))
		.adopt(new Element('a',{ href:'javascript:;', text: '##NG_DELETE##', events: { 'click': function(){ this.getParent('li').destroy(); } } }));
	checkLightbox.close();
	updateTotals();
}

function updateTotals(){
	currency = currency.toInt();
	var available_to_include = 0;
	if($('use_available') && $('use_available').value.toFloat()){
		available_to_include = $('use_available').value.toFloat();
	}
	var total_payments = 0;
	if($('cash_currency').value.toInt() == currency){
		total_payments += $('cash').value.toFloat();
	} else {
		total_payments += ($('cash').value.toFloat() * currencies[$('cash_currency').value.toInt()].rate.toFloat() / currencies[currency].rate.toFloat()).round(4);
	}
	$$("#payments_container .check_amount").each(function(el){
		var cur = el.get('data-currency').toInt();

		if(cur == currency){
			total_payments += el.value.toFloat();
		} else {
			total_payments += (el.value.toFloat() * currencies[cur].rate.toFloat() / currencies[currency].rate.toFloat()).round(4);
		}
	});
	$$("#payments_container .existing_check_amount").each(function(el){
		var cur = el.get('data-currency').toInt();

		if(cur == currency){
			total_payments += el.value.toFloat();
		} else {
			total_payments += (el.value.toFloat() * currencies[cur].rate.toFloat() / currencies[currency].rate.toFloat()).round(4);
		}
	});

	var total_invoices = 0;
	$$('#invoices input[type=text]').each(function(el){
		if(!el.disabled){
			total_invoices += el.value.toFloat();
		}
	});

	available_to_include += total_payments;
	var credit = (available_to_include - total_invoices).round(4);

	if(credit > total_payments){
		credit = total_payments;
	}

	$('total_payments').value = total_payments.round(4);
	$('total_invoices').value = total_invoices.round(4);
	$('available_to_include').value = available_to_include.round(4);
	$('credit').value = credit;

	$('total_payments_text').set('text',symbol+' '+total_payments.round(4));
	$('total_invoices_text').set('text',symbol+' '+total_invoices.round(4));
	$('available_to_include_text').set('text',symbol+' '+available_to_include.round(4));
	$('credit_text').set('text',symbol+' '+credit);

	$('future_balance_text').set('text',symbol+' '+( $('current_balance').value.toFloat() + total_payments.round(4) ).round(4));

	if(credit < 0){
		$('save_btn').setStyle('display','none');
	} else {
		$('save_btn').setStyle('display','inline-block');
	}
}

function adjust(el){
	var input = $(el).getParent('td').getFirst('input');
	var credit = $('credit').value.toFloat();
	var total = input.get('data-rel').toFloat();
	var current = input.value.toFloat();
	if(credit < 0){
		var value = Math.max((total + credit).round(4),0);
		input.value = value;
	} else if(credit > 0){
		var value = Math.max((current + credit).round(4),0);
		input.value = Math.min(value,total);
	}
	updateTotals();
}

function reset(el){
	var input = $(el).getParent('td').getFirst('input');
	input.value = input.get('data-rel');
	updateTotals();
}

function save(){
	$('add_fields_form').submit();
}

function cancel(){
	if(confirmBox('##NG_CANCEL_CONFIRMATION##')){
		location.href=return_url;
	}
}

function keyboardListener(ev){
	if(calculator && calculator.opened) return false;
	if(ev.keyCode==27){ // Esc key
		cancel();
	}
}

function getInvoices(provider_id,currency){
	new Request({
		method: 'post',
		url: 'ajax/get_invoices.php',
		data: { 'id_provider': provider_id, 'currency': currency },

		onSuccess: function(response){
			$('provider_invoices').empty();
			if(!response) return false;
			var res = parseJSON(response);
			if(res){
				res.each(function(el){
					if(el.payed.toInt()==0){
						var classname = (el.total_due==el.total?'not_payed':'partial');
						var checkbox = new Element('input',{ 'type':'checkbox','name':'invoices[]','value':el.id });
						new Element('tr',{ 'class':'invoice '+classname })
							.adopt(
								new Element('td',{ 'class':'invoice_selected' })
								.adopt(checkbox)
							)
							.adopt(new Element('td',{ 'class':'invoice_date','text':el.date }))
							.adopt(new Element('td',{ 'class':'invoice_number','text':el.number }))
							.adopt(new Element('td',{ 'class':'invoice_orig_amount','text':el.symbol+' '+el.total }))
							.adopt(
								new Element('td',{ 'class':'invoice_amount' })
								.adopt(new Element('input',{
									'type':'text','name':'invoices_amounts[]','data-rel':el.total_due,'value':el.total_due,'size':'8','disabled':true
								}))
								.adopt(new Element('a',{
									'href':'javascript:;','text':'##NG_ADJUST##',events:{ 'click':function(){ adjust(this); } }
								}))
								.adopt(new Element('span',{ 'html':"&nbsp;" }))
								.adopt(new Element('a',{
									'href':'javascript:;','text':'##NG_RESET##',events:{ 'click':function(){ reset(this); } }
								}))
							)
							.inject('provider_invoices');
						if(el.checked){
							checkbox.checked = true;
						}
					}
				});
			}
			setTimeout('init()',250);
		}
	});
}

function searchProvider(id){
	if(id==0) {
		setFocus(nextInput('provider_id'));
		return false;
	}
	Request({
		'url':'ajax/search_provider.php',
		'method':'post',
		'data':{'id':id, 'current_balance':1},
		'onSuccess':function(response){
			var res = eval('('+response+')');
			if(res && res.name){
				$('provider_id').set('rel',id);
				$('provider_id').value = id;
				$('provider_name').set('text',res.name);

				//$('current_balance_in_favor_text').set('text',symbol+' '+res.available_to_include);
				//$('current_balance_in_favor').value = res.available_to_include;

				if(res.credit_limit_currency && res.credit_limit_currency.toInt() > 0){
					currency = res.credit_limit_currency.toInt();
					symbol = currencies[currency].symbol;
				}
				$('cash_currency').setSelected(currency);
				getInvoices(id,currency);
				updateTotals();

				setFocus(nextInput('provider_id'));
			} else {
				msgBox("##NG_WRONG_PROVIDER##");
				$('provider_id').value = $('provider_id').get('rel');
				setFocus('provider_id');
			}
		}
	});
}

function searchCheck(id,el){
	Request({
		'url':'ajax/search_check.php',
		'method':'post',
		'data':{ 'id':id },
		'onSuccess':function(response){
			if(response)
				var res = parseJSON(response);
			if(res && res.id){
				addExistingCheck(res);
				updateTotals();
			} else {
			}
		}
	});
}

function init(){
	$$("#invoices input[type=checkbox]").each(function(el){
		el.addEvents({
			'keyup':updateTotals,
			'click':function(){
				var related = $(this).getParent('tr').getElements("input")[1];
				if(this.checked){
					related.disabled = false;
				} else {
					related.disabled = true;
				}
				updateTotals();
			}
		});
		if(el.checked){
			var related = el.getParent('tr').getElements("input")[1];
			related.disabled = false;
			updateTotals();
		}
	});

	$$('#invoices input[type=text]').addEvents({
		'keyup':updateTotals,
		'blur': function(){
			var related = $(this);
			if(related.get('data-rel').toFloat() < related.value){
				related.value = related.get('data-rel');
			}
			updateTotals();
		}
	});
}

$('cash').addEvent('keyup',updateTotals);
$('cash_currency').addEvent('change',updateTotals);
if($('use_available')) $('use_available').addEvents({
	'keyup':updateTotals,
	'blur': function(){
		if($('orig_available_to_include').value.toFloat() < $('use_available').value.toFloat()){
			$('use_available').value = $('orig_available_to_include').value.toFloat();
			updateTotals();
		}
	}
});

init();
$(window).addEvent('keydown',keyboardListener);

if($('provider')){
	$('provider').addEvents({
		'keydown': function(ev){
			if(ev.keyCode==13){
				if(!isNaN(this.value)){
					if(this.value===''){
						openSearchProviderBox();
					} else {
						searchProvider(this.value);
					}
				} else {
					openSearchProviderBox();
				}
			}
		},
		'blur': function(){
			if(!isNaN(this.get('rel'))){
				this.value = this.get('rel');
			}
		}
	});
	setFocus('provider');
} else {
	setFocus('payment_number');
}
