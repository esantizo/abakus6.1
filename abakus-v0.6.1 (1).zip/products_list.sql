select * INTO OUTFILE '/tmp/products.csv'
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'

from
((select
   'Referencia',
   'Nombre',
   'Categoria',
   'Proveedor',
   'Cod. Fabricante',
   'Descripcion',
   'Promo',
   'Color',
   'GranMayorista',
   'Mayorista',
   'Cliente',
   'Publico',
   'Taller',
   'Lubricantes'
)
UNION
(SELECT
   p.referencia,
   p.nombre,
   c.name AS categoria,
   pr.nombre AS proveedor,
   p.cod_fabricante,
   p.descripcion,
   p.PROMO,
   p.color,
   max(if(pp.id_price_scale=11,pp.price,'-')) as GranMayorista,
   max(if(pp.id_price_scale=12,pp.price,'-')) as Mayorista,
   max(if(pp.id_price_scale=13,pp.price,'-')) as Cliente,
   max(if(pp.id_price_scale=14,pp.price,'-')) as Publico,
   max(if(pp.id_price_scale=15,pp.price,'-')) as Taller,
   max(if(pp.id_price_scale=16,pp.price,'-')) as Lubricantes

FROM products as p
LEFT JOIN categories as c
ON c.id=p.id_category
LEFT JOIN proveedores as pr
on pr.id=p.id_provider
LEFT JOIN products_prices as pp
on pp.id_product=p.id
GROUP BY p.id
)) as t;
