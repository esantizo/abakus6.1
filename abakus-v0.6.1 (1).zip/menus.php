<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = "menus.php";
	$module_name = $thispage;

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	if($_POST['save']){
		$ids = array_keys($_POST['menus']);
		$db->update("UPDATE menu SET active=0");
		if(is_array($ids)){
			$db->update("UPDATE menu SET active=1 WHERE id IN (".implode(',',$ids).")");
		}
		redirect($thispage);
	}

	// We instantiate the pager using the query. It will return a limited query.
//	$link_template = $thispage.'&amp;page=__page__';
//	$pager = new Pager($sql, $_GET['page'], 20 , $link_template);

	$menu_items = $db->fetch_all("
		SELECT m.*, m2.name AS parent_name
		FROM menu AS m
		LEFT JOIN menu AS m2
			ON m2.id=m.parent
		ORDER BY m.parent,m.`order`,m.id
	");

	if(is_array($menu_items) && !empty($menu_items)){
		foreach($menu_items AS $mi){
			if($mi['parent']==0){
				$results[$mi['id']] = $mi;
				$results[$mi['id']]['submenus'] = array();
			} else {
				if(is_array($results[$mi['parent']]['submenus'])){
					$results[$mi['parent']]['submenus'][] = $mi;
				}
			}
		}
	}

// We get the user list, limited by the paginator
//	$results = $db->fetch_all($sql);

	$smarty->assign('results',$results);
	$smarty->display('menus.tpl');
?>
