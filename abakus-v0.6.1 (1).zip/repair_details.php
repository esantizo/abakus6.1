<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';
	include 'inc/class.upload_image.php';

	$module_name = 'repairs';
	// We load the module
	$module = loadModule($module_name,$db);
	$thispage = 'repairs.php';

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$id_client = (int)$_GET['id_client'];

	$return = 'search';
	if($_GET['return']) $return = $_GET['return'];

	$redirect_url = return_to_module_url($module_name);

	if((int)$_GET['id']){
		$repair = $db->fetch_item("
			SELECT r.*,rs.*,
				c.id AS client_id,
				c.name AS client,
				p.id AS product_id,
				p.name AS product,
				rt.name AS repair_type,
				rstatus.name AS status,
				r.notes AS notes,
				rs.notes AS repair_shop_notes
			FROM repairs AS r
			LEFT JOIN repair_shop AS rs
				ON r.id=rs.id_repair
			JOIN clients AS c
				ON c.id=r.id_client
			JOIN product_models AS p
				ON p.id = r.id_product
			JOIN repairs_types AS rt
				ON rt.id = r.id_repair_type
			LEFT JOIN repairs_statuses AS rstatus
				ON rstatus.id = rs.id_status
			WHERE r.id=".(int)$_GET['id']
		);
		if($repair){
			$image = $db->fetch_item("SELECT * FROM images WHERE id={$repair['id_image']}");
			$repair_annotations = $db->fetch_all("
				SELECT r.*,u.name AS user
				FROM repairs_annotations AS r
				JOIN users AS u
					ON u.id=r.id_user
				WHERE r.id_repair={$repair['id']}
			");
		}
	}

	$default_status = $db->fetch_item_field("SELECT name FROM repairs_statuses ORDER BY name LIMIT 1");

	$smarty->assign('annotations',$repair_annotations);
	$smarty->assign('default_status',$default_status);
	$smarty->assign('repair',$repair);
	$smarty->assign('image',$image);

	$smarty->display('repair_details.tpl');
?>
