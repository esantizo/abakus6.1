<?php
	$img_ok = 'img/accepted.png';
	$img_err = 'img/rejected.png';

	$check = true;
	include 'inc/config.php';

	function checkPrivileges($required_permissions,$privileges){
		return;
	}

	if(!$db){
		$db_status = $img_err;
		$db_can_install = false;
	} else {
		$db_status = $img_ok;
		$table_count = count($db->getTables());
		$required_permissions = array('SELECT','INSERT','UPDATE','DELETE','CREATE','ALTER','INDEX','DROP');
		$db_schema = new SQL($db_server,$db_username,$db_password,'information_schema','mysqli');

		// First, check for users global privileges
		$sql = "SELECT PRIVILEGE_TYPE FROM USER_PRIVILEGES WHERE GRANTEE LIKE '\'$db_username\'\@\'$db_server\'' AND IS_GRANTABLE='YES'";
		$privileges = $db_schema->fetch_all($sql,'PRIVILEGE_TYPE');
		$permissions_ok = true;
		$remaining_permissions = $required_permissions;
		if(is_array($privileges)) foreach($privileges as $p){
			$remaining_permissions = array_diff($remaining_permissions,array($p));
		}
		if(count($remaining_permissions) > 0) $permissions_ok = false;

		if($table_count > 0){
			$db_installed = true;

			// If user has no global permissions and the database is installed, check for specific table permissions
			if(!$permissions_ok){
				$sql = "
					SELECT COUNT(TABLE_NAME) AS table_count,PRIVILEGE_TYPE as privilege_type
					FROM information_schema.SCHEMA_PRIVILEGES AS sp
					JOIN information_schema.TABLES AS t
						ON sp.TABLE_SCHEMA=t.TABLE_SCHEMA
					WHERE PRIVILEGE_TYPE IN ('".join("','",$required_permissions)."')
						AND t.TABLE_SCHEMA LIKE '$db_name'
						AND GRANTEE LIKE '\'$db_username\'\@\'$db_server\''
					GROUP BY PRIVILEGE_TYPE
				";
				$privileges = $db_schema->fetch_all($sql);

				$permissions_ok = true;
				$remaining_permissions = $required_permissions;
				foreach($privileges as $p){
					if($p['table_count'] < $table_count){
						$permissions_ok = false;
					}
					$remaining_permissions = array_diff($remaining_permissions,array($p['privilege_type']));
				}
				if(count($remaining_permissions) > 0) $permissions_ok = false;
			}
		} else {

			// If user has no global permissions and the database is NOT installed, check for specific database permissions
			if(!$permissions_ok){
				$sql = "SELECT PRIVILEGE_TYPE FROM SCHEMA_PRIVILEGES WHERE TABLE_SCHEMA LIKE '$db_name' AND GRANTEE LIKE '\'$db_username\'\@\'$db_server\''";
				$privileges = $db_schema->fetch_all($sql,'PRIVILEGE_TYPE');

				$permissions_ok = true;
				$remaining_permissions = $required_permissions;
				if(is_array($privileges)) foreach($privileges as $p){
					$remaining_permissions = array_diff($remaining_permissions,array($p));
				}
				if(count($remaining_permissions) > 0) $permissions_ok = false;
			}

			if($permissions_ok && is_file('database.sql') && is_readable('database.sql')){
				if(isset($_GET['install']) && $db){
					$db->importSql('database.sql');
					redirect('check.php');
				}

				$db_can_install = true;
			}
		}
	}

	if($permissions_ok){
		$permissions_img = $img_ok;
	} else {
		$permissions_img = $img_err;
	}

	if (extension_loaded('gd') && function_exists('gd_info')) {
		$gd_installed_img = $img_ok;
	} else {
		$gd_installed_img = $img_err;
	}

	if(is_dir('backups') && is_writable('backups')){
		$backups = $img_ok;
	} else {
		$backups = $img_err;
	}
	if(is_dir('uploads') && is_writable('uploads')){
		$uploads = $img_ok;
	} else {
		$uploads = $img_err;
	}
	if(is_dir('uploads/icons') && is_writable('uploads/icons')){
		$uploads_icons = $img_ok;
	} else {
		$uploads_icons = $img_err;
	}
	if(is_dir('uploads/images') && is_writable('uploads/images')){
		$uploads_images = $img_ok;
	} else {
		$uploads_images = $img_err;
	}
	if(is_dir('uploads/tmp') && is_writable('uploads/tmp')){
		$uploads_tmp = $img_ok;
	} else {
		$uploads_tmp = $img_err;
	}

	if(file_exists('database.sql')){
		$db_file = $img_err;
	} else {
		$db_file = $img_ok;
	}

	$templates_languages = $img_ok;
	$files = scandir('templates');
	foreach($files as $f){
		if(substr($f,0,1)=='.') continue;
		$lang_dirs = scandir('templates/'.$f.'/languages');
		foreach($lang_dirs as $ld){
			if(substr($ld,0,1)=='.') continue;
			if(is_dir("templates/$f/languages/$ld") && !is_writable("templates/$f/languages/$ld")){
				$templates_languages = $img_err;
			} elseif(is_dir('templates/'.$f.'/languages/'.$ld)) {
				$files = scandir('templates/'.$f.'/languages/'.$ld);
				if(is_array($files)) foreach($files as $fn){
					if(is_file("templates/$f/languages/$ld/$fn") && substr($fn,-4) == '.lng' && !is_writable("templates/$f/languages/$ld/$fn")){
						$templates_languages = $img_err;
					}
				}
			}
		}
	}

	if(is_dir('smarty_tmp/cache') && is_writable('smarty_tmp/cache')){
		$smarty_tmp_cache = $img_ok;
	} else {
		$smarty_tmp_cache = $img_err;
	}
	if(is_dir('smarty_tmp/compiled') && is_writable('smarty_tmp/compiled')){
		$smarty_tmp_compiled = $img_ok;
	} else {
		$smarty_tmp_compiled = $img_err;
	}
	if(is_dir('smarty_tmp/configs') && is_writable('smarty_tmp/configs')){
		$smarty_tmp_configs = $img_ok;
	} else {
		$smarty_tmp_configs = $img_err;
	}

	if(is_readable('VERSION')){
		$version = trim(file_get_contents('VERSION'));
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Abakus 0.1</title>
		<link type="image/x-icon" href="favicon.ico" rel="icon">
		<link type="image/x-icon" href="favicon.ico" rel="shortcut icon">
		<link type="text/css" rel="stylesheet" href="templates/default/css/main.css" media="all">
		<link type="text/css" rel="stylesheet" href="templates/default/css/about.css" media="all">
	</head>
	<body>
		<div id="full_body_wrapper">
			<content>
<?	if($_GET['lang']=='en'){ ?>
				<div id="add_fields_form">
					<h3>Abakus: Requirements Check <span class="langs"><a href="check.php?lang=es"><img src="img/ar.png" width="23" height="16" alt="Espa&ntilde;ol"></a> <a href="check.php?lang=en" class="selected"><img src="img/uk.png" width="23" height="16" alt="English"></a></span></h3>
					<p class="highlighted"><span><img src="img/abakus-chico.jpg" width="350" height="107" alt="Abakus">Version <?=$version?></span><span style="padding-left:35px;">Developed By <img src="img/company.png" width="350" height="107" alt="PhantaSoft"></span></p>
					<div style="text-align:left;padding:0 200px">
						<p>
							You must check the following before you start using Abakus:
						</p>

						<ul>
							<li><strong>Write Permissions:</strong>
							<table class="checktable">
								<tr><td>backups directory</td><td><img src="<?=$backups?>" width="20" height="20"></td></tr>
								<tr><td>uploads directory</td><td><img src="<?=$uploads?>" width="20" height="20"></td></tr>
								<tr><td>uploads/icons directory</td><td><img src="<?=$uploads_icons?>" width="20" height="20"></td></tr>
								<tr><td>uploads/images directory</td><td><img src="<?=$uploads_images?>" width="20" height="20"></td></tr>
								<tr><td>uploads/tmp directory</td><td><img src="<?=$uploads_tmp?>" width="20" height="20"></td></tr>
								<tr><td>templates/*/languages/* directories</td><td><img src="<?=$templates_languages?>" width="20" height="20"></td></tr>
								<tr><td>smarty_tmp/cache directory</td><td><img src="<?=$smarty_tmp_cache?>" width="20" height="20"></td></tr>
								<tr><td>smarty_tmp/compiled directory</td><td><img src="<?=$smarty_tmp_compiled?>" width="20" height="20"></td></tr>
								<tr><td>smarty_tmp/configs directory</td><td><img src="<?=$smarty_tmp_configs?>" width="20" height="20"></td></tr>
							</table>
							<li><strong>Configurations (you must edit the inc/config.php file):</strong>
								<table class="checktable">
									<tr><td>PHP GD Extension Installed</td><td><strong><img src="<?=$gd_installed_img?>" width="20" height="20" title="You need the PHP GD extension"></strong></td></tr>
									<tr>
										<td>DB Access</td>
										<td>
											<img src="<?=$db_status?>" width="20" height="20">
											<?if($db_can_install){?>&nbsp;&nbsp;&nbsp;<input type="button" value="Install DB" onclick="location.href='check.php?install'"><?}?>
											<?if($db_installed){?><strong>Installed</strong><?}?>
										</td>
									</tr>
									<tr><td>Permissions</td><td><strong><img src="<?=$permissions_img?>" width="20" height="20" title="The DB and every table must have the following permissions: <?=join(', ',$required_permissions)?>"></strong></td></tr>
									<tr><td>db_server</td><td><strong><?=$db_server?></strong></td></tr>
									<tr><td>db_username</td><td><strong><?=$db_username?></strong></td></tr>
									<tr><td>db_password</td><td><strong><?=$db_password?></strong></td></tr>
									<tr><td>db_name</td><td><strong><?=$db_name?></strong></td></tr>
									<tr><td>autologin_cookie_time</td><td><strong><?=$autologin_cookie_time?></strong> segs</td></tr>
									<tr><td>autologin_salt</td><td><strong><?=$autologin_salt?></strong></td></tr>
									<tr><td>default_lang</td><td><strong><?=$default_lang?></strong></td></tr>
								</table>
							</li>
							<li><strong>Installation files:</strong>
								<table class="checktable">
									<tr><td>Delete the SQL file (database.sql)</td><td><img src="<?=$db_file?>" width="20" height="20"></td></tr>
									<tr><td>Delete this file (check.php, or set $check_config=false)</td><td><img src="<?=$img_err?>" width="20" height="20"></td></tr>
								</table>
							</li>
						</ul>

						<p>For help or more information visit us at <a href="http://www.phanta-soft.com">www.phanta-soft.com</a></p>
					</div>
					<div class="sponsors_block">
						<h3>Sponsors:</h3>
						<div class="sponsors"><p>This system is exclusively brought to you by courtesy of:</p>
							<div class="sponsor"><img src="img/phantasoft-small.png" width="189" height="41" alt="PhantaSoft S.R.L."><span>PhantaSoft S.R.L.</span></div>
						</div>
					</div>
				</div>
<? } else { ?>
				<div id="add_fields_form">
					<h3>Abakus: Comprobaci&oacute;n de requerimientos <span class="langs"><a href="check.php?lang=es" class="selected"><img src="img/ar.png" width="23" height="16" alt="Espa&ntilde;ol"></a> <a href="check.php?lang=en"><img src="img/uk.png" width="23" height="16" alt="English"></a></span></h3>
					<p class="highlighted"><span><img src="img/abakus-chico.jpg" width="350" height="107" alt="Abakus">Version <?=$version?></span><span style="padding-left:35px;">Developed By <img src="img/company.png" width="350" height="107" alt="PhantaSoft"></span></p>
					<div style="text-align:left;padding:0 200px">
						<p>
							Debe verificar los siguientes items antes de comenzar a utilizar Abakus.
						</p>

						<ul>
							<li><strong>Permisos de Escritura:</strong>
							<table class="checktable">
								<tr><td>Directorio backups</td><td><img src="<?=$backups?>" width="20" height="20"></td></tr>
								<tr><td>Directorio uploads</td><td><img src="<?=$uploads?>" width="20" height="20"></td></tr>
								<tr><td>Directorio uploads/icons</td><td><img src="<?=$uploads_icons?>" width="20" height="20"></td></tr>
								<tr><td>Directorio uploads/images</td><td><img src="<?=$uploads_images?>" width="20" height="20"></td></tr>
								<tr><td>Directorio uploads/tmp</td><td><img src="<?=$uploads_tmp?>" width="20" height="20"></td></tr>
								<tr><td>Directorios templates/*/languages/*</td><td><img src="<?=$templates_languages?>" width="20" height="20"></td></tr>
								<tr><td>Directorio smarty_tmp/cache</td><td><img src="<?=$smarty_tmp_cache?>" width="20" height="20"></td></tr>
								<tr><td>Directorio smarty_tmp/compiled</td><td><img src="<?=$smarty_tmp_compiled?>" width="20" height="20"></td></tr>
								<tr><td>Directorio smarty_tmp/configs</td><td><img src="<?=$smarty_tmp_configs?>" width="20" height="20"></td></tr>
							</table>
							<li><strong>Configuraciones (debe editar el archivo inc/config.php):</strong>
								<table class="checktable">
									<tr><td>Complemento PHP GD Instalado</td><td><strong><img src="<?=$gd_installed_img?>" width="20" height="20" title="You need the PHP GD extension"></strong></td></tr>
									<tr>
										<td>Acceso a la BD</td>
										<td>
											<img src="<?=$db_status?>" width="20" height="20">
											<?if($db_can_install){?>&nbsp;&nbsp;&nbsp;<input type="button" value="Instalar BD" onclick="location.href='check.php?install'"><?}?>
											<?if($db_installed){?><strong>Instalada</strong><?}?>
										</td>
									</tr>
									<tr><td>Permisos</td><td><strong><img src="<?=$permissions_img?>" width="20" height="20" title="La BD y todas las tablas deben tener los permisos: <?=join(', ',$required_permissions)?>"></strong></td></tr>
									<tr><td>db_server</td><td><strong><?=$db_server?></strong></td></tr>
									<tr><td>db_username</td><td><strong><?=$db_username?></strong></td></tr>
									<tr><td>db_password</td><td><strong><?=$db_password?></strong></td></tr>
									<tr><td>db_name</td><td><strong><?=$db_name?></strong></td></tr>
									<tr><td>autologin_cookie_time</td><td><strong><?=$autologin_cookie_time?></strong> segs</td></tr>
									<tr><td>autologin_salt</td><td><strong><?=$autologin_salt?></strong></td></tr>
									<tr><td>default_lang</td><td><strong><?=$default_lang?></strong></td></tr>
								</table>
							</li>
							<li><strong>Archivos de instalacion:</strong>
								<table class="checktable">
									<tr><td>Eliminar el archivo SQL (database.sql)</td><td><img src="<?=$db_file?>" width="20" height="20"></td></tr>
									<tr><td>Eliminar este archivo (check.php, o definir $check_config=false)</td><td><img src="<?=$img_err?>" width="20" height="20"></td></tr>
								</table>
							</li>
						</ul>

						<p>Para ayuda o m&aacute;s informaci&oacute;n vis&iacute;tenos en <a href="http://www.phanta-soft.com">www.phanta-soft.com</a></p>
					</div>
					<div class="sponsors_block">
						<h3>Sponsors:</h3>
						<div class="sponsors"><p>Este sistema llega a usted por exclusiva gentileza de:</p>
							<div class="sponsor"><img src="img/phantasoft-small.png" width="189" height="41" alt="PhantaSoft S.R.L."><span>PhantaSoft S.R.L.</span></div>
						</div>
					</div>
				</div>
<?	} ?>
			</content>

			<footer>
				<a href="http://www.phanta-soft.com"><img src="img/phantasoft-small.png" width="189" height="41" /></a>
				<b>Abakus</b> Copyright &copy; 2011 <a href="http://www.phanta-soft.com"> Phantasoft SRL</a><br>
				This program is distributed AS IS, without any warranties.<br>

				<b>Abakus</b> is free software; we invite you to redistribute, copy and modify it according to certain restrictions. <a href="http://www.gnu.org/licenses/gpl.html">More info</a>.
			</footer>
		</div>
	</body>
</html>
