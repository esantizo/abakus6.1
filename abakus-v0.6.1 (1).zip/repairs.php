<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';
	include 'inc/class.upload_image.php';

	$module_name = 'repairs';
	// We load the module
	$module = loadModule($module_name,$db);
	$thispage = 'repairs.php';

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$id_client = (int)$_GET['id_client'];

	$upload_image = new UploadImage($db,'repairs');

	$return = 'search';
	if($_GET['return']) $return = $_GET['return'];

	$redirect_url = return_to_module_url($module_name);

	$categories = $db->fetch_all("SELECT * FROM categories ORDER BY name",'name','id');
	$repairs_statuses = $db->fetch_all("SELECT * FROM repairs_statuses ORDER BY name");

	if((int)$_GET['id']){
		$repair = $db->fetch_item("
			SELECT r.*,c.name AS client,p.name AS product, con.name AS contact
			FROM repairs AS r
			JOIN clients AS c
				ON c.id=r.id_client
			JOIN product_models AS p
				ON p.id=r.id_product
			LEFT JOIN contacts AS con
				ON con.id=r.id_contact
			WHERE r.id=".(int)$_GET['id']
		);
		if($repair) $image = $db->fetch_item("SELECT * FROM images WHERE id={$repair['id_image']}");
	}

	if((int)$_GET['reinstate']){
		$previous_repair = $db->fetch_item("
			SELECT r.*,c.name AS client,p.name AS product, con.name AS contact
			FROM repairs AS r
			JOIN clients AS c
				ON c.id=r.id_client
			JOIN product_models AS p
				ON p.id=r.id_product
			LEFT JOIN contacts AS con
				ON con.id=r.id_contact
			WHERE r.id=".(int)$_GET['reinstate']
		);
	}

	if($_POST['save']){
		$id_client = (int)$_POST['id_client'];
		$id_contact = (int)$_POST['id_contact'];
		$id_product = (int)$_POST['id_product'];

		$number = (int)$_POST['number'];
		$date = date_formatted2sql($_POST['date']);
		$serial_number = $db->escape_string($_POST['serial_number']);
		$id_seller = (int)$_POST['id_seller'];
		$purchase_date = date_formatted2sql($_POST['purchase_date']);
		$warranty_number = $db->escape_string($_POST['warranty_number']);
		$id_repair_type = (int)$_POST['id_repair_type'];
		$unit_condition = $db->escape_string($_POST['unit_condition']);
		$expected_behaviour = $db->escape_string($_POST['expected_behaviour']);
		$obtained_behaviour = $db->escape_string($_POST['obtained_behaviour']);
		$steps_to_reproduce = $db->escape_string($_POST['steps_to_reproduce']);

		$estimated_notice_date = date_formatted2sql($_POST['estimated_notice_date']);
		$estimated_pickup_date = date_formatted2sql($_POST['estimated_pickup_date']);
		$pickup_address = $db->escape_string($_POST['home_pickup_address']);

		$quote_generated = ($_POST['quote_generated']?1:0);

		if(!$quote_generated){
			$quote_description = '';
			$quote_accepted = 0;
			$quote_acceptance_date = '';
			$estimated_delivery_date = '';
			$estimated_repair_date = '';
			$delivery_address = '';
		} else {
			$quote_description = $db->escape_string($_POST['quote_description']);
			$quote_accepted = ($_POST['quote_accepted']?1:0);

			if(!$quote_accepted){
				$quote_acceptance_date = '';
				$estimated_delivery_date = '';
				$estimated_repair_date = '';
				$delivery_address = '';
			} else {
				$quote_acceptance_date = date_formatted2sql($_POST['quote_acceptance_date']);
				$estimated_delivery_date = date_formatted2sql($_POST['estimated_delivery_date']);
				$estimated_repair_date = date_formatted2sql($_POST['estimated_repair_date']);
				$delivery_address = $db->escape_string($_POST['home_delivery_address']);
			}
		}

		$testing_cost = float($_POST['testing_cost']);
		$notes = $db->escape_string($_POST['notes']);

		$fields = "
			number='$number',
			date='$date',
			serial_number='$serial_number',
			id_seller='$id_seller',
			purchase_date='$purchase_date',
			warranty_number='$warranty_number',
			id_repair_type='$id_repair_type',
			unit_condition='$unit_condition',
			expected_behaviour='$expected_behaviour',
			obtained_behaviour='$obtained_behaviour',
			steps_to_reproduce='$steps_to_reproduce',
			estimated_notice_date='$estimated_notice_date',
			estimated_pickup_date='$estimated_pickup_date',
			testing_cost='$testing_cost',
			notes='$notes',
			pickup_address='$pickup_address',
			quote_generated=$quote_generated,
			quote_description='$quote_description',
			quote_accepted=$quote_accepted,
			quote_acceptance_date='$quote_acceptance_date',
			estimated_delivery_date='$estimated_delivery_date',
			estimated_repair_date='$estimated_repair_date',
			delivery_address='$delivery_address'
		";
		if($repair){
			$db->update("UPDATE repairs SET $fields WHERE id={$repair['id']}");
			$repair_id = $repair['id'];
		} else {
			$repair_id = $db->insert("INSERT INTO repairs SET id_client='$id_client',id_contact='$id_contact',id_product='$id_product',$fields");
		}

		$image_id = $upload_image->process_upload($_POST,$_FILES);
		if($upload_image->deleted) $db->delete("UPDATE repairs SET id_image=0 WHERE id=$repair_id");
		if($image_id) $db->update("UPDATE repairs SET id_image=$image_id WHERE id=$repair_id");

		if($_POST['next']=='new'){
			redirect("repairs.php?return=$return");
		} else {
			redirect($redirect_url);
		}
	}

	$number = max(1,$db->fetch_item_field("SELECT (MAX(number)+1) FROM repairs"));

	$repair_types = $db->fetch_all("SELECT * FROM repairs_types");
	$sellers = $db->fetch_all("SELECT * FROM sellers ORDER BY name");

	$form_action = "$thispage?return=$return";
	if($repair){
		$form_action.="&amp;id={$repair['id']}";
	}

	$smarty->assign('number',$number);
	$smarty->assign('repair_types',$repair_types);
	$smarty->assign('sellers',$sellers);
	$smarty->assign('form_action',$form_action);
	$smarty->assign('previous_repair',$previous_repair);
	$smarty->assign('repair',$repair);
	$smarty->assign('categories',$categories);
	$smarty->assign('repairs_statuses',$repairs_statuses);
	$smarty->assign('upload_image',$upload_image);
	$smarty->assign('image',$image);
	$smarty->assign('redirect_url',$redirect_url);

	$smarty->display('repairs.tpl');
?>
