<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';
	include 'inc/class.upload_image.php';

	$module_name = 'repair_assignation.php';
	$thispage = 'repair_assignation.php';

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$redirect_url = $thispage;

	$users = $db->fetch_all("
		SELECT u.*,i.filename AS image, i.width AS image_width, i.height AS image_height
		FROM users AS u
		LEFT JOIN images AS i
			ON i.id=u.id_image
		WHERE active=1
			AND deleted=0
		GROUP BY u.id
		ORDER BY name
	");

	$pending_repairs = $db->fetch_all("
		SELECT r.*,p.name AS product_name,p.id_category
		FROM repairs AS r
		JOIN product_models AS p
			ON p.id=r.id_product
		JOIN categories AS c
			ON c.id=p.id_category
		LEFT JOIN repairs_assignations AS ra
			ON ra.id_repair=r.id
		WHERE ra.id_user IS NULL
	");

	if(is_array($users)) foreach($users as $k => $u){
		$users[$k]['pending_jobs'] = $db->fetch_all("
			SELECT r.*,p.name AS product_name,p.id_category
			FROM repairs AS r
			JOIN product_models AS p
				ON p.id=r.id_product
			JOIN repairs_assignations AS ra
				ON ra.id_repair=r.id
			WHERE ra.id_user = {$u['id']}
		");
	}

	$categories = $db->fetch_all("
		SELECT c.id,c.name,GROUP_CONCAT(DISTINCT skills.id_user ORDER BY skills.level DESC SEPARATOR ',') AS users
		FROM categories AS c
		LEFT JOIN user_skills AS skills
			ON skills.id_category=c.id
			AND skills.level > 0
		GROUP BY c.id
		ORDER BY c.name
	");

	$smarty->assign('categories',$categories);
	$smarty->assign('users',$users);
	$smarty->assign('pending_repairs',$pending_repairs);
	$smarty->assign('redirect_url',$redirect_url);

	$smarty->display('repair_assignation.tpl');
?>
