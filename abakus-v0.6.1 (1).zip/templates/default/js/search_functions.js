function del(module,id){
	if(confirmBox('##NG_DELETE_CONFIRMATION##')){
		if(double_confirm){
			if(confirmBox('##NG_DELETE_SECOND_CONFIRMATION##')){
				location.href='del.php?module='+module+'&id='+id;
				return false;
			}
		} else {
			location.href='del.php?module='+module+'&id='+id;
			return true;
		}
	}

	if(current){
		window.focus();
		searchNavigationListener();
	}
}

function enterKeyAction(module,id){
	if(searchlist_keyactions['enter']=='view'){
		viewItem();
	} else if(searchlist_keyactions['enter']=='edit') {
		editItem();
	} else if(searchlist_keyactions['enter']=='preview') {
		previewItem(module,id);
	}
}
function spaceKeyAction(module,id){
	if(searchlist_keyactions['space']=='view'){
		viewItem();
	} else if(searchlist_keyactions['space']=='edit') {
		editItem();
	} else if(searchlist_keyactions['space']=='preview') {
		previewItem(module,id);
	}
}
function viewItem(){
	if(current){
		current.getLast('td').getElements('a.iconButtonLink').each(function(el){
			if(el.get('title') == '##NG_VIEW##'){
				location.href = el.get('href');
				return true;
			}
		});
	}
	return false;
}
function editItem(){
	if(current){
		current.getLast('td').getElements('a.iconButtonLink').each(function(el){
			if(el.get('title') == '##NG_EDIT##'){
				location.href = el.get('href');
				return true;
			}
		});
	}
	return false;
}

function searchNavigationListener(ev){
	if(typeof calculator != 'undefined' && calculator && calculator.opened) return false;
	$$('#search_result_body tr').each(function(e){e.removeClass('selected');});
	if(ev){
		if($(ev.target).get('tagName').toLowerCase() == 'input' || $(ev.target).get('tagName').toLowerCase() == 'select' || $(ev.target).get('tagName').toLowerCase() == 'textarea'){
			if(ev.target==firstInput && ev.keyCode==40 || ev.keyCode==38){
				navigateItems = true;
				firstInput.blur();
				collapseSearch('hide');
			} else {
				return;
			}
		}
		if(ev.keyCode==40){ // Down key
			if(current == null){
				current = $('search_result_body').getFirst('tr');
			} else {
				current = nextItem(current,'TR');
				if(!current) current = $('search_result_body').getFirst('tr');
			}
		} else if(ev.keyCode==38){  // Up key
			if(current == null){
				current = $('search_result_body').getLast('tr');
			} else {
				current = previousItem(current,'TR');
				if(!current) current = $('search_result_body').getLast('tr');
			}
		} else if(ev.keyCode==37) { // Left key
			if(prevPage){
				location.href=prevPage;
			}
		} else if(ev.keyCode==39) { // Right key
			if(nextPage){
				location.href=nextPage;
			}
		} else if(ev.keyCode==13) { // Enter key or Space key
			if(current){
				enterKeyAction(module_name,current.get('rel'));
				navigateItems = false;
			}
		} else if(ev.keyCode==32) { // Enter key or Space key
			if(current){
				spaceKeyAction(module_name,current.get('rel'));
				navigateItems = false;
			}
		} else if(ev.keyCode==66) { // B key
			collapseSearch('show');
			setFocus(firstInput);
			current = null;
			$$('#search_result_body tr').each(function(e){e.removeClass('selected');});
			return;
		} else if(ev.keyCode==68 || ev.keyCode==8 || ev.keyCode==46) { // D key or Backspace key or Delete key
			var rel = current.get('rel').split('_');
			del(module_name,rel[1]);
		} else if(ev.keyCode==69) { // E key
			if(current){
				var href = current.getLast('td').getElements('a')[1].get('href');
				location.href = href;
			}
		} else if(ev.keyCode==73) { // I key
			window.print();
		} else if(ev.keyCode==76) { // L key
			location.href = location.href;
		} else if(ev.keyCode==83) { // S key
			if(module_name == 'products' && current){
				var href = current.getLast('td').getElements('a')[2].get('href');
				location.href = href;
			}
		} else if(ev.keyCode==107 || ev.keyCode==187 || ev.keyCode==61) { // + key
			location.href='add.php?module='+module_name;
		} else {
			//console.log(ev);
			//console.log(ev.keyCode);
		}
	}

	if(current){
		if(previewLightbox && previewLightbox.opened) previewItem(module_name,current.get('rel'));
		current.addClass('selected');
		current.focus();
		if(paging_style=='scroll'){
			var curPos = current.getPosition();
			var contHeight = $('search_result_wrapper').getPosition().height;
			var maxScroll = $('search_result_table').getPosition().totalHeight - contHeight;
			var scroll = parseInt(curPos.top + curPos.height - contHeight / 2,10);
			if(scroll < 0) scroll = 0;
			if(scroll > maxScroll) scroll = maxScroll;
			$('search_result_wrapper').scrollTop = scroll;
		}
	}
}

function resizeResultsWrapper(){
	var footerHeight = $('full_body_wrapper').getFirst('footer').getPosition().totalHeight;
	var wrapperPos = $('search_result_wrapper').getPosition(true);
	height = (Math.max(window.innerHeight - wrapperPos.top - footerHeight - 30,100)).toInt();
	$('search_result_wrapper').setStyles({
		'overflow':'auto',
		'height':height+'px'
	});
	return;

	var a = $('search_result_table');
	if($('search_result_head_fixer')){
		var c = $('search_result_head_fixer');
		var f = $('search_result_head_fixer2');
	} else {
		var c = new Element("div",{ 'id': 'search_result_head_fixer' });
		$('search_result_wrapper').replaceChild(c, a);
		var f = new Element("div",{ 'id': 'search_result_head_fixer2' }).adopt(a).inject(c);
	}
	var table_head = $('search_result_head');
	var head_height = table_head.offsetHeight;
	var body_cells = $('search_result_body').getElements('tr:first-child td');
	f.setStyle('width', a.offsetWidth + 13 + "px");
	c.setStyle('width', f.getStyle.width);
	var padding_left = body_cells[0].getStyle('padding-left');
	var padding_right = body_cells[0].getStyle('padding-right');

	$$("#search_result_head tr:first-child th")
		.each(function(cell,index){
			var cell_width = cell.getStyle("width").toInt();
			body_cells[index].setStyle('width',cell_width);
			if(index === 0){
				cell_width = cell_width.toInt() + "px";
			}
			cell.setStyle('width', cell_width);
		});
	c.setStyles({
		'position': "relative",
		'padding-top': head_height + "px",
		'background-color': a.getStyle("background-color")
	});
	f.setStyles({
		'overflow': "auto",
		'height': height - head_height + "px"
	});
	table_head.setStyles({
		'position': "absolute",
		'top': 0,
		'left': 0
	});

	searchNavigationListener();
}

function collapseSearch(type){
	if($('search_form').getStyle('display')=='none' || type=='show'){
		$('search_form').setStyle('display','block');
		$('collapse_icon').set('src','##IMG_UP##');
	} else {
		$('search_form').setStyle('display','none');
		$('collapse_icon').set('src','##IMG_DOWN##');
	}
	if(paging_style=='scroll'){
		resizeResultsWrapper();
	}
}

function printList(){
	if($('search_result_head_fixer2')) $('search_result_head_fixer2').setStyles({
		'overflow': "hidden",
		'height': "auto"
	});
	window.print();
	if(paging_style=='scroll'){
		resizeResultsWrapper();
	}

/*
	var action = $('search_form').get('action');
	$('search_form').set('action','print_list.php?module='+module_name);
	$('search_form').set('target','_blank');
	$('search_form').submit();
	$('search_form').set('action',action);
	$('search_form').set('target','');
*/
}

function printBarcodes(id,type){
	var qty = promptBox("##NG_INSERT_BARCODE_QUANTITY##");
	if(qty !==null){
		if(qty > 0){
			window.open('print_barcode.php?module='+module_name+'&id='+id+'&qty='+qty+'&type='+type,html_entity_decode('##NG_BARCODES##'),'status=0,toolbar=0,location=0,scrollbar=1,menubar=0,directories=0,height=500,width=750',false);
		} else {
			msgBox("##NG_QUANTITY_LESS_THAN_ONE##");
		}
	}
}

function orderList(orderBy){
	if(order == orderBy){
		reverseTable();
		order = orderBy + '_d';
		$$('#search_result_head th').setStyle('background-image','none');
		$('th_'+orderBy).setStyles({
			'background-image':'url(##IMG_ORDER_DESCENDING##)',
			'background-position':'95% center',
			'background-repeat':'no-repeat'
		});
		return true;
	} else if (order == orderBy + '_d') {
		reverseTable();
		order = orderBy;
		$$('#search_result_head th').setStyle('background-image','none');
		$('th_'+orderBy).setStyles({
			'background-image':'url(##IMG_ORDER_ASCENDING##)',
			'background-position':'95% center',
			'background-repeat':'no-repeat'
		});
		return true;
	}
	var myHash = [];
	var count = 0;
	var rows = $$('#search_result_body tr');
	rows.each(function(el){
		var tds = el.getElements('td');
		myHash.push({ 'index':count, 'value':tds[orderBy].get('text') });
		count++;
	});

	myHash.sort(function(a,b) {
		if(typeof a['value'] == 'undefined'){
			return -1;
		} else if(typeof b['value'] == 'undefined'){
			return 1;
		} else {
			if(a['value'].toLowerCase() == b['value'].toLowerCase()){
				return 0;
			} else if(isNaN(a['value']) || isNaN(b['value'])){
				if (a['value'].toLowerCase() > b['value'].toLowerCase()) {
					return 1;
				} else {
					return -1;
				}
			} else {
				if (a['value'].toFloat() > b['value'].toFloat()) {
					return 1;
				} else {
					return -1;
				}
			}
		}
	});

	var newTableBody = new Element('tbody');

	for(var i=0,len=myHash.length; i<len; i++){
		var row = rows[myHash[i].index];
		newTableBody.adopt(row);
	}

	$('search_result_body').destroy();
	newTableBody.set('id','search_result_body').inject('search_result_table');
	order = orderBy;
	$$('#search_result_head th').setStyle('background-image','none');
	$('th_'+orderBy).setStyles({
		'background-image':'url(##IMG_ORDER_ASCENDING##)',
		'background-position':'95% center',
		'background-repeat':'no-repeat'
	});
	orderBy++;
	$$('#search_result_body td').each(function(e){ e.removeClass('ordered') });
	$$('#search_result_body td:nth-child('+orderBy+')').each(function(e){ e.addClass('ordered') });
}

function reverseTable(){
	var trs = $$('#search_result_body tr');
	var tBody = $('search_result_body');
	for(var i=1; i<trs.length; i++) {
		trs[i].inject(tBody,'first');
	}
}
