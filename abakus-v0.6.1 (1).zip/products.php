<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';
	include 'inc/class.upload_image.php';

	$module_name = 'products';
	// We load the module
	$module = loadModule($module_name,$db);
	$thispage = 'products.php';

	include 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$fields = $module->getFields('addform');

	$editing = false;
	if($_GET['id']){
		$item = $module->getElement($_GET['id']);
		$editing = true;
		$image = $db->fetch_item("SELECT i.* FROM products_to_images AS pti JOIN images AS i ON i.id=pti.id_image WHERE pti.id_product={$item['id']}");
	}

	$upload_image = new UploadImage($db,'product');

	if($_POST['save']){
		$_POST['internal_code'] = strtoupper($_POST['internal_code']);
		$input_array = $_POST;
		$data = array();
		foreach($fields as $k => $f){
			if(!$module->isFixedField($f['Field'])){
				$v = $input_array[$f['Field']];
				preg_match("/(\w+)\((\d+)\)/",$module->getFieldType($f['Field']),$matches);
				list($x,$type,$len) = $matches;
				switch(strtolower($type)){
					case 'tinyint':
					case 'smallint':
					case 'int':
					case 'mediumint':
					case 'bigint':
						if($len==1){
							$v = ($v?1:0);
						} else {
							$v = (int)$v;
						}
						break;
					default:
						$v = $module->db->escape_string($v);
				}
				$data[] = "`$k`='$v'";
			}
		}

		if(!empty($data)){
			$db = $module->db;
			if($editing){
				$product_id = $item['id'];
				$db->update("UPDATE products SET ".implode(',',$data)." WHERE id=$product_id");
			} else {
				$product_id = $db->insert("INSERT INTO products SET ".implode(',',$data));
			}

			if($db->errno()==1062){
				$errors[] = __("##NG_ERR_ARTICLE_DUPLICATE_ITEM##");
			} else {
				if($product_id) {
					$image_id = $upload_image->process_upload($_POST,$_FILES);
					if($upload_image->deleted){
						$db->delete("DELETE FROM products_to_images WHERE id_image=".$upload_image->deleted);
					}
					if($image_id){
						$db->insert("INSERT INTO products_to_images (id_product,id_image) VALUES ($product_id,$image_id)");
					}
					if(is_array($_POST['prices']) && !empty($_POST['prices'])){
						foreach($_POST['prices'] as $price_scale => $price){
							$price_scale = (int)$price_scale;
							$price = float($price);

							if($price_scale > 0 && $price > 0){
								$db->delete("DELETE FROM products_prices WHERE id_product=$product_id AND id_price_scale=$price_scale LIMIT 1");
								print $db->error();
								$db->insert("INSERT INTO products_prices (id_product,id_price_scale,price) VALUES ($product_id,$price_scale,'$price')");
								print $db->error();
							}
						}
					}
					if($_POST['next']=='new'){
						redirect('add.php?module=products');
					} elseif($_POST['next'] == 'closeLightbox'){
						$data = $module->getElement($id);
						$data['status'] = 'OK';
						$smarty->assign('data',$data);
						$smarty->display('closeLightbox.tpl');
						die();
					} else {
						return_to_module($module_name);
					}
				}
			}
		}
	}

	$price_scales = $db->fetch_all("
		SELECT *, ROUND('{$item['cost']}'*(1+percentage/100),2) AS suggested
		FROM price_scales ORDER BY id
	");

	if($editing){
		$prices = $db->fetch_all("SELECT * FROM products_prices WHERE id_product={$item['id']} ORDER BY id",'price','id_price_scale');
		$stock = $module->db->fetch_all("
			SELECT l.name AS location, SUM(ps.quantity) AS quantity
			FROM locations AS l
			LEFT JOIN products_stock AS ps
				ON ps.id_location=l.id
				AND ps.id_product={$item['id']}
			GROUP BY l.id
		");
	}

	$formatted_fields = array();
	if(is_array($fields) && !empty($fields)){
		foreach($fields as $f){
			if(!$module->isFixedField($f['Field']) && !$module->isHiddenField($f['Field'])) {
				$tmp['field'] =  $f['Field'];
				$tmp['name'] = beautifyFieldName(__($f['Name']));
				$tmp['input'] = getFieldInput($module,$f['Field'],($_POST[$f['Field']]?$_POST[$f['Field']]:$item[$f['Field']]));
				$formatted_fields[] = $tmp;
			}
		}
	}

	$return_url = return_to_module_url($module_name);

	$taxes = $db->fetch_all("SELECT * FROM taxes ORDER BY id",'percentage','id');

	$smarty->assign('taxes', json_encode($taxes));
	$smarty->assign('fields',$formatted_fields);
	$smarty->assign('item',$item);
	$smarty->assign('upload_image',$upload_image);
	$smarty->assign('image',$image);
	$smarty->assign('price_scales',$price_scales);
	$smarty->assign('prices',$prices);
	$smarty->assign('stock',$stock);
	$smarty->assign('editing',$editing);
	$smarty->assign('errors',$errors);
	$smarty->assign('return_url',$return_url);

	$smarty->display('products.tpl');
?>
