<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'error.php';

	require 'inc/smarty.php';

	$return_url = 'index.php';
	$return_text = __('##NG_ACCEPT##');
	$return_img = __('##IMG_ACCEPT##');
	if(!empty($_GET['return_url'])){
		$return_url = urldecode($_GET['return_url']);
		$return_text = __('##NG_RETURN##');
		$return_img = __('##IMG_RETURN##');
	}

	$smarty->assign('return_text',$return_text);
	$smarty->assign('return_img',$return_img);
	$smarty->assign('return_url',$return_url);
	$smarty->assign('message',$_GET['message']);

	$smarty->display('error.tpl');
?>
