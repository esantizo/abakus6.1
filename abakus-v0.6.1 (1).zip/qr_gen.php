<?php
	include 'inc/config.php';
	include 'inc/BarcodeQR.php';

	$id = (int)$_GET['id'];

	if($id > 0){
		$qr = new BarcodeQR();

		$qr->url($website_root."/product_details.php?id=".$id);
		$size = (!$_GET['size']?100:$_GET['size']);

		$qr->draw($size);
	}
?>
