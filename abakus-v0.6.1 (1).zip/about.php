<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'about.php';

	require 'inc/smarty.php';

	if(is_readable('VERSION')){
		$version = trim(file_get_contents('VERSION'));
	}

	$lang = substr($smarty->language->getCurrentLanguage(),0,2);

	$smarty->assign('lang',$lang);
	$smarty->assign('version',$version);
	$smarty->display('about.tpl');
?>