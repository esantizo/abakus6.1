<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$id = (int)$_GET['id'];
	$thispage = "dispatch_note_edit.php?id=$id";

	$module_name = 'dispatch_notes';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	if((int)$_GET['id'] > 0){
		$dispatch_note = $db->fetch_item("
			SELECT q.*,
				u.name AS salesman_name
			FROM dispatch_notes AS q
			JOIN users AS u
				ON u.id=q.salesman
			WHERE q.id=$id
		");
		$dispatch_note_items = $db->fetch_all("SELECT * FROM dispatch_note_items WHERE id_dispatch_note={$dispatch_note['id']} ORDER BY id");
	}

	if(!$dispatch_note) die('error');

	if($_POST['save']){
    $number = (int)$_POST['number'];
    $date = date2db($_POST['date'],$date_format);
    $salesman = (int)$_POST['salesman'];
    $client = (int)$_POST['client'];
    $client_name = $db->escape_string($_POST['client_name']);
    $client_address = $db->escape_string($_POST['client_address']);
    $client_taxpayer_id = $db->escape_string($_POST['client_taxpayer_id']);
    $client_city = $db->escape_string($_POST['client_city']);
    $client_state = $db->escape_string($_POST['client_state']);
    $client_country = $db->escape_string($_POST['client_country']);
    $client_postcode = $db->escape_string($_POST['client_postcode']);
    $notes = $db->escape_string($_POST['notes']);

    // The invoice has items
    if(is_array($_POST['ref'])){
			$dispatch_note_id = $db->insert("
				UPDATE dispatch_notes SET
					number='$number',
					date='$date',
					salesman='$salesman',
					client_id='$client',
					client_name='$client_name',
					client_address='$client_address',
					client_taxpayer_id='$client_taxpayer_id',
					client_city='$client_city',
					client_state='$client_state',
					client_country='$client_country',
					client_postcode='$client_postcode',
					notes='$notes'
				WHERE id={$dispatch_note['id']}
			");
			$db->delete("DELETE FROM dispatch_note_items WHERE id_dispatch_note={$dispatch_note['id']}");
			foreach($_POST['ref'] as $k => $ref){
				$product_id = (int)$_POST['product_id'][$k];
				$ref = $db->escape_string($ref);
				$desc = $db->escape_string($_POST['desc'][$k]);
				$qty = $db->escape_string($_POST['qty'][$k]);
				$db->insert("
					INSERT INTO dispatch_note_items SET
						id_dispatch_note={$dispatch_note['id']},
						id_product=$product_id,
						reference='$ref',
						description='$desc',
						quantity='$qty'
				");
			}
			redirect("dispatch_note_details.php?id={$dispatch_note['id']}");

		}

		// The invoice doesn't have any item
		else {
		}
		//print_pre($_POST);
		die();
	}

	$client = $db->fetch_all("SELECT * FROM clients WHERE id='{$dispatch_note['client_id']}'");

	$smarty->assign('dispatch_note',$dispatch_note);
	$smarty->assign('dispatch_note_items',$dispatch_note_items);
	$smarty->assign('ignore_stock',($config['ignore_stock']?1:0));

	$smarty->display('dispatch_note_edit.tpl');
?>