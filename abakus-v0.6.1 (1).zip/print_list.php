<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = $_GET['module'];

	// We load the module
	$module = loadModule($module_name,$db);

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'read')) noPermissionsError();

	function canShowField($field, $pre, $arr){
		if(empty($arr)){
			return true;
		}
		return in_array($pre.'_'.$field,$arr);
	}

	//Save user preferences
	if(is_array($_POST['box_search_terms'])){
		$db->delete("DELETE FROM user_preferences WHERE id_user=".$user->getId()." AND module='$module_name' AND attribute LIKE 'box_search_terms_%'");
		foreach($_POST['box_search_terms'] as $i){
			$db->insert("INSERT INTO user_preferences SET id_user=".$user->getId().", module='$module_name', attribute='box_search_terms_{$i}', value='1'");
		}
		redirect($thispage);
	}

	if(is_array($_POST['box_table_fields'])){
		$db->delete("DELETE FROM user_preferences WHERE id_user=".$user->getId()." AND module='$module_name' AND attribute LIKE 'box_table_fields_%'");
		foreach($_POST['box_table_fields'] as $i){
			$db->insert("INSERT INTO user_preferences SET id_user=".$user->getId().", module='$module_name', attribute='box_table_fields_{$i}', value='1'");
		}
		redirect($thispage);
	}

	$box_search_terms = $db->fetch_all("SELECT * FROM user_preferences WHERE id_user=".$user->getId()." AND module='$module_name' AND attribute LIKE 'box_search_terms_%'",'attribute');
	$box_table_fields = $db->fetch_all("SELECT * FROM user_preferences WHERE id_user=".$user->getId()." AND module='$module_name' AND attribute LIKE 'box_table_fields_%'",'attribute');

	// We get the SQL Query for the search
	$sql = $module->getSearchQuery($_POST);

	// We instantiate the pager using the query. It will return a limited query.
	$link_template = $thispage.'&amp;page=__page__';

	if($user_preferences['paging_style']=='fixed'){
		$pager = new ImagePager($sql, $_GET['page'], $user_preferences['pager_max_per_page'], $link_template);

		// We generate the search result by executing the query;
		$module->search($pager->result());
	} else {
		$module->search($sql);
	}

	// We get the results for latter use
	$results = $module->getSearchResults();

	$fields = $module->getFields();

	// Presentation Layer
?>
	<div id="search_result">
		<h3 id="table_caption">Resultados de la b&uacute;squeda en <?php echo __($module->getItemName());?></h3>
		<div id="search_result_wrapper">
			<table id="search_result_table">
				<thead>
					<tr>
<?php	if(is_array($fields) && !empty($fields)) foreach($fields as $f) if(canShowField($f['Field'],'box_table_fields',$box_table_fields) && !$module->isHiddenField($f['Field'])) { ?>
					<th><?php echo beautifyFieldName($f['Name']); ?></th>
<?php	} ?>
					</tr>
				</thead>
				<tbody id="search_result_body">
<?php
		if(is_array($results) && !empty($results)) foreach($results as $r){
?>
					<tr rel="item_<?php echo $r['id'];?>">
<?php	if(is_array($fields) && !empty($fields)) foreach($fields as $f) if(canShowField($f['Field'],'box_table_fields',$box_table_fields) && !$module->isHiddenField($f['Field'])) { ?>
						<td><?php echo $r[$f['Name']];?></td>
<?php	} ?>
					</tr>
<?php
		}
?>
				</tbody>
			</table>
		</div>
	</div>
	<script type="text/javascript">
		//window.print();
		//window.close();
	</script>
<?php
//	include 'inc/inc_bottom.php';
?>