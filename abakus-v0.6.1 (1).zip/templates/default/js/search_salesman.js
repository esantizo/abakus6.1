var lightbox_salesmen;
var navigateSalesmen = false;

$(document).addEvent('domready',function(){
	if(!$('box_search_salesman')){
		new Element('div',{ 'id':'box_search_salesman', 'class':'lightbox search_box' })
			.adopt(new Element('div',{'class':'search_item_search_container'})
				.adopt(new Element('input',{ type:'text', id:'search_salesman_input', 'class':'search_items_input' }))
				.adopt(new Element('img',{ src:'##IMG_CLEAN##', width:20, height:20, alt:'X', 'class': 'search_items_clean_btn', events:{'click':function(){ $('search_salesman_input').value='';executeSalesmanSearch(); } } }))
				.adopt(new Element('input',{ type:'button', value:'Buscar', id:'search_salesman_btn' }))
			)
			.adopt(
				new Element('div',{ id:'search_salesman_response','class':'search_results_response' }).adopt(new Element('table',{ id:'salesmen_results_table','class': 'search_results_table'})
					.adopt(new Element('thead').adopt(new Element('tr')
						.adopt(new Element('th',{ text:'##Id##' }))
						.adopt(new Element('th',{ text:'##Name##' }))
						.adopt(new Element('th',{ text:'##Username##' }))
						.adopt(new Element('th',{ text:'##Email##' }))
						.adopt(new Element('th',{ text:'##Active##' }))
					))
					.adopt(new Element('tbody',{ id:'salesmen_results_table_body' }))
				)
			)
			.inject(document.body);
	}

	$('search_salesman_input').addEvent('focus',function(){
		$$('#salesmen_results_table_body tr').each(function(e){e.removeClass('selected');});
		current = null;
	});
	$('search_salesman_input').addEvent('keydown',function(ev){ if(ev.keyCode==13){ executeSalesmanSearch(); } });
	$('search_salesman_btn').addEvent('click',function(){executeSalesmanSearch();});

	if($('salesman')) setFocus('salesman');

	$(window).addEvent('keydown',searchSalesmanNavigationListener);
});

function openSearchSalesmanBox(){
	lightbox_salesmen = new Lightbox('box_search_salesman',{'onClose':function(){navigateSalesmen=false;current=null;}}).open();
	$('search_salesman_input').value=$('salesman').value;
	$('salesmen_results_table_body').empty();
	navigateSalesmen = true;
	current = null;
	executeSalesmanSearch();
}

function executeSalesmanSearch(){
	Request({
		'url':'ajax/search_salesman.php',
		'method':'post',
		'data':'q='+$('search_salesman_input').value,
		'onSuccess':function(response){
			$('salesmen_results_table_body').set('html',response);
			$$('#salesmen_results_table_body tr').each(function(tr){
				if(tr && tr.tagName=='TR'){
					tr.setStyle('cursor','pointer');
					tr.addEvent('click',function(){
						$('salesman').value = this.getElements('td')[0].innerHTML;
						lightbox_salesmen.close();
						searchSalesman($('salesman').value);
					});
				}
			});
			lightbox_salesmen.reposition();
		}
	});
	setFocus('search_salesman_input');
}

function searchSalesmanNavigationListener(ev){
	if(calculator && calculator.opened) return false;
	if(navigateSalesmen==true){
		$$('#salesmen_results_table_body tr').each(function(e){e.removeClass('selected');});
		if(ev.target==$('search_salesman_input')){
			if(ev.keyCode==40 || ev.keyCode==38){
				$('search_salesman_input').blur();
			}
		}
		if(ev.keyCode==40){
			if(current == null){
				current = $('salesmen_results_table_body').getFirst('tr');
			} else {
				current = nextItem(current,'TR');
				if(!current) current = $('salesmen_results_table_body').getFirst('tr');
			}
		} else if(ev.keyCode==38){
			if(current == null){
				current = $('salesmen_results_table_body').getLast('tr');
			} else {
				current = previousItem(current,'TR');
				if(!current) current = $('salesmen_results_table_body').getLast('tr');
			}
		} else if(ev.keyCode==13) {
			if(current){
				$('salesman').value = current.getElements('td')[0].innerHTML;
				lightbox_salesmen.close();
				searchSalesman($('salesman').value);
				navigateSalesmen = false;
				return false;
			}
		}
		if(current){
			current.addClass('selected');
			var curPos = current.getPosition();
				var contHeight = $('search_salesman_response').getPosition().height;
				var maxScroll = $('salesmen_results_table').getPosition().totalHeight - contHeight;
			var scroll = curPos.top + curPos.height - contHeight / 2;
			if(scroll < 0) scroll = 0;
			if(scroll > maxScroll) scroll = maxScroll;
				$('search_salesman_response').scrollTop = scroll;
			if(ev.preventDefault) ev.preventDefault();
			if(ev.preventBubble) ev.preventBubble();
			return false;
		}
	}
}
