<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';
	include 'inc/class.upload_image.php';

	$module_name = 'repairs_in';
	// We load the module
	$module = loadModule($module_name,$db);
	$thispage = 'repairs_in.php';

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$id_client = (int)$_GET['id_client'];

	$upload_image = new UploadImage($db,'repairs_in');

	$return = 'search';
	if($_GET['return']) $return = $_GET['return'];

	$redirect_url = "search.php?module=repairs_in";

	$categories = $db->fetch_all("SELECT * FROM categories ORDER BY name",'name','id');
	$repairs_statuses = $db->fetch_all("SELECT * FROM repairs_statuses ORDER BY name");

	if((int)$_GET['id']){
		$repair = $db->fetch_item("
			SELECT r.*,p.name AS provider
			FROM repairs_in AS r
			JOIN providers AS p
				ON p.id=r.id_client
			WHERE r.id=".(int)$_GET['id']
		);
		if($repair) $image = $db->fetch_item("SELECT * FROM images WHERE id={$repair['id_image']}");
	}

	if($_POST['save']){
		$id_provider = (int)$_POST['id_provider'];
		$date = $db->escape_string($_POST['date']);
		$id_category = (int)$_POST['id_category'];
		$item = $db->escape_string($_POST['item']);
		$expected_behaviour = $db->escape_string($_POST['expected_behaviour']);
		$obtained_behaviour = $db->escape_string($_POST['obtained_behaviour']);
		$steps_to_reproduce = $db->escape_string($_POST['steps_to_reproduce']);
		$estimated_notice_date = fecha($_POST['estimated_notice_date']);
		$notice_date = $db->escape_string($_POST['notice_date']);
		$found_failures = $db->escape_string($_POST['found_failures']);
		$repair_value = float($_POST['repair_value']);
		$delivery_date = $db->escape_string($_POST['delivery_date']);
		$id_status = (int)$_POST['id_status'];

		if($repair){
			$fields = "
				id_provider=$id_provider,
				date='$date',
				id_category=$id_category,
				item='$item',
				expected_behaviour='$expected_behaviour',
				obtained_behaviour='$obtained_behaviour',
				steps_to_reproduce='$steps_to_reproduce',
				estimated_notice_date='$estimated_notice_date',
				notice_date='$notice_date',
				found_failures='$found_failures',
				repair_value='$repair_value',
				delivery_date='$delivery_date',
				id_status=$id_status,
				id_image=NULL
			";
			$db->update("UPDATE repairs_in SET $fields WHERE id={$repair['id']}");
			$repair_id = $repair['id'];
		} else {
			$fields = "
				id_provider=$id_provider,
				date='$date',
				id_category=$id_category,
				item='$item',
				expected_behaviour='$expected_behaviour',
				obtained_behaviour='$obtained_behaviour',
				steps_to_reproduce='$steps_to_reproduce',
				estimated_notice_date='$estimated_notice_date',
				id_image=NULL
			";
			$repair_id = $db->insert("INSERT INTO repairs_in SET $fields");
		}

		$image_id = $upload_image->process_upload($_POST,$_FILES);
		if($upload_image->deleted) $db->delete("UPDATE repairs_in SET id_image=0 WHERE id=$repair_id");
		if($image_id) $db->insert("UPDATE repairs_in SET id_image=$image_id WHERE id=$repair_id");

		if($_POST['next']=='new'){
			redirect("repairs_in.php?return=$return");
		} else {
			redirect($redirect_url);
		}
	}

	$form_action = "$thispage?return=$return";

	if($repair) $form_action.="&amp;id={$repair['id']}";

	$smarty->assign('form_action',$form_action);
	$smarty->assign('repair',$repair);
	$smarty->assign('categories',$categories);
	$smarty->assign('repairs_statuses',$repairs_statuses);
	$smarty->assign('upload_image',$upload_image);
	$smarty->assign('image',$image);
	$smarty->assign('redirect_url',$redirect_url);

	$smarty->display('repairs_in.tpl');
?>
