<?php
	include 'inc/config.php';

	$thispage = "configuration.php";
	if(!$_GET['section']) $_GET['section'] = 'general_data';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($thispage),'write')) noPermissionsError();

	$products_fields = $db->fetch_all("SHOW COLUMNS FROM products",false,'Field');
	$products_fixed_fields = array('id','name','price');
	foreach($products_fields as $key => $f){
		if(in_array($f['Field'],$products_fixed_fields)){
			$products_fields[$key]['fixed'] = true;
		} else {
			$products_fields[$key]['fixed'] = false;
		}
		$products_fields[$key]['field'] = $f['Field'];
		$products_fields[$key]['type'] = $f['Type'];
	}

	$providers_fields = $db->fetch_all("SHOW COLUMNS FROM providers",false,'Field');
	$providers_fixed_fields = array('id','name');
	foreach($providers_fields as $key => $f){
		if(in_array($f['Field'],$providers_fixed_fields)){
			$providers_fields[$key]['fixed'] = true;
		} else {
			$providers_fields[$key]['fixed'] = false;
		}
		$providers_fields[$key]['field'] = $f['Field'];
		$providers_fields[$key]['type'] = $f['Type'];
	}

	$clients_fields = $db->fetch_all("SHOW COLUMNS FROM clients",false,'Field');
	$clients_fixed_fields = array('id','name');
	foreach($clients_fields as $key => $f){
		if(in_array($f['Field'],$clients_fixed_fields)){
			$clients_fields[$key]['fixed'] = true;
		} else {
			$clients_fields[$key]['fixed'] = false;
		}
		$clients_fields[$key]['field'] = $f['Field'];
		$clients_fields[$key]['type'] = $f['Type'];
	}

	switch($_GET['section']){
		case 'products_fields':
			$table = 'products';
			break;
		case 'providers_fields':
			$table = 'providers';
			break;
		case 'clients_fields':
			$table = 'clients';
			break;
	}

	$company = $db->fetch_all("SELECT * FROM config WHERE name LIKE 'company_%'",'value','name');

	$print_templates = $db->fetch_all("SELECT * FROM print_templates",'name','id');

	if($_GET['section']=='general_data' && $_POST['save']){
		$fields = array('company_name','company_taxpayer_id','company_gross_income_tax_id','company_actstart','company_address','company_phone','company_zip','company_city','company_state','company_country','company_web','company_tax_condition');

		if($_POST['delete_logo'] && is_file('uploads/images/company_logo.jpg')){
			unlink('uploads/images/company_logo.jpg');
			$_POST['company_logo'] = '';
			array_push($fields,'company_logo');
		}

		if(is_uploaded_file($_FILES['company_logo_filename']['tmp_name'])){
			include 'inc/class.image.php';
			$image = new Image($_FILES['company_logo_filename']['tmp_name']);
			$image->resize(400,250,MODE_KEEP_AR);
			$image->save('uploads/images/company_logo.jpg');
			$_POST['company_logo'] = 'company_logo.jpg';
			array_push($fields,'company_logo');
		}

		foreach($fields as $f){
			$val = $db->escape_string($_POST[$f]);
			$sql = "INSERT INTO config (name,value) VALUES ('$f','$val') ON DUPLICATE KEY UPDATE value='$val'";
			$db->insert($sql);
		}

		redirect($thispage."?section=".$_GET['section']);
	}

	elseif($_GET['section']=='general_config' && $_POST['save']){
		$fields = array('pack_js','ignore_stock','use_barcode','use_qrcode','serial_number_prefix','invoice_number_format','receipt_number_format','credit_note_number_format','invoice_search_field','barcodes_print_template','qrs_print_template','catalog_print_template','system_template');

		foreach($fields as $f){
			$val = $db->escape_string($_POST[$f]);
			$sql = "INSERT INTO config (name,value) VALUES ('$f','$val') ON DUPLICATE KEY UPDATE value='$val'";
			$db->insert($sql);
		}

		redirect($thispage."?section=".$_GET['section']);
	}

	// User clicked the "Save" button
	elseif($_POST['save'] && is_array($_POST['text']) && !empty($_POST['text']) && $table){
		foreach($_POST['text'] as $k => $v){
			switch($_POST['select'][$k]){
				case 'int':
					$sql = "ALTER TABLE $table ADD `$v` INT(11) NULL DEFAULT NULL";
					break;
				case 'string':
					$sql = "ALTER TABLE $table ADD `$v` VARCHAR(200) NULL DEFAULT NULL";
					break;
				case 'float':
					$sql = "ALTER TABLE $table ADD `$v` FLOAT(10,2) NULL DEFAULT NULL";
					break;
				case 'bool':
					$sql = "ALTER TABLE $table ADD `$v` INT(1) NOT NULL DEFAULT 0";
					break;
				case 'relation':
					//$sql = "ALTER TABLE $table ADD `$v` FLOAT(10,2) NULL DEFAULT NULL";
					break;
			}
			$db->query($sql);
		}
		redirect($thispage."?section=".$_GET['section']);
	}

	// User clicked the "Delete" button
	elseif($_POST['delete'] && $table){
		if(is_array($_POST['del']) && !empty($_POST['del'])){
			foreach($_POST['del'] as $v){
				if(!in_array($v,$products_fixed_fields)) $db->query("ALTER TABLE $table DROP `$v`");
			}
		}
		redirect($thispage."?section=".$_GET['section']);
	}

	$files = scandir('templates/');
	foreach($files as $f){
		if(substr($f,0,1)!='.'){
			$system_templates[] = $f;
		}
	}

	$smarty->assign('company',$company);
	$smarty->assign('section',$_GET['section']);
	$smarty->assign('system_templates',$system_templates);
	$smarty->assign('print_templates',$print_templates);
	$smarty->assign('products_fields',$products_fields);
	$smarty->assign('providers_fields',$providers_fields);
	$smarty->assign('clients_fields',$clients_fields);
	$smarty->display('configuration.tpl');
?>
