<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'account.php';
	$module_name = 'payments';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	if($_REQUEST['id_client']) {
		$client = $db->fetch_item("SELECT * FROM clients WHERE id=".(int)$_GET['id_client']);
		if($client_currency = $client['credit_limit_currency']){
			$symbol = $db->fetch_item_field("SELECT symbol FROM currency WHERE id={$client_currency} LIMIT 1");
		}
	}
	if(!$client) die(__("##NG_INVALID_CLIENT##"));

	if(!$client_currency){
		$foo = $db->fetch_item("SELECT id,symbol FROM currency ORDER BY `default` DESC,id LIMIT 1");
		$client_currency = $foo['id'];
		$symbol = $foo['symbol'];
	}

	$filter = ($_GET['filter']?1:0);

	if($_REQUEST['regenerate'] && $client){
		$id_client = $client['id'];
		$items = $db->fetch_all("
			(
				SELECT 'invoice' AS type, id AS id_item, insert_date AS date, due_date, number AS reference, id_currency, total AS value, currencies
				FROM invoices
				WHERE client_id={$client['id']}
				AND pending=0
			)
			UNION
			(
				SELECT 'receipt' AS type, id AS id_item, date, NULL AS due_date, number AS reference, receipt_currency AS id_currency, total AS value, currencies
				FROM receipts
				WHERE id_client={$client['id']}
			)
			ORDER BY `date`,type,id_item
		");

		$balance = 0;
		$db->delete("DELETE FROM accounts WHERE id_client={$client['id']}");
		if(is_array($items)) foreach($items as $i){
			$credit = 0;
			$debit = 0;
			$currencies = parseCurrencies($i['currencies']);
			$client_rate = $currencies[$client_currency];
			$receipt_rate = $currencies[$i['id_currency']];

			switch($i['type']){
				case 'invoice':
					$credit = round(-1 * ($i['value'] * $receipt_rate / $client_rate),4);
					$debit = 0;
					break;
				case 'receipt':
					$credit = 0;
					$debit = round($i['value'] * $receipt_rate / $client_rate,4);
					break;
			}
			$balance += $credit+$debit;

			if(!$i['due_date']){
				$i['due_date'] = "NULL";
			} else {
				$i['due_date'] = "'{$i['due_date']}'";
			}
			if($credit || $debit) $db->insert("INSERT INTO accounts SET
				id_client={$client['id']},
				type='{$i['type']}',
				id_item='{$i['id_item']}',
				`date`='{$i['date']}',
				due_date={$i['due_date']},
				reference='{$i['reference']}',
				id_currency='{$i['id_currency']}',
				credit='$credit',
				debit='$debit',
				balance='$balance',
				currencies='{$i['currencies']}'
			");
		}
		redirect("account.php?id_client={$client['id']}");
	}

	if(!$filter){
		$account = $db->fetch_all("SELECT * FROM accounts WHERE id_client={$client['id']} ORDER BY date,id");
	} else {
		$from_date = getDbDate($_GET['from_month'],$_GET['from_day'],$_GET['from_year']);
		$to_date = getDbDate($_GET['to_month'],$_GET['to_day']+1,$_GET['to_year']);
		$account = $db->fetch_all("
			SELECT *
			FROM accounts
			WHERE id_client={$client['id']}
				AND date >= '$from_date'
				AND date < '$to_date'
			ORDER BY date,id
		");
	}

	$movements = array();
	if(is_array($account) && !empty($account)){
		if(is_array($account)) foreach($account as $movement){
			if($movement['reference']){
				$reference = str_pad($movement['reference'],10,'0',STR_PAD_LEFT);
			} else {
				$reference = '';
			}
			$movement['credit'] = str_replace('-','',$movement['credit']);
			switch($movement['type']){
				case 'invoice':
					if($reference){
						$reference = sprintf($config['invoice_number_format'],$reference);
					} else {
						$reference = 'No Number';
					}
					$ref_url = "invoice_details.php?id={$movement['id_item']}&amp;return=account";
					break;
				case 'receipt':
					if($reference){
						$reference = sprintf($config['receipt_number_format'],$reference);
					} else {
						$reference = 'No Number';
					}
					$ref_url = "receipt_details.php?id={$movement['id_item']}&amp;return=account";
					//$ref_url = "javascript: payments.php?id={$movement['id_item']}";
					break;
			}
			$tmp['date'] = fecha($movement['date']);
			$tmp['type'] = __($movement['type']);
			$tmp['ref_url'] = $ref_url;
			$tmp['reference'] = $reference;
			$tmp['due_date'] = ($movement['due_date']?fecha($movement['due_date']):'');
			$tmp['credit'] = ($movement['credit']!=0?$symbol.' '.$movement['credit']:'');
			$tmp['debit'] = ($movement['debit']!=0?$symbol.' '.$movement['debit']:'');
			$tmp['balance'] = $symbol.' '.$movement['balance'];
			$movements[] = $tmp;
		}
	}

	if($filter){
		$dates['from_day'] = $_GET['from_day'];
		$dates['from_month'] = $_GET['from_month'];
		$dates['from_year'] = $_GET['from_year'];
		$dates['to_day'] = $_GET['to_day'];
		$dates['to_month'] = $_GET['to_month'];
		$dates['to_year'] = $_GET['to_year'];
	} else {
		$dates['from_day'] = date('d');
		$dates['from_month'] = date('m');
		$dates['from_year'] = date('Y');
		$dates['to_day'] = date('d');
		$dates['to_month'] = date('m');
		$dates['to_year'] = date('Y');
	}

	$smarty->assign('dates',$dates);
	$smarty->assign('client',$client);
	$smarty->assign('movements',$movements);
	$smarty->display('account.tpl');
?>
