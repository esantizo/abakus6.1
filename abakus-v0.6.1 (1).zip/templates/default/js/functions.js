function parseJSON(str){
	return eval('('+str+')');
}

function nextItem(item, nodeName) {
	if (item == null) return;
	var next = item.nextSibling;
	while (next != null) {
		if (next.nodeName.toLowerCase() == nodeName.toLowerCase()) return next;
		next = next.nextSibling;
	}
	return null;
}

function previousItem(item, nodeName) {
	var previous = item.previousSibling;
	while (previous != null) {
		if (previous.nodeName.toLowerCase() == nodeName.toLowerCase()) return previous;
		previous = previous.previousSibling;
	}
	return null;
}

function moveBefore(item1, item2) {
	var parent = item1.parentNode;
	parent.removeChild(item1);
	parent.insertBefore(item1,item2);
}

function findPos(obj) {
	var curleft = curtop = 0;
	if (obj.offsetParent) {
		do {
				curleft += obj.offsetLeft;
				curtop += obj.offsetTop;
		} while (obj = obj.offsetParent);
	}
	return {x:curleft,y:curtop};
}

function nextInput(el){
	if(typeof el == 'undefined'){
		el = $(document).getFirst('form');
	}
	el = $(el);

	if(!el) return;

	if(el.get('tag').toLowerCase() == 'form'){
		return el.getFirst('input,select,textarea');
	}

	var parent = el.getParent('form');
	if(!parent) parent = el.getParent();
	var flag = 0;
	var els = parent.getElements('input[type=text],input[type=password],input[type=submit],input[type=radio],input[type=checkbox],input[type=button],select,textarea');
	for(var i=0,len=els.length; i<len; i++){
		var e = els[i];
		if(e==el){
			flag = 1;
		} else if(flag == 1){
			return e;
		}
	};
}

function round(val){
	var tmp = (parseInt(val * 100,10)/100);
	return tmp;
}

function typeOf(obj) {
	if ( typeof(obj) == 'object' ) {
		if (obj.length)
			return 'array';
		else
			return 'object';
  } else
		return typeof(obj);
}

function msgBox(message){
	alert(html_entity_decode(message));
}

function confirmBox(message){
	return confirm(html_entity_decode(message));
}

function promptBox(message,defval){
	return prompt(html_entity_decode(message),html_entity_decode(defval));
}

String.prototype.html_entity_decode = function(){
	return html_entity_decode(this);
}

function html_entity_decode(str){
	if(typeof str=='undefined'){
		return '';
	}
	str = str.replace('&agrave;','\340').replace('&Agrave;','\300');
	str = str.replace('&aacute;','\341').replace('&Aacute;','\301');
	str = str.replace('&acirc;','\342').replace('&Acirc;','\302');
	str = str.replace('&atilde;','\343').replace('&Atilde;','\303');
	str = str.replace('&auml;','\344').replace('&Auml;','\304');
	str = str.replace('&aring;','\345').replace('&Aring;','\305');

	str = str.replace('&egrave;','\350').replace('&Egrave;','\310');
	str = str.replace('&eacute;','\351').replace('&Eacute;','\311');
	str = str.replace('&ecirc;','\352').replace('&Ecirc;','\312');
	str = str.replace('&euml;','\353').replace('&Euml;','\313');

	str = str.replace('&igrave;','\354').replace('&Igrave;','\314');
	str = str.replace('&iacute;','\355').replace('&Iacute;','\315');
	str = str.replace('&icirc;','\356').replace('&Icirc;','\316');
	str = str.replace('&iuml;','\357').replace('&Iuml;','\317');

	str = str.replace('&ograve;','\362').replace('&Ograve;','\322');
	str = str.replace('&oacute;','\363').replace('&Oacute;','\323');
	str = str.replace('&ocirc;','\364').replace('&Ocirc;','\324');
	str = str.replace('&otilde;','\365').replace('&Otilde;','\325');
	str = str.replace('&ouml;','\366').replace('&Ouml;','\326');

	str = str.replace('&ugrave;','\371').replace('&Ugrave;','\331');
	str = str.replace('&uacute;','\372').replace('&Uacute;','\332');
	str = str.replace('&ucirc;','\373').replace('&Ucirc;','\333');
	str = str.replace('&uuml;','\374').replace('&Uuml;','\334');

	str = str.replace('&ntilde;','\361').replace('&Ntilde;','\321');
	str = str.replace('&lt;','\74').replace('&gt;','\76').replace('&nbsp;','\240');
	str = str.replace('&iquest;','\277').replace('&iexcl;','\241');
	str = str.replace('&raquo;','\273').replace('&laquo;','\253');
	str = str.replace('&ordf;','\252').replace('&ordm;','\272');
	str = str.replace('&bull;','\2219').replace('&hellip;','\u2026');
	return str;
}

function keyCodeIsNumber(val){
	return ([48,49,50,51,52,53,54,55,56,57,96,97,98,99,100,101,102,103,104,105].indexOf(val)!==-1);
}

function keyCodeIsNavigation(val){
	return ([8,9,16,17,18,33,34,35,36,37,39,45,46].indexOf(val)!==-1);
}

function nicetime(date){
	 if(date == ''){
		return "Fecha no especificada";
	 }
	 var periods = ["segundo", "minuto", "hora", "d&iacute;a", "semana", "mes", "a&ntilde;o", "d&eacute;cada"];
	 var lengths = ["60","60","24","7","4.35","12","10"];

	 var nowDate = new Date;
	 now = (nowDate.getTime() / 1000).round();
	 if(!isNaN(date)){
		var unix_date = date;
	 }
	 if(unix_date == '') {
		return "Fecha incorrecta";
	 }
	 if(now >= unix_date) {
		var difference = now - unix_date;
		var tense = "Hace ";
	 }else{
		var difference = unix_date - now;
		var tense = "Dentro de ";
	 }
	 for(var j=0; difference >= lengths[j] && j< lengths.length-1; j++) {
		difference /= lengths[j];
	 }
	 difference = difference.round();
	 if(difference != 1) {
		periods[j] += (periods[j]!='mes'?'s':'es');
	 }
	 return tense+' '+difference+' '+periods[j]+' ';
}

function disableInputs(inputs){
	$(inputs).each(function(el){
		$(document).getElements(el).each(function(e){
			e.disabled = true;
			e.addClass('disabled');
		});
	});
}

function enableInputs(inputs){
	$(inputs).each(function(el){
		$(document).getElements(el).each(function(e){
			e.disabled = false;
			e.removeClass('disabled');
		});
	});
}

function previewItem(module_name,id){
	var navigation = true;
	if(typeof current == 'undefined'){
		var current = null;
		navigation = false;
	}
	if(!$('box_item_info')){
		var newContainer = new Element('div',{
			'id':'box_item_info',
			'class':'lightbox'
		})
		.adopt(
			new Element('div',{ 'id':'box_item_info_contents' })
		);

		if(navigation){
			newContainer.adopt(
				new Element('div',{ 'id':'box_item_info_arrows' })
					.adopt(new Element('img',{ src:'##IMG_NAVIGATION_LEFT##',alt:'prev','class':'box_item_info_prev',events:{ 'click':function(){ searchNavigationListener({ 'keyCode':38,'target':this }); } } }))
					.adopt(new Element('div',{ 'id':'box_item_info_description' }))
					.adopt(new Element('img',{ src:'##IMG_NAVIGATION_RIGHT##',alt:'next','class':'box_item_info_next',events:{ 'click':function(){ searchNavigationListener({ 'keyCode':40,'target':this }); } } }))
			);
		}
		newContainer.inject($('full_body_wrapper'));
	}
	if(typeof previewLightbox == 'undefined' || !previewLightbox || !previewLightbox.opened)
		previewLightbox = new Lightbox('box_item_info').open();
	new Request({
		'method':'post',
		'url':'ajax/get_item.php',
		'data':'module='+module_name+'&item='+id,
		'onRequest': function(){
			$('box_item_info_contents').set('html','');
			$('box_item_info').setStyles({
				'background-image':'url(img/wait2.gif)',
				'background-position':' center center',
				'background-repeat':'no-repeat'
			});
			previewLightbox.reposition();
		},
		'onSuccess':function(res){
			$('box_item_info').setStyle('background-image','none');
			$('box_item_info_contents').set('html',res);
			if($('box_item_info_description') && current){
				$('box_item_info_description').set('text',current.getFirst('td').get('text'));
			}
			if($('box_item_info_controls')){
				var controls = $$('#box_item_info_controls a');
				if(controls.length > 7){
					$('box_item_info_controls').empty();
					var half = Math.floor(controls.length / 2);
					controls.each(function(el,i){
						$('box_item_info_controls').adopt(el);
						$('box_item_info_controls').adopt(new Element('text',' '));
						if(i==half){
							$('box_item_info_controls').adopt(new Element('br'));
						}
					});
				}
			}
			previewLightbox.reposition();
		}
	});
}
