if(typeof ask_price_change == 'undefined'){
	var ask_price_change = 0;
}

$(document).addEvent('domready',function(){

	$('pos_input').addEvent('keydown',posInputKeydown);

	$('client').addEvent('keydown',function(ev){
		if(ev.keyCode==13){
			if(this.value===0 || this.value==='0') {
				var price_scale_name = $('default_price_scale').get('alt');
				var price_scale_value = $('default_price_scale').value;

				$('client').set('rel',0);
				$('client_name_input').value='##NG_POS_GENERAL_CLIENT_NAME##';
				$('client_address_input').value='';
				$('client_city_input').value='';
				$('client_state_input').value='';
				$('client_country_input').value='';
				$('client_taxpayer_id_input').value='';
				$('client_tax_condition_input').value='';
				$('client_payment_type_input').value='';
				$('client_price_scale_input').value = price_scale_value;

				$('client_name').set('text','');
				$('client_address').set('text','');
				$('client_city').set('text','');
				$('client_state').set('text','');
				$('client_country').set('text','');
				$('client_taxpayer_id').set('text','');
				$('client_tax_condition').set('text','');
				$('client_payment_type').set('text','');
				$('client_price_scale').set('text',price_scale_name);

				$('client_name_input').set('type','text');
				$('client_address_input').set('type','text');
				$('client_city_input').set('type','text');
				$('client_state_input').set('type','text');
				$('client_country_input').set('type','text');
				$('client_taxpayer_id_input').set('type','text');

				$('client_tax_condition_select').setStyle('display','inline');
				$('client_payment_type_select').setStyle('display','inline');

				$('client_tax_condition_input').set('name','');
				$('client_tax_condition_input').removeAttribute('data-printer-code');
				$('client_tax_condition_select').set('name','client_tax_condition');

				$('client_payment_type_input').set('name','');
				$('client_payment_type_select').set('name','client_payment_type');

				$('invoice_type').setSelected(default_invoice_type);
				updateInvoiceType();
				changeInvoiceType(discriminate_taxes);

				$('invoice_table').setStyle('display','block');

			} else if(!isNaN(this.value)){
				$('client_name_input').value='';
				$('client_address_input').value='';
				$('client_city_input').value='';
				$('client_state_input').value='';
				$('client_country_input').value='';
				$('client_taxpayer_id_input').value='';
				$('client_tax_condition_input').value='';
				$('client_payment_type_input').value='';
				$('client_price_scale_input').value = '';

				$('client_name').set('text','');
				$('client_address').set('text','');
				$('client_city').set('text','');
				$('client_state').set('text','');
				$('client_country').set('text','');
				$('client_taxpayer_id').set('text','');
				$('client_tax_condition').set('text','');
				$('client_payment_type').set('text','');
				$('client_price_scale').set('text','');

				$('client_name_input').set('type','hidden');
				$('client_address_input').set('type','hidden');
				$('client_city_input').set('type','hidden');
				$('client_state_input').set('type','hidden');
				$('client_country_input').set('type','hidden');
				$('client_taxpayer_id_input').set('type','hidden');
				$('client_tax_condition_select').setStyle('display','none');
				$('client_payment_type_select').setStyle('display','none');

				$('client_tax_condition_input').set('name','client_tax_condition');
				$('client_tax_condition_input').removeAttribute('data-printer-code');
				$('client_tax_condition_select').set('name','');

				$('client_payment_type_input').set('name','client_payment_type');
				$('client_payment_type_select').set('name','');

				$('invoice_table').setStyle('display','none');
				updateInvoiceType();
			}
			unlockPos();
		}
	});

	if($('invoice_type')){
		changeInvoiceType($('invoice_type').getSelected().get('data-separates-taxes'));
		$('invoice_type').addEvent('change',function(){changeInvoiceType($('invoice_type').getSelected().get('data-separates-taxes'))});
	}

	lockPos();

	cashLightbox = new Lightbox('box_cash',{ onClose: function(){ unlockPos(); setFocus('pos_input'); if(alreadyPayed) clearPosData();} });
	$('cashLightboxPayment').addEvents({
		'keydown': function(ev){
			if(ev.keyCode==13){
				$('box_cash').startWaiting();
				cashPayment(true);
				if(ev.preventDefault()) ev.preventDefault();
			}
		},
		'keyup':function(){
			var payment = this.value.toFloat() || 0;
			var total = $('invoice_total').value.toFloat();
			var change = total - payment;
			if(change > 0){
				change = 0;
			} else {
				change = -1 * change.round(2);
			}
			$('cashLightboxChange').set('text',change);
		}
	});
	$('accept_cash_btn').addEvent('click',function(ev){
		$('box_cash').startWaiting();
		cashPayment(true);
		if(ev.preventDefault()) ev.preventDefault();
	});
	$('cancel_cash_btn').addEvent('click',function(ev){
		cashLightbox.close();
		if(ev.preventDefault()) ev.preventDefault();
	});
	$('new_ticket_btn').addEvent('click',function(ev){
		cashLightbox.close();
		if(ev.preventDefault()) ev.preventDefault();
	});

	$(window).addEvent('keydown',searchNavigationListener);
	$(window).addEvent('keydown',keyboardListener);

	if(ticketOpened){
		if(saved_invoice.client_id > 0){
			openClient(saved_invoice.client_id);
		} else {
			setClientData(saved_invoice);
		}
		updateInvoiceType();
		changeInvoiceType(discriminate_taxes);
		lockClient();
		unlockPos();
		setInvoiceData(saved_invoice);
		if(saved_invoice_items) for(var i=0,len=saved_invoice_items.length; i<len; i++){
			var item = saved_invoice_items[i];
			addItemToList({
				'product_id': item.id_product,
				'reference': item.reference,
				'short_description': item.description,
				'quantity': item.quantity.toInt(),
				'tax': item.tax.toFloat(),
				'unit_price': item.price.toFloat(),
				'unit_price_taxed': item.price.toFloat() * (1 + item.tax.toFloat() / 100)
			});
		}
		setFocus('pos_input');
	} else {
		setFocus('client');
	}
});
