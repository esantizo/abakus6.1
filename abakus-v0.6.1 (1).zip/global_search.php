<?php
	include 'inc/config.php';

	$q = $_REQUEST['q'];

	$thispage = "global_search.php?q=$q";

	require 'inc/smarty.php';

	if(!$user || !$user->isValid()) noPermissionsError();

	$search_in = array(
		'products' => array( 'name', 'internal_code', 'description', 'short_description' ),
		'contacts' => array( 'name', 'telephone', 'address' ),
		'clients' => array( 'name', 'phone', 'movil', 'address' )
	);

	foreach($search_in as $table => $fields){
		$where = array();
		foreach($fields as $f){
			$where[] = "`$f` LIKE '%$q%'";
		}
		$results[$table] = $db->fetch_all("SELECT * FROM $table WHERE ".join(' OR ',$where));
	}
/*
	$results['repairs'] = $db->fetch_all("
		SELECT r.*,c.name AS client,p.name AS product,cat.name AS category
		FROM repairs AS r
		JOIN clients AS c
			ON c.id=r.id_client
		JOIN products AS p
			ON p.id=r.id_product
		JOIN categories AS cat
			ON cat.id=p.id_category
		LEFT JOIN contacts AS con
			ON con.id=r.id_contact
		WHERE
			r.number LIKE '%$q%'
			OR r.serial_number LIKE '%$q%'
			OR r.delivery_address LIKE '%$q%'
			OR r.pickup_address LIKE '%$q%'
			OR c.name LIKE '%$q%'
			OR p.name LIKE '%$q%'
			OR con.name LIKE '%$q%'
		ORDER BY r.date ASC
	");
*/
	$smarty->assign('results',$results);
	$smarty->display('global_search.tpl');
?>
