<!DOCTYPE html>
<html>
	<head>
		<title>Abakus</title>
		<link type="image/x-icon" href="favicon.ico" rel="icon">
		<link type="image/x-icon" href="favicon.ico" rel="shortcut icon">
		<link type="text/css" rel="stylesheet" href="templates/default/css/main.css">
	</head>
	<body>
		<div id="full_body_wrapper">
			<content>
				<div class="error">
					Su navegador no est&aacute; soportado.<br><br>
					Por favor utilice la versi&oacute;n m&aacute;s reciente de alguno de los siguientes navegadores:<br>
					<ul>
						<li><a href="https://www.google.com/chrome/">Chrome</a></li>
						<li><a href="http://www.mozilla.org/en-US/firefox/new/">Firefox</a></li>
						<li><a href="http://www.apple.com/es/safari/">Safari</a></li>
					</ul>
				</div>
			</content>
		</div>
	</body>
</html>