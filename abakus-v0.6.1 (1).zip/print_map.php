<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';
	include 'inc/class.upload_image.php';

	$module_name = 'repairs';
	// We load the module
	$module = loadModule($module_name,$db);
	$thispage = 'repairs_delivery_assignation.php';

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$uid = (int)$_REQUEST['deliveryman_id'];

	$jobs = $db->fetch_all("
		SELECT r.*,p.name AS product_name
		FROM repairs AS r
		JOIN products AS p
			ON p.id=r.id_product
		JOIN repairs_delivery_assignations AS ra
			ON ra.id_repair=r.id
		WHERE ra.id_deliveryman=$uid
		ORDER BY ra.`order`ASC
	");

	$smarty->assign('iframe',1);
	$smarty->assign('jobs',$jobs);

	$smarty->display('print_map.tpl');
?>
