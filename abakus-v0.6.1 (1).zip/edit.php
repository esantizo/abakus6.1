<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = $_GET['module'];
	$thispage = "edit.php?module=".$module_name;

	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$module->init('edit');

	$item = $module->getElement($_GET['id']);

	if($_POST['save']){
		$id = (int)$_POST['id'];
		if($id && $module->validate($_POST,$errors)){
			$module->updateElement($id,$_POST);
			return_to_module($module_name);
		} else {
			if(is_string($errors) && !empty($errors)){
				$errors[] = $errors;
			}
		}
	}

	$fields = $module->getFields();
	$fixed_fields = $module->getFixedFieldsNames();

	$formatted_fields = array();
	if(is_array($fields) && !empty($fields)) foreach($fields as $f) if(!$module->isHiddenField($f['Field'])) {
		$tmp['field'] = $f['Field'];
		$tmp['name'] = beautifyFieldName($f['Name']);
		if(!$module->isFixedField($f['Field'])){
			$tmp['input'] = getFieldInput($module,$f['Field'],($_POST[$f['Field']]?$_POST[$f['Field']]:$item[$f['Field']]));
		} else {
			$tmp['input'] = $item[$f['Field']];
		}
		$formatted_fields[] = $tmp;
	}

	$return_url = return_to_module_url($module_name);

	$smarty->assign('errors',$errors);
	$smarty->assign('fields',$formatted_fields);
	$smarty->assign('item',$item);
	$smarty->assign('return_url',$return_url);

	$smarty->display('edit.tpl');
?>