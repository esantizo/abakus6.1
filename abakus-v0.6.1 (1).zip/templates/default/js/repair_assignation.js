var items = {};
var quickdrop_elements = [];
var currentObject = null;
var preview_iframe = null;
var videoTimer = null;
var modified = false;
var repairs_ids = [];

var dragIcon = new Element('img',{ 'src': 'img/repairs.png' });

function selectItem(el){
	$$('.repair').each(function(e){
		e.setStyle('border','1px solid #ccc');
	});

	if(el){
		$(el).setStyle('border','1px solid #00f');

		$$('.user').each(function(e){ e.inject('users_pool'); });

		if(el.getParent('section').getData('users')){
			var users = el.getParent('section').getData('users').split(',');
			if(users.length && typeof users == 'object'){
				users.each(function(user_id){
					$('user_'+user_id).inject('users_container');
				});
			}
		} else {
			$$('#users_pool .user').each(function(el){
				el.inject('users_container');
			});
		}
	}
}

function userDropEvent(e){
	if (e.stopPropagation) e.stopPropagation(); // stops the browser from redirecting...why???
	var el = $(e.dataTransfer.getData('Text')); // Get the dragged element by its ID (saved in the 'Text' data of the transfer)

	var parent = $(e.target).getParent();
	parent.removeClass('over');
	var repair_id = el.get('id').split('_')[1];
	var user_id = parent.get('id').split('_')[1];
	new Request({
		'url':'ajax/repair_assignations.php',
		'method':'post',
		'data':{ 'user_id':user_id, 'repair_id':repair_id },
		'onSuccess': function(response){
			if(response=='ok'){
				var product_name = $('repair_'+repair_id).getFirst('.product_name').get('text');
				var insert_date = $('repair_'+repair_id).getFirst('.insert_date').get('text');
				var container = $('user_'+user_id).getFirst('.user_extended_info_jobs');
				var newItem = new Element('div',{ 'class':'pending_job', 'data-job-id':repair_id, 'html': insert_date + ': <strong>' + product_name + '</strong>', 'rel': repair_id })
					.adopt(new Element('text', ' - '))
					.adopt(new Element('a',{ 'href': 'repair_details.php?id='+repair_id+'&amp;return=repair_assignation.php', 'text': '##NG_VIEW_REPAIR##' }))
					.adopt(new Element('text', ' - '))
					.adopt(new Element('a',{ 'href': 'javascript:unassign('+user_id+','+repair_id+');', 'text': '##NG_UNASSIGN##' }));
				container.adopt(newItem);
				$('user_'+user_id).getFirst('.user_extended_info').slide.hide();

				var pending = $('user_'+user_id).getFirst('.user_pending_jobs');
				pending.set('text',pending.get('text').toInt()+1);

				var repair = $('repair_'+repair_id);
				new Tween(repair,{
					'property': 'opacity',
					'duration': 250,
					'easing': 'quadEaseOut',
					'onEnd': function(){
						repair.destroy();
					}
				}).start(1,0);
			}
		}
	});
};

function unassign(user_id,job_id){
	new Request({
		'url':'ajax/repair_assignations.php',
		'method':'post',
		'data':{ 'user_id':user_id, 'repair_id':job_id, 'action':'unassign' },
		'onSuccess': function(response){
			if(response=='ok'){
				location.href='repair_assignation.php';
			}
		}
	});
}


$$('#repairs_container .repair').addEvents({
	'dragstart':function(ev) {
		var dt = ev.dataTransfer;

		dt.effectAllowed = 'move'; // only dropEffect='copy' will be dropable
		dt.setData('Text', this.get('id')); // required otherwise doesn't work
		dt.setDragImage(dragIcon, 0, 0);
		return false;
	},
	'mousedown':function(ev){ selectItem(this);	}
});

$$('#users_container .user_pending_jobs').addEvents({
	'dragenter': function(e){
		if (e.preventDefault) e.preventDefault(); /* allows us to drop */
		$(this).getParent().set('class','user over');
		return false;
	},
	'dragover': function(e) {
		$(this).getParent().set('class','user over');;
		if (e.preventDefault) e.preventDefault(); // allows us to drop
		e.dataTransfer.dropEffect = 'move';
		return false;
	},
	'dragleave': function(){ $(this).getParent().set('class','user'); },
	'drop': userDropEvent,
	'click': function(){
		var el = this.getParent().getFirst('.user_extended_info');
		if(el.slide.visible){
			el.slide.slideOut();
		} else {
			el.slide.slideIn();
		}
	}
});

$$('.user_extended_info_close').addEvent('click',function(){
	var el = this.getParent();
	el.slide.slideOut();
});

$$('.user_extended_info').each(function(e){
	e.slide = new Slide(e);
	e.slide.hide();
});

function resizeWrappers(){
	var footerHeight = $('full_body_wrapper').getFirst('footer').getPosition().totalHeight;
	var wrapperPos = $('repairs_container').getPosition(true);
	var errorsContainerHeight = $('errors_container').getPosition().height;
	var actionButtonsHeight = $('action_buttons').getPosition().height;

	height = (Math.max(window.innerHeight - wrapperPos.top - footerHeight - errorsContainerHeight - actionButtonsHeight - 30,100)).toInt();
	$('repairs_container').setStyles({
		'overflow':'auto',
		'height':height+'px'
	});
	var wrapperPos = $('users_container').getPosition(true);
	height = (Math.max(window.innerHeight - wrapperPos.top - footerHeight - errorsContainerHeight - actionButtonsHeight - 30,100)).toInt();
	$('users_container').setStyles({
		'overflow':'auto',
		'height':height+'px'
	});
	return;
}

function checkNewAssignations(){
	Request({
		'url': 'ajax/repair_assignations.php',
		'method':'post',
		'data':{ 'ids': JSON.stringify(repairs_ids), 'check': 1 },
		'onSuccess': function(response){
			if(response.toInt() > 0){
				$('new_repairs_container').setStyle('display','block');
				$('new_repairs').set('text',response);
			}
			setTimeout(checkNewAssignations,30000);
		}
	});
	return true;
}

setTimeout(checkNewAssignations,30000);

$(document).addEvent('domready',function(){
	$(window).addEvent('resize',resizeWrappers);
	resizeWrappers();
	$$('.repair').each(function(el){
		var id = el.get('id').split('_')[1].toInt();
		repairs_ids[repairs_ids.length] = id;
		var category = el.getData('category');
		el.inject('category_'+category);
		el.setStyle('display','inline-block');
	});
});
