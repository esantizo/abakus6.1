function cancel(){
	if(confirmBox('##NG_CANCEL_CONFIRMATION##')){
		location.href=return_url;
	}
}

function keyboardListener(ev){
	if(calculator && calculator.opened) return false;
	if(ev.keyCode==27){ // Esc key
		cancel();
	}
}

function setActiveState(id,state){
	$('item_'+id).startWaiting();
	new Request({
		method: 'post',
		url: 'ajax/menus.php',
		data: { 'action': 'change_active_state', 'menu_id': id, 'state': state },
		onSuccess: function(response){
			$('item_'+id).stopWaiting();
			var res;
			if(response) res = parseJSON(response);
			if(res && res.success){
				var link = $('item_'+id).getFirst('.menuitem_active_btn');
				var img = link.getFirst('img');
				if(res.state == 1){
					link.setData('state',1);
					img.set('src',img.getData('active-img'));
				} else {
					link.setData('state',0);
					img.set('src',img.getData('inactive-img'));
				}
			} else {
				alert("##NG_ERROR_SAVING_MENU_STATE##");
			}
		},
		onError: function(){
			$('item_'+id).stopWaiting();
			alert("##NG_ERROR_SAVING_MENU_STATE##");
		}
	});
}

$(document).addEvent('domready',function(){
	$$('.menuitem_active_btn').addEvent('click',function(ev){
		var id_parts = $(this).getParent('li').get('id').split('_');
		var id = id_parts[id_parts.length - 1];

		var new_state = ($(this).getData('state')==1?0:1);

		setActiveState(id, new_state);

		if(ev.preventDefault) ev.preventDefault();
		return false;
	})
});
