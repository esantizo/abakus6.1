var lightbox_providers;
var navigateProviders = false;

$(document).addEvent('domready',function(){
	if(!$('box_search_provider')){
		new Element('div',{ 'id':'box_search_provider', 'class':'lightbox search_box' })
			.adopt(new Element('div',{'class':'search_item_search_container'})
				.adopt(new Element('input',{ type:'text', id:'search_provider_input', 'class':'search_items_input' }))
				.adopt(new Element('img',{ src:'##IMG_CLEAN##', width:20, height:20, alt:'X', 'class': 'search_items_clean_btn', events:{'click':function(){ $('search_provider_input').value='';executeProviderSearch(); } } }))
				.adopt(new Element('input',{ type:'button', value:'Buscar', id:'search_provider_btn' }))
			)
			.adopt(
				new Element('div',{ id:'search_provider_response','class':'search_results_response' }).adopt(new Element('table',{ id:'providers_results_table','class': 'search_results_table'})
					.adopt(new Element('thead').adopt(new Element('tr')
						.adopt(new Element('th',{ text:'##Id##' }))
						.adopt(new Element('th',{ text:'##Name##' }))
						.adopt(new Element('th',{ text:'##Taxpayer Id##' }))
						.adopt(new Element('th',{ text:'##Address##' }))
						.adopt(new Element('th',{ text:'##City##' }))
						.adopt(new Element('th',{ text:'##Postcode##' }))
					))
					.adopt(new Element('tbody',{ id:'providers_results_table_body' }))
				)
			)
			.inject(document.body);
	}

	$('search_provider_input').addEvent('focus',function(){
		$$('#providers_results_table_body tr').each(function(e){e.removeClass('selected');});
		current_provider_popup = null;
	});
	$('search_provider_input').addEvent('keydown',function(ev){ if(ev.keyCode==13){ executeProviderSearch(); } });
	$('search_provider_btn').addEvent('click',function(){executeProviderSearch();});

	if($('provider_id')) $('provider_id').addEvent('keydown',function(ev){
		if(ev.keyCode==13){
			if(!isNaN(this.value)){
				if(this.value===''){
					openSearchProviderBox();
				} else {
					searchProvider(this.value);
				}
			} else {
				openSearchProviderBox();
			}
		}
	}).addEvent('blur',function(){
		if(!isNaN(this.get('rel')))
			this.value = this.get('rel');
	});

	$(window).addEvent('keydown',searchProviderNavigationListener);
});

function openSearchProviderBox(){
	lightbox_providers = new Lightbox('box_search_provider',{'onClose':function(){navigateProviders=false;current_provider_popup=null;}}).open();
	if($('provider_id')) $('search_provider_input').value=$('provider_id').value;
	$('providers_results_table_body').empty();
	navigateProviders = true;
	current_provider_popup = null;
	executeProviderSearch();
}

function executeProviderSearch(){
	Request({
		'url':'ajax/search_provider.php',
		'method':'post',
		'data':'q='+$('search_provider_input').value,
		'onRequest': function(){
			$('providers_results_table_body').startWaiting();
		},
		'onSuccess':function(response){
			$('providers_results_table_body').stopWaiting();
			$('providers_results_table_body').empty();
			var res = parseJSON(response);
			for(var i=0,len=res.length; i<len; i++){
				var it = res[i];
				new Element('tr',{
						styles: {
							'cursor': 'pointer'
						},
						events: {
							'click':function(){
								if($('provider_id')) $('provider_id').value = this.getFirst('td input').value;
								searchProvider(this.getFirst('td input').value, it);
								lightbox_providers.close();
							}
						}
					})
					.adopt(new Element('td',{ text: it.id }).adopt(new Element('input',{ 'type':'hidden','name':'return_field','value':it.id })))
					.adopt(new Element('td',{ text: it.name }))
					.adopt(new Element('td',{ text: it.taxpayer_id }))
					.adopt(new Element('td',{ text: it.address }))
					.adopt(new Element('td',{ text: it.city }))
					.adopt(new Element('td',{ text: it.postcode }))
					.inject('providers_results_table_body');
			}
			lightbox_providers.reposition();
		}
	});
	setFocus('search_provider_input');
}

function searchProviderNavigationListener(ev){
	if(calculator && calculator.opened) return false;
	if(navigateProviders==true){
		$$('#providers_results_table_body tr').each(function(e){e.removeClass('selected');});
		if(ev.target==$('search_provider_input')){
			if(ev.keyCode==40 || ev.keyCode==38){
				$('search_provider_input').blur();
			}
		}
		if(ev.keyCode==40){
			if(current_provider_popup == null){
				current_provider_popup = $('providers_results_table_body').getFirst('tr');
			} else {
				current_provider_popup = nextItem(current_provider_popup,'TR');
				if(!current_provider_popup) current_provider_popup = $('providers_results_table_body').getFirst('tr');
			}
		} else if(ev.keyCode==38){
			if(current_provider_popup == null){
				current_provider_popup = $('providers_results_table_body').getLast('tr');
			} else {
				current_provider_popup = previousItem(current_provider_popup,'TR');
				if(!current_provider_popup) current_provider_popup = $('providers_results_table_body').getLast('tr');
			}
		} else if(ev.keyCode==13) {
			if(current_provider_popup){
				if($('provider_id')) $('provider_id').value = current_provider_popup.getFirst('td input').value;
				searchProvider(current_provider_popup.getFirst('td input').value,current_provider_popup);
				lightbox_providers.close();
				navigateProviders = false;
				return false;
			}
		}
		if(current_provider_popup){
			current_provider_popup.addClass('selected');
			var curPos = current_provider_popup.getPosition();
				var contHeight = $('search_provider_response').getPosition().height;
				var maxScroll = $('providers_results_table').getPosition().totalHeight - contHeight;
			var scroll = curPos.top + curPos.height - contHeight / 2;
			if(scroll < 0) scroll = 0;
			if(scroll > maxScroll) scroll = maxScroll;
				$('search_provider_response').scrollTop = scroll;
			if(ev.preventDefault) ev.preventDefault();
			if(ev.preventBubble) ev.preventBubble();
			return false;
		}
	}
}

if(!(searchProvider && searchProvider.call)){
var searchProvider =	function(id){
		Request({
			'url':'ajax/search_provider.php',
			'method':'post',
			'data':'id='+id,
			'onSuccess':function(response){
				var res = eval('('+response+')');
				if(res.name){
					$('provider_id').value = id;
					$('provider_id').set('rel',id);
					if($('provider_name')) $('provider_name').set('text',res.name);
					if($('provider_checked')) $('provider_checked').value = 1;
					setFocus(nextInput('provider_id'));
				} else {
					msgBox("##NG_WRONG_PROVIDER##");
					$('provider_id').value = '';
					if($('provider_checked')) $('provider_checked').value = 0;
					setFocus('provider_id');
				}
			}
		});
	}
}
