<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$thispage = 'quotes.php';

	$module_name = 'quotes';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	if($_POST['save']){
		$number = (int)$_POST['number'];
		$date = date2db($_POST['date'],$date_format);
		$salesman = (int)$_POST['salesman'];
		$discriminate_taxes = ($_POST['discriminate_taxes']?1:0);
		$client = (int)$_POST['client'];
		$client_name = $db->escape_string($_POST['client_name']);
		$client_address = $db->escape_string($_POST['client_address']);
		$client_taxpayer_id = $db->escape_string($_POST['client_taxpayer_id']);
		$client_city = $db->escape_string($_POST['client_city']);
		$client_state = $db->escape_string($_POST['client_state']);
		$client_country = $db->escape_string($_POST['client_country']);
		$client_postcode = $db->escape_string($_POST['client_postcode']);
		$client_tax_condition = (int)$_POST['client_tax_condition'];
		$client_payment_type = (int)$_POST['client_payment_type'];
		$client_price_scale = (int)$_POST['client_price_scale'];
		$id_currency = (int)$_POST['currency'];
		if(is_array($_POST['currency_rates'])){
			$currencies = stringifyCurrencies($_POST['currency_rates']);
		}
		$subtotal = float($_POST['subtotal']);
		$taxes = stringifyTaxes($_POST['total_taxes']);
			$discount = float($_POST['discount']);
		$total = float($_POST['total']);
		$quote_duration = $db->escape_string($_POST['quote_duration']);
		$notes = $db->escape_string($_POST['notes']);

		// The invoice has items
		if(is_array($_POST['ref'])){
			$quote_id = $db->insert("
				INSERT INTO quotes SET
					discriminate_taxes=$discriminate_taxes,
					number='$number',
					`date`='$date',
					salesman='$salesman',
					client_id='$client',
					client_name='$client_name',
					client_address='$client_address',
					client_taxpayer_id='$client_taxpayer_id',
					client_city='$client_city',
					client_postcode='$client_postcode',
					client_state='$client_state',
					client_country='$client_country',
					id_tax_condition='$client_tax_condition',
					id_payment_type='$client_payment_type',
					id_price_scale='$client_price_scale',
					id_currency='$id_currency',
					currencies='$currencies',
					subtotal='$subtotal',
					taxes='$taxes',
					discount='$discount',
					total='$total',
					quote_duration='$quote_duration',
					notes='$notes'
			");
			if($quote_id){
				foreach($_POST['ref'] as $k => $ref){
					$product_id = (int)$_POST['product_id'][$k];
					$ref = $db->escape_string($ref);
					$desc = $db->escape_string($_POST['desc'][$k]);
					$qty = $db->escape_string($_POST['qty'][$k]);
					$price = $db->escape_string($_POST['price'][$k]);
					$tax = $db->escape_string($_POST['tax'][$k]);
					$item_total = $db->escape_string($_POST['item_total'][$k]);
					$db->insert("
						INSERT INTO quote_items SET
							id_quote=$quote_id,
							id_product=$product_id,
							reference='$ref',
							description='$desc',
							quantity='$qty',
							price='$price',
							tax='$tax',
							total='$item_total'
					");
				}

				redirect("quote_details.php?id=$quote_id");
			}

			// INSERT error
			else{
				//echo $db->error();
			}

		}

		// The invoice doesn't have any item
		else {
		}
	}

	$salesmen = $db->fetch_all("
		SELECT u.*, IF(u.id='{$user->getId()}','selected=\"selected\"','') AS selected
		FROM users AS u
		WHERE u.can_sell=1
			AND deleted=0
	");
	$invoice_number = max(1,$db->fetch_item_field("SELECT (MAX(number)+1) FROM quotes"));
	$tax_values = $db->fetch_all("SELECT percentage FROM taxes ORDER BY percentage",'percentage');
	$currency = $db->fetch_all("SELECT * FROM currency ORDER BY rate");

	$price_scale = $db->fetch_item("SELECT id,name FROM price_scales ORDER BY `default` DESC,id DESC LIMIT 1");
	$tax_conditions = $db->fetch_all("SELECT * FROM tax_conditions ORDER BY name");
	$payment_types = $db->fetch_all("SELECT * FROM payment_types ORDER BY name");

	switch($config['invoice_search_field']){
		case 'internal_code': $first_field = __("Internal Code"); break;
		case 'manufacturers_code': $first_field = __("Manufacturers Code"); break;
		default: $first_field = __("Reference");
	}

	$return_url = return_to_module_url($module_name);

	$smarty->assign('return_url',$return_url);
	$smarty->assign('tax_conditions',$tax_conditions);
	$smarty->assign('payment_types',$payment_types);
	$smarty->assign('invoice_number',$invoice_number);
	$smarty->assign('price_scale',$price_scale);
	$smarty->assign('currency',$currency);
	$smarty->assign('salesmen',$salesmen);
	$smarty->assign('first_field',$first_field);
	$smarty->assign('tax_values',implode(',',$tax_values));
	$smarty->assign('ignore_stock',($config['ignore_stock']?1:0));

	$smarty->display('quotes.tpl');
?>
