(function(){

window.Slide = function(obj,options){
	var self = this;
	var el = $(obj);
	this.visible = true;
	var defaultOptions = {
		'direction': 'down',
		'property':'margin-top'
	};

	var tween = new Tween(el,merge(defaultOptions,options));
	this.options = tween.options;

	var getHiddenPosition = function(){
		return -1 * el.measure().height;
	};

	var init = function(){
		var parent = el.getParent();
		var styles = {};
		styles.position = el.getStyle('position');
		styles.width = el.getStyle('width');
		styles.top = el.getStyle('top');
		styles.left = el.getStyle('left');
		styles.clear = el.getStyle('clear');
		styles.float = el.getStyle('float');
		styles.height = 'auto';
		styles.overflow = 'hidden';
		var newNode = new Element('div',{
			'styles': styles
		});
		parent.replaceChild(newNode,el);
		el.inject(newNode).setStyles({
			'position':'relative',
			'margin':0
		});
		return this;
	};

	this.pause = function(){
		tween.pause();
	};

	this.slideIn = function(){
		tween.options.onEnd = null;
		tween.start(getHiddenPosition(),0);
		self.visible = true;
		return this;
	};
	this.slideOut = function(){
		tween.options.onEnd = function(){
			el.setStyle('margin-top','-9999px');
		}
		tween.start(0,getHiddenPosition());
		self.visible = false;
		return this;
	};
	this.show = function(){
		tween.set(0);
		self.visible = true;
		return this;
	};
	this.hide = function(){
		tween.set('-9999px');
		self.visible = false;
		return this;
	};

	init();
}

})();
