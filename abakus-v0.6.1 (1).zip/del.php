<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$module_name = $_GET['module'];
	// We load the module
	$module = loadModule($module_name,$db);

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$item = $module->deleteElement($_GET['id']);
	if($_GET['return_url']){
		redirect(urldecode($_GET['return_url']));
	} else {
		return_to_module($module_name);
	}
?>