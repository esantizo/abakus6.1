<?php
	include 'inc/config.php';
	include 'inc/class.pager.php';

	$id = (int)$_GET['id'];
	$thispage = "credit_note_edit.php?id=$id";

	$module_name = 'credit_notes';
	// We load the module
	$module = loadModule($module_name,$db);

	require 'inc/smarty.php';

	if(!$user->isSuperadmin() && !$user->isAllowed(getModuleId($module_name),'write')) noPermissionsError();

	$sql = "
		SELECT i.*,
			u.name AS salesman_name,
			u.discount_limit AS salesman_discount_limit,
			tc.name AS tax_condition,
			pt.name AS payment_type,
			ps.name AS price_scale,
			c.symbol AS currency_symbol,
			c.name AS currency_name,
			IF(LENGTH(i.client_postcode)>0,CONCAT('(',i.client_postcode,') ',i.client_city),i.client_city) AS client_city,
			it.name AS invoice_type_name
		FROM credit_notes AS i
		LEFT JOIN users AS u
			ON u.id = i.salesman
		LEFT JOIN tax_conditions AS tc
			ON tc.id = i.id_tax_condition
		LEFT JOIN payment_types AS pt
			ON pt.id = i.id_payment_type
		LEFT JOIN price_scales AS ps
			ON ps.id = i.id_price_scale
		JOIN currency AS c
			ON c.id = i.id_currency
		JOIN invoice_types AS it
			ON it.id=i.invoice_type
		WHERE i.id = $id
	";
	$credit_note = $db->fetch_item($sql);

	if($credit_note){
		$credit_note_items = $db->fetch_all("
			SELECT *, IF(reference LIKE '0','&nbsp;',reference) AS reference, CONCAT('<span class=\"symbol\">{$credit_note['symbol']}</span> ',price) AS price,CONCAT('<span class=\"symbol\">{$credit_note['symbol']}</span> ',total) AS total
			FROM credit_note_items
			WHERE id_credit_note=$id
			ORDER BY id
		");
		//~ if(is_array($credit_note_items)) foreach($credit_note_items as $k => $ii){
			//~ $stock = $db->fetch_all("
				//~ SELECT CONCAT(l.id,';',SUM(s.quantity),';',l.name) AS data, l.name
				//~ FROM products_stock AS s
				//~ JOIN locations AS l
					//~ ON l.id=s.id_location
				//~ WHERE id_product={$ii['id_product']}
				//~ GROUP BY l.id
				//~ ORDER BY name
			//~ ",'data');
			//~ if(empty($stock)){
				//~ $stock = '';
			//~ } else {
				//~ $stock = implode('|',$stock);
			//~ }
			//~ $invoice_items[$k]['stock'] = $stock;
		//~ }
		if($credit_note['client_id'] > 0){
			$client = $db->fetch_item("
				SELECT c.*,c.credit_limit,c.credit_limit_interval,cur.symbol AS credit_limit_currency_symbol
				FROM clients AS c
				JOIN currency AS cur
					ON cur.id=c.credit_limit_currency
				WHERE c.id={$credit_note['client_id']}
				LIMIT 1
			");
			//~ if($client['credit_limit']){
				//~ $invoices = $db->fetch_all("SELECT SUM(total) AS total_sum,id_currency,currencies FROM invoices WHERE client_id={$client['id']} AND DATEDIFF(CURDATE(),`date`) <= '{$client['credit_limit_interval']}' GROUP BY client_id,id_currency");
				//~ if(is_array($invoices)){
					//~ $invoices_total = 0;
					//~ foreach($invoices as $i){
						//~ $currencies = parseCurrencies($i['currencies']);
						//~ if(is_array($currencies)){
							//~ $invoices_total += round($i['total_sum'] * $currencies[$i['id_currency']] / $currencies[$client['credit_limit_currency']],4);
						//~ }
					//~ }
					//~ $limite = $client['credit_limit'] - $invoices_total;
					//~ $client['credit_limit'] = $limite;
				//~ }
			//~ }
		}
	} else {
		$error = __("##NG_INCORRECT_CREDIT_NOTE_ID##");
	}

	if($_POST['save']){
		$pending = ($_POST['save']=='pending'?1:0);
		$number = (int)$_POST['number'];
		$invoice_type = (int)$_POST['invoice_type'];
		$date = date2db($_POST['date'],$date_format);
		$salesman = (int)$_POST['salesman'];
		$client = (int)$_POST['client'];
		$client_name = $db->escape_string($_POST['client_name']);
		$client_address = $db->escape_string($_POST['client_address']);
		$client_taxpayer_id = $db->escape_string($_POST['client_taxpayer_id']);
		$client_city = $db->escape_string($_POST['client_city']);
		$client_state = $db->escape_string($_POST['client_state']);
		$client_country = $db->escape_string($_POST['client_country']);
		$client_postcode = $db->escape_string($_POST['client_postcode']);
		$tax_condition = (int)$_POST['tax_condition'];
		$payment_type = (int)$_POST['payment_type'];
		$client_price_scale = (int)$_POST['client_price_scale'];
		$id_currency = (int)$_POST['currency'];
		if(is_array($_POST['currency_rates'])){
			$currencies = stringifyCurrencies($_POST['currency_rates']);
		}
		$subtotal = float($_POST['subtotal']);
		if(is_array($_POST['total_taxes'])){
			$taxes = stringifyTaxes($_POST['total_taxes']);
		}
		$total = float($_POST['total']);
		$discount = float($_POST['discount']);
		$pending = ($_POST['save']=='pending'?1:0);

		// The invoice has items
		if(is_array($_POST['ref'])){
			$db->update("
				UPDATE credit_notes SET
					number='$number',
					`date`='$date',
					invoice_type='$invoice_type',
					salesman='$salesman',
					client_id='$client',
					client_name='$client_name',
					client_address='$client_address',
					client_taxpayer_id='$client_taxpayer_id',
					client_city='$client_city',
					client_postcode='$client_postcode',
					client_state='$client_state',
					client_country='$client_country',
					id_tax_condition='$tax_condition',
					id_payment_type='$payment_type',
					id_price_scale='$client_price_scale',
					id_currency='$id_currency',
					currencies='$currencies',
					subtotal='$subtotal',
					taxes='$taxes',
					discount='$discount',
					total='$total',
					pending=$pending
				WHERE id={$credit_note['id']}
			");
			$db->delete("DELETE FROM credit_note_items WHERE id_credit_note={$credit_note['id']}");
			foreach($_POST['ref'] as $k => $ref){
				$product_id = (int)$_POST['product_id'][$k];
				$ref = $db->escape_string($ref);
				$desc = $db->escape_string($_POST['desc'][$k]);
				$qty = $db->escape_string($_POST['qty'][$k]);
				$price = $db->escape_string($_POST['price'][$k]);
				$tax = $db->escape_string($_POST['tax'][$k]);
				$item_total = $db->escape_string($_POST['item_total'][$k]);
				$selected_stock = $db->escape_string($_POST['sel_stock'][$k]);
				$db->insert("
					INSERT INTO credit_note_items SET
						id_credit_note={$credit_note['id']},
						id_product=$product_id,
						reference='$ref',
						description='$desc',
						quantity='$qty',
						selected_stock='$selected_stock',
						price='$price',
						tax='$tax',
						total='$item_total'
				");
				//~ if(!$pending){
					//~ $sel_stock = explode('|',$_POST['sel_stock'][$k]);
					//~ if(is_array($sel_stock)) foreach($sel_stock as $st){
						//~ list($id,$qty) = explode(';',$st);
						//~ if((int)$id > 0 && (int)$qty > 0){
							//~ $db->insert("INSERT INTO products_stock SET
								//~ id_product=$product_id,
								//~ id_location=".(int)$id.",
								//~ quantity=(".(int)$qty." * -1)
							//~ ");
						//~ }
					//~ }
				//~ }
			}
			redirect("credit_note_details.php?id={$credit_note['id']}");

		}

		// The invoice doesn't have any item
		else {
		}
	}

	$tax_values = $db->fetch_all("SELECT percentage FROM taxes ORDER BY percentage",'percentage');
	$currency = $db->fetch_all("SELECT * FROM currency ORDER BY rate");
	$invoice_currency = parseCurrencies($credit_note['currencies']);
	$invoice_types = $db->fetch_all("SELECT * FROM invoice_types ORDER BY name");

	if($client){
		$price_scale = $db->fetch_item("SELECT id,name FROM price_scales WHERE id={$client['id_price_scale']} LIMIT 1");
	}
	if(!$price_scale) {
		$price_scale = $db->fetch_item("SELECT id,name FROM price_scales ORDER BY `default` DESC,id DESC LIMIT 1");
	}

	$discount_p = round($credit_note['discount'] * 100 / ($credit_note['total']+$credit_note['discount']),4);

	switch($config['invoice_search_field']){
		case 'internal_code': $first_field = __("Internal Code"); break;
		case 'manufacturers_code': $first_field = __("Manufacturers Code"); break;
		default: $first_field = __("Reference");
	}

	$formatted_credit_note_items = array();
	if(is_array($credit_note_items)) foreach($credit_note_items as $k => $item){
		$tmp = $item;
		$tmp['price_str'] = float(preg_replace("/[^\d\.\,]/",' ',strip_tags($item['price'])));
		$tmp['total_str'] = float(preg_replace("/[^\d\.\,]/",' ',strip_tags($item['total'])));
		$formatted_credit_note_items[] = $tmp;
	}

	$return_url = return_to_module_url($module_name);

	$smarty->assign('return_url',$return_url);
	$smarty->assign('credit_note',$credit_note);
	$smarty->assign('invoice_types',$invoice_types);
	$smarty->assign('credit_note_items',$formatted_credit_note_items);
	$smarty->assign('currency',$currency);
	$smarty->assign('invoice_currency',$invoice_currency);
	$smarty->assign('discount',$discount_p);
	$smarty->assign('first_field',$first_field);
	$smarty->assign('tax_values',implode(',',$tax_values));
	$smarty->assign('ignore_stock',($config['ignore_stock']?1:0));

	$smarty->display('credit_note_edit.tpl');
?>
