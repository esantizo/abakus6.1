var order = null;
var calendar_lightbox;
var current_calendar = null;
if($('calendar')){
	var calendar = new Calendar('calendar',{
		'onDayClick': function(elem,data){
			if(current_calendar == 'from'){
				$('date_from').set('value',data.date+'/'+data.month+'/'+data.year);
				$('date_from_link').set('text',data.date+'/'+data.month+'/'+data.year);
			} else {
				$('date_to').set('value',data.date+'/'+data.month+'/'+data.year);
				$('date_to_link').set('text',data.date+'/'+data.month+'/'+data.year);
			}
			calendar_lightbox.close();
		}
	});
}

function calendarLoad(){
	if(current_calendar == 'from'){
		var date = $('date_from').get('value').split('/');//,data.date+'/'+data.month+'/'+data.year);
	} else {
		var date = $('date_to').get('value').split('/');
	}
	calendar.load(date[1],date[2],date[0]);
}

function filter(){
	var params = getURLParams() || {};
	params.date_from = $('date_from').get('value');
	params.date_to = $('date_to').get('value');
	location.href = thispage+'?'+ArrayToURL(params);
}

$(document).addEvent('domready',function(){
	if(paging_style=='scroll'){
		$(document.body).setStyle('overflow','hidden');
		$(window).addEvent('resize',function(){resizeResultsWrapper();});
		resizeResultsWrapper();
	} else {
		$(document.body).setStyle('overflow','auto');
	}

	var count = 0;
	$$('#search_result_head th').each(function(th){
		th
			.set({ 'id':'th_'+count, 'rel':count })
			.setStyles({ 'cursor':'pointer' })
			.addEvent('click',function(ev){
				orderList(this.get('rel'));
			});
		count++;
	});

	if($('date_from_link')) $('date_from_link').addEvent('click',function(ev){
		current_calendar = 'from';
		calendar_lightbox = new Lightbox('calendar_lightbox',{ onOpen: calendarLoad }).open();
		ev.preventDefault();
	});

	if($('date_to_link')) $('date_to_link').addEvent('click',function(ev){
		current_calendar = 'to';
		calendar_lightbox = new Lightbox('calendar_lightbox',{ onOpen: calendarLoad }).open();
		ev.preventDefault();
	});
});
